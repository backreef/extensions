import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DownloadOption,
} from "../../../../packages/plugin-sdk/src/index"
import {
    cacheOptions,
    clampLimit,
    createTorrentOption,
    extractInfoHashFromMagnet,
    extractResolution,
    extractSingleEpisode,
    fetchText,
    isLikelyBatchTitle,
    normalizeInfoHash,
    normalizeTitle,
    parseIsoDate,
    parseSize,
    resolveCachedOrFallback,
    resolveMediaContext,
    type MediaContext,
} from "../../torrent-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const PROVIDER_ID = "backreef.knaben:search"
const BASE_URL = "https://knaben.org"

const CAT_ANIME = "6000000"
const CAT_TV = "2000000"
const CAT_MOVIES = "3000000"
const CAT_ALL = "0"

const TECH_TOKEN_RE =
    /^(?:s\d{1,2}e\d{1,3}|s\d{1,2}|e\d{1,3}|ep\d{1,3}|\d{1,4}|\d{3,4}p|[248]k|web|webrip|webdl|hdtv|hdrip|dvdrip|bluray|blu|bdrip|bdr|bd|remux|x264|x265|h264|h265|hevc|avc|hdr|hdr10|dolby|vision|atmos|dts|truehd|aac|ac3|eac3|flac|multi|dual|dualaudio|sub|subs|subbed|dub|dubbed|eng|en|fr|french|esp|spa|ger|deu|ita|kor|jpn|jap|chi|pol|por|rus|tur|10bit|8bit|complete|collection|boxset|series|season|pack|batch|mini|miniseries|part|parts|vol|volume|final|full|remaster|restored|extended|uncut|edition|amzn|nf|dsnp|atvp|nyaa|subsplease|erai|judas|ryujin)$/i
const BOUNDARY_TOKEN_RE =
    /^(?:s\d{1,2}e\d{0,3}|s\d{1,2}|e\d{1,3}|ep\d{1,3}|season|series|complete|collection|pack|batch|volume|vol|boxset|(?:19|20)\d{2})$/i
const PART_WORD_RE =
    /^(?:one|two|three|four|five|six|seven|eight|nine|ten|first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|1st|2nd|3rd|[4-9]th|10th|ii|iii|iv|vi|vii|viii|ix)$/i
const NOISE_WORDS = new Set([
    "the",
    "a",
    "an",
    "of",
    "to",
    "in",
    "for",
    "on",
    "with",
    "at",
    "by",
    "from",
    "and",
    "or",
])

type ParsedRow = {
    name: string
    magnet: string
    infoHash: string
    size: number
    publishedAt?: string
    seeders: number
    leechers: number
    pageUrl: string
    resolution: string
    isBatch: boolean
    episode: number
    season: number
}

function splitSeasonMarker(title: string): { base: string; season: number } {
    const m = /\s*[—–-]\s*season\s+(\d{1,2})\s*$/i.exec(title)
    if (m) {
        return { base: title.slice(0, m.index).trim(), season: Number.parseInt(m[1], 10) }
    }
    const norm = normalizeTitle(title)
    if (norm.season > 0 && norm.cleanBaseTitle) {
        return { base: norm.cleanBaseTitle, season: norm.season }
    }
    return { base: title.trim(), season: 0 }
}

function seasonOfName(name: string): number {
    const m = /\bS(\d{1,2})E\d{1,3}\b/i.exec(name)
    return m ? Number.parseInt(m[1], 10) : 0
}

function hasEpisodeMarker(name: string): boolean {
    if (/\bS\d{1,2}E\d{1,3}\b/i.test(name)) return true
    if (/\b(?:Episode|EP)\s*#?\s*\d{1,3}\b/i.test(name)) return true
    if (/(?:^|[.\s\-_])E\d{1,3}(?:[.\s\-_]|$)/i.test(name)) return true
    return /(?:^|[\s\-_\[])(\d{1,3})(?:[\s\-_\].]|$)/.test(name) && /\b\d{3,4}p\b/i.test(name)
}

function buildAliasTokens(titles: string[]): Set<string> {
    const set = new Set<string>()
    for (const title of titles) {
        if (!title) continue
        const base = splitSeasonMarker(title).base
        for (const t of normalizeTitle(base).tokens) set.add(t)
        const dequoted = base.replace(/[''":]/g, "")
        if (dequoted !== base) {
            for (const t of normalizeTitle(dequoted).tokens) set.add(t)
        }
    }
    return set
}

function belongsToMedia(
    name: string,
    aliases: Set<string>,
    isMovie: boolean,
    expectedSeason: number,
    mediaYear: number,
): boolean {
    if (aliases.size === 0) return true
    const norm = normalizeTitle(name)
    const toks = norm.tokens
    const nameYear = norm.year

    if (isMovie) {
        if (hasEpisodeMarker(name)) return false
        const boundaryIdx = toks.findIndex((t) => /^(19|20)\d{2}$/.test(t) || TECH_TOKEN_RE.test(t))
        const stem = boundaryIdx === -1 ? toks : toks.slice(0, boundaryIdx)
        const foreign = stem.filter(
            (t) =>
                t.length > 1 &&
                !NOISE_WORDS.has(t) &&
                !aliases.has(t) &&
                !TECH_TOKEN_RE.test(t) &&
                !/^(19|20)\d{2}$/.test(t) &&
                !PART_WORD_RE.test(t),
        )
        if (foreign.length > 0) return false
        if (nameYear > 0 && mediaYear > 0 && Math.abs(nameYear - mediaYear) > 1) return false
        return true
    }

    if (!isLikelyBatchTitle(name) && !hasEpisodeMarker(name)) return false
    const boundaryIdx = toks.findIndex((t) => BOUNDARY_TOKEN_RE.test(t))
    const stem = boundaryIdx === -1 ? toks : toks.slice(0, boundaryIdx)
    const foreign = stem.filter(
        (t) =>
            t.length > 1 &&
            !NOISE_WORDS.has(t) &&
            !aliases.has(t) &&
            !TECH_TOKEN_RE.test(t) &&
            !PART_WORD_RE.test(t),
    )
    if (foreign.length > 0) return false

    if (expectedSeason > 0) {
        const s = seasonOfName(name)
        if (s > 0 && s !== expectedSeason) return false
    }
    if (nameYear > 0 && mediaYear > 0 && Math.abs(nameYear - mediaYear) > 1) return false
    return true
}

function matchesEpisode(row: ParsedRow, episode: number, season: number, offset: number): boolean {
    let ep = row.episode
    if (ep !== episode && !(offset > 0 && episode > offset && ep === episode - offset)) {
        const abs = /(?:^|[\s\-_\[]v?\d*\s?)(\d{1,4})(?:[\s\-_\].]|$)/.exec(row.name)
        if (!abs || Number.parseInt(abs[1], 10) !== episode) return false
    }
    if (season <= 0) return true
    return row.season === 0 || row.season === season
}

function parseRows(html: string, searchUrl: string): ParsedRow[] {
    const doc = caye.html.parse(html)
    const rows: ParsedRow[] = []

    doc.find("table.table tbody tr").each((_, el) => {
        const cells = el.find("td")
        if (cells.length < 6) return true
        const titleLink = cells.eq(1).find('a[href^="magnet:"]').first()
        const magnet = titleLink.attr("href")?.trim() || ""
        const title = (titleLink.attr("title") || titleLink.text() || "").trim()
        if (!title || !magnet) return true

        let infoHash = ""
        const candidates = [
            el.attr("data-id") || "",
            cells
                .eq(1)
                .find("span.copy-to-clipboard")
                .first()
                .attr("data-copy-to-clipboard-content") || "",
            extractInfoHashFromMagnet(magnet),
        ]
        for (const c of candidates) {
            if (!c) continue
            try {
                infoHash = normalizeInfoHash(c)
                break
            } catch {}
        }

        const sizeCell = cells.eq(2)
        const sizeTitle = sizeCell.attr("title") || ""
        let size = 0
        const byteMatch = /([\d.]+)\s*Bytes/i.exec(sizeTitle)
        if (byteMatch) size = Math.round(Number.parseFloat(byteMatch[1]))
        if (!size) size = parseSize(sizeCell.text().trim())

        const dateCell = cells.eq(3)
        const publishedAt = parseIsoDate(caye, dateCell.attr("title") || dateCell.text(), [
            "2006-01-02 15:04:05",
            "2006-01-02",
        ])

        const seeders = Number.parseInt(cells.eq(4).text().trim(), 10) || 0
        const leechers = Number.parseInt(cells.eq(5).text().trim(), 10) || 0
        const isBatch = isLikelyBatchTitle(title)
        const episode = isBatch ? -1 : extractSingleEpisode(caye, title)

        rows.push({
            name: title,
            magnet,
            infoHash,
            size,
            publishedAt,
            seeders,
            leechers,
            pageUrl: searchUrl,
            resolution: extractResolution(caye, title),
            isBatch,
            episode,
            season: seasonOfName(title),
        })
        return true
    })

    return rows
}

function categoryFor(media: MediaContext, query: AcquisitionQuery): string {
    if (media.isMovie) return CAT_MOVIES
    if (media.isAnime) return CAT_ANIME
    if (query.itemId) return CAT_TV
    return CAT_ALL
}

async function scrapePages(
    queryStr: string,
    category: string,
    maxItems: number,
): Promise<ParsedRow[]> {
    const seen = new Set<string>()
    const out: ParsedRow[] = []
    for (let page = 1; page <= 3; page++) {
        const searchUrl = `${BASE_URL}/search/${encodeURIComponent(queryStr)}/${category}/${page}/`
        const res = await fetchText(caye, "Knaben", searchUrl, {
            headers: { Accept: "text/html", Referer: `${BASE_URL}/` },
        })
        const rows = parseRows(res.body, searchUrl)
        if (rows.length === 0) break
        let added = 0
        for (const r of rows) {
            const key = (r.infoHash || r.magnet || r.name).toLowerCase()
            if (seen.has(key)) continue
            seen.add(key)
            out.push(r)
            added++
            if (out.length >= maxItems) return out
        }
        if (added === 0) break
    }
    return out
}

function toOption(row: ParsedRow, confirmed: boolean): DownloadOption {
    const key =
        row.infoHash ||
        row.name
            .toLowerCase()
            .replace(/[^a-z0-9]+/g, "-")
            .slice(0, 40)
    return createTorrentOption(caye, {
        id: `knaben-${key}`,
        key,
        providerId: PROVIDER_ID,
        name: row.name,
        magnet: row.magnet,
        pageUrl: row.pageUrl,
        size: row.size > 0 ? row.size : undefined,
        seeders: row.seeders,
        leechers: row.leechers,
        publishedAt: row.publishedAt,
        resolution: row.resolution || undefined,
        confirmed,
    })
}

async function find(_context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const media = await resolveMediaContext(caye, query)
    const rawBase = query.text?.trim() || media.englishTitle || media.romajiTitle || ""
    if (!rawBase) {
        throw failure("unsupported", "Enter a title to search.")
    }

    const split = splitSeasonMarker(rawBase)
    const base = split.base
    const season = query.season && query.season > 0 ? query.season : split.season
    const category = categoryFor(media, query)
    const aliases = buildAliasTokens([rawBase, ...media.titles])
    const mediaYear = media.year || 0
    const limit = clampLimit(query.limit, 50, 100)
    const isSmart = Boolean(query.batch || (query.number && query.number > 0) || query.itemId)

    if (!isSmart) {
        const rows = await scrapePages(base, category, limit)
        const items = rows.slice(0, limit).map((r) => toOption(r, false))
        await cacheOptions(caye, "knaben", items)
        return { items, state: "complete" }
    }

    let q = base
    if (media.isMovie) {
        if (mediaYear > 0) q += ` ${mediaYear}`
    } else if (query.batch) {
        q += " complete"
    } else if (query.number && query.number > 0) {
        const s = season > 0 ? season : 1
        q += ` S${String(s).padStart(2, "0")}E${String(Math.trunc(query.number)).padStart(2, "0")}`
    }
    if (query.resolution) q += ` ${query.resolution}`

    const fallback = async () => {
        const fb = query.resolution ? `${base} ${query.resolution}` : base
        return await scrapePages(fb, category, limit)
    }

    let chosen: ParsedRow[] = []
    if (!media.isMovie && query.batch) {
        let rows = await scrapePages(q, category, limit)
        if (rows.length === 0) {
            rows = (await fallback()).filter((r) => r.isBatch)
        }
        chosen = rows.filter(
            (r) => r.isBatch && belongsToMedia(r.name, aliases, false, season, mediaYear),
        )
    }

    if (chosen.length === 0 && !media.isMovie && query.number && query.number > 0) {
        const epNum = Math.trunc(query.number)
        const keep = (r: ParsedRow) =>
            r.isBatch || matchesEpisode(r, epNum, season, media.absoluteSeasonOffset)
        let rows = query.batch ? await fallback() : await scrapePages(q, category, limit)
        chosen = rows.filter(
            (r) => belongsToMedia(r.name, aliases, false, season, mediaYear) && keep(r),
        )
        if (chosen.length === 0) {
            rows = await fallback()
            chosen = rows.filter(
                (r) => belongsToMedia(r.name, aliases, false, season, mediaYear) && keep(r),
            )
        }
    } else if (chosen.length === 0) {
        let rows = await scrapePages(q, category, limit)
        if (rows.length === 0) rows = await fallback()
        chosen = rows.filter((r) =>
            belongsToMedia(r.name, aliases, media.isMovie, season, mediaYear),
        )
    }

    const confirmed = Boolean(!query.batch && query.number && query.number > 0)
    const items = chosen.slice(0, limit).map((r) => toOption(r, confirmed))
    await cacheOptions(caye, "knaben", items)
    return { items, state: "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    return await resolveCachedOrFallback(
        caye,
        "knaben",
        input,
        "Unknown or uncached Knaben option.",
    )
}

caye.register(PROVIDER_ID, { acquisition: { find, resolve } })
