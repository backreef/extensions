(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __pow = Math.pow;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __objRest = (source, exclude) => {
    var target = {};
    for (var prop in source)
      if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
        target[prop] = source[prop];
    if (source != null && __getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(source)) {
        if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
          target[prop] = source[prop];
      }
    return target;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve2, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve2(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../../../packages/plugin-std/src/magnet.ts
  var BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  function decodeBase32(input) {
    const cleaned = input.trim().toUpperCase().replace(/=+$/, "");
    if (!cleaned || !/^[A-Z2-7]+$/.test(cleaned)) {
      throw new TypeError("Invalid base32 string");
    }
    const bytes = [];
    let buffer = 0;
    let bitsLeft = 0;
    for (let i = 0; i < cleaned.length; i++) {
      const val = BASE32_ALPHABET.indexOf(cleaned[i]);
      buffer = buffer << 5 | val;
      bitsLeft += 5;
      if (bitsLeft >= 8) {
        bitsLeft -= 8;
        bytes.push(buffer >>> bitsLeft & 255);
      }
    }
    return new Uint8Array(bytes);
  }
  function bytesToHex(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i++) {
      out += bytes[i].toString(16).padStart(2, "0");
    }
    return out;
  }
  function normalizeInfoHash(raw) {
    const trimmed = raw.trim();
    if (/^[0-9a-fA-F]{40}$/.test(trimmed)) {
      return trimmed.toLowerCase();
    }
    if (/^[A-Za-z2-7]{32}=*$/.test(trimmed)) {
      const decoded = decodeBase32(trimmed);
      if (decoded.length === 20) {
        return bytesToHex(decoded);
      }
    }
    throw new TypeError(`Invalid infoHash: ${raw}`);
  }
  function parseMagnet(uri) {
    var _a;
    const trimmed = uri.trim();
    if (!/^magnet:\?/i.test(trimmed)) {
      throw new TypeError("Invalid magnet URI");
    }
    const query = trimmed.slice(trimmed.indexOf("?") + 1);
    const params = new URLSearchParams(query);
    let infoHash = "";
    for (const xt of params.getAll("xt")) {
      const match = xt.match(/^urn:btih:([0-9a-fA-F]{40}|[A-Za-z2-7]{32}=*)$/i);
      if (match) {
        infoHash = normalizeInfoHash(match[1]);
        break;
      }
    }
    if (!infoHash) {
      throw new TypeError("Magnet URI missing valid btih infoHash");
    }
    const name = (_a = params.get("dn")) != null ? _a : "";
    const seen = /* @__PURE__ */ new Set();
    const trackers = [];
    for (const tr of params.getAll("tr")) {
      const t = tr.trim();
      if (t && !seen.has(t)) {
        seen.add(t);
        trackers.push(t);
      }
    }
    const xlRaw = params.get("xl");
    let size = 0;
    if (xlRaw && /^\d+$/.test(xlRaw.trim())) {
      size = Number.parseInt(xlRaw.trim(), 10);
    }
    return { infoHash, name, trackers, size };
  }
  function buildMagnet(options) {
    const infoHash = normalizeInfoHash(options.infoHash);
    const parts = [`magnet:?xt=urn:btih:${infoHash}`];
    if (options.name) {
      parts.push(`dn=${encodeURIComponent(options.name)}`);
    }
    if (options.trackers) {
      const seen = /* @__PURE__ */ new Set();
      for (const tr of options.trackers) {
        const trimmed = tr.trim();
        if (trimmed && !seen.has(trimmed)) {
          seen.add(trimmed);
          parts.push(`tr=${encodeURIComponent(trimmed)}`);
        }
      }
    }
    return parts.join("&");
  }

  // ../../../packages/plugin-std/src/size.ts
  var UNIT_EXPONENTS = {
    B: 0,
    K: 1,
    M: 2,
    G: 3,
    T: 4,
    P: 5
  };
  function parseSize(input) {
    const match = input.trim().match(/^([\d,]+(?:\.\d+)?|\.\d+)\s*([KMGTPE]?i?B)$/i);
    if (!match) {
      const inner = input.match(/([\d,]+(?:\.\d+)?)\s*([KMGT]?i?B)/i);
      if (!inner) return 0;
      return computeBytes(inner[1], inner[2]);
    }
    return computeBytes(match[1], match[2]);
  }
  function computeBytes(numStr, rawUnit) {
    const value = Number.parseFloat(numStr.replace(/,/g, ""));
    if (!Number.isFinite(value) || value < 0) return 0;
    const unit = rawUnit.toUpperCase();
    const base = unit.endsWith("IB") ? 1024 : 1e3;
    const prefix = unit === "B" ? "B" : unit[0];
    const exp = UNIT_EXPONENTS[prefix];
    if (exp === void 0) return 0;
    return Math.round(value * __pow(base, exp));
  }

  // ../../../packages/plugin-std/src/titles.ts
  var NOISE_WORDS = /* @__PURE__ */ new Set([
    "the",
    "a",
    "an",
    "of",
    "to",
    "in",
    "for",
    "on",
    "with",
    "at",
    "by",
    "from",
    "as",
    "is",
    "it",
    "that",
    "this",
    "be",
    "are",
    "was",
    "were",
    "no",
    "wa",
    "wo",
    "ga",
    "ni",
    "de",
    "ka",
    "mo",
    "ya",
    "e",
    "he",
    "anime",
    "ova",
    "ona",
    "oad",
    "tv",
    "movie",
    "nc",
    "nced",
    "ncop",
    "extras",
    "ending",
    "opening",
    "preview",
    "special",
    "specials",
    "sp",
    "finale",
    "season",
    "uncensored",
    "censored",
    "bluray"
  ]);
  var FORMAT_WORDS = /* @__PURE__ */ new Set([
    "ova",
    "ona",
    "oad",
    "oav",
    "sp",
    "special",
    "specials",
    "movie",
    "film",
    "tv",
    "nc",
    "nced",
    "ncop",
    "extras",
    "opening",
    "ending",
    "preview",
    "finale"
  ]);
  var ORDINAL_TO_NUMBER = {
    first: 1,
    "1st": 1,
    second: 2,
    "2nd": 2,
    third: 3,
    "3rd": 3,
    fourth: 4,
    "4th": 4,
    fifth: 5,
    "5th": 5,
    sixth: 6,
    "6th": 6,
    seventh: 7,
    "7th": 7,
    eighth: 8,
    "8th": 8,
    ninth: 9,
    "9th": 9,
    tenth: 10,
    "10th": 10
  };
  var ROMAN_SEASON_MAP = {
    ii: 2,
    iii: 3,
    iv: 4,
    v: 5,
    vi: 6,
    vii: 7,
    viii: 8,
    ix: 9,
    xi: 11,
    xii: 12,
    xiii: 13
  };
  var SEASON_EXPLICIT_RE = /\b(?:season|s|series)\s*0*(\d+)\b/gi;
  var SEASON_ORDINAL_RE = /\b(\d+)(?:st|nd|rd|th)\s*(?:part|season|series)\b/gi;
  var SEASON_WORD_ORDINAL_RE = /\b(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)\s+season\b/gi;
  var SEASON_SUFFIX_RE = /(\d+)\s*(?:期|シーズン)/gi;
  var PART_EXPLICIT_RE = /\b(?:part|cour)\s*0*(\d+)\b/i;
  var PART_ORDINAL_RE = /\b(\d+)(?:st|nd|rd|th)\s*(?:part|cour)\b/i;
  var PART_ROMAN_RE = /\b(?:part|cour)\s+(i{1,3}|iv|vi?i?i?|ix|x)\b/i;
  var YEAR_PAREN_RE = /\((\d{4})\)/;
  var YEAR_STANDALONE_RE = /\b(19\d{2}|20\d{2})\b/;
  function isAlphanumAscii(ch) {
    const code = ch.charCodeAt(0);
    return code >= 97 && code <= 122 || code >= 65 && code <= 90 || code >= 48 && code <= 57;
  }
  function replaceWholeWord(input, word, replacement) {
    if (!input || !word) return input;
    let out = "";
    let pos = 0;
    while (pos < input.length) {
      const idx = input.indexOf(word, pos);
      if (idx === -1) {
        out += input.slice(pos);
        break;
      }
      const beforeOk = idx === 0 || !isAlphanumAscii(input[idx - 1]);
      const afterIdx = idx + word.length;
      const afterOk = afterIdx === input.length || !isAlphanumAscii(input[afterIdx]);
      if (beforeOk && afterOk) {
        out += input.slice(pos, idx) + replacement;
        pos = afterIdx;
      } else {
        out += input.slice(pos, idx + 1);
        pos = idx + 1;
      }
    }
    return out;
  }
  function normalizeString(input) {
    let s = input.toLowerCase();
    s = s.replace(/ō/g, "ou").replace(/ū/g, "uu");
    s = s.replace(/@/g, "a").replace(/×/g, " x ").replace(/꞉/g, ":").replace(/＊/g, " * ");
    s = replaceWholeWord(s, "the animation", "");
    s = replaceWholeWord(s, "the", "");
    s = replaceWholeWord(s, "episode", "");
    s = replaceWholeWord(s, "oad", "ova");
    s = replaceWholeWord(s, "oav", "ova");
    s = replaceWholeWord(s, "specials", "sp");
    s = replaceWholeWord(s, "special", "sp");
    s = s.replace(/\(tv\)/g, "");
    s = replaceWholeWord(s, "&", "and");
    s = s.replace(/'s|’s|`s/g, " ");
    s = s.replace(/['’`"“”]/g, "");
    let cleaned = "";
    let prevSpace = false;
    for (let i = 0; i < s.length; i++) {
      const ch = s[i];
      const code = ch.charCodeAt(0);
      const isLowerAlphaNum = code >= 97 && code <= 122 || code >= 48 && code <= 57 || ch === " ";
      if (!isLowerAlphaNum) {
        if (!prevSpace) {
          cleaned += " ";
          prevSpace = true;
        }
      } else {
        cleaned += ch;
        prevSpace = ch === " ";
      }
    }
    cleaned = cleaned.replace(SEASON_EXPLICIT_RE, " ").replace(SEASON_ORDINAL_RE, " ").replace(SEASON_WORD_ORDINAL_RE, " ").replace(SEASON_SUFFIX_RE, " ").replace(/\b(?:part|cour)\s*0*(\d+)\b/gi, " ").replace(/\b(\d+)(?:st|nd|rd|th)\s*(?:part|cour)\b/gi, " ").replace(/\b(?:part|cour)\s+(i{1,3}|iv|vi?i?i?|ix|x)\b/gi, " ");
    return cleaned.replace(/\s+/g, " ").trim();
  }
  function computeCleanBaseTitle(normalized) {
    const strippedNum = normalized.replace(/\b\d+\b$/, " ").trim();
    const tokens = strippedNum ? strippedNum.split(/\s+/) : [];
    const clean = [];
    const denoised = [];
    for (const token of tokens) {
      if (FORMAT_WORDS.has(token) || ROMAN_SEASON_MAP[token] !== void 0) continue;
      clean.push(token);
      if (!NOISE_WORDS.has(token)) {
        denoised.push(token);
      }
    }
    return {
      cleanBaseTitle: clean.join(" "),
      denoisedTitle: denoised.join(" ")
    };
  }
  function extractSeason(title) {
    const val = title.toLowerCase();
    const explicit = val.match(/season\s*(\d+)/);
    if (explicit) return Number.parseInt(explicit[1], 10);
    const sFmt = val.match(/\bs0?(\d{1,2})(?:e\d|$|\s|\.)/);
    if (sFmt) {
      const num = Number.parseInt(sFmt[1], 10);
      if (num > 0 && num < 20) return num;
    }
    const ordinal = val.match(/(\d+)(?:st|nd|rd|th)\s+season/);
    if (ordinal) return Number.parseInt(ordinal[1], 10);
    const romanCleaned = val.replace(
      /\b((?:act|arc|chapter|saga|hen|part|cour))[\s._:-]+(i{1,3}|iv|vi?i?i?|ix|x)\b/g,
      "$1"
    );
    const romanPatterns = [
      /[\s.](i{1,3}|iv|vi?i?i?|ix|x)(?:\s|$|[:,.]|[''])/,
      /[\s.](i{1,3}|iv|vi?i?i?|ix|x)[.\s]*(?:s\d|e\d|part)/
    ];
    for (const re of romanPatterns) {
      const m = romanCleaned.match(re);
      if (m && ROMAN_SEASON_MAP[m[1]] !== void 0) {
        return ROMAN_SEASON_MAP[m[1]];
      }
    }
    const trailing = val.match(/(?:^|\s)(\d{1,2})\s*$/);
    if (trailing && !/(?:part|cour|specials?|sp|movie|ova|ona|oad)\s*\d{1,2}\s*$/.test(val)) {
      const num = Number.parseInt(trailing[1], 10);
      if (num >= 2 && num <= 10) return num;
    }
    const jp = val.match(/(?:第)?(\d+)\s*期/);
    if (jp) return Number.parseInt(jp[1], 10);
    const wordOrd = val.match(
      /\b(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)\s+season\b/
    );
    if (wordOrd && ORDINAL_TO_NUMBER[wordOrd[1]] !== void 0) {
      return ORDINAL_TO_NUMBER[wordOrd[1]];
    }
    return -1;
  }
  function extractPart(title) {
    const val = title.toLowerCase();
    const explicit = val.match(PART_EXPLICIT_RE);
    if (explicit) return Number.parseInt(explicit[1], 10);
    const ordinal = val.match(PART_ORDINAL_RE);
    if (ordinal) return Number.parseInt(ordinal[1], 10);
    const roman = val.match(PART_ROMAN_RE);
    if (roman) {
      const r = roman[1].toLowerCase();
      if (r === "i" || r === "x") return -1;
      if (ROMAN_SEASON_MAP[r] !== void 0) return ROMAN_SEASON_MAP[r];
    }
    return -1;
  }
  function extractYear(title) {
    const paren = title.match(YEAR_PAREN_RE);
    if (paren) {
      const year = Number.parseInt(paren[1], 10);
      if (year >= 1900 && year <= 2100) return year;
    }
    const standalone = title.match(YEAR_STANDALONE_RE);
    if (standalone) {
      return Number.parseInt(standalone[1], 10);
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];
  function normalizeTitle(title) {
    if (!title) {
      return {
        original: "",
        normalized: "",
        cleanBaseTitle: "",
        denoisedTitle: "",
        tokens: [],
        season: -1,
        part: -1,
        year: -1
      };
    }
    const season = extractSeason(title);
    const part = extractPart(title);
    const year = extractYear(title);
    const normalized = normalizeString(title);
    const { cleanBaseTitle, denoisedTitle } = computeCleanBaseTitle(normalized);
    const tokens = normalized ? normalized.split(" ") : [];
    return {
      original: title,
      normalized,
      cleanBaseTitle,
      denoisedTitle,
      tokens,
      season,
      part,
      year
    };
  }

  // ../torrent-common/src/option.ts
  var DEFAULT_TRACKERS = [
    "http://nyaa.tracker.wf:7777/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce"
  ];
  var MAX_RETRIEVAL_URI_LENGTH = 2e3;
  function numberValue(value) {
    return { kind: "number", number: value };
  }
  function makeFact(producerId, id, field, value, at = (/* @__PURE__ */ new Date()).toISOString()) {
    return {
      id,
      producerId,
      field,
      value: numberValue(value),
      locale: "",
      region: "",
      status: "complete",
      at
    };
  }
  function buildCountsFacts(producerId, key, counts) {
    const at = (/* @__PURE__ */ new Date()).toISOString();
    const facts = [];
    if (counts.size !== void 0 && Number.isFinite(counts.size) && counts.size > 0) {
      facts.push(makeFact(producerId, `size-${key}`, "size", counts.size, at));
    }
    if (counts.seeders !== void 0 && Number.isFinite(counts.seeders) && counts.seeders >= 0) {
      facts.push(makeFact(producerId, `seeders-${key}`, "seeders", counts.seeders, at));
    }
    if (counts.leechers !== void 0 && Number.isFinite(counts.leechers) && counts.leechers >= 0) {
      facts.push(makeFact(producerId, `leechers-${key}`, "leechers", counts.leechers, at));
    }
    if (counts.downloads !== void 0 && Number.isFinite(counts.downloads) && counts.downloads > 0) {
      facts.push(makeFact(producerId, `downloads-${key}`, "downloads", counts.downloads, at));
    }
    return facts;
  }
  function parseIsoDate(caye2, raw, layouts) {
    var _a;
    const trimmed = raw == null ? void 0 : raw.trim();
    if (!trimmed) return void 0;
    if (typeof ((_a = caye2.time) == null ? void 0 : _a.parse) === "function") {
      try {
        const ms = caye2.time.parse(trimmed, layouts ? { layouts } : void 0);
        if (Number.isFinite(ms)) {
          return new Date(ms).toISOString();
        }
      } catch (e) {
      }
    }
    const parsed = Date.parse(trimmed);
    if (Number.isFinite(parsed)) {
      return new Date(parsed).toISOString();
    }
    return void 0;
  }
  function pickUri(magnet, torrentUrl) {
    if (magnet && Array.from(magnet).length <= MAX_RETRIEVAL_URI_LENGTH) {
      return magnet;
    }
    return torrentUrl || magnet || "";
  }
  function createTorrentOption(caye2, input) {
    var _a, _b, _c, _d;
    const uri = pickUri(input.magnet, input.torrentUrl);
    const facts = buildCountsFacts(input.providerId, input.key, {
      size: input.size,
      seeders: input.seeders,
      leechers: input.leechers,
      downloads: input.downloads
    });
    let resolution = ((_a = input.resolution) == null ? void 0 : _a.trim()) || "";
    let group = ((_b = input.group) == null ? void 0 : _b.trim()) || "";
    if ((!resolution || !group) && typeof ((_c = caye2.release) == null ? void 0 : _c.parse) === "function") {
      try {
        const parsed = caye2.release.parse(input.name);
        if (!resolution && parsed.resolution) resolution = parsed.resolution;
        if (!group && parsed.group) group = parsed.group;
      } catch (e) {
      }
    }
    const option = {
      id: input.id,
      name: input.name,
      kind: "torrent",
      uri,
      files: [],
      facts,
      availability: "available",
      eligible: true,
      reasons: [],
      confirmed: Boolean(input.confirmed)
    };
    if (input.seeders !== void 0 && Number.isFinite(input.seeders) && input.seeders >= 0) {
      option.seeders = Math.trunc(input.seeders);
    }
    if (input.size !== void 0 && Number.isFinite(input.size) && input.size > 0) {
      option.size = Math.round(input.size);
    }
    if (input.publishedAt) option.publishedAt = input.publishedAt;
    if (input.pageUrl && /^https?:\/\//i.test(input.pageUrl)) {
      option.pageUrl = input.pageUrl;
    }
    if ((_d = input.magnet) == null ? void 0 : _d.startsWith("magnet:")) {
      option.magnet = input.magnet;
    }
    if (resolution) option.resolution = resolution;
    if (group) option.group = group;
    if (input.best) option.best = true;
    return option;
  }
  function extractInfoHashFromMagnet(magnet) {
    if (!magnet) return "";
    try {
      return parseMagnet(magnet).infoHash;
    } catch (e) {
      const match = /btih:([a-fA-F0-9]{40}|[A-Za-z2-7]{32})/i.exec(magnet);
      return match ? match[1].toLowerCase() : "";
    }
  }
  var missingMessage = (service) => `${service} no longer lists this torrent.`;
  function fetchText(caye2, service, url, options) {
    return __async(this, null, function* () {
      var _b, _c;
      const _a = options != null ? options : {}, { missingOn404 } = _a, input = __objRest(_a, ["missingOn404"]);
      const response = yield httpClient(caye2, service).send(
        __spreadProps(__spreadValues({}, input), { url }),
        missingOn404 ? { missing: missingMessage(service) } : void 0
      );
      return {
        status: response.status,
        headers: (_b = response.headers) != null ? _b : {},
        body: (_c = response.body) != null ? _c : "",
        url: response.url
      };
    });
  }

  // ../../../packages/plugin-std/src/cache.ts
  function getCachedJson(api, key) {
    return __async(this, null, function* () {
      try {
        const value = yield api.cache.get({ key });
        if ((value == null ? void 0 : value.kind) === "text") return JSON.parse(value.text);
      } catch (e) {
      }
      return void 0;
    });
  }
  function setCachedJson(api, key, value, ttlSeconds) {
    return __async(this, null, function* () {
      try {
        yield api.cache.set({
          key,
          value: { kind: "text", text: JSON.stringify(value) },
          ttlSeconds
        });
      } catch (e) {
      }
    });
  }

  // ../torrent-common/src/smart.ts
  var OPTION_CACHE_TTL_SECONDS = 7 * 24 * 60 * 60;
  function parseResolutionNumber(raw) {
    if (!raw) return 0;
    const lower = raw.trim().toLowerCase();
    if (lower === "4k" || lower === "uhd") return 2160;
    if (lower === "8k") return 4320;
    const match = /(\d{3,4})/.exec(lower);
    return match ? Number.parseInt(match[1], 10) : 0;
  }
  function normalizeResolutionLabel(raw) {
    const n = parseResolutionNumber(raw);
    if (n >= 360 && n <= 4320) return `${n}p`;
    return "";
  }
  function extractResolution(caye2, title) {
    try {
      const parsed = caye2.release.parse(title);
      if (parsed.resolution) {
        const normalized = normalizeResolutionLabel(parsed.resolution);
        if (normalized) return normalized;
      }
    } catch (e) {
    }
    if (/\b(?:4k|2160p?|uhd)\b/i.test(title)) return "2160p";
    const match = /\b(\d{3,4})\s*p\b/i.exec(title);
    if (match) {
      const normalized = normalizeResolutionLabel(match[1]);
      if (normalized) return normalized;
    }
    return "";
  }
  function parseEpisodesFromTitle(caye2, title) {
    var _a;
    const out = [];
    try {
      const parsed = caye2.release.parse(title);
      for (const raw of (_a = parsed.episodes) != null ? _a : []) {
        const n = Number.parseInt(raw, 10);
        if (Number.isInteger(n) && n >= 0 && !out.includes(n)) out.push(n);
      }
    } catch (e) {
    }
    return out;
  }
  function extractSingleEpisode(caye2, title) {
    const eps = parseEpisodesFromTitle(caye2, title);
    if (eps.length === 1) return eps[0];
    return -1;
  }
  function isLikelyBatchTitle(title) {
    if (/\b(?:batch|complete(?:\s+series)?|collection|box\s*set|boxset|all\s+seasons|integrale)\b/i.test(
      title
    )) {
      return true;
    }
    if (/(?:合集|全集|完整|全話|全\s*\d+\s*[話话卷]|第\s*\d+\s*[-~～—]\s*\d+\s*[集話话])/.test(
      title
    )) {
      return true;
    }
    if (/S\d{1,2}E\d{1,3}\s*(?:~|-|–|—)\s*E?\d{1,3}/i.test(title)) return true;
    if (/\bS\d{1,2}\s*-\s*BATCH\b/i.test(title)) return true;
    const range = /\b0*(\d{1,3})\s*[-~～—]\s*0*(\d{1,3})\b/.exec(title);
    if (range) {
      const s = Number.parseInt(range[1], 10);
      const e = Number.parseInt(range[2], 10);
      if (e > s && s >= 1 && e <= 300) return true;
    }
    return false;
  }
  function clampLimit(limit, fallback = 50, max = 100) {
    return Math.min(Math.max(limit || fallback, 1), max);
  }
  function cacheOptions(_0, _1, _2) {
    return __async(this, arguments, function* (caye2, prefix, options, ttlSeconds = OPTION_CACHE_TTL_SECONDS) {
      for (const option of options) {
        yield setCachedJson(caye2, `${prefix}:option:${option.id}`, option, ttlSeconds);
      }
    });
  }
  function validateHttpUrl(raw) {
    const trimmed = (raw == null ? void 0 : raw.trim()) || "";
    if (!trimmed) return void 0;
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol === "http:" || parsed.protocol === "https:") {
        return parsed.toString();
      }
    } catch (e) {
    }
    return void 0;
  }
  function resolveFromRetrievalInput(caye2, providerId, prefix, input, notFoundMessage, defaultGroup) {
    var _a, _b, _c, _d;
    const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
    const rawMagnet = ((_b = input.magnet) == null ? void 0 : _b.trim()) || "";
    const rawInfoHash = ((_c = input.infoHash) == null ? void 0 : _c.trim()) || "";
    const rawTorrentUrl = ((_d = input.torrentUrl) == null ? void 0 : _d.trim()) || "";
    const hasRetrieval = Boolean(rawMagnet || rawInfoHash || rawTorrentUrl);
    if (!hasRetrieval) return void 0;
    if (optionId && !optionId.startsWith(`${prefix}-`)) {
      throw failure("missing", notFoundMessage);
    }
    const validTorrentUrl = rawTorrentUrl ? validateHttpUrl(rawTorrentUrl) : void 0;
    if (rawTorrentUrl && !validTorrentUrl) {
      throw failure("missing", "Invalid torrent retrieval URL.");
    }
    if (rawMagnet) {
      let parsed;
      try {
        parsed = parseMagnet(rawMagnet);
      } catch (e) {
        throw failure("missing", "Invalid magnet retrieval URI.");
      }
      const id = optionId || `${prefix}-${parsed.infoHash}`;
      return createTorrentOption(caye2, {
        id,
        key: parsed.infoHash,
        providerId,
        name: parsed.name || `${prefix} ${parsed.infoHash}`,
        magnet: rawMagnet,
        torrentUrl: validTorrentUrl,
        size: parsed.size > 0 ? parsed.size : void 0,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (rawInfoHash) {
      let infoHash = "";
      try {
        infoHash = normalizeInfoHash(rawInfoHash);
      } catch (e) {
        throw failure("missing", "Invalid torrent info hash.");
      }
      const id = optionId || `${prefix}-${infoHash}`;
      const magnet = buildMagnet({ infoHash, trackers: DEFAULT_TRACKERS });
      return createTorrentOption(caye2, {
        id,
        key: infoHash,
        providerId,
        name: `${prefix} ${infoHash}`,
        magnet,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (validTorrentUrl) {
      const id = optionId || `${prefix}-torrent`;
      const key = id.startsWith(`${prefix}-`) ? id.slice(prefix.length + 1) : id;
      return createTorrentOption(caye2, {
        id,
        key,
        providerId,
        name: `${prefix} ${key}`,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    return void 0;
  }
  function resolveCachedOrFallback(caye2, prefix, input, notFoundMessage, fetchFallback, options) {
    return __async(this, null, function* () {
      var _a;
      const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
      if (!optionId && !input.magnet && !input.torrentUrl && !input.infoHash) {
        throw failure("missing", notFoundMessage);
      }
      if (optionId && !optionId.startsWith(`${prefix}-`)) {
        throw failure("missing", notFoundMessage);
      }
      if (optionId) {
        const cached = yield getCachedJson(caye2, `${prefix}:option:${optionId}`);
        if (cached && cached.id === optionId) {
          return cached;
        }
      }
      if (fetchFallback && optionId) {
        try {
          return yield fetchFallback(optionId);
        } catch (err) {
          const code = err == null ? void 0 : err.code;
          if (code !== "missing" && code !== "unavailable" && code !== "rate-limited") throw err;
          const fallback2 = resolveFromRetrievalInput(
            caye2,
            (options == null ? void 0 : options.providerId) || `backreef.${prefix}:search`,
            prefix,
            input,
            notFoundMessage,
            options == null ? void 0 : options.group
          );
          if (fallback2) return fallback2;
          throw err;
        }
      }
      const fallback = resolveFromRetrievalInput(
        caye2,
        (options == null ? void 0 : options.providerId) || `backreef.${prefix}:search`,
        prefix,
        input,
        notFoundMessage,
        options == null ? void 0 : options.group
      );
      if (fallback) return fallback;
      throw failure("missing", notFoundMessage);
    });
  }

  // ../torrent-common/src/media.ts
  function asRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return void 0;
    return value;
  }
  function positiveIntString(value) {
    if (typeof value === "number") {
      return Number.isInteger(value) && value > 0 ? String(value) : void 0;
    }
    if (typeof value === "string") {
      const trimmed = value.trim();
      return /^[1-9][0-9]*$/.test(trimmed) ? trimmed : void 0;
    }
    return void 0;
  }
  function addUniqueTitle(target, raw) {
    if (typeof raw !== "string") return;
    const trimmed = raw.trim();
    if (trimmed && !target.includes(trimmed)) {
      target.push(trimmed);
    }
  }
  function extractEntriesIds(entriesValue, preferredNative) {
    if (!Array.isArray(entriesValue)) return {};
    let anilistId;
    let anidbId;
    let malId;
    let bgmId;
    const inspect = (requireMatch) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      for (const rawEntry of entriesValue) {
        const entry = asRecord(rawEntry);
        if (!entry) continue;
        const ref = asRecord(entry.ref);
        if (requireMatch && preferredNative) {
          if ((ref == null ? void 0 : ref.providerId) !== preferredNative.entry.providerId || (ref == null ? void 0 : ref.nativeId) !== preferredNative.entry.nativeId) {
            continue;
          }
        }
        const ids = asRecord(entry.ids);
        if (ids) {
          anilistId != null ? anilistId : anilistId = positiveIntString((_b = (_a = ids.anilistid) != null ? _a : ids.anilistId) != null ? _b : ids.anilist);
          anidbId != null ? anidbId : anidbId = positiveIntString((_d = (_c = ids.anidbid) != null ? _c : ids.anidbId) != null ? _d : ids.anidb);
          malId != null ? malId : malId = positiveIntString((_f = (_e = ids.malid) != null ? _e : ids.malId) != null ? _f : ids.mal);
          bgmId != null ? bgmId : bgmId = positiveIntString((_i = (_h = (_g = ids.bgmid) != null ? _g : ids.bgmId) != null ? _h : ids.bgm) != null ? _i : ids.bangumi);
        }
        if ((ref == null ? void 0 : ref.providerId) === "caye.anilist:catalog" || (ref == null ? void 0 : ref.providerId) === "anilist" || typeof (ref == null ? void 0 : ref.providerId) === "string" && ref.providerId.includes("anilist")) {
          anilistId != null ? anilistId : anilistId = positiveIntString(ref.nativeId);
        }
      }
    };
    if (preferredNative) inspect(true);
    inspect(false);
    return { anilistId, anidbId, malId, bgmId };
  }
  function extractFieldMap(fieldsValue) {
    const out = {};
    if (!Array.isArray(fieldsValue)) return out;
    for (const rawField of fieldsValue) {
      const entry = asRecord(rawField);
      if (!entry || typeof entry.field !== "string") continue;
      const val = asRecord(entry.value);
      if (val) out[entry.field] = val;
    }
    return out;
  }
  function parseDateParts(raw) {
    if (typeof raw !== "string") return void 0;
    const m = /^(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?/.exec(raw.trim());
    if (!m) return void 0;
    const year = Number.parseInt(m[1], 10);
    if (year < 1900 || year > 2100) return void 0;
    return {
      year,
      month: m[2] ? Number.parseInt(m[2], 10) : void 0,
      day: m[3] ? Number.parseInt(m[3], 10) : void 0
    };
  }
  function safeGetItem(caye2, itemId) {
    return __async(this, null, function* () {
      if (!itemId || typeof caye2.request !== "function") return void 0;
      try {
        const raw = yield caye2.request("getItem", { path: { itemId } });
        return asRecord(raw);
      } catch (e) {
        return void 0;
      }
    });
  }
  function pickPreferredNative(query) {
    var _a;
    const refs = (_a = query.native) != null ? _a : [];
    if (refs.length === 0) return void 0;
    const exact = refs.find((r) => r.itemId === query.itemId);
    if (exact) return exact;
    return refs[0];
  }
  function resolveMediaContext(caye2, query) {
    return __async(this, null, function* () {
      var _a, _b;
      const titles = [];
      let romajiTitle = "";
      let englishTitle = "";
      let originalTitle = "";
      const synonyms = [];
      let anilistId;
      let anidbId;
      let malId;
      let bgmId;
      let isMovie = false;
      let isAnime = false;
      let adult = false;
      let year;
      let startDate;
      let episodeCount;
      let releaseStatus;
      const preferredNative = pickPreferredNative(query);
      const item = yield safeGetItem(caye2, query.itemId || (preferredNative == null ? void 0 : preferredNative.itemId));
      const parentId = typeof (item == null ? void 0 : item.parentId) === "string" ? item.parentId : void 0;
      const parentItem = parentId ? yield safeGetItem(caye2, parentId) : void 0;
      const consumeTitlesObj = (rawTitles) => {
        const t = asRecord(rawTitles);
        if (!t) return;
        if (!romajiTitle && typeof t.romaji === "string") romajiTitle = t.romaji.trim();
        if (!englishTitle && typeof t.english === "string") englishTitle = t.english.trim();
        if (!originalTitle && typeof t.original === "string") originalTitle = t.original.trim();
        addUniqueTitle(titles, t.romaji);
        addUniqueTitle(titles, t.english);
        addUniqueTitle(titles, t.original);
      };
      const inspectRecord = (record) => {
        var _a2, _b2, _c, _d, _e, _f, _g, _h, _i, _j, _k;
        if (!record) return;
        if (record.adult === true) adult = true;
        const kindId = typeof record.kindId === "string" ? record.kindId : "";
        const kindLeaf = (kindId.includes(":") ? kindId.split(":")[1] : kindId).toLowerCase();
        if (kindLeaf === "movie") isMovie = true;
        if (kindLeaf === "anime" || kindId.toLowerCase().includes(":anime")) isAnime = true;
        const ids = extractEntriesIds(record.entries, preferredNative);
        anilistId != null ? anilistId : anilistId = ids.anilistId;
        anidbId != null ? anidbId : anidbId = ids.anidbId;
        malId != null ? malId : malId = ids.malId;
        bgmId != null ? bgmId : bgmId = ids.bgmId;
        if (anilistId || anidbId) isAnime = true;
        const parentSummary = asRecord(record.parent);
        if (parentSummary) {
          consumeTitlesObj(parentSummary.titles);
          addUniqueTitle(titles, parentSummary.name);
        }
        consumeTitlesObj(record.titles);
        addUniqueTitle(titles, record.name);
        const totalChildren = typeof record.totalChildren === "number" ? record.totalChildren : typeof record.childCount === "number" ? record.childCount : void 0;
        if (totalChildren !== void 0 && totalChildren > 0 && episodeCount === void 0) {
          episodeCount = totalChildren;
        }
        const fields = extractFieldMap(record.fields);
        if (((_a2 = fields["caye:adult"]) == null ? void 0 : _a2.boolean) === true) adult = true;
        const formatVal = typeof ((_b2 = fields["caye:format"]) == null ? void 0 : _b2.text) === "string" ? fields["caye:format"].text.trim() : "";
        if (/^movie$/i.test(formatVal)) isMovie = true;
        if (/^(?:tv|tv_short|ova|ona|special|anime)$/i.test(formatVal) && isAnime) isMovie = false;
        const romajiField = typeof ((_c = fields["caye:romaji"]) == null ? void 0 : _c.text) === "string" ? fields["caye:romaji"].text.trim() : "";
        const englishField = typeof ((_d = fields["caye:english"]) == null ? void 0 : _d.text) === "string" ? fields["caye:english"].text.trim() : "";
        const originalField = typeof ((_e = fields["caye:original"]) == null ? void 0 : _e.text) === "string" ? fields["caye:original"].text.trim() : "";
        if (!romajiTitle && romajiField) romajiTitle = romajiField;
        if (!englishTitle && englishField) englishTitle = englishField;
        if (!originalTitle && originalField) originalTitle = originalField;
        addUniqueTitle(titles, romajiField);
        addUniqueTitle(titles, englishField);
        addUniqueTitle(titles, originalField);
        if (!releaseStatus) {
          const statusVal = (_h = (_f = fields["caye:status"]) == null ? void 0 : _f.text) != null ? _h : (_g = fields["caye:releaseStatus"]) == null ? void 0 : _g.text;
          if (typeof statusVal === "string" && statusVal.trim()) releaseStatus = statusVal.trim();
        }
        if (!startDate) {
          const releaseAt = (_i = fields["caye:releaseAt"]) == null ? void 0 : _i.text;
          startDate = parseDateParts(releaseAt);
        }
        if (year === void 0) {
          const yNum = (_j = fields["caye:year"]) == null ? void 0 : _j.number;
          if (typeof yNum === "number" && yNum >= 1900 && yNum <= 2100) {
            year = Math.trunc(yNum);
          } else if (startDate) {
            year = startDate.year;
          }
        }
        for (const key of ["caye:titles", "caye:synonyms", "caye:alternativeTitles"]) {
          const list = (_k = fields[key]) == null ? void 0 : _k.list;
          if (Array.isArray(list)) {
            for (const v of list) {
              const obj = asRecord(v);
              if (typeof (obj == null ? void 0 : obj.text) === "string" && obj.text.trim()) {
                addUniqueTitle(synonyms, obj.text);
                addUniqueTitle(titles, obj.text);
              }
            }
          }
        }
      };
      inspectRecord(parentItem);
      inspectRecord(item);
      const text = ((_a = query.text) == null ? void 0 : _a.trim()) || "";
      if (text) {
        addUniqueTitle(titles, text);
      }
      if (!anilistId) {
        for (const ref of (_b = query.native) != null ? _b : []) {
          if (ref.entry.providerId === "caye.anilist:catalog" || ref.entry.providerId === "anilist" || ref.entry.providerId.includes("anilist")) {
            anilistId = positiveIntString(ref.entry.nativeId);
            if (anilistId) break;
          }
        }
      }
      const season = typeof query.season === "number" && query.season > 0 ? query.season : typeof (item == null ? void 0 : item.season) === "number" && item.season > 0 ? item.season : void 0;
      const number = typeof query.number === "number" && query.number > 0 ? query.number : typeof (item == null ? void 0 : item.number) === "number" && item.number > 0 ? item.number : void 0;
      const absolute = typeof query.absolute === "number" && query.absolute > 0 ? query.absolute : void 0;
      const absoluteSeasonOffset = absolute !== void 0 && number !== void 0 && absolute > number ? absolute - number : 0;
      return {
        text,
        titles,
        romajiTitle: romajiTitle || titles[0] || "",
        englishTitle: englishTitle || "",
        originalTitle,
        synonyms,
        anilistId,
        anidbId,
        malId,
        bgmId,
        season,
        number,
        absolute,
        isMovie,
        isAnime,
        adult,
        year,
        startDate: startDate != null ? startDate : year ? { year } : void 0,
        episodeCount,
        releaseStatus,
        absoluteSeasonOffset
      };
    });
  }

  // src/backend.ts
  var PROVIDER_ID = "backreef.knaben:search";
  var BASE_URL = "https://knaben.org";
  var CAT_ANIME = "6000000";
  var CAT_TV = "2000000";
  var CAT_MOVIES = "3000000";
  var CAT_ALL = "0";
  var TECH_TOKEN_RE = /^(?:s\d{1,2}e\d{1,3}|s\d{1,2}|e\d{1,3}|ep\d{1,3}|\d{1,4}|\d{3,4}p|[248]k|web|webrip|webdl|hdtv|hdrip|dvdrip|bluray|blu|bdrip|bdr|bd|remux|x264|x265|h264|h265|hevc|avc|hdr|hdr10|dolby|vision|atmos|dts|truehd|aac|ac3|eac3|flac|multi|dual|dualaudio|sub|subs|subbed|dub|dubbed|eng|en|fr|french|esp|spa|ger|deu|ita|kor|jpn|jap|chi|pol|por|rus|tur|10bit|8bit|complete|collection|boxset|series|season|pack|batch|mini|miniseries|part|parts|vol|volume|final|full|remaster|restored|extended|uncut|edition|amzn|nf|dsnp|atvp|nyaa|subsplease|erai|judas|ryujin)$/i;
  var BOUNDARY_TOKEN_RE = /^(?:s\d{1,2}e\d{0,3}|s\d{1,2}|e\d{1,3}|ep\d{1,3}|season|series|complete|collection|pack|batch|volume|vol|boxset|(?:19|20)\d{2})$/i;
  var PART_WORD_RE = /^(?:one|two|three|four|five|six|seven|eight|nine|ten|first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|1st|2nd|3rd|[4-9]th|10th|ii|iii|iv|vi|vii|viii|ix)$/i;
  var NOISE_WORDS2 = /* @__PURE__ */ new Set([
    "the",
    "a",
    "an",
    "of",
    "to",
    "in",
    "for",
    "on",
    "with",
    "at",
    "by",
    "from",
    "and",
    "or"
  ]);
  function splitSeasonMarker(title) {
    const m = /\s*[—–-]\s*season\s+(\d{1,2})\s*$/i.exec(title);
    if (m) {
      return { base: title.slice(0, m.index).trim(), season: Number.parseInt(m[1], 10) };
    }
    const norm = normalizeTitle(title);
    if (norm.season > 0 && norm.cleanBaseTitle) {
      return { base: norm.cleanBaseTitle, season: norm.season };
    }
    return { base: title.trim(), season: 0 };
  }
  function seasonOfName(name) {
    const m = /\bS(\d{1,2})E\d{1,3}\b/i.exec(name);
    return m ? Number.parseInt(m[1], 10) : 0;
  }
  function hasEpisodeMarker(name) {
    if (/\bS\d{1,2}E\d{1,3}\b/i.test(name)) return true;
    if (/\b(?:Episode|EP)\s*#?\s*\d{1,3}\b/i.test(name)) return true;
    if (/(?:^|[.\s\-_])E\d{1,3}(?:[.\s\-_]|$)/i.test(name)) return true;
    return /(?:^|[\s\-_\[])(\d{1,3})(?:[\s\-_\].]|$)/.test(name) && /\b\d{3,4}p\b/i.test(name);
  }
  function buildAliasTokens(titles) {
    const set = /* @__PURE__ */ new Set();
    for (const title of titles) {
      if (!title) continue;
      const base = splitSeasonMarker(title).base;
      for (const t of normalizeTitle(base).tokens) set.add(t);
      const dequoted = base.replace(/[''":]/g, "");
      if (dequoted !== base) {
        for (const t of normalizeTitle(dequoted).tokens) set.add(t);
      }
    }
    return set;
  }
  function belongsToMedia(name, aliases, isMovie, expectedSeason, mediaYear) {
    if (aliases.size === 0) return true;
    const norm = normalizeTitle(name);
    const toks = norm.tokens;
    const nameYear = norm.year;
    if (isMovie) {
      if (hasEpisodeMarker(name)) return false;
      const boundaryIdx2 = toks.findIndex((t) => /^(19|20)\d{2}$/.test(t) || TECH_TOKEN_RE.test(t));
      const stem2 = boundaryIdx2 === -1 ? toks : toks.slice(0, boundaryIdx2);
      const foreign2 = stem2.filter(
        (t) => t.length > 1 && !NOISE_WORDS2.has(t) && !aliases.has(t) && !TECH_TOKEN_RE.test(t) && !/^(19|20)\d{2}$/.test(t) && !PART_WORD_RE.test(t)
      );
      if (foreign2.length > 0) return false;
      if (nameYear > 0 && mediaYear > 0 && Math.abs(nameYear - mediaYear) > 1) return false;
      return true;
    }
    if (!isLikelyBatchTitle(name) && !hasEpisodeMarker(name)) return false;
    const boundaryIdx = toks.findIndex((t) => BOUNDARY_TOKEN_RE.test(t));
    const stem = boundaryIdx === -1 ? toks : toks.slice(0, boundaryIdx);
    const foreign = stem.filter(
      (t) => t.length > 1 && !NOISE_WORDS2.has(t) && !aliases.has(t) && !TECH_TOKEN_RE.test(t) && !PART_WORD_RE.test(t)
    );
    if (foreign.length > 0) return false;
    if (expectedSeason > 0) {
      const s = seasonOfName(name);
      if (s > 0 && s !== expectedSeason) return false;
    }
    if (nameYear > 0 && mediaYear > 0 && Math.abs(nameYear - mediaYear) > 1) return false;
    return true;
  }
  function matchesEpisode(row, episode, season, offset) {
    let ep = row.episode;
    if (ep !== episode && !(offset > 0 && episode > offset && ep === episode - offset)) {
      const abs = /(?:^|[\s\-_\[]v?\d*\s?)(\d{1,4})(?:[\s\-_\].]|$)/.exec(row.name);
      if (!abs || Number.parseInt(abs[1], 10) !== episode) return false;
    }
    if (season <= 0) return true;
    return row.season === 0 || row.season === season;
  }
  function parseRows(html, searchUrl) {
    const doc = caye.html.parse(html);
    const rows = [];
    doc.find("table.table tbody tr").each((_, el) => {
      var _a;
      const cells = el.find("td");
      if (cells.length < 6) return true;
      const titleLink = cells.eq(1).find('a[href^="magnet:"]').first();
      const magnet = ((_a = titleLink.attr("href")) == null ? void 0 : _a.trim()) || "";
      const title = (titleLink.attr("title") || titleLink.text() || "").trim();
      if (!title || !magnet) return true;
      let infoHash = "";
      const candidates = [
        el.attr("data-id") || "",
        cells.eq(1).find("span.copy-to-clipboard").first().attr("data-copy-to-clipboard-content") || "",
        extractInfoHashFromMagnet(magnet)
      ];
      for (const c of candidates) {
        if (!c) continue;
        try {
          infoHash = normalizeInfoHash(c);
          break;
        } catch (e) {
        }
      }
      const sizeCell = cells.eq(2);
      const sizeTitle = sizeCell.attr("title") || "";
      let size = 0;
      const byteMatch = /([\d.]+)\s*Bytes/i.exec(sizeTitle);
      if (byteMatch) size = Math.round(Number.parseFloat(byteMatch[1]));
      if (!size) size = parseSize(sizeCell.text().trim());
      const dateCell = cells.eq(3);
      const publishedAt = parseIsoDate(caye, dateCell.attr("title") || dateCell.text(), [
        "2006-01-02 15:04:05",
        "2006-01-02"
      ]);
      const seeders = Number.parseInt(cells.eq(4).text().trim(), 10) || 0;
      const leechers = Number.parseInt(cells.eq(5).text().trim(), 10) || 0;
      const isBatch = isLikelyBatchTitle(title);
      const episode = isBatch ? -1 : extractSingleEpisode(caye, title);
      rows.push({
        name: title,
        magnet,
        infoHash,
        size,
        publishedAt,
        seeders,
        leechers,
        pageUrl: searchUrl,
        resolution: extractResolution(caye, title),
        isBatch,
        episode,
        season: seasonOfName(title)
      });
      return true;
    });
    return rows;
  }
  function categoryFor(media, query) {
    if (media.isMovie) return CAT_MOVIES;
    if (media.isAnime) return CAT_ANIME;
    if (query.itemId) return CAT_TV;
    return CAT_ALL;
  }
  function scrapePages(queryStr, category, maxItems) {
    return __async(this, null, function* () {
      const seen = /* @__PURE__ */ new Set();
      const out = [];
      for (let page = 1; page <= 3; page++) {
        const searchUrl = `${BASE_URL}/search/${encodeURIComponent(queryStr)}/${category}/${page}/`;
        const res = yield fetchText(caye, "Knaben", searchUrl, {
          headers: { Accept: "text/html", Referer: `${BASE_URL}/` }
        });
        const rows = parseRows(res.body, searchUrl);
        if (rows.length === 0) break;
        let added = 0;
        for (const r of rows) {
          const key = (r.infoHash || r.magnet || r.name).toLowerCase();
          if (seen.has(key)) continue;
          seen.add(key);
          out.push(r);
          added++;
          if (out.length >= maxItems) return out;
        }
        if (added === 0) break;
      }
      return out;
    });
  }
  function toOption(row, confirmed) {
    const key = row.infoHash || row.name.toLowerCase().replace(/[^a-z0-9]+/g, "-").slice(0, 40);
    return createTorrentOption(caye, {
      id: `knaben-${key}`,
      key,
      providerId: PROVIDER_ID,
      name: row.name,
      magnet: row.magnet,
      pageUrl: row.pageUrl,
      size: row.size > 0 ? row.size : void 0,
      seeders: row.seeders,
      leechers: row.leechers,
      publishedAt: row.publishedAt,
      resolution: row.resolution || void 0,
      confirmed
    });
  }
  function find(_context, query) {
    return __async(this, null, function* () {
      var _a;
      const media = yield resolveMediaContext(caye, query);
      const rawBase = ((_a = query.text) == null ? void 0 : _a.trim()) || media.englishTitle || media.romajiTitle || "";
      if (!rawBase) {
        throw failure("unsupported", "Enter a title to search.");
      }
      const split = splitSeasonMarker(rawBase);
      const base = split.base;
      const season = query.season && query.season > 0 ? query.season : split.season;
      const category = categoryFor(media, query);
      const aliases = buildAliasTokens([rawBase, ...media.titles]);
      const mediaYear = media.year || 0;
      const limit = clampLimit(query.limit, 50, 100);
      const isSmart = Boolean(query.batch || query.number && query.number > 0 || query.itemId);
      if (!isSmart) {
        const rows = yield scrapePages(base, category, limit);
        const items2 = rows.slice(0, limit).map((r) => toOption(r, false));
        yield cacheOptions(caye, "knaben", items2);
        return { items: items2, state: "complete" };
      }
      let q = base;
      if (media.isMovie) {
        if (mediaYear > 0) q += ` ${mediaYear}`;
      } else if (query.batch) {
        q += " complete";
      } else if (query.number && query.number > 0) {
        const s = season > 0 ? season : 1;
        q += ` S${String(s).padStart(2, "0")}E${String(Math.trunc(query.number)).padStart(2, "0")}`;
      }
      if (query.resolution) q += ` ${query.resolution}`;
      const fallback = () => __async(null, null, function* () {
        const fb = query.resolution ? `${base} ${query.resolution}` : base;
        return yield scrapePages(fb, category, limit);
      });
      let chosen = [];
      if (!media.isMovie && query.batch) {
        let rows = yield scrapePages(q, category, limit);
        if (rows.length === 0) {
          rows = (yield fallback()).filter((r) => r.isBatch);
        }
        chosen = rows.filter(
          (r) => r.isBatch && belongsToMedia(r.name, aliases, false, season, mediaYear)
        );
      }
      if (chosen.length === 0 && !media.isMovie && query.number && query.number > 0) {
        const epNum = Math.trunc(query.number);
        const keep = (r) => r.isBatch || matchesEpisode(r, epNum, season, media.absoluteSeasonOffset);
        let rows = query.batch ? yield fallback() : yield scrapePages(q, category, limit);
        chosen = rows.filter(
          (r) => belongsToMedia(r.name, aliases, false, season, mediaYear) && keep(r)
        );
        if (chosen.length === 0) {
          rows = yield fallback();
          chosen = rows.filter(
            (r) => belongsToMedia(r.name, aliases, false, season, mediaYear) && keep(r)
          );
        }
      } else if (chosen.length === 0) {
        let rows = yield scrapePages(q, category, limit);
        if (rows.length === 0) rows = yield fallback();
        chosen = rows.filter(
          (r) => belongsToMedia(r.name, aliases, media.isMovie, season, mediaYear)
        );
      }
      const confirmed = Boolean(!query.batch && query.number && query.number > 0);
      const items = chosen.slice(0, limit).map((r) => toOption(r, confirmed));
      yield cacheOptions(caye, "knaben", items);
      return { items, state: "complete" };
    });
  }
  function resolve(_context, input) {
    return __async(this, null, function* () {
      return yield resolveCachedOrFallback(
        caye,
        "knaben",
        input,
        "Unknown or uncached Knaben option."
      );
    });
  }
  caye.register(PROVIDER_ID, { acquisition: { find, resolve } });
})();
//# sourceMappingURL=backend.js.map
