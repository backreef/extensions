import type { API, Ref, SourceRecord } from "../../../../packages/plugin-sdk/src/index.ts"
import {
    buildChapterList,
    createMangaSource,
    fetchText,
    makeDirectPageResolver,
    parseChapterNumber,
    type ParsedChapterInput,
    type RawPageInput,
} from "../../manga-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"
import { resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.mangafreak:source"
const providerName = "MangaFreak"
const siteUrl = "https://ww2.mangafreak.me"

async function findPages(_context: unknown, ref: Ref): Promise<RawPageInput[]> {
    const chapterPath = ref.nativeId.replace(/^\/+/, "")
    const pageUrl = `${siteUrl}/${chapterPath}`
    const res = await fetchText(providerName, pageUrl)
    const doc = caye.html.parse(res.text)

    const pages: RawPageInput[] = []
    doc.find("div.mySlides.fade img").each((_, el) => {
        const src = el.attr("src") || el.attr("data-src") || ""
        const resolved = resolveUrl(src, res.url || pageUrl)
        if (resolved) pages.push({ url: resolved })
    })
    return pages
}

const mangafreakSource = createMangaSource({
    providerId,
    providerName,

    async search(_context, text) {
        const url = `${siteUrl}/Find/${encodeURIComponent(text)}`
        const res = await fetchText(providerName, url)
        const doc = caye.html.parse(res.text)

        const records: SourceRecord[] = []
        const seen = new Set<string>()
        doc.find("div.search_result div.manga_search_item").each((_, el) => {
            const link = el.find("h3 a").first()
            const href = link.attr("href") || ""
            const parts = href.split("/Manga/")
            const nativeId = parts[1]?.replace(/^\/+|\/+$/g, "") ?? ""
            const title = link.text().trim()
            if (!nativeId || !title || seen.has(nativeId)) return
            seen.add(nativeId)
            records.push({
                ref: { providerId, type: "manga", nativeId },
                name: title,
            })
        })

        if (records.length === 0 && !res.text.toLowerCase().includes("mangafreak")) {
            throw failure("unavailable", `${providerName} returned unexpected search page.`)
        }
        return records
    },

    async read(_context, ref) {
        const url = `${siteUrl}/Manga/${encodeURIComponent(ref.nativeId)}`
        const res = await fetchText(providerName, url)
        const doc = caye.html.parse(res.text)
        const name =
            doc.find("div.manga_series_data h1").first().text().trim() ||
            doc.find("h1").first().text().trim()
        if (!name) {
            throw failure("unavailable", `${providerName} title not found.`)
        }
        return { name }
    },

    async list(_context, ref) {
        const url = `${siteUrl}/Manga/${encodeURIComponent(ref.nativeId)}`
        const res = await fetchText(providerName, url)
        const doc = caye.html.parse(res.text)

        const entries: ParsedChapterInput[] = []
        const collectLink = (linkHtml: ReturnType<typeof doc.find>) => {
            const href = linkHtml.attr("href") || ""
            const titleWithDate = linkHtml.text().trim()
            if (!href || !titleWithDate) return
            const chapterId = href.replace(/^\/+/, "").split("/")[0]
            if (!chapterId) return
            const headPart = titleWithDate.split(" - ")[0] ?? titleWithDate
            entries.push({
                nativeId: chapterId,
                name: titleWithDate,
                number: parseChapterNumber(headPart),
            })
        }

        doc.find("div.manga_series_list table tr").each((_, row) => {
            const link = row.find("td:first-child a").first()
            if (link.length > 0) collectLink(link)
        })
        doc.find("div.series_sub_chapter_list div a").each((_, link) => {
            collectLink(link)
        })

        if (entries.length === 0 && !doc.find("h1").first().text().trim()) {
            throw failure("unavailable", `${providerName} chapters page unavailable.`)
        }
        return buildChapterList(providerId, entries, { sortByNumber: true })
    },

    findPages,

    resolveTarget: makeDirectPageResolver(
        (ref) => ({ Referer: `${siteUrl}/${ref.nativeId.replace(/^\/+/, "")}` }),
        findPages,
    ),
})

caye.register(providerId, { source: mangafreakSource })
