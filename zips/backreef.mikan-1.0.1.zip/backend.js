(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __objRest = (source, exclude) => {
    var target = {};
    for (var prop in source)
      if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
        target[prop] = source[prop];
    if (source != null && __getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(source)) {
        if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
          target[prop] = source[prop];
      }
    return target;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve2, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve2(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../../../packages/plugin-std/src/magnet.ts
  var BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  function decodeBase32(input) {
    const cleaned = input.trim().toUpperCase().replace(/=+$/, "");
    if (!cleaned || !/^[A-Z2-7]+$/.test(cleaned)) {
      throw new TypeError("Invalid base32 string");
    }
    const bytes = [];
    let buffer = 0;
    let bitsLeft = 0;
    for (let i = 0; i < cleaned.length; i++) {
      const val = BASE32_ALPHABET.indexOf(cleaned[i]);
      buffer = buffer << 5 | val;
      bitsLeft += 5;
      if (bitsLeft >= 8) {
        bitsLeft -= 8;
        bytes.push(buffer >>> bitsLeft & 255);
      }
    }
    return new Uint8Array(bytes);
  }
  function bytesToHex(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i++) {
      out += bytes[i].toString(16).padStart(2, "0");
    }
    return out;
  }
  function normalizeInfoHash(raw) {
    const trimmed = raw.trim();
    if (/^[0-9a-fA-F]{40}$/.test(trimmed)) {
      return trimmed.toLowerCase();
    }
    if (/^[A-Za-z2-7]{32}=*$/.test(trimmed)) {
      const decoded = decodeBase32(trimmed);
      if (decoded.length === 20) {
        return bytesToHex(decoded);
      }
    }
    throw new TypeError(`Invalid infoHash: ${raw}`);
  }
  function parseMagnet(uri) {
    var _a;
    const trimmed = uri.trim();
    if (!/^magnet:\?/i.test(trimmed)) {
      throw new TypeError("Invalid magnet URI");
    }
    const query = trimmed.slice(trimmed.indexOf("?") + 1);
    const params = new URLSearchParams(query);
    let infoHash = "";
    for (const xt of params.getAll("xt")) {
      const match = xt.match(/^urn:btih:([0-9a-fA-F]{40}|[A-Za-z2-7]{32}=*)$/i);
      if (match) {
        infoHash = normalizeInfoHash(match[1]);
        break;
      }
    }
    if (!infoHash) {
      throw new TypeError("Magnet URI missing valid btih infoHash");
    }
    const name = (_a = params.get("dn")) != null ? _a : "";
    const seen = /* @__PURE__ */ new Set();
    const trackers = [];
    for (const tr of params.getAll("tr")) {
      const t = tr.trim();
      if (t && !seen.has(t)) {
        seen.add(t);
        trackers.push(t);
      }
    }
    const xlRaw = params.get("xl");
    let size = 0;
    if (xlRaw && /^\d+$/.test(xlRaw.trim())) {
      size = Number.parseInt(xlRaw.trim(), 10);
    }
    return { infoHash, name, trackers, size };
  }
  function buildMagnet(options) {
    const infoHash = normalizeInfoHash(options.infoHash);
    const parts = [`magnet:?xt=urn:btih:${infoHash}`];
    if (options.name) {
      parts.push(`dn=${encodeURIComponent(options.name)}`);
    }
    if (options.trackers) {
      const seen = /* @__PURE__ */ new Set();
      for (const tr of options.trackers) {
        const trimmed = tr.trim();
        if (trimmed && !seen.has(trimmed)) {
          seen.add(trimmed);
          parts.push(`tr=${encodeURIComponent(trimmed)}`);
        }
      }
    }
    return parts.join("&");
  }
  function parseTorrent(api, bytes) {
    const infoHash = api.crypto.digest("sha1", api.bencode.raw(bytes, "info"), { output: "hex" }).toLowerCase();
    const trackers = [];
    let name = "";
    try {
      const decoded = api.bencode.decode(bytes);
      const add = (value) => {
        if (typeof value === "string" && value.trim() && !trackers.includes(value.trim())) {
          trackers.push(value.trim());
        }
      };
      add(decoded.announce);
      if (Array.isArray(decoded["announce-list"])) {
        for (const tier of decoded["announce-list"]) {
          if (Array.isArray(tier)) tier.forEach(add);
          else add(tier);
        }
      }
      const info = decoded.info;
      if (typeof (info == null ? void 0 : info.name) === "string") name = info.name.trim();
    } catch (e) {
    }
    return { infoHash, name, trackers };
  }

  // ../../../packages/plugin-std/src/titles.ts
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../../../packages/plugin-std/src/limit.ts
  function mapLimit(items, limit, fn) {
    return __async(this, null, function* () {
      if (items.length === 0) return [];
      const concurrency = Math.max(1, Math.floor(limit));
      const out = new Array(items.length);
      let next = 0;
      const worker = () => __async(null, null, function* () {
        while (next < items.length) {
          const index = next++;
          out[index] = yield fn(items[index], index);
        }
      });
      yield Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
      return out;
    });
  }

  // ../torrent-common/src/option.ts
  var DEFAULT_TRACKERS = [
    "http://nyaa.tracker.wf:7777/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce"
  ];
  var MAX_RETRIEVAL_URI_LENGTH = 2e3;
  function numberValue(value) {
    return { kind: "number", number: value };
  }
  function makeFact(producerId, id, field, value, at = (/* @__PURE__ */ new Date()).toISOString()) {
    return {
      id,
      producerId,
      field,
      value: numberValue(value),
      locale: "",
      region: "",
      status: "complete",
      at
    };
  }
  function buildCountsFacts(producerId, key, counts) {
    const at = (/* @__PURE__ */ new Date()).toISOString();
    const facts = [];
    if (counts.size !== void 0 && Number.isFinite(counts.size) && counts.size > 0) {
      facts.push(makeFact(producerId, `size-${key}`, "size", counts.size, at));
    }
    if (counts.seeders !== void 0 && Number.isFinite(counts.seeders) && counts.seeders >= 0) {
      facts.push(makeFact(producerId, `seeders-${key}`, "seeders", counts.seeders, at));
    }
    if (counts.leechers !== void 0 && Number.isFinite(counts.leechers) && counts.leechers >= 0) {
      facts.push(makeFact(producerId, `leechers-${key}`, "leechers", counts.leechers, at));
    }
    if (counts.downloads !== void 0 && Number.isFinite(counts.downloads) && counts.downloads > 0) {
      facts.push(makeFact(producerId, `downloads-${key}`, "downloads", counts.downloads, at));
    }
    return facts;
  }
  function parseIsoDate(caye2, raw, layouts) {
    var _a;
    const trimmed = raw == null ? void 0 : raw.trim();
    if (!trimmed) return void 0;
    if (typeof ((_a = caye2.time) == null ? void 0 : _a.parse) === "function") {
      try {
        const ms = caye2.time.parse(trimmed, layouts ? { layouts } : void 0);
        if (Number.isFinite(ms)) {
          return new Date(ms).toISOString();
        }
      } catch (e) {
      }
    }
    const parsed = Date.parse(trimmed);
    if (Number.isFinite(parsed)) {
      return new Date(parsed).toISOString();
    }
    return void 0;
  }
  function pickUri(magnet, torrentUrl) {
    if (magnet && Array.from(magnet).length <= MAX_RETRIEVAL_URI_LENGTH) {
      return magnet;
    }
    return torrentUrl || magnet || "";
  }
  function createTorrentOption(caye2, input) {
    var _a, _b, _c, _d;
    const uri = pickUri(input.magnet, input.torrentUrl);
    const facts = buildCountsFacts(input.providerId, input.key, {
      size: input.size,
      seeders: input.seeders,
      leechers: input.leechers,
      downloads: input.downloads
    });
    let resolution = ((_a = input.resolution) == null ? void 0 : _a.trim()) || "";
    let group = ((_b = input.group) == null ? void 0 : _b.trim()) || "";
    if ((!resolution || !group) && typeof ((_c = caye2.release) == null ? void 0 : _c.parse) === "function") {
      try {
        const parsed = caye2.release.parse(input.name);
        if (!resolution && parsed.resolution) resolution = parsed.resolution;
        if (!group && parsed.group) group = parsed.group;
      } catch (e) {
      }
    }
    const option = {
      id: input.id,
      name: input.name,
      kind: "torrent",
      uri,
      files: [],
      facts,
      availability: "available",
      eligible: true,
      reasons: [],
      confirmed: Boolean(input.confirmed)
    };
    if (input.seeders !== void 0 && Number.isFinite(input.seeders) && input.seeders >= 0) {
      option.seeders = Math.trunc(input.seeders);
    }
    if (input.size !== void 0 && Number.isFinite(input.size) && input.size > 0) {
      option.size = Math.round(input.size);
    }
    if (input.publishedAt) option.publishedAt = input.publishedAt;
    if (input.pageUrl && /^https?:\/\//i.test(input.pageUrl)) {
      option.pageUrl = input.pageUrl;
    }
    if ((_d = input.magnet) == null ? void 0 : _d.startsWith("magnet:")) {
      option.magnet = input.magnet;
    }
    if (resolution) option.resolution = resolution;
    if (group) option.group = group;
    if (input.best) option.best = true;
    return option;
  }
  var missingMessage = (service) => `${service} no longer lists this torrent.`;
  function fetchText(caye2, service, url, options) {
    return __async(this, null, function* () {
      var _b, _c;
      const _a = options != null ? options : {}, { missingOn404 } = _a, input = __objRest(_a, ["missingOn404"]);
      const response = yield httpClient(caye2, service).send(
        __spreadProps(__spreadValues({}, input), { url }),
        missingOn404 ? { missing: missingMessage(service) } : void 0
      );
      return {
        status: response.status,
        headers: (_b = response.headers) != null ? _b : {},
        body: (_c = response.body) != null ? _c : "",
        url: response.url
      };
    });
  }
  function fetchJson(caye2, service, url, options) {
    return __async(this, null, function* () {
      const res = yield fetchText(caye2, service, url, options);
      if (!res.body) {
        throw failure("unavailable", `${service} returned an empty response.`);
      }
      try {
        return JSON.parse(res.body);
      } catch (e) {
        throw failure("unavailable", `${service} returned malformed JSON.`);
      }
    });
  }
  function torrentUrlToMagnet(caye2, service, torrentUrl, options) {
    return __async(this, null, function* () {
      var _a;
      const body = yield httpClient(caye2, service).base64(
        { url: torrentUrl, headers: options == null ? void 0 : options.headers },
        (options == null ? void 0 : options.missingOn404) ? { missing: missingMessage(service) } : void 0
      );
      let torrent;
      try {
        torrent = parseTorrent(caye2, caye2.encoding.base64.decode(body));
      } catch (e) {
        throw failure("unavailable", `${service} returned an invalid torrent file.`);
      }
      const trackers = [...torrent.trackers, ...(_a = options == null ? void 0 : options.extraTrackers) != null ? _a : []];
      return {
        infoHash: torrent.infoHash,
        magnet: buildMagnet({
          infoHash: torrent.infoHash,
          name: (options == null ? void 0 : options.fallbackName) || torrent.name || void 0,
          trackers: trackers.length > 0 ? trackers : DEFAULT_TRACKERS
        })
      };
    });
  }

  // ../../../packages/plugin-std/src/cache.ts
  function getCachedJson(api, key) {
    return __async(this, null, function* () {
      try {
        const value = yield api.cache.get({ key });
        if ((value == null ? void 0 : value.kind) === "text") return JSON.parse(value.text);
      } catch (e) {
      }
      return void 0;
    });
  }
  function setCachedJson(api, key, value, ttlSeconds) {
    return __async(this, null, function* () {
      try {
        yield api.cache.set({
          key,
          value: { kind: "text", text: JSON.stringify(value) },
          ttlSeconds
        });
      } catch (e) {
      }
    });
  }

  // ../torrent-common/src/smart.ts
  var OPTION_CACHE_TTL_SECONDS = 7 * 24 * 60 * 60;
  function parseResolutionNumber(raw) {
    if (!raw) return 0;
    const lower = raw.trim().toLowerCase();
    if (lower === "4k" || lower === "uhd") return 2160;
    if (lower === "8k") return 4320;
    const match = /(\d{3,4})/.exec(lower);
    return match ? Number.parseInt(match[1], 10) : 0;
  }
  function normalizeResolutionLabel(raw) {
    const n = parseResolutionNumber(raw);
    if (n >= 360 && n <= 4320) return `${n}p`;
    return "";
  }
  function extractResolution(caye2, title) {
    try {
      const parsed = caye2.release.parse(title);
      if (parsed.resolution) {
        const normalized = normalizeResolutionLabel(parsed.resolution);
        if (normalized) return normalized;
      }
    } catch (e) {
    }
    if (/\b(?:4k|2160p?|uhd)\b/i.test(title)) return "2160p";
    const match = /\b(\d{3,4})\s*p\b/i.exec(title);
    if (match) {
      const normalized = normalizeResolutionLabel(match[1]);
      if (normalized) return normalized;
    }
    return "";
  }
  function parseEpisodesFromTitle(caye2, title) {
    var _a;
    const out = [];
    try {
      const parsed = caye2.release.parse(title);
      for (const raw of (_a = parsed.episodes) != null ? _a : []) {
        const n = Number.parseInt(raw, 10);
        if (Number.isInteger(n) && n >= 0 && !out.includes(n)) out.push(n);
      }
    } catch (e) {
    }
    return out;
  }
  function extractSingleEpisode(caye2, title) {
    const eps = parseEpisodesFromTitle(caye2, title);
    if (eps.length === 1) return eps[0];
    return -1;
  }
  function extractEpisodeRange(caye2, title) {
    const eps = parseEpisodesFromTitle(caye2, title);
    if (eps.length > 1) {
      return [Math.min(...eps), Math.max(...eps)];
    }
    const match = /\b0*(\d{1,3})\s*[-~～—]\s*0*(\d{1,3})\b/.exec(title);
    if (!match) return void 0;
    const a = Number.parseInt(match[1], 10);
    const b = Number.parseInt(match[2], 10);
    if (a <= 0 || b <= 0 || a === b) return void 0;
    return a < b ? [a, b] : [b, a];
  }
  function isLikelyBatchTitle(title) {
    if (/\b(?:batch|complete(?:\s+series)?|collection|box\s*set|boxset|all\s+seasons|integrale)\b/i.test(
      title
    )) {
      return true;
    }
    if (/(?:合集|全集|完整|全話|全\s*\d+\s*[話话卷]|第\s*\d+\s*[-~～—]\s*\d+\s*[集話话])/.test(
      title
    )) {
      return true;
    }
    if (/S\d{1,2}E\d{1,3}\s*(?:~|-|–|—)\s*E?\d{1,3}/i.test(title)) return true;
    if (/\bS\d{1,2}\s*-\s*BATCH\b/i.test(title)) return true;
    const range = /\b0*(\d{1,3})\s*[-~～—]\s*0*(\d{1,3})\b/.exec(title);
    if (range) {
      const s = Number.parseInt(range[1], 10);
      const e = Number.parseInt(range[2], 10);
      if (e > s && s >= 1 && e <= 300) return true;
    }
    return false;
  }
  function filterByResolution(items, wanted, fallbackWhenEmpty = true) {
    const target = parseResolutionNumber(wanted);
    if (!target) return items;
    const matched = items.filter((item) => {
      const res = parseResolutionNumber(item.resolution || item.name);
      return res === target;
    });
    if (matched.length > 0 || !fallbackWhenEmpty) return matched;
    return items;
  }
  function clampLimit(limit, fallback = 50, max = 100) {
    return Math.min(Math.max(limit || fallback, 1), max);
  }
  function cacheOptions(_0, _1, _2) {
    return __async(this, arguments, function* (caye2, prefix, options, ttlSeconds = OPTION_CACHE_TTL_SECONDS) {
      for (const option of options) {
        yield setCachedJson(caye2, `${prefix}:option:${option.id}`, option, ttlSeconds);
      }
    });
  }
  function validateHttpUrl(raw) {
    const trimmed = (raw == null ? void 0 : raw.trim()) || "";
    if (!trimmed) return void 0;
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol === "http:" || parsed.protocol === "https:") {
        return parsed.toString();
      }
    } catch (e) {
    }
    return void 0;
  }
  function resolveFromRetrievalInput(caye2, providerId, prefix, input, notFoundMessage, defaultGroup) {
    var _a, _b, _c, _d;
    const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
    const rawMagnet = ((_b = input.magnet) == null ? void 0 : _b.trim()) || "";
    const rawInfoHash = ((_c = input.infoHash) == null ? void 0 : _c.trim()) || "";
    const rawTorrentUrl = ((_d = input.torrentUrl) == null ? void 0 : _d.trim()) || "";
    const hasRetrieval = Boolean(rawMagnet || rawInfoHash || rawTorrentUrl);
    if (!hasRetrieval) return void 0;
    if (optionId && !optionId.startsWith(`${prefix}-`)) {
      throw failure("missing", notFoundMessage);
    }
    const validTorrentUrl = rawTorrentUrl ? validateHttpUrl(rawTorrentUrl) : void 0;
    if (rawTorrentUrl && !validTorrentUrl) {
      throw failure("missing", "Invalid torrent retrieval URL.");
    }
    if (rawMagnet) {
      let parsed;
      try {
        parsed = parseMagnet(rawMagnet);
      } catch (e) {
        throw failure("missing", "Invalid magnet retrieval URI.");
      }
      const id = optionId || `${prefix}-${parsed.infoHash}`;
      return createTorrentOption(caye2, {
        id,
        key: parsed.infoHash,
        providerId,
        name: parsed.name || `${prefix} ${parsed.infoHash}`,
        magnet: rawMagnet,
        torrentUrl: validTorrentUrl,
        size: parsed.size > 0 ? parsed.size : void 0,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (rawInfoHash) {
      let infoHash = "";
      try {
        infoHash = normalizeInfoHash(rawInfoHash);
      } catch (e) {
        throw failure("missing", "Invalid torrent info hash.");
      }
      const id = optionId || `${prefix}-${infoHash}`;
      const magnet = buildMagnet({ infoHash, trackers: DEFAULT_TRACKERS });
      return createTorrentOption(caye2, {
        id,
        key: infoHash,
        providerId,
        name: `${prefix} ${infoHash}`,
        magnet,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (validTorrentUrl) {
      const id = optionId || `${prefix}-torrent`;
      const key = id.startsWith(`${prefix}-`) ? id.slice(prefix.length + 1) : id;
      return createTorrentOption(caye2, {
        id,
        key,
        providerId,
        name: `${prefix} ${key}`,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    return void 0;
  }
  function resolveCachedOrFallback(caye2, prefix, input, notFoundMessage, fetchFallback, options) {
    return __async(this, null, function* () {
      var _a;
      const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
      if (!optionId && !input.magnet && !input.torrentUrl && !input.infoHash) {
        throw failure("missing", notFoundMessage);
      }
      if (optionId && !optionId.startsWith(`${prefix}-`)) {
        throw failure("missing", notFoundMessage);
      }
      if (optionId) {
        const cached = yield getCachedJson(caye2, `${prefix}:option:${optionId}`);
        if (cached && cached.id === optionId) {
          return cached;
        }
      }
      if (fetchFallback && optionId) {
        try {
          return yield fetchFallback(optionId);
        } catch (err) {
          const code = err == null ? void 0 : err.code;
          if (code !== "missing" && code !== "unavailable" && code !== "rate-limited") throw err;
          const fallback2 = resolveFromRetrievalInput(
            caye2,
            (options == null ? void 0 : options.providerId) || `backreef.${prefix}:search`,
            prefix,
            input,
            notFoundMessage,
            options == null ? void 0 : options.group
          );
          if (fallback2) return fallback2;
          throw err;
        }
      }
      const fallback = resolveFromRetrievalInput(
        caye2,
        (options == null ? void 0 : options.providerId) || `backreef.${prefix}:search`,
        prefix,
        input,
        notFoundMessage,
        options == null ? void 0 : options.group
      );
      if (fallback) return fallback;
      throw failure("missing", notFoundMessage);
    });
  }
  function connectionStringConfig(context, key, fallback) {
    var _a;
    const raw = (_a = context.config) == null ? void 0 : _a[key];
    if (typeof raw === "string" && raw.trim()) {
      return raw.trim();
    }
    return fallback;
  }
  function resolveBgmTitles(caye2, cachePrefix, bgmId) {
    return __async(this, null, function* () {
      var _a, _b;
      const cacheKey = `${cachePrefix}:bgm:${bgmId}`;
      const cached = yield getCachedJson(caye2, cacheKey);
      if (Array.isArray(cached) && cached.length > 0) return cached;
      for (const ep of ["https://api.bgm.tv/v0/subjects/", "https://api.bangumi.lol/v0/subjects/"]) {
        try {
          const data = yield fetchJson(
            caye2,
            "Bangumi",
            ep + encodeURIComponent(bgmId),
            {
              headers: {
                Accept: "application/json",
                "User-Agent": `caye-${cachePrefix}/1.0`
              }
            }
          );
          const out = [];
          if ((_a = data.name_cn) == null ? void 0 : _a.trim()) out.push(data.name_cn.trim());
          if (((_b = data.name) == null ? void 0 : _b.trim()) && !out.includes(data.name.trim())) out.push(data.name.trim());
          if (out.length > 0) {
            yield setCachedJson(caye2, cacheKey, out, OPTION_CACHE_TTL_SECONDS);
            return out;
          }
        } catch (e) {
        }
      }
      return [];
    });
  }

  // ../torrent-common/src/media.ts
  function asRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return void 0;
    return value;
  }
  function positiveIntString(value) {
    if (typeof value === "number") {
      return Number.isInteger(value) && value > 0 ? String(value) : void 0;
    }
    if (typeof value === "string") {
      const trimmed = value.trim();
      return /^[1-9][0-9]*$/.test(trimmed) ? trimmed : void 0;
    }
    return void 0;
  }
  function addUniqueTitle(target, raw) {
    if (typeof raw !== "string") return;
    const trimmed = raw.trim();
    if (trimmed && !target.includes(trimmed)) {
      target.push(trimmed);
    }
  }
  function extractEntriesIds(entriesValue, preferredNative) {
    if (!Array.isArray(entriesValue)) return {};
    let anilistId;
    let anidbId;
    let malId;
    let bgmId;
    const inspect = (requireMatch) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      for (const rawEntry of entriesValue) {
        const entry = asRecord(rawEntry);
        if (!entry) continue;
        const ref = asRecord(entry.ref);
        if (requireMatch && preferredNative) {
          if ((ref == null ? void 0 : ref.providerId) !== preferredNative.entry.providerId || (ref == null ? void 0 : ref.nativeId) !== preferredNative.entry.nativeId) {
            continue;
          }
        }
        const ids = asRecord(entry.ids);
        if (ids) {
          anilistId != null ? anilistId : anilistId = positiveIntString((_b = (_a = ids.anilistid) != null ? _a : ids.anilistId) != null ? _b : ids.anilist);
          anidbId != null ? anidbId : anidbId = positiveIntString((_d = (_c = ids.anidbid) != null ? _c : ids.anidbId) != null ? _d : ids.anidb);
          malId != null ? malId : malId = positiveIntString((_f = (_e = ids.malid) != null ? _e : ids.malId) != null ? _f : ids.mal);
          bgmId != null ? bgmId : bgmId = positiveIntString((_i = (_h = (_g = ids.bgmid) != null ? _g : ids.bgmId) != null ? _h : ids.bgm) != null ? _i : ids.bangumi);
        }
        if ((ref == null ? void 0 : ref.providerId) === "caye.anilist:catalog" || (ref == null ? void 0 : ref.providerId) === "anilist" || typeof (ref == null ? void 0 : ref.providerId) === "string" && ref.providerId.includes("anilist")) {
          anilistId != null ? anilistId : anilistId = positiveIntString(ref.nativeId);
        }
      }
    };
    if (preferredNative) inspect(true);
    inspect(false);
    return { anilistId, anidbId, malId, bgmId };
  }
  function extractFieldMap(fieldsValue) {
    const out = {};
    if (!Array.isArray(fieldsValue)) return out;
    for (const rawField of fieldsValue) {
      const entry = asRecord(rawField);
      if (!entry || typeof entry.field !== "string") continue;
      const val = asRecord(entry.value);
      if (val) out[entry.field] = val;
    }
    return out;
  }
  function parseDateParts(raw) {
    if (typeof raw !== "string") return void 0;
    const m = /^(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?/.exec(raw.trim());
    if (!m) return void 0;
    const year = Number.parseInt(m[1], 10);
    if (year < 1900 || year > 2100) return void 0;
    return {
      year,
      month: m[2] ? Number.parseInt(m[2], 10) : void 0,
      day: m[3] ? Number.parseInt(m[3], 10) : void 0
    };
  }
  function safeGetItem(caye2, itemId) {
    return __async(this, null, function* () {
      if (!itemId || typeof caye2.request !== "function") return void 0;
      try {
        const raw = yield caye2.request("getItem", { path: { itemId } });
        return asRecord(raw);
      } catch (e) {
        return void 0;
      }
    });
  }
  function pickPreferredNative(query) {
    var _a;
    const refs = (_a = query.native) != null ? _a : [];
    if (refs.length === 0) return void 0;
    const exact = refs.find((r) => r.itemId === query.itemId);
    if (exact) return exact;
    return refs[0];
  }
  function resolveMediaContext(caye2, query) {
    return __async(this, null, function* () {
      var _a, _b;
      const titles = [];
      let romajiTitle = "";
      let englishTitle = "";
      let originalTitle = "";
      const synonyms = [];
      let anilistId;
      let anidbId;
      let malId;
      let bgmId;
      let isMovie = false;
      let isAnime = false;
      let adult = false;
      let year;
      let startDate;
      let episodeCount;
      let releaseStatus;
      const preferredNative = pickPreferredNative(query);
      const item = yield safeGetItem(caye2, query.itemId || (preferredNative == null ? void 0 : preferredNative.itemId));
      const parentId = typeof (item == null ? void 0 : item.parentId) === "string" ? item.parentId : void 0;
      const parentItem = parentId ? yield safeGetItem(caye2, parentId) : void 0;
      const consumeTitlesObj = (rawTitles) => {
        const t = asRecord(rawTitles);
        if (!t) return;
        if (!romajiTitle && typeof t.romaji === "string") romajiTitle = t.romaji.trim();
        if (!englishTitle && typeof t.english === "string") englishTitle = t.english.trim();
        if (!originalTitle && typeof t.original === "string") originalTitle = t.original.trim();
        addUniqueTitle(titles, t.romaji);
        addUniqueTitle(titles, t.english);
        addUniqueTitle(titles, t.original);
      };
      const inspectRecord = (record) => {
        var _a2, _b2, _c, _d, _e, _f, _g, _h, _i, _j, _k;
        if (!record) return;
        if (record.adult === true) adult = true;
        const kindId = typeof record.kindId === "string" ? record.kindId : "";
        const kindLeaf = (kindId.includes(":") ? kindId.split(":")[1] : kindId).toLowerCase();
        if (kindLeaf === "movie") isMovie = true;
        if (kindLeaf === "anime" || kindId.toLowerCase().includes(":anime")) isAnime = true;
        const ids = extractEntriesIds(record.entries, preferredNative);
        anilistId != null ? anilistId : anilistId = ids.anilistId;
        anidbId != null ? anidbId : anidbId = ids.anidbId;
        malId != null ? malId : malId = ids.malId;
        bgmId != null ? bgmId : bgmId = ids.bgmId;
        if (anilistId || anidbId) isAnime = true;
        const parentSummary = asRecord(record.parent);
        if (parentSummary) {
          consumeTitlesObj(parentSummary.titles);
          addUniqueTitle(titles, parentSummary.name);
        }
        consumeTitlesObj(record.titles);
        addUniqueTitle(titles, record.name);
        const totalChildren = typeof record.totalChildren === "number" ? record.totalChildren : typeof record.childCount === "number" ? record.childCount : void 0;
        if (totalChildren !== void 0 && totalChildren > 0 && episodeCount === void 0) {
          episodeCount = totalChildren;
        }
        const fields = extractFieldMap(record.fields);
        if (((_a2 = fields["caye:adult"]) == null ? void 0 : _a2.boolean) === true) adult = true;
        const formatVal = typeof ((_b2 = fields["caye:format"]) == null ? void 0 : _b2.text) === "string" ? fields["caye:format"].text.trim() : "";
        if (/^movie$/i.test(formatVal)) isMovie = true;
        if (/^(?:tv|tv_short|ova|ona|special|anime)$/i.test(formatVal) && isAnime) isMovie = false;
        const romajiField = typeof ((_c = fields["caye:romaji"]) == null ? void 0 : _c.text) === "string" ? fields["caye:romaji"].text.trim() : "";
        const englishField = typeof ((_d = fields["caye:english"]) == null ? void 0 : _d.text) === "string" ? fields["caye:english"].text.trim() : "";
        const originalField = typeof ((_e = fields["caye:original"]) == null ? void 0 : _e.text) === "string" ? fields["caye:original"].text.trim() : "";
        if (!romajiTitle && romajiField) romajiTitle = romajiField;
        if (!englishTitle && englishField) englishTitle = englishField;
        if (!originalTitle && originalField) originalTitle = originalField;
        addUniqueTitle(titles, romajiField);
        addUniqueTitle(titles, englishField);
        addUniqueTitle(titles, originalField);
        if (!releaseStatus) {
          const statusVal = (_h = (_f = fields["caye:status"]) == null ? void 0 : _f.text) != null ? _h : (_g = fields["caye:releaseStatus"]) == null ? void 0 : _g.text;
          if (typeof statusVal === "string" && statusVal.trim()) releaseStatus = statusVal.trim();
        }
        if (!startDate) {
          const releaseAt = (_i = fields["caye:releaseAt"]) == null ? void 0 : _i.text;
          startDate = parseDateParts(releaseAt);
        }
        if (year === void 0) {
          const yNum = (_j = fields["caye:year"]) == null ? void 0 : _j.number;
          if (typeof yNum === "number" && yNum >= 1900 && yNum <= 2100) {
            year = Math.trunc(yNum);
          } else if (startDate) {
            year = startDate.year;
          }
        }
        for (const key of ["caye:titles", "caye:synonyms", "caye:alternativeTitles"]) {
          const list = (_k = fields[key]) == null ? void 0 : _k.list;
          if (Array.isArray(list)) {
            for (const v of list) {
              const obj = asRecord(v);
              if (typeof (obj == null ? void 0 : obj.text) === "string" && obj.text.trim()) {
                addUniqueTitle(synonyms, obj.text);
                addUniqueTitle(titles, obj.text);
              }
            }
          }
        }
      };
      inspectRecord(parentItem);
      inspectRecord(item);
      const text = ((_a = query.text) == null ? void 0 : _a.trim()) || "";
      if (text) {
        addUniqueTitle(titles, text);
      }
      if (!anilistId) {
        for (const ref of (_b = query.native) != null ? _b : []) {
          if (ref.entry.providerId === "caye.anilist:catalog" || ref.entry.providerId === "anilist" || ref.entry.providerId.includes("anilist")) {
            anilistId = positiveIntString(ref.entry.nativeId);
            if (anilistId) break;
          }
        }
      }
      const season = typeof query.season === "number" && query.season > 0 ? query.season : typeof (item == null ? void 0 : item.season) === "number" && item.season > 0 ? item.season : void 0;
      const number = typeof query.number === "number" && query.number > 0 ? query.number : typeof (item == null ? void 0 : item.number) === "number" && item.number > 0 ? item.number : void 0;
      const absolute = typeof query.absolute === "number" && query.absolute > 0 ? query.absolute : void 0;
      const absoluteSeasonOffset = absolute !== void 0 && number !== void 0 && absolute > number ? absolute - number : 0;
      return {
        text,
        titles,
        romajiTitle: romajiTitle || titles[0] || "",
        englishTitle: englishTitle || "",
        originalTitle,
        synonyms,
        anilistId,
        anidbId,
        malId,
        bgmId,
        season,
        number,
        absolute,
        isMovie,
        isAnime,
        adult,
        year,
        startDate: startDate != null ? startDate : year ? { year } : void 0,
        episodeCount,
        releaseStatus,
        absoluteSeasonOffset
      };
    });
  }

  // src/backend.ts
  var PROVIDER_ID = "backreef.mikan:search";
  var DEFAULT_BASE_URL = "https://mikanani.kas.pub";
  var MIKAN_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    Referer: "https://mikanime.tv/"
  };
  function extensionText(item, field) {
    var _a, _b, _c, _d;
    for (const ns of Object.values((_a = item.extensions) != null ? _a : {})) {
      const val = (_d = (_c = (_b = ns == null ? void 0 : ns[field]) == null ? void 0 : _b[0]) == null ? void 0 : _c.value) == null ? void 0 : _d.trim();
      if (val) return val;
    }
    return "";
  }
  function isBatchName(name) {
    if (isLikelyBatchTitle(name)) return true;
    if (/全\s*\d{1,2}\s*卷/.test(name)) return true;
    if (/\bS\d{1,2}\b(?!\s*[-–—]?\s*[\]\[Ex]*\d)/i.test(name)) return true;
    if (/Season\s+\d{1,2}/i.test(name) || /第\d+季/.test(name)) return true;
    return false;
  }
  function isSingleRelease(name) {
    return /OAD|OVA|OAV|SP\b|Special|Event|演唱会|Live|剧场版|Movie|Vol\.|Vol\s*\d|PV\b|CM\b|OST|特典|NCOP|NCED|Soundtrack|Trailer|Music/i.test(
      name
    );
  }
  function parseEpisodeNumber(title) {
    const jp = /第\s*0*(\d{1,4})\s*[話话集]/.exec(title);
    if (jp) {
      const n = Number.parseInt(jp[1], 10);
      if (n > 0 && n < 500) return n;
    }
    const bracket = /\[\s*0*(\d{1,3})\s*(?:v\d+)?\s*\]/.exec(title);
    if (bracket) {
      const n = Number.parseInt(bracket[1], 10);
      if (n > 0 && n < 500) return n;
    }
    return extractSingleEpisode(caye, title);
  }
  function isFullSeriesPack(name) {
    if (isSingleRelease(name) || isBatchName(name)) return false;
    if (parseEpisodeNumber(name) > 0) return false;
    if (/[-–—]\s*\d{1,3}(?=\s*(?:\[|\())/.test(name)) return false;
    return true;
  }
  function matchEpisodeText(title, epNum) {
    const padded = epNum < 10 ? `0${epNum}` : String(epNum);
    return new RegExp(
      `\\[${padded}\\]|\u7B2C0?${epNum}[\u96C6\u8A71\u8BDD]|[Ee][Pp]?${padded}\\b|[-\u2013\u2014]\\s*0?${epNum}(?=\\s*(?:\\[|\\()|$)`
    ).test(title);
  }
  function optionKey(link, torrentUrl, title) {
    const epMatch = /\/Episode\/([a-zA-Z0-9_-]+)/i.exec(link);
    if (epMatch) return epMatch[1];
    const torMatch = /\/([a-fA-F0-9]{40})\.torrent/i.exec(torrentUrl);
    if (torMatch) return torMatch[1].toLowerCase();
    const bytes = caye.encoding.utf8.encode(torrentUrl || link || title);
    return caye.crypto.digest("sha1", bytes, { output: "hex" }).slice(0, 16);
  }
  function parseFeedItems(xml, confirmed) {
    var _a, _b, _c, _d, _e, _f, _g;
    let feed;
    try {
      feed = caye.feed.parse(xml);
    } catch (e) {
      throw failure("unavailable", "Mikan returned an invalid RSS feed.");
    }
    const out = [];
    for (const item of (_a = feed.items) != null ? _a : []) {
      const title = ((_b = item.title) == null ? void 0 : _b.trim()) || "";
      const torrentUrl = ((_e = (_d = (_c = item.enclosures) == null ? void 0 : _c[0]) == null ? void 0 : _d.url) == null ? void 0 : _e.trim()) || "";
      const pageUrl = (item.link || extensionText(item, "link") || item.guid || "").trim();
      if (!title || !torrentUrl && !pageUrl) continue;
      const key = optionKey(pageUrl, torrentUrl, title);
      const lenStr = ((_g = (_f = item.enclosures) == null ? void 0 : _f[0]) == null ? void 0 : _g.length) || extensionText(item, "contentLength") || "0";
      const size = Number.parseInt(lenStr, 10) || 0;
      let publishedAt;
      if (typeof item.published === "number" && Number.isFinite(item.published)) {
        publishedAt = new Date(item.published).toISOString();
      } else if (typeof item.updated === "number" && Number.isFinite(item.updated)) {
        publishedAt = new Date(item.updated).toISOString();
      } else {
        const rawExtDate = extensionText(item, "pubDate");
        if (rawExtDate) publishedAt = parseIsoDate(caye, rawExtDate);
      }
      const resolution = extractResolution(caye, title);
      const isBatch = isBatchName(title) || isFullSeriesPack(title);
      const range = extractEpisodeRange(caye, title);
      const episode = isBatch ? -1 : parseEpisodeNumber(title);
      const option = createTorrentOption(caye, {
        id: `mikan-${key}`,
        key,
        providerId: PROVIDER_ID,
        name: title,
        torrentUrl: torrentUrl || pageUrl,
        pageUrl: pageUrl || void 0,
        size: size > 0 ? size : void 0,
        publishedAt,
        resolution: resolution || void 0,
        confirmed
      });
      out.push({
        option,
        key,
        torrentUrl,
        pageUrl,
        episode,
        range,
        isBatch,
        resolution
      });
    }
    return out;
  }
  function resolveItemMagnet(baseUrl, torrentUrl, pageUrl, name) {
    return __async(this, null, function* () {
      var _a;
      const cacheKey = `mikan:magnet:${torrentUrl || pageUrl}`;
      const cached = yield getCachedJson(caye, cacheKey);
      if (cached && cached.startsWith("magnet:")) return cached;
      if (torrentUrl) {
        try {
          const { magnet } = yield torrentUrlToMagnet(caye, "Mikan", torrentUrl, {
            headers: MIKAN_HEADERS,
            fallbackName: name,
            missingOn404: true
          });
          if (magnet) {
            yield setCachedJson(caye, cacheKey, magnet, OPTION_CACHE_TTL_SECONDS);
            return magnet;
          }
        } catch (err) {
          const code = err == null ? void 0 : err.code;
          if (code === "rate-limited") throw err;
        }
      }
      if (pageUrl) {
        const fullUrl = /^https?:\/\//i.test(pageUrl) ? pageUrl : `${baseUrl}${pageUrl.startsWith("/") ? "" : "/"}${pageUrl}`;
        const res = yield fetchText(caye, "Mikan", fullUrl, {
          headers: __spreadProps(__spreadValues({}, MIKAN_HEADERS), { Accept: "text/html" }),
          missingOn404: true
        });
        const doc = caye.html.parse(res.body);
        const magnet = ((_a = doc.find('a[href^="magnet:"]').first().attr("href")) == null ? void 0 : _a.trim()) || "";
        if (magnet.startsWith("magnet:")) {
          yield setCachedJson(caye, cacheKey, magnet, OPTION_CACHE_TTL_SECONDS);
          return magnet;
        }
      }
      return "";
    });
  }
  function selectBestResolution(items) {
    var _a;
    if (items.length <= 1) return items;
    const rank = { 2160: 4, 1080: 3, 720: 2, 480: 1 };
    let bestRank = 0;
    for (const item of items) {
      const r = (_a = rank[parseResolutionNumber(item.resolution || item.option.name)]) != null ? _a : 0;
      if (r > bestRank) bestRank = r;
    }
    if (bestRank === 0) return items;
    return items.filter(
      (item) => {
        var _a2;
        return ((_a2 = rank[parseResolutionNumber(item.resolution || item.option.name)]) != null ? _a2 : 0) === bestRank;
      }
    );
  }
  function find(context, query) {
    return __async(this, null, function* () {
      var _a;
      const baseUrl = connectionStringConfig(context, "baseUrl", DEFAULT_BASE_URL).replace(/\/+$/, "");
      const media = yield resolveMediaContext(caye, query);
      const rawText = ((_a = query.text) == null ? void 0 : _a.trim()) || "";
      const searchQueries = [];
      if (/^\d+$/.test(rawText)) {
        searchQueries.push(...yield resolveBgmTitles(caye, "mikan", rawText));
      } else if (media.bgmId && !rawText) {
        searchQueries.push(...yield resolveBgmTitles(caye, "mikan", media.bgmId));
      }
      const baseTitles = [
        rawText && !/^\d+$/.test(rawText) ? rawText : "",
        media.romajiTitle,
        media.englishTitle,
        media.originalTitle,
        ...media.synonyms
      ].filter(Boolean);
      if (query.batch) {
        for (const t of baseTitles) {
          if (!searchQueries.includes(`${t} \u5408\u96C6`)) searchQueries.push(`${t} \u5408\u96C6`);
          if (!searchQueries.includes(`${t} \u5168\u96C6`)) searchQueries.push(`${t} \u5168\u96C6`);
          if (searchQueries.length >= 4) break;
        }
      }
      for (const t of baseTitles) {
        if (!searchQueries.includes(t)) searchQueries.push(t);
        if (searchQueries.length >= 4) break;
      }
      if (searchQueries.length === 0) {
        throw failure("unsupported", "Enter a title or Bangumi ID to search.");
      }
      const confirmed = Boolean(query.number || query.batch || media.bgmId);
      const pages = yield mapLimit(searchQueries.slice(0, 3), 3, (q) => __async(null, null, function* () {
        const res = yield fetchText(
          caye,
          "Mikan",
          `${baseUrl}/RSS/Search?searchstr=${encodeURIComponent(q)}`,
          {
            headers: __spreadProps(__spreadValues({}, MIKAN_HEADERS), {
              Accept: "application/rss+xml, application/xml, text/xml"
            })
          }
        );
        return parseFeedItems(res.body, confirmed);
      }));
      const deduped = /* @__PURE__ */ new Map();
      for (const list of pages) {
        for (const item of list) {
          if (!deduped.has(item.option.id)) deduped.set(item.option.id, item);
        }
      }
      let items = Array.from(deduped.values());
      if (query.batch) {
        items = items.filter((item) => item.isBatch);
      } else if (query.number && query.number > 0 && !media.isMovie) {
        const ep = Math.trunc(query.number);
        const abs = query.absolute && query.absolute > 0 ? Math.trunc(query.absolute) : -1;
        const matched = items.filter(
          (item) => item.episode === ep || abs > 0 && item.episode === abs || item.range !== void 0 && (ep >= item.range[0] && ep <= item.range[1] || abs > 0 && abs >= item.range[0] && abs <= item.range[1]) || matchEpisodeText(item.option.name, ep)
        );
        items = matched.concat(items.filter((item) => item.episode === -1 && !item.isBatch));
      }
      if (query.resolution) {
        const keepIds = new Set(
          filterByResolution(
            items.map((i) => i.option),
            query.resolution,
            true
          ).map((o) => o.id)
        );
        items = items.filter((i) => keepIds.has(i.option.id));
      }
      if (query.best) {
        items = selectBestResolution(items);
        for (const item of items) item.option.best = true;
      }
      const limit = clampLimit(query.limit, 50, 100);
      const selected = items.slice(0, limit);
      yield mapLimit(selected.slice(0, 10), 5, (item) => __async(null, null, function* () {
        try {
          const magnet = yield resolveItemMagnet(
            baseUrl,
            item.torrentUrl,
            item.pageUrl,
            item.option.name
          );
          if (magnet) {
            item.option.magnet = magnet;
            if (magnet.length <= 2e3) item.option.uri = magnet;
          }
        } catch (e) {
        }
      }));
      const options = selected.map((item) => item.option);
      yield cacheOptions(caye, "mikan", options);
      for (const item of selected) {
        yield setCachedJson(
          caye,
          `mikan:meta:${item.option.id}`,
          { torrentUrl: item.torrentUrl, pageUrl: item.pageUrl, name: item.option.name },
          OPTION_CACHE_TTL_SECONDS
        );
      }
      return { items: options, state: "complete" };
    });
  }
  function resolve(context, input) {
    return __async(this, null, function* () {
      const baseUrl = connectionStringConfig(context, "baseUrl", DEFAULT_BASE_URL).replace(/\/+$/, "");
      return yield resolveCachedOrFallback(
        caye,
        "mikan",
        input,
        "Unknown Mikan Project option.",
        (optionId) => __async(null, null, function* () {
          const rawKey = optionId.slice("mikan-".length);
          const meta = yield getCachedJson(caye, `mikan:meta:${optionId}`);
          const torrentUrl = (meta == null ? void 0 : meta.torrentUrl) || "";
          const pageUrl = (meta == null ? void 0 : meta.pageUrl) || (/^[a-f0-9]{40}$/i.test(rawKey) ? `${baseUrl}/Home/Episode/${rawKey}` : "");
          const name = (meta == null ? void 0 : meta.name) || `Mikan ${rawKey}`;
          if (!torrentUrl && !pageUrl) {
            throw failure("missing", "Mikan option is no longer cached; search again.");
          }
          const magnet = yield resolveItemMagnet(baseUrl, torrentUrl, pageUrl, name);
          if (!magnet) {
            throw failure("unavailable", "Mikan did not provide a magnet link or torrent.");
          }
          const resolved = createTorrentOption(caye, {
            id: optionId,
            key: rawKey,
            providerId: PROVIDER_ID,
            name,
            magnet,
            torrentUrl: torrentUrl || void 0,
            pageUrl: pageUrl || void 0,
            confirmed: false
          });
          yield setCachedJson(
            caye,
            `mikan:option:${optionId}`,
            resolved,
            OPTION_CACHE_TTL_SECONDS
          );
          return resolved;
        }),
        { providerId: PROVIDER_ID }
      );
    });
  }
  caye.register(PROVIDER_ID, { acquisition: { find, resolve } });
})();
//# sourceMappingURL=backend.js.map
