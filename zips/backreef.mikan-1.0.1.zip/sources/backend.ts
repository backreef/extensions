import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DownloadOption,
    FeedItem,
} from "../../../../packages/plugin-sdk/src/index"
import {
    cacheOptions,
    clampLimit,
    connectionStringConfig,
    createTorrentOption,
    extractEpisodeRange,
    extractResolution,
    extractSingleEpisode,
    fetchText,
    filterByResolution,
    isLikelyBatchTitle,
    mapLimit,
    OPTION_CACHE_TTL_SECONDS,
    parseIsoDate,
    parseResolutionNumber,
    resolveBgmTitles,
    resolveCachedOrFallback,
    resolveMediaContext,
    torrentUrlToMagnet,
} from "../../torrent-common/src/index.ts"
import { getCachedJson, setCachedJson } from "../../../../packages/plugin-std/src/cache.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const PROVIDER_ID = "backreef.mikan:search"
const DEFAULT_BASE_URL = "https://mikanani.kas.pub"
const MIKAN_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
    Referer: "https://mikanime.tv/",
}

type MikanParsedItem = {
    option: DownloadOption
    key: string
    torrentUrl: string
    pageUrl: string
    episode: number
    range?: [number, number]
    isBatch: boolean
    resolution: string
}

function extensionText(item: FeedItem, field: string): string {
    for (const ns of Object.values(item.extensions ?? {})) {
        const val = ns?.[field]?.[0]?.value?.trim()
        if (val) return val
    }
    return ""
}

function isBatchName(name: string): boolean {
    if (isLikelyBatchTitle(name)) return true
    if (/全\s*\d{1,2}\s*卷/.test(name)) return true
    if (/\bS\d{1,2}\b(?!\s*[-–—]?\s*[\]\[Ex]*\d)/i.test(name)) return true
    if (/Season\s+\d{1,2}/i.test(name) || /第\d+季/.test(name)) return true
    return false
}

function isSingleRelease(name: string): boolean {
    return /OAD|OVA|OAV|SP\b|Special|Event|演唱会|Live|剧场版|Movie|Vol\.|Vol\s*\d|PV\b|CM\b|OST|特典|NCOP|NCED|Soundtrack|Trailer|Music/i.test(
        name,
    )
}

function parseEpisodeNumber(title: string): number {
    const jp = /第\s*0*(\d{1,4})\s*[話话集]/.exec(title)
    if (jp) {
        const n = Number.parseInt(jp[1], 10)
        if (n > 0 && n < 500) return n
    }
    const bracket = /\[\s*0*(\d{1,3})\s*(?:v\d+)?\s*\]/.exec(title)
    if (bracket) {
        const n = Number.parseInt(bracket[1], 10)
        if (n > 0 && n < 500) return n
    }
    return extractSingleEpisode(caye, title)
}

function isFullSeriesPack(name: string): boolean {
    if (isSingleRelease(name) || isBatchName(name)) return false
    if (parseEpisodeNumber(name) > 0) return false
    if (/[-–—]\s*\d{1,3}(?=\s*(?:\[|\())/.test(name)) return false
    return true
}

function matchEpisodeText(title: string, epNum: number): boolean {
    const padded = epNum < 10 ? `0${epNum}` : String(epNum)
    return new RegExp(
        `\\[${padded}\\]|第0?${epNum}[集話话]|[Ee][Pp]?${padded}\\b|[-–—]\\s*0?${epNum}(?=\\s*(?:\\[|\\()|$)`,
    ).test(title)
}

function optionKey(link: string, torrentUrl: string, title: string): string {
    const epMatch = /\/Episode\/([a-zA-Z0-9_-]+)/i.exec(link)
    if (epMatch) return epMatch[1]
    const torMatch = /\/([a-fA-F0-9]{40})\.torrent/i.exec(torrentUrl)
    if (torMatch) return torMatch[1].toLowerCase()
    const bytes = caye.encoding.utf8.encode(torrentUrl || link || title)
    return caye.crypto.digest("sha1", bytes, { output: "hex" }).slice(0, 16)
}

function parseFeedItems(xml: string, confirmed: boolean): MikanParsedItem[] {
    let feed
    try {
        feed = caye.feed.parse(xml)
    } catch {
        throw failure("unavailable", "Mikan returned an invalid RSS feed.")
    }
    const out: MikanParsedItem[] = []
    for (const item of feed.items ?? []) {
        const title = item.title?.trim() || ""
        const torrentUrl = item.enclosures?.[0]?.url?.trim() || ""
        const pageUrl = (item.link || extensionText(item, "link") || item.guid || "").trim()
        if (!title || (!torrentUrl && !pageUrl)) continue

        const key = optionKey(pageUrl, torrentUrl, title)
        const lenStr = item.enclosures?.[0]?.length || extensionText(item, "contentLength") || "0"
        const size = Number.parseInt(lenStr, 10) || 0

        let publishedAt: string | undefined
        if (typeof item.published === "number" && Number.isFinite(item.published)) {
            publishedAt = new Date(item.published).toISOString()
        } else if (typeof item.updated === "number" && Number.isFinite(item.updated)) {
            publishedAt = new Date(item.updated).toISOString()
        } else {
            const rawExtDate = extensionText(item, "pubDate")
            if (rawExtDate) publishedAt = parseIsoDate(caye, rawExtDate)
        }

        const resolution = extractResolution(caye, title)
        const isBatch = isBatchName(title) || isFullSeriesPack(title)
        const range = extractEpisodeRange(caye, title)
        const episode = isBatch ? -1 : parseEpisodeNumber(title)

        const option = createTorrentOption(caye, {
            id: `mikan-${key}`,
            key,
            providerId: PROVIDER_ID,
            name: title,
            torrentUrl: torrentUrl || pageUrl,
            pageUrl: pageUrl || undefined,
            size: size > 0 ? size : undefined,
            publishedAt,
            resolution: resolution || undefined,
            confirmed,
        })

        out.push({
            option,
            key,
            torrentUrl,
            pageUrl,
            episode,
            range,
            isBatch,
            resolution,
        })
    }
    return out
}

async function resolveItemMagnet(
    baseUrl: string,
    torrentUrl: string,
    pageUrl: string,
    name: string,
): Promise<string> {
    const cacheKey = `mikan:magnet:${torrentUrl || pageUrl}`
    const cached = await getCachedJson<string>(caye, cacheKey)
    if (cached && cached.startsWith("magnet:")) return cached

    if (torrentUrl) {
        try {
            const { magnet } = await torrentUrlToMagnet(caye, "Mikan", torrentUrl, {
                headers: MIKAN_HEADERS,
                fallbackName: name,
                missingOn404: true,
            })
            if (magnet) {
                await setCachedJson(caye, cacheKey, magnet, OPTION_CACHE_TTL_SECONDS)
                return magnet
            }
        } catch (err) {
            const code = (err as { code?: string })?.code
            if (code === "rate-limited") throw err
        }
    }

    if (pageUrl) {
        const fullUrl = /^https?:\/\//i.test(pageUrl)
            ? pageUrl
            : `${baseUrl}${pageUrl.startsWith("/") ? "" : "/"}${pageUrl}`
        const res = await fetchText(caye, "Mikan", fullUrl, {
            headers: { ...MIKAN_HEADERS, Accept: "text/html" },
            missingOn404: true,
        })
        const doc = caye.html.parse(res.body)
        const magnet = doc.find('a[href^="magnet:"]').first().attr("href")?.trim() || ""
        if (magnet.startsWith("magnet:")) {
            await setCachedJson(caye, cacheKey, magnet, OPTION_CACHE_TTL_SECONDS)
            return magnet
        }
    }
    return ""
}

function selectBestResolution(items: MikanParsedItem[]): MikanParsedItem[] {
    if (items.length <= 1) return items
    const rank: Record<number, number> = { 2160: 4, 1080: 3, 720: 2, 480: 1 }
    let bestRank = 0
    for (const item of items) {
        const r = rank[parseResolutionNumber(item.resolution || item.option.name)] ?? 0
        if (r > bestRank) bestRank = r
    }
    if (bestRank === 0) return items
    return items.filter(
        (item) =>
            (rank[parseResolutionNumber(item.resolution || item.option.name)] ?? 0) === bestRank,
    )
}

async function find(context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const baseUrl = connectionStringConfig(context, "baseUrl", DEFAULT_BASE_URL).replace(/\/+$/, "")
    const media = await resolveMediaContext(caye, query)
    const rawText = query.text?.trim() || ""

    const searchQueries: string[] = []
    if (/^\d+$/.test(rawText)) {
        searchQueries.push(...(await resolveBgmTitles(caye, "mikan", rawText)))
    } else if (media.bgmId && !rawText) {
        searchQueries.push(...(await resolveBgmTitles(caye, "mikan", media.bgmId)))
    }

    const baseTitles = [
        rawText && !/^\d+$/.test(rawText) ? rawText : "",
        media.romajiTitle,
        media.englishTitle,
        media.originalTitle,
        ...media.synonyms,
    ].filter(Boolean)

    if (query.batch) {
        for (const t of baseTitles) {
            if (!searchQueries.includes(`${t} 合集`)) searchQueries.push(`${t} 合集`)
            if (!searchQueries.includes(`${t} 全集`)) searchQueries.push(`${t} 全集`)
            if (searchQueries.length >= 4) break
        }
    }
    for (const t of baseTitles) {
        if (!searchQueries.includes(t)) searchQueries.push(t)
        if (searchQueries.length >= 4) break
    }
    if (searchQueries.length === 0) {
        throw failure("unsupported", "Enter a title or Bangumi ID to search.")
    }

    const confirmed = Boolean(query.number || query.batch || media.bgmId)
    const pages = await mapLimit(searchQueries.slice(0, 3), 3, async (q) => {
        const res = await fetchText(
            caye,
            "Mikan",
            `${baseUrl}/RSS/Search?searchstr=${encodeURIComponent(q)}`,
            {
                headers: {
                    ...MIKAN_HEADERS,
                    Accept: "application/rss+xml, application/xml, text/xml",
                },
            },
        )
        return parseFeedItems(res.body, confirmed)
    })

    const deduped = new Map<string, MikanParsedItem>()
    for (const list of pages) {
        for (const item of list) {
            if (!deduped.has(item.option.id)) deduped.set(item.option.id, item)
        }
    }
    let items = Array.from(deduped.values())

    if (query.batch) {
        items = items.filter((item) => item.isBatch)
    } else if (query.number && query.number > 0 && !media.isMovie) {
        const ep = Math.trunc(query.number)
        const abs = query.absolute && query.absolute > 0 ? Math.trunc(query.absolute) : -1
        const matched = items.filter(
            (item) =>
                item.episode === ep ||
                (abs > 0 && item.episode === abs) ||
                (item.range !== undefined &&
                    ((ep >= item.range[0] && ep <= item.range[1]) ||
                        (abs > 0 && abs >= item.range[0] && abs <= item.range[1]))) ||
                matchEpisodeText(item.option.name, ep),
        )
        items = matched.concat(items.filter((item) => item.episode === -1 && !item.isBatch))
    }

    if (query.resolution) {
        const keepIds = new Set(
            filterByResolution(
                items.map((i) => i.option),
                query.resolution,
                true,
            ).map((o) => o.id),
        )
        items = items.filter((i) => keepIds.has(i.option.id))
    }

    if (query.best) {
        items = selectBestResolution(items)
        for (const item of items) item.option.best = true
    }

    const limit = clampLimit(query.limit, 50, 100)
    const selected = items.slice(0, limit)

    await mapLimit(selected.slice(0, 10), 5, async (item) => {
        try {
            const magnet = await resolveItemMagnet(
                baseUrl,
                item.torrentUrl,
                item.pageUrl,
                item.option.name,
            )
            if (magnet) {
                item.option.magnet = magnet
                if (magnet.length <= 2000) item.option.uri = magnet
            }
        } catch {}
    })

    const options = selected.map((item) => item.option)
    await cacheOptions(caye, "mikan", options)
    for (const item of selected) {
        await setCachedJson(
            caye,
            `mikan:meta:${item.option.id}`,
            { torrentUrl: item.torrentUrl, pageUrl: item.pageUrl, name: item.option.name },
            OPTION_CACHE_TTL_SECONDS,
        )
    }
    return { items: options, state: "complete" }
}

async function resolve(context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    const baseUrl = connectionStringConfig(context, "baseUrl", DEFAULT_BASE_URL).replace(/\/+$/, "")
    return await resolveCachedOrFallback(
        caye,
        "mikan",
        input,
        "Unknown Mikan Project option.",
        async (optionId) => {
            const rawKey = optionId.slice("mikan-".length)
            const meta = await getCachedJson<{
                torrentUrl?: string
                pageUrl?: string
                name?: string
            }>(caye, `mikan:meta:${optionId}`)
            const torrentUrl = meta?.torrentUrl || ""
            const pageUrl =
                meta?.pageUrl ||
                (/^[a-f0-9]{40}$/i.test(rawKey) ? `${baseUrl}/Home/Episode/${rawKey}` : "")
            const name = meta?.name || `Mikan ${rawKey}`
            if (!torrentUrl && !pageUrl) {
                throw failure("missing", "Mikan option is no longer cached; search again.")
            }
            const magnet = await resolveItemMagnet(baseUrl, torrentUrl, pageUrl, name)
            if (!magnet) {
                throw failure("unavailable", "Mikan did not provide a magnet link or torrent.")
            }
            const resolved = createTorrentOption(caye, {
                id: optionId,
                key: rawKey,
                providerId: PROVIDER_ID,
                name,
                magnet,
                torrentUrl: torrentUrl || undefined,
                pageUrl: pageUrl || undefined,
                confirmed: false,
            })
            await setCachedJson(
                caye,
                `mikan:option:${optionId}`,
                resolved,
                OPTION_CACHE_TTL_SECONDS,
            )
            return resolved
        },
        { providerId: PROVIDER_ID },
    )
}

caye.register(PROVIDER_ID, { acquisition: { find, resolve } })
