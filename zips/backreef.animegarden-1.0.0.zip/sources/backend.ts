import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DownloadOption,
} from "../../../../packages/plugin-sdk/src/index"
import {
    cacheOptions,
    clampLimit,
    connectionStringConfig,
    createTorrentOption,
    extractEpisodeRange,
    extractInfoHashFromMagnet,
    extractResolution,
    extractSingleEpisode,
    fetchJson,
    filterByResolution,
    isLikelyBatchTitle,
    parseIsoDate,
    resolveBgmTitles,
    resolveCachedOrFallback,
    resolveMediaContext,
} from "../../torrent-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const PROVIDER_ID = "backreef.animegarden:search"
const DEFAULT_BASE_URL = "https://api.animes.garden"

type GardenResource = {
    id?: string | number
    provider?: string
    providerId?: string
    title?: string
    href?: string
    magnet?: string
    tracker?: string
    size?: number
    createdAt?: string
    type?: string
}

type GardenResponse = {
    resources?: GardenResource[]
}

type ParsedGardenItem = {
    option: DownloadOption
    episode: number
    range?: [number, number]
    isBatch: boolean
    isBest: boolean
    publishedMs: number
}

function isAnimeCategory(r: GardenResource): boolean {
    const t = r.type || ""
    return t === "动画" || /合集|全集|Complete/i.test(t)
}

function isSingleRelease(title: string): boolean {
    return /OAD|OVA|OAV|SP\b|Special|演唱会|剧场版|Movie|Vol\.|Vol\s*\d|PV\b|CM\b|OST|特典|NCOP|NCED|Soundtrack|Trailer|Music/i.test(
        title,
    )
}

function parseChineseEpisode(title: string): number {
    const jp = /第\s*0*(\d{1,4})\s*[話话集]/.exec(title)
    if (jp) {
        const n = Number.parseInt(jp[1], 10)
        if (n > 0 && n < 500) return n
    }
    const bracket = /\[\s*0*(\d{1,3})\s*(?:v\d+)?\s*\]/.exec(title)
    if (bracket) {
        const n = Number.parseInt(bracket[1], 10)
        if (n > 0 && n < 500) return n
    }
    return extractSingleEpisode(caye, title)
}

function detectBatch(title: string, resourceType: string): boolean {
    if (/合集|全集|Batch|Complete/i.test(resourceType)) return true
    if (isLikelyBatchTitle(title)) return true
    if (isSingleRelease(title)) return false
    if (parseChineseEpisode(title) > 0) return false
    return !/\[\s*\d{1,3}\s*\]/.test(title)
}

function isBestRelease(title: string): boolean {
    const high =
        /\b(?:BDRip|BluRay|Blu-ray|BD|WebRip|WEB-DL|WEB|HDRip|H265|HEVC|x265|10bit|Hi10P)\b/i
    const low = /\b(?:CAM|TS|TC|HDTS|HDTC|DVDScr|SCR|VCD|TVRip|VHSRip)\b/i
    return high.test(title) && !low.test(title)
}

async function fetchResources(
    baseUrl: string,
    search: string,
    maxPages = 2,
): Promise<GardenResource[]> {
    const out: GardenResource[] = []
    const seen = new Set<string>()
    const pageSize = 50

    for (let page = 1; page <= maxPages; page++) {
        const sp = new URLSearchParams()
        sp.set("pageSize", String(pageSize))
        sp.set("page", String(page))
        sp.set("tracker", "true")
        if (search) sp.set("search", search)
        const data = await fetchJson<GardenResponse>(
            caye,
            "Anime Garden",
            `${baseUrl}/resources?${sp.toString()}`,
            {
                headers: { Accept: "application/json" },
            },
        )
        const rows = Array.isArray(data.resources) ? data.resources : []
        let added = 0
        for (const r of rows) {
            if (!isAnimeCategory(r)) continue
            const key = String(r.href || r.id || "")
            if (!key || seen.has(key)) continue
            seen.add(key)
            out.push(r)
            added++
        }
        if (rows.length < pageSize || added === 0) break
    }
    return out
}

function toParsedItem(r: GardenResource, confirmed: boolean): ParsedGardenItem | undefined {
    const title = r.title?.trim() || ""
    const rawMagnet = r.magnet?.trim() || ""
    if (!title || !rawMagnet) return undefined
    const trackerSuffix = typeof r.tracker === "string" ? r.tracker : ""
    const magnet =
        trackerSuffix && !rawMagnet.includes("&tr=") ? `${rawMagnet}${trackerSuffix}` : rawMagnet
    const infoHash = extractInfoHashFromMagnet(magnet)
    const idKey = String(r.id ?? r.providerId ?? infoHash ?? title.length)
    const size = typeof r.size === "number" && r.size > 0 ? Math.round(r.size * 1024) : 0
    const publishedAt = parseIsoDate(caye, r.createdAt)
    const resolution = extractResolution(caye, title)
    const isBatch = detectBatch(title, r.type || "")
    const range = extractEpisodeRange(caye, title)
    const episode = isBatch ? -1 : parseChineseEpisode(title)
    const isBest = isBestRelease(title)

    const option = createTorrentOption(caye, {
        id: `animegarden-${idKey}`,
        key: idKey,
        providerId: PROVIDER_ID,
        name: title,
        magnet,
        pageUrl: r.href,
        size: size > 0 ? size : undefined,
        publishedAt,
        resolution: resolution || undefined,
        best: isBest,
        confirmed,
    })

    return {
        option,
        episode,
        range,
        isBatch,
        isBest,
        publishedMs: publishedAt ? Date.parse(publishedAt) || 0 : 0,
    }
}

async function find(context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const baseUrl = connectionStringConfig(context, "baseUrl", DEFAULT_BASE_URL).replace(/\/+$/, "")
    const media = await resolveMediaContext(caye, query)
    const rawText = query.text?.trim() || ""

    const searchQueries: string[] = []
    if (/^\d+$/.test(rawText)) {
        searchQueries.push(...(await resolveBgmTitles(caye, "animegarden", rawText)))
    } else if (media.bgmId && !rawText) {
        searchQueries.push(...(await resolveBgmTitles(caye, "animegarden", media.bgmId)))
    }

    const baseTitles = [
        rawText && !/^\d+$/.test(rawText) ? rawText : "",
        media.romajiTitle,
        media.englishTitle,
        media.originalTitle,
        ...media.synonyms,
    ].filter(Boolean)

    if (query.number && query.number > 0 && !query.batch && baseTitles.length > 0) {
        const ep = String(Math.trunc(query.number)).padStart(2, "0")
        const res = query.resolution ? ` ${query.resolution.replace(/p$/i, "")}` : ""
        searchQueries.push(`${baseTitles[0]} ${ep}${res}`.trim())
    }
    for (const t of baseTitles) {
        if (!searchQueries.includes(t)) searchQueries.push(t)
        if (searchQueries.length >= 4) break
    }
    if (searchQueries.length === 0) {
        throw failure("unsupported", "Enter a title or Bangumi ID to search.")
    }

    const collected = new Map<string, GardenResource>()
    for (const q of searchQueries.slice(0, 3)) {
        const rows = await fetchResources(baseUrl, q, 2)
        for (const r of rows) {
            const key = String(r.href || r.id || "")
            if (key && !collected.has(key)) collected.set(key, r)
        }
        if (collected.size >= 30) break
    }

    const confirmed = Boolean(query.number || query.batch || media.bgmId)
    let parsed = Array.from(collected.values())
        .map((r) => toParsedItem(r, confirmed))
        .filter((item): item is ParsedGardenItem => Boolean(item))

    if (query.batch) {
        parsed = parsed.filter((p) => p.isBatch)
    } else if (query.number && query.number > 0) {
        const ep = Math.trunc(query.number)
        const abs = query.absolute && query.absolute > 0 ? Math.trunc(query.absolute) : -1
        const exact = parsed.filter((p) => p.episode === ep || (abs > 0 && p.episode === abs))
        if (exact.length > 0) {
            parsed = exact.concat(parsed.filter((p) => p.episode === -1))
        } else {
            parsed = parsed.filter(
                (p) =>
                    p.episode === -1 ||
                    (p.range !== undefined &&
                        ((ep >= p.range[0] && ep <= p.range[1]) ||
                            (abs > 0 && abs >= p.range[0] && abs <= p.range[1]))),
            )
        }
    }

    if (query.resolution) {
        const matchedIds = new Set(
            filterByResolution(
                parsed.map((p) => p.option),
                query.resolution,
                true,
            ).map((o) => o.id),
        )
        parsed = parsed.filter((p) => matchedIds.has(p.option.id))
    }

    if (query.best) {
        const bestOnly = parsed.filter((p) => p.isBest)
        if (bestOnly.length > 0) parsed = bestOnly
    }

    parsed.sort((a, b) => {
        if (a.isBest !== b.isBest) return a.isBest ? -1 : 1
        return b.publishedMs - a.publishedMs
    })

    const limit = clampLimit(query.limit, 50, 100)
    const items = parsed.slice(0, limit).map((p) => p.option)
    await cacheOptions(caye, "animegarden", items)
    return { items, state: "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    return await resolveCachedOrFallback(
        caye,
        "animegarden",
        input,
        "Unknown or uncached Anime Garden option.",
    )
}

caye.register(PROVIDER_ID, { acquisition: { find, resolve } })
