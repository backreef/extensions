import type {
    API,
    Context,
    Query,
    Ref,
    Source,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
} from "../../../../packages/plugin-sdk/src/index"
import { base64ToBytes, bytesToUtf8, ModeOfOperationCBC, pkcs7strip, stringToBytes } from "./aes"
import { withYear } from "./year"

declare const caye: API

const providerId = "backreef.anikoto:site"
const defaultBaseUrl = "https://anikototv.to"

const knownCipherPairs = [{ key: "i?LMTAx0Q6,:}50U", iv: "W0;27ToaUpl_P%'c" }]

type ServerSkipData = {
    intro?: [number, number]
    outro?: [number, number]
}

type ServerAjaxResult = {
    status: number
    result: {
        url: string
        skip_data?: ServerSkipData
    }
}

type PayloadTrack = {
    file?: string
    label?: string
    kind?: string
    default?: boolean
}

type SourcePayload = {
    sources?: { file: string } | { file: string }[]
    tracks?: PayloadTrack[]
    enc?: string
}

type StreamFound = { file: string; tracks?: PayloadTrack[] }

const subtitleLanguages: Record<string, string> = {
    english: "en",
    spanish: "es",
    french: "fr",
    german: "de",
    italian: "it",
    portuguese: "pt",
    russian: "ru",
    arabic: "ar",
    japanese: "ja",
    indonesian: "id",
    chinese: "zh",
    korean: "ko",
    turkish: "tr",
    vietnamese: "vi",
    thai: "th",
}

function subtitlesOf(tracks: PayloadTrack[] | undefined): Source["subtitles"] {
    const out: NonNullable<Source["subtitles"]> = []
    const seen = new Set<string>()
    for (const track of tracks ?? []) {
        const url = track.file
        if (typeof url !== "string" || !/^https?:\/\//i.test(url)) continue
        if (track.kind && track.kind !== "captions" && track.kind !== "subtitles") continue
        const extension = (url.split(/[?#]/)[0].match(/\.(vtt|srt|ass)$/i) ?? [])[1]
        if (!extension && track.kind !== "captions") continue
        if (seen.has(url)) continue
        seen.add(url)
        const label = cleanLabel(track.label)
        const word = label.toLowerCase().split(/[^a-z]+/)[0]
        out.push({
            url,
            format: (extension?.toLowerCase() ?? "vtt") as "vtt" | "srt" | "ass",
            language: subtitleLanguages[word],
            label: label || undefined,
            default: track.default === true,
        })
        if (out.length === 32) break
    }
    return out
}

// cleanLabel normalizes subtitle labels by removing leading dashes and redundant language names
function cleanLabel(value: unknown): string {
    if (typeof value !== "string") return ""
    const label = value
        .replace(/^[\s\-\u2013\u2014]+/, "")
        .replace(/\(\s*[-\u2013\u2014]\s*/g, "(")
        .replace(/(\S)\(/g, "$1 (")
        .replace(/\s+/g, " ")
        .trim()
    const nested = /^(.+?) \((.+)\)$/.exec(label)
    return nested && nested[2].startsWith(`${nested[1]} `) ? nested[2] : label
}

function site(context: Context): string {
    const url = (context?.config?.url ?? "").replace(/\/+$/, "")
    return url || defaultBaseUrl
}

function ajaxHeaders(siteUrl: string): Record<string, string> {
    return {
        Referer: `${siteUrl}/`,
        "X-Requested-With": "XMLHttpRequest",
        "User-Agent":
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    }
}

function originOf(url: string): string {
    if (url.startsWith("//")) url = `https:${url}`
    const match = url.match(/^(https?:\/\/[^/]+)/i)
    return match ? match[1] : ""
}

function decodeHtml(text: string): string {
    return text
        .replace(/&#039;/g, "'")
        .replace(/&quot;/g, '"')
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
}

function tryDecryptEnc(
    cipherBytes: Uint8Array,
    pairs: { key: string; iv: string }[],
): StreamFound | undefined {
    for (const pair of pairs) {
        try {
            const keyBytes = new Uint8Array(32)
            keyBytes.set(stringToBytes(pair.key).subarray(0, 32))
            const ivBytes = stringToBytes(pair.iv).subarray(0, 16)
            const cbc = new ModeOfOperationCBC(keyBytes, ivBytes)
            const dec = cbc.decrypt(cipherBytes)
            const unpadded = pkcs7strip(dec)
            const text = bytesToUtf8(unpadded)
            if (!text || text.indexOf("http") === -1) continue
            const parsed = JSON.parse(text) as {
                file?: string
                tracks?: PayloadTrack[]
            }
            if (typeof parsed.file === "string") {
                return { file: parsed.file, tracks: parsed.tracks }
            }
        } catch {}
    }
    return undefined
}

async function scanEncKeys(
    origin: string,
    embedUrl: string,
): Promise<{ key: string; iv: string }[]> {
    const out: { key: string; iv: string }[] = []
    try {
        const page = await caye.http({
            url: embedUrl,
            headers: { Referer: embedUrl },
        })
        if (page.status !== 200 || !page.body) return out
        const html = page.body
        const re = /<script[^>]+src="([^"]+)"/g
        const scripts: string[] = []
        while (true) {
            const m = re.exec(html)
            if (!m) break
            let u = m[1]
            if (u.startsWith("//")) u = `https:${u}`
            else if (u.startsWith("/")) u = `${origin}${u}`
            if (u.startsWith(origin) && scripts.length < 12) scripts.push(u)
        }
        for (const s of scripts) {
            const js = await caye.http({
                url: s,
                headers: { Referer: embedUrl },
            })
            if (js.status !== 200 || !js.body) continue
            const body = js.body
            const kr = /=\s*"([^"\\]{16,32})"\s*,\s*\w+\s*=\s*"([^"\\]{16,32})"/g
            while (out.length < 24) {
                const km = kr.exec(body)
                if (!km) break
                out.push({ key: km[1], iv: km[2] })
            }
            const er = /\.encode\(\s*"([^"\\]{16,32})"\s*\)/g
            const lits: string[] = []
            while (true) {
                const km = er.exec(body)
                if (!km) break
                lits.push(km[1])
            }
            for (let i = 0; i + 1 < lits.length; i += 2) {
                out.push({ key: lits[i], iv: lits[i + 1] })
            }
            if (out.length >= 24) break
        }
    } catch {}
    return out
}

async function extractVideoUrl(
    origin: string,
    embedUrl: string,
    dataId: string,
    cdn: string,
): Promise<StreamFound | undefined> {
    const paths = ["stream/getSourcesNew", "stream/getSources"]
    for (const path of paths) {
        const query = `id=${encodeURIComponent(dataId)}${cdn ? `&s=${encodeURIComponent(cdn)}` : ""}`
        const res = await caye.http({
            url: `${origin}/${path}?${query}`,
            headers: {
                Referer: embedUrl,
                "X-Requested-With": "XMLHttpRequest",
            },
        })
        if (res.status !== 200 || !res.body) continue
        let payload: SourcePayload | undefined
        try {
            payload = JSON.parse(res.body) as SourcePayload
        } catch {
            continue
        }
        if (!payload) continue

        if (payload.sources) {
            const raw = Array.isArray(payload.sources)
                ? payload.sources[0]?.file
                : payload.sources.file
            if (typeof raw === "string" && /^https?:\/\//i.test(raw)) {
                return { file: raw, tracks: payload.tracks }
            }
        }

        if (payload.enc) {
            let b64 = String(payload.enc).replace(/-/g, "+").replace(/_/g, "/")
            const pad = b64.length % 4
            if (pad) b64 = b64 + "====".slice(pad)
            const cipherBytes = base64ToBytes(b64)

            const decrypted =
                tryDecryptEnc(cipherBytes, knownCipherPairs) ??
                tryDecryptEnc(cipherBytes, await scanEncKeys(origin, embedUrl))
            if (decrypted?.file) {
                return {
                    file: decrypted.file,
                    tracks: decrypted.tracks ?? payload.tracks,
                }
            }
        }
    }
    return undefined
}

type Server = {
    audio: string
    serverId: string
    linkId: string
}

async function listServers(context: Context, ref: Ref): Promise<Server[]> {
    const base = site(context)
    const parts = ref.nativeId.split(":")
    const slug = parts[0]
    let seriesId = parts.length >= 4 ? parts[1] : ""
    const epId = parts.length >= 4 ? parts[2] : ""
    const epNumber = parseInt(parts.length >= 4 ? parts[3] : (parts[1] ?? "1"), 10)

    if (!seriesId) {
        const watchRes = await caye.http({
            url: `${base}/watch/${encodeURIComponent(slug)}`,
            headers: { Referer: `${base}/` },
        })
        if (watchRes.status !== 200 || !watchRes.body) {
            throw new Error(`The site answered ${watchRes.status}`)
        }
        const match =
            watchRes.body.match(/id="watch-main"[^>]*data-id="(\d+)"/) ??
            watchRes.body.match(/data-id="(\d+)"/)
        if (!match) throw new Error("Could not determine series ID")
        seriesId = match[1]
    }

    const epListRes = await caye.http({
        url: `${base}/ajax/episode/list/${seriesId}`,
        headers: {
            Referer: `${base}/watch/${encodeURIComponent(slug)}`,
            "X-Requested-With": "XMLHttpRequest",
        },
    })
    if (epListRes.status !== 200 || !epListRes.body) {
        throw new Error(`The site answered ${epListRes.status}`)
    }
    const epListJson = JSON.parse(epListRes.body) as {
        status: number
        result: string
    }
    const epHtml = epListJson.result
    const epRe =
        /<a\s+[^>]*data-id="([^"]+)"[^>]*data-num="([^"]+)"[^>]*data-slug="([^"]+)"[^>]*data-sub="([^"]+)"[^>]*data-dub="([^"]+)"[^>]*data-ids="([^"]+)"/g
    let dataIds = ""
    while (true) {
        const em = epRe.exec(epHtml)
        if (!em) break
        const currentEpId = em[1]
        const currentNum = parseInt(em[2], 10)
        if ((epId && currentEpId === epId) || (!epId && currentNum === epNumber)) {
            dataIds = em[6]
            break
        }
    }
    if (!dataIds) {
        throw new Error("Could not locate episode data IDs")
    }

    const slRes = await caye.http({
        url: `${base}/ajax/server/list?servers=${encodeURIComponent(dataIds)}`,
        headers: ajaxHeaders(base),
    })
    if (slRes.status !== 200 || !slRes.body) {
        throw new Error(`The site answered ${slRes.status}`)
    }
    const slJson = JSON.parse(slRes.body) as {
        status: number
        result: string
    }
    const slHtml = slJson.result
    const typeRe = /<div class="type" data-type="([^"]+)">([\s\S]*?)<\/ul>/g
    const foundServers: Server[] = []
    while (true) {
        const typem = typeRe.exec(slHtml)
        if (!typem) break
        const audio = typem[1]
        const serverBlock = typem[2]
        const liRe = /<li[^>]*data-link-id="([^"]+)"[^>]*>([\s\S]*?)<\/li>/g
        while (true) {
            const lim = liRe.exec(serverBlock)
            if (!lim) break
            const linkId = lim[1]
            const serverName = lim[2].trim()
            foundServers.push({
                audio,
                serverId: serverName.toLowerCase(),
                linkId,
            })
        }
    }
    return foundServers
}

caye.register(providerId, {
    source: {
        async search(context: Context, query: Query): Promise<SourceRecords> {
            const base = site(context)
            const q = query.q ?? ""
            const response = await caye.http({
                url: `${base}/filter?keyword=${encodeURIComponent(q)}`,
                headers: { Referer: `${base}/` },
            })
            if (response.status !== 200 || response.body === undefined) {
                throw new Error(`The site answered ${response.status}`)
            }
            const html = response.body
            const titleRe =
                /<a[^>]+class="[^"]*name d-title[^"]*"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/g
            const items: SourceRecord[] = []
            const seen = new Set<string>()
            while (true) {
                const tm = titleRe.exec(html)
                if (!tm) break
                const href = tm[1]
                const name = decodeHtml(tm[2].replace(/<[^>]+>/g, "").trim())
                const slug = href
                    .replace(/.*?\/watch\//, "")
                    .replace(/\/ep-[^/]+.*$/, "")
                    .replace(/\/+$/, "")
                if (!slug || seen.has(slug)) continue
                seen.add(slug)
                items.push(
                    withYear(
                        {
                            ref: { providerId, type: "video", nativeId: slug },
                            name,
                        },
                        tm[0],
                    ),
                )
            }
            return {
                items: query.limit > 0 ? items.slice(0, query.limit) : items,
                nextCursor: "",
                state: "complete",
            }
        },

        async read(context: Context, ref: Ref): Promise<SourceRecord> {
            const base = site(context)
            const slug = ref.nativeId.split(":")[0]
            const response = await caye.http({
                url: `${base}/watch/${encodeURIComponent(slug)}`,
                headers: { Referer: `${base}/` },
            })
            if (response.status !== 200 || response.body === undefined) {
                throw new Error(`The site answered ${response.status}`)
            }
            const html = response.body
            const titleMatch =
                html.match(/<h2[^>]*class="[^"]*title[^"]*"[^>]*>([\s\S]*?)<\/h2>/i) ??
                html.match(/<h1[^>]*class="[^"]*title[^"]*"[^>]*>([\s\S]*?)<\/h1>/i) ??
                html.match(/<title>([\s\S]*?)<\/title>/i)
            const rawTitle = titleMatch ? titleMatch[1].replace(/<[^>]+>/g, "").trim() : slug
            const name = decodeHtml(rawTitle)
            return {
                ref,
                name,
            }
        },

        async list(context: Context, ref: Ref): Promise<SourceListResult> {
            const base = site(context)
            const slug = ref.nativeId.split(":")[0]
            const watchRes = await caye.http({
                url: `${base}/watch/${encodeURIComponent(slug)}`,
                headers: { Referer: `${base}/` },
            })
            if (watchRes.status !== 200 || !watchRes.body) {
                throw new Error(`The site answered ${watchRes.status}`)
            }
            const watchHtml = watchRes.body
            const seriesIdMatch =
                watchHtml.match(/id="watch-main"[^>]*data-id="(\d+)"/) ??
                watchHtml.match(/data-id="(\d+)"/)
            if (!seriesIdMatch) {
                throw new Error("Could not determine series ID")
            }
            const seriesId = seriesIdMatch[1]

            const epListRes = await caye.http({
                url: `${base}/ajax/episode/list/${seriesId}`,
                headers: {
                    Referer: `${base}/watch/${encodeURIComponent(slug)}`,
                    "X-Requested-With": "XMLHttpRequest",
                },
            })
            if (epListRes.status !== 200 || !epListRes.body) {
                throw new Error(`The site answered ${epListRes.status}`)
            }
            const epListJson = JSON.parse(epListRes.body) as {
                status: number
                result: string
            }
            const epHtml = epListJson.result
            const epRe =
                /<a\s+[^>]*data-id="([^"]+)"[^>]*data-num="([^"]+)"[^>]*data-slug="([^"]+)"[^>]*data-sub="([^"]+)"[^>]*data-dub="([^"]+)"[^>]*data-ids="([^"]+)"/g
            const episodes: {
                epId: string
                num: number
                sub: boolean
                dub: boolean
            }[] = []
            while (true) {
                const em = epRe.exec(epHtml)
                if (!em) break
                const num = parseInt(em[2], 10)
                if (Number.isInteger(num)) {
                    episodes.push({
                        epId: em[1],
                        num,
                        sub: em[4] === "1",
                        dub: em[5] === "1",
                    })
                }
            }

            const hasSub = episodes.some((e) => e.sub)
            const hasDub = episodes.some((e) => e.dub)

            return {
                installments: episodes.map((ep) => ({
                    number: ep.num,
                    ref: {
                        providerId,
                        type: "video",
                        nativeId: `${slug}:${seriesId}:${ep.epId}:${ep.num}`,
                    },
                })),
                choices: {
                    audio: [
                        ...(hasSub || !hasDub ? [{ id: "sub", label: "Sub" }] : []),
                        ...(hasDub ? [{ id: "dub", label: "Dub" }] : []),
                    ],
                    server: [
                        { id: "hd-1", label: "HD-1" },
                        { id: "vidstream-2", label: "Vidstream-2" },
                        { id: "vidstream-1", label: "Vidstream-1" },
                    ],
                    quality: [{ id: "default", label: "Default" }],
                },
            }
        },

        async find(context: Context, ref: Ref): Promise<SourcePage> {
            const foundServers = await listServers(context, ref)
            const deadline = context.deadline || new Date(Date.now() + 300000).toISOString()
            const items: Source[] = foundServers.map((s) => ({
                id: `${s.audio}:${s.serverId}`,
                origin: "hls",
                capabilities: ["video"],
                expiresAt: deadline,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: s.audio === "dub" ? "en" : "ja",
                        label: "Default",
                    },
                ],
                ranges: [],
                choices: {
                    audio: s.audio,
                    server: s.serverId,
                    quality: "default",
                },
            }))

            return {
                items,
                state: "complete",
            }
        },

        async resolve(context: Context, input: { ref: Ref; sourceId: string }): Promise<Source> {
            const base = site(context)
            const [audio, serverId] = input.sourceId.split(":")
            const linkId = (await listServers(context, input.ref)).find(
                (s) => s.audio === audio && s.serverId === serverId,
            )?.linkId
            if (!linkId) {
                throw new Error("The episode no longer offers this server")
            }

            const srvRes = await caye.http({
                url: `${base}/ajax/server?get=${encodeURIComponent(linkId)}`,
                headers: ajaxHeaders(base),
            })
            if (srvRes.status !== 200 || !srvRes.body) {
                throw new Error(`The site answered ${srvRes.status}`)
            }
            const srvJson = JSON.parse(srvRes.body) as ServerAjaxResult
            if (!srvJson.result?.url) {
                throw new Error("Could not resolve server embed URL")
            }
            let embedUrl = srvJson.result.url
            const origin = originOf(embedUrl)
            const cdn = (embedUrl.match(/[?&]s=([\w-]+)/) || [])[1] ?? ""

            const embedRes = await caye.http({
                url: embedUrl,
                headers: { Referer: `${base}/` },
            })
            if (embedRes.status !== 200 || !embedRes.body) {
                throw new Error(`Embed answered ${embedRes.status}`)
            }
            const ehtml = embedRes.body
            let dataId = (ehtml.match(/data-id="([^"]+)"/) || [])[1]
            if (!dataId) {
                const ifr = ehtml.match(/<iframe[^>]+\bsrc="([^"]*\/stream\/[^"]*)"/i)
                if (ifr) {
                    let inner = ifr[1]
                    if (inner.startsWith("//")) inner = `https:${inner}`
                    else if (inner.startsWith("/")) inner = `${origin}${inner}`
                    const innerRes = await caye.http({
                        url: inner,
                        headers: { Referer: embedUrl },
                    })
                    if (innerRes.status === 200 && innerRes.body) {
                        dataId = (innerRes.body.match(/data-id="([^"]+)"/) || [])[1]
                        if (dataId) embedUrl = inner
                    }
                }
            }
            if (!dataId) {
                throw new Error("Could not locate player data ID")
            }

            const stream = await extractVideoUrl(origin, embedUrl, dataId, cdn)
            if (!stream) {
                throw new Error("The video stream is unavailable or encrypted")
            }
            const videoUrl = stream.file

            const response = await caye.http({
                url: videoUrl,
                mode: "handle",
                headers: {
                    Referer: `${origin}/`,
                    Origin: origin,
                },
            })
            if (!response.handle) {
                throw new Error("The stream handle is unavailable")
            }

            const markers: NonNullable<Source["markers"]> = []
            const skip = srvJson.result.skip_data
            if (skip) {
                if (
                    skip.intro &&
                    skip.intro.length >= 2 &&
                    skip.intro[1] > skip.intro[0] &&
                    skip.intro[0] >= 0
                ) {
                    markers.push({
                        kind: "intro",
                        start: skip.intro[0],
                        end: skip.intro[1],
                        label: "Intro",
                    })
                }
                if (
                    skip.outro &&
                    skip.outro.length >= 2 &&
                    skip.outro[1] > skip.outro[0] &&
                    skip.outro[0] >= 0
                ) {
                    markers.push({
                        kind: "credits",
                        start: skip.outro[0],
                        end: skip.outro[1],
                        label: "Outro",
                    })
                }
            }

            return {
                id: input.sourceId,
                origin: /\.m3u8(\?|$)/.test(videoUrl) ? "hls" : "http",
                capabilities: ["video"],
                expiresAt: response.handle.expiresAt,
                handle: response.handle,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: audio === "dub" ? "en" : "ja",
                        label: "Default",
                    },
                ],
                ranges: [],
                markers: markers.length > 0 ? markers : undefined,
                subtitles: subtitlesOf(stream.tracks),
                choices: {
                    audio,
                    server: serverId,
                    quality: "default",
                },
            }
        },
    },
})
