export function yearOf(value: unknown): number | undefined {
    if (typeof value === "number") {
        return Number.isInteger(value) && value >= 1000 && value <= 9999 ? value : undefined
    }
    if (typeof value !== "string") return undefined

    const text = value.trim()
    const direct = text.match(/^(\d{4})(?:-\d{2}-\d{2})?$/)?.[1]
    const field = text.match(
        /(?:first_air_date|release_date|firstAired|airedOn|data-year|datetime|released|premiere|year)["']?\s*(?::|=)\s*["']?(\d{4})(?=$|[^\w.])/i,
    )?.[1]
    const startDate = text.match(
        /\bstartDate\b.{0,40}?\byear\b["']?\s*:\s*["']?(\d{4})(?=$|[^\w.])/i,
    )?.[1]
    const year = Number(direct ?? field ?? startDate)
    return Number.isInteger(year) && year >= 1000 && year <= 9999 ? year : undefined
}

export function withYear<T extends object>(record: T, source: unknown): T & { year?: number } {
    const year = yearOf(source)
    return year === undefined ? record : { ...record, year }
}
