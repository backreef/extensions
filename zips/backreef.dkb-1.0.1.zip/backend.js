(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __pow = Math.pow;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __objRest = (source, exclude) => {
    var target = {};
    for (var prop in source)
      if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
        target[prop] = source[prop];
    if (source != null && __getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(source)) {
        if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
          target[prop] = source[prop];
      }
    return target;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve2, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve2(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../../../packages/plugin-std/src/magnet.ts
  var BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  function decodeBase32(input) {
    const cleaned = input.trim().toUpperCase().replace(/=+$/, "");
    if (!cleaned || !/^[A-Z2-7]+$/.test(cleaned)) {
      throw new TypeError("Invalid base32 string");
    }
    const bytes = [];
    let buffer = 0;
    let bitsLeft = 0;
    for (let i = 0; i < cleaned.length; i++) {
      const val = BASE32_ALPHABET.indexOf(cleaned[i]);
      buffer = buffer << 5 | val;
      bitsLeft += 5;
      if (bitsLeft >= 8) {
        bitsLeft -= 8;
        bytes.push(buffer >>> bitsLeft & 255);
      }
    }
    return new Uint8Array(bytes);
  }
  function bytesToHex(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i++) {
      out += bytes[i].toString(16).padStart(2, "0");
    }
    return out;
  }
  function normalizeInfoHash(raw) {
    const trimmed = raw.trim();
    if (/^[0-9a-fA-F]{40}$/.test(trimmed)) {
      return trimmed.toLowerCase();
    }
    if (/^[A-Za-z2-7]{32}=*$/.test(trimmed)) {
      const decoded = decodeBase32(trimmed);
      if (decoded.length === 20) {
        return bytesToHex(decoded);
      }
    }
    throw new TypeError(`Invalid infoHash: ${raw}`);
  }
  function parseMagnet(uri) {
    var _a;
    const trimmed = uri.trim();
    if (!/^magnet:\?/i.test(trimmed)) {
      throw new TypeError("Invalid magnet URI");
    }
    const query = trimmed.slice(trimmed.indexOf("?") + 1);
    const params = new URLSearchParams(query);
    let infoHash = "";
    for (const xt of params.getAll("xt")) {
      const match = xt.match(/^urn:btih:([0-9a-fA-F]{40}|[A-Za-z2-7]{32}=*)$/i);
      if (match) {
        infoHash = normalizeInfoHash(match[1]);
        break;
      }
    }
    if (!infoHash) {
      throw new TypeError("Magnet URI missing valid btih infoHash");
    }
    const name = (_a = params.get("dn")) != null ? _a : "";
    const seen = /* @__PURE__ */ new Set();
    const trackers = [];
    for (const tr of params.getAll("tr")) {
      const t = tr.trim();
      if (t && !seen.has(t)) {
        seen.add(t);
        trackers.push(t);
      }
    }
    const xlRaw = params.get("xl");
    let size = 0;
    if (xlRaw && /^\d+$/.test(xlRaw.trim())) {
      size = Number.parseInt(xlRaw.trim(), 10);
    }
    return { infoHash, name, trackers, size };
  }
  function buildMagnet(options) {
    const infoHash = normalizeInfoHash(options.infoHash);
    const parts = [`magnet:?xt=urn:btih:${infoHash}`];
    if (options.name) {
      parts.push(`dn=${encodeURIComponent(options.name)}`);
    }
    if (options.trackers) {
      const seen = /* @__PURE__ */ new Set();
      for (const tr of options.trackers) {
        const trimmed = tr.trim();
        if (trimmed && !seen.has(trimmed)) {
          seen.add(trimmed);
          parts.push(`tr=${encodeURIComponent(trimmed)}`);
        }
      }
    }
    return parts.join("&");
  }

  // ../../../packages/plugin-std/src/size.ts
  var UNIT_EXPONENTS = {
    B: 0,
    K: 1,
    M: 2,
    G: 3,
    T: 4,
    P: 5
  };
  function parseSize(input) {
    const match = input.trim().match(/^([\d,]+(?:\.\d+)?|\.\d+)\s*([KMGTPE]?i?B)$/i);
    if (!match) {
      const inner = input.match(/([\d,]+(?:\.\d+)?)\s*([KMGT]?i?B)/i);
      if (!inner) return 0;
      return computeBytes(inner[1], inner[2]);
    }
    return computeBytes(match[1], match[2]);
  }
  function computeBytes(numStr, rawUnit) {
    const value = Number.parseFloat(numStr.replace(/,/g, ""));
    if (!Number.isFinite(value) || value < 0) return 0;
    const unit = rawUnit.toUpperCase();
    const base = unit.endsWith("IB") ? 1024 : 1e3;
    const prefix = unit === "B" ? "B" : unit[0];
    const exp = UNIT_EXPONENTS[prefix];
    if (exp === void 0) return 0;
    return Math.round(value * __pow(base, exp));
  }

  // ../../../packages/plugin-std/src/titles.ts
  var ORDINAL_TO_NUMBER = {
    first: 1,
    "1st": 1,
    second: 2,
    "2nd": 2,
    third: 3,
    "3rd": 3,
    fourth: 4,
    "4th": 4,
    fifth: 5,
    "5th": 5,
    sixth: 6,
    "6th": 6,
    seventh: 7,
    "7th": 7,
    eighth: 8,
    "8th": 8,
    ninth: 9,
    "9th": 9,
    tenth: 10,
    "10th": 10
  };
  var ROMAN_SEASON_MAP = {
    ii: 2,
    iii: 3,
    iv: 4,
    v: 5,
    vi: 6,
    vii: 7,
    viii: 8,
    ix: 9,
    xi: 11,
    xii: 12,
    xiii: 13
  };
  function extractSeason(title) {
    const val = title.toLowerCase();
    const explicit = val.match(/season\s*(\d+)/);
    if (explicit) return Number.parseInt(explicit[1], 10);
    const sFmt = val.match(/\bs0?(\d{1,2})(?:e\d|$|\s|\.)/);
    if (sFmt) {
      const num = Number.parseInt(sFmt[1], 10);
      if (num > 0 && num < 20) return num;
    }
    const ordinal = val.match(/(\d+)(?:st|nd|rd|th)\s+season/);
    if (ordinal) return Number.parseInt(ordinal[1], 10);
    const romanCleaned = val.replace(
      /\b((?:act|arc|chapter|saga|hen|part|cour))[\s._:-]+(i{1,3}|iv|vi?i?i?|ix|x)\b/g,
      "$1"
    );
    const romanPatterns = [
      /[\s.](i{1,3}|iv|vi?i?i?|ix|x)(?:\s|$|[:,.]|[''])/,
      /[\s.](i{1,3}|iv|vi?i?i?|ix|x)[.\s]*(?:s\d|e\d|part)/
    ];
    for (const re of romanPatterns) {
      const m = romanCleaned.match(re);
      if (m && ROMAN_SEASON_MAP[m[1]] !== void 0) {
        return ROMAN_SEASON_MAP[m[1]];
      }
    }
    const trailing = val.match(/(?:^|\s)(\d{1,2})\s*$/);
    if (trailing && !/(?:part|cour|specials?|sp|movie|ova|ona|oad)\s*\d{1,2}\s*$/.test(val)) {
      const num = Number.parseInt(trailing[1], 10);
      if (num >= 2 && num <= 10) return num;
    }
    const jp = val.match(/(?:第)?(\d+)\s*期/);
    if (jp) return Number.parseInt(jp[1], 10);
    const wordOrd = val.match(
      /\b(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)\s+season\b/
    );
    if (wordOrd && ORDINAL_TO_NUMBER[wordOrd[1]] !== void 0) {
      return ORDINAL_TO_NUMBER[wordOrd[1]];
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../../../packages/plugin-std/src/limit.ts
  function mapLimit(items, limit, fn) {
    return __async(this, null, function* () {
      if (items.length === 0) return [];
      const concurrency = Math.max(1, Math.floor(limit));
      const out = new Array(items.length);
      let next = 0;
      const worker = () => __async(null, null, function* () {
        while (next < items.length) {
          const index = next++;
          out[index] = yield fn(items[index], index);
        }
      });
      yield Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
      return out;
    });
  }

  // ../../../packages/plugin-std/src/json.ts
  function extractJson(text) {
    const results = [];
    let i = 0;
    while (i < text.length) {
      const open = text[i];
      if (open !== "{" && open !== "[") {
        i++;
        continue;
      }
      const stack = [open === "{" ? "}" : "]"];
      let inString = false;
      let escaped = false;
      let j = i + 1;
      let parsed = false;
      while (j < text.length && stack.length > 0) {
        const ch = text[j];
        if (inString) {
          if (escaped) {
            escaped = false;
          } else if (ch === "\\") {
            escaped = true;
          } else if (ch === '"') {
            inString = false;
          }
        } else {
          if (ch === '"') {
            inString = true;
          } else if (ch === "{") {
            stack.push("}");
          } else if (ch === "[") {
            stack.push("]");
          } else if (ch === "}" || ch === "]") {
            if (stack[stack.length - 1] !== ch) {
              break;
            }
            stack.pop();
          }
        }
        j++;
      }
      if (stack.length === 0) {
        const candidate = text.slice(i, j);
        try {
          results.push(JSON.parse(candidate));
          parsed = true;
        } catch (e) {
          parsed = false;
        }
      }
      i = parsed ? j : i + 1;
    }
    return results;
  }

  // ../torrent-common/src/option.ts
  var DEFAULT_TRACKERS = [
    "http://nyaa.tracker.wf:7777/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce"
  ];
  var MAX_RETRIEVAL_URI_LENGTH = 2e3;
  function numberValue(value) {
    return { kind: "number", number: value };
  }
  function makeFact(producerId, id, field, value, at = (/* @__PURE__ */ new Date()).toISOString()) {
    return {
      id,
      producerId,
      field,
      value: numberValue(value),
      locale: "",
      region: "",
      status: "complete",
      at
    };
  }
  function buildCountsFacts(producerId, key, counts) {
    const at = (/* @__PURE__ */ new Date()).toISOString();
    const facts = [];
    if (counts.size !== void 0 && Number.isFinite(counts.size) && counts.size > 0) {
      facts.push(makeFact(producerId, `size-${key}`, "size", counts.size, at));
    }
    if (counts.seeders !== void 0 && Number.isFinite(counts.seeders) && counts.seeders >= 0) {
      facts.push(makeFact(producerId, `seeders-${key}`, "seeders", counts.seeders, at));
    }
    if (counts.leechers !== void 0 && Number.isFinite(counts.leechers) && counts.leechers >= 0) {
      facts.push(makeFact(producerId, `leechers-${key}`, "leechers", counts.leechers, at));
    }
    if (counts.downloads !== void 0 && Number.isFinite(counts.downloads) && counts.downloads > 0) {
      facts.push(makeFact(producerId, `downloads-${key}`, "downloads", counts.downloads, at));
    }
    return facts;
  }
  function parseIsoDate(caye2, raw, layouts) {
    var _a;
    const trimmed = raw == null ? void 0 : raw.trim();
    if (!trimmed) return void 0;
    if (typeof ((_a = caye2.time) == null ? void 0 : _a.parse) === "function") {
      try {
        const ms = caye2.time.parse(trimmed, layouts ? { layouts } : void 0);
        if (Number.isFinite(ms)) {
          return new Date(ms).toISOString();
        }
      } catch (e) {
      }
    }
    const parsed = Date.parse(trimmed);
    if (Number.isFinite(parsed)) {
      return new Date(parsed).toISOString();
    }
    return void 0;
  }
  function pickUri(magnet, torrentUrl) {
    if (magnet && Array.from(magnet).length <= MAX_RETRIEVAL_URI_LENGTH) {
      return magnet;
    }
    return torrentUrl || magnet || "";
  }
  function createTorrentOption(caye2, input) {
    var _a, _b, _c, _d;
    const uri = pickUri(input.magnet, input.torrentUrl);
    const facts = buildCountsFacts(input.providerId, input.key, {
      size: input.size,
      seeders: input.seeders,
      leechers: input.leechers,
      downloads: input.downloads
    });
    let resolution = ((_a = input.resolution) == null ? void 0 : _a.trim()) || "";
    let group = ((_b = input.group) == null ? void 0 : _b.trim()) || "";
    if ((!resolution || !group) && typeof ((_c = caye2.release) == null ? void 0 : _c.parse) === "function") {
      try {
        const parsed = caye2.release.parse(input.name);
        if (!resolution && parsed.resolution) resolution = parsed.resolution;
        if (!group && parsed.group) group = parsed.group;
      } catch (e) {
      }
    }
    const option = {
      id: input.id,
      name: input.name,
      kind: "torrent",
      uri,
      files: [],
      facts,
      availability: "available",
      eligible: true,
      reasons: [],
      confirmed: Boolean(input.confirmed)
    };
    if (input.seeders !== void 0 && Number.isFinite(input.seeders) && input.seeders >= 0) {
      option.seeders = Math.trunc(input.seeders);
    }
    if (input.size !== void 0 && Number.isFinite(input.size) && input.size > 0) {
      option.size = Math.round(input.size);
    }
    if (input.publishedAt) option.publishedAt = input.publishedAt;
    if (input.pageUrl && /^https?:\/\//i.test(input.pageUrl)) {
      option.pageUrl = input.pageUrl;
    }
    if ((_d = input.magnet) == null ? void 0 : _d.startsWith("magnet:")) {
      option.magnet = input.magnet;
    }
    if (resolution) option.resolution = resolution;
    if (group) option.group = group;
    if (input.best) option.best = true;
    return option;
  }
  var missingMessage = (service) => `${service} no longer lists this torrent.`;
  function fetchText(caye2, service, url, options) {
    return __async(this, null, function* () {
      var _b, _c;
      const _a = options != null ? options : {}, { missingOn404 } = _a, input = __objRest(_a, ["missingOn404"]);
      const response = yield httpClient(caye2, service).send(
        __spreadProps(__spreadValues({}, input), { url }),
        missingOn404 ? { missing: missingMessage(service) } : void 0
      );
      return {
        status: response.status,
        headers: (_b = response.headers) != null ? _b : {},
        body: (_c = response.body) != null ? _c : "",
        url: response.url
      };
    });
  }
  function fetchJson(caye2, service, url, options) {
    return __async(this, null, function* () {
      const res = yield fetchText(caye2, service, url, options);
      if (!res.body) {
        throw failure("unavailable", `${service} returned an empty response.`);
      }
      try {
        return JSON.parse(res.body);
      } catch (e) {
        throw failure("unavailable", `${service} returned malformed JSON.`);
      }
    });
  }

  // ../../../packages/plugin-std/src/cache.ts
  function getCachedJson(api, key) {
    return __async(this, null, function* () {
      try {
        const value = yield api.cache.get({ key });
        if ((value == null ? void 0 : value.kind) === "text") return JSON.parse(value.text);
      } catch (e) {
      }
      return void 0;
    });
  }
  function setCachedJson(api, key, value, ttlSeconds) {
    return __async(this, null, function* () {
      try {
        yield api.cache.set({
          key,
          value: { kind: "text", text: JSON.stringify(value) },
          ttlSeconds
        });
      } catch (e) {
      }
    });
  }

  // ../torrent-common/src/smart.ts
  var OPTION_CACHE_TTL_SECONDS = 7 * 24 * 60 * 60;
  function parseResolutionNumber(raw) {
    if (!raw) return 0;
    const lower = raw.trim().toLowerCase();
    if (lower === "4k" || lower === "uhd") return 2160;
    if (lower === "8k") return 4320;
    const match = /(\d{3,4})/.exec(lower);
    return match ? Number.parseInt(match[1], 10) : 0;
  }
  function normalizeResolutionLabel(raw) {
    const n = parseResolutionNumber(raw);
    if (n >= 360 && n <= 4320) return `${n}p`;
    return "";
  }
  function extractResolution(caye2, title) {
    try {
      const parsed = caye2.release.parse(title);
      if (parsed.resolution) {
        const normalized = normalizeResolutionLabel(parsed.resolution);
        if (normalized) return normalized;
      }
    } catch (e) {
    }
    if (/\b(?:4k|2160p?|uhd)\b/i.test(title)) return "2160p";
    const match = /\b(\d{3,4})\s*p\b/i.exec(title);
    if (match) {
      const normalized = normalizeResolutionLabel(match[1]);
      if (normalized) return normalized;
    }
    return "";
  }
  function clampLimit(limit, fallback = 50, max = 100) {
    return Math.min(Math.max(limit || fallback, 1), max);
  }
  function cacheOptions(_0, _1, _2) {
    return __async(this, arguments, function* (caye2, prefix, options, ttlSeconds = OPTION_CACHE_TTL_SECONDS) {
      for (const option of options) {
        yield setCachedJson(caye2, `${prefix}:option:${option.id}`, option, ttlSeconds);
      }
    });
  }
  function validateHttpUrl(raw) {
    const trimmed = (raw == null ? void 0 : raw.trim()) || "";
    if (!trimmed) return void 0;
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol === "http:" || parsed.protocol === "https:") {
        return parsed.toString();
      }
    } catch (e) {
    }
    return void 0;
  }
  function resolveFromRetrievalInput(caye2, providerId, prefix, input, notFoundMessage, defaultGroup) {
    var _a, _b, _c, _d;
    const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
    const rawMagnet = ((_b = input.magnet) == null ? void 0 : _b.trim()) || "";
    const rawInfoHash = ((_c = input.infoHash) == null ? void 0 : _c.trim()) || "";
    const rawTorrentUrl = ((_d = input.torrentUrl) == null ? void 0 : _d.trim()) || "";
    const hasRetrieval = Boolean(rawMagnet || rawInfoHash || rawTorrentUrl);
    if (!hasRetrieval) return void 0;
    if (optionId && !optionId.startsWith(`${prefix}-`)) {
      throw failure("missing", notFoundMessage);
    }
    const validTorrentUrl = rawTorrentUrl ? validateHttpUrl(rawTorrentUrl) : void 0;
    if (rawTorrentUrl && !validTorrentUrl) {
      throw failure("missing", "Invalid torrent retrieval URL.");
    }
    if (rawMagnet) {
      let parsed;
      try {
        parsed = parseMagnet(rawMagnet);
      } catch (e) {
        throw failure("missing", "Invalid magnet retrieval URI.");
      }
      const id = optionId || `${prefix}-${parsed.infoHash}`;
      return createTorrentOption(caye2, {
        id,
        key: parsed.infoHash,
        providerId,
        name: parsed.name || `${prefix} ${parsed.infoHash}`,
        magnet: rawMagnet,
        torrentUrl: validTorrentUrl,
        size: parsed.size > 0 ? parsed.size : void 0,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (rawInfoHash) {
      let infoHash = "";
      try {
        infoHash = normalizeInfoHash(rawInfoHash);
      } catch (e) {
        throw failure("missing", "Invalid torrent info hash.");
      }
      const id = optionId || `${prefix}-${infoHash}`;
      const magnet = buildMagnet({ infoHash, trackers: DEFAULT_TRACKERS });
      return createTorrentOption(caye2, {
        id,
        key: infoHash,
        providerId,
        name: `${prefix} ${infoHash}`,
        magnet,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (validTorrentUrl) {
      const id = optionId || `${prefix}-torrent`;
      const key = id.startsWith(`${prefix}-`) ? id.slice(prefix.length + 1) : id;
      return createTorrentOption(caye2, {
        id,
        key,
        providerId,
        name: `${prefix} ${key}`,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    return void 0;
  }
  function resolveCachedOrFallback(caye2, prefix, input, notFoundMessage, fetchFallback, options) {
    return __async(this, null, function* () {
      var _a;
      const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
      if (!optionId && !input.magnet && !input.torrentUrl && !input.infoHash) {
        throw failure("missing", notFoundMessage);
      }
      if (optionId && !optionId.startsWith(`${prefix}-`)) {
        throw failure("missing", notFoundMessage);
      }
      if (optionId) {
        const cached = yield getCachedJson(caye2, `${prefix}:option:${optionId}`);
        if (cached && cached.id === optionId) {
          return cached;
        }
      }
      if (fetchFallback && optionId) {
        try {
          return yield fetchFallback(optionId);
        } catch (err) {
          const code = err == null ? void 0 : err.code;
          if (code !== "missing" && code !== "unavailable" && code !== "rate-limited") throw err;
          const fallback2 = resolveFromRetrievalInput(
            caye2,
            (options == null ? void 0 : options.providerId) || `backreef.${prefix}:search`,
            prefix,
            input,
            notFoundMessage,
            options == null ? void 0 : options.group
          );
          if (fallback2) return fallback2;
          throw err;
        }
      }
      const fallback = resolveFromRetrievalInput(
        caye2,
        (options == null ? void 0 : options.providerId) || `backreef.${prefix}:search`,
        prefix,
        input,
        notFoundMessage,
        options == null ? void 0 : options.group
      );
      if (fallback) return fallback;
      throw failure("missing", notFoundMessage);
    });
  }
  function normalizeLatinText(s) {
    let out = (s || "").toLowerCase().replace(/×/g, "x");
    try {
      out = out.normalize("NFKD").replace(/[\u0300-\u036f]/g, "");
    } catch (e) {
    }
    return out.replace(/[^a-z0-9]+/g, " ").trim();
  }
  function inferSeasonFromTitle(title) {
    return Math.max(1, extractSeason(title || ""));
  }
  function stripTitleSeason(title) {
    return (title || "").replace(/\(?\b\d+(?:st|nd|rd|th)\s+season\b\)?/gi, "").replace(/\b(?:season|part|cour)\s*\d+\b/gi, "").replace(/\s+(?:ii|iii|iv|v|vi|vii|viii|\d{1,2})\s*$/i, "").replace(/[\s:\-–]+$/, "").trim();
  }

  // ../torrent-common/src/media.ts
  function asRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return void 0;
    return value;
  }
  function positiveIntString(value) {
    if (typeof value === "number") {
      return Number.isInteger(value) && value > 0 ? String(value) : void 0;
    }
    if (typeof value === "string") {
      const trimmed = value.trim();
      return /^[1-9][0-9]*$/.test(trimmed) ? trimmed : void 0;
    }
    return void 0;
  }
  function addUniqueTitle(target, raw) {
    if (typeof raw !== "string") return;
    const trimmed = raw.trim();
    if (trimmed && !target.includes(trimmed)) {
      target.push(trimmed);
    }
  }
  function extractEntriesIds(entriesValue, preferredNative) {
    if (!Array.isArray(entriesValue)) return {};
    let anilistId;
    let anidbId;
    let malId;
    let bgmId;
    const inspect = (requireMatch) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      for (const rawEntry of entriesValue) {
        const entry = asRecord(rawEntry);
        if (!entry) continue;
        const ref = asRecord(entry.ref);
        if (requireMatch && preferredNative) {
          if ((ref == null ? void 0 : ref.providerId) !== preferredNative.entry.providerId || (ref == null ? void 0 : ref.nativeId) !== preferredNative.entry.nativeId) {
            continue;
          }
        }
        const ids = asRecord(entry.ids);
        if (ids) {
          anilistId != null ? anilistId : anilistId = positiveIntString((_b = (_a = ids.anilistid) != null ? _a : ids.anilistId) != null ? _b : ids.anilist);
          anidbId != null ? anidbId : anidbId = positiveIntString((_d = (_c = ids.anidbid) != null ? _c : ids.anidbId) != null ? _d : ids.anidb);
          malId != null ? malId : malId = positiveIntString((_f = (_e = ids.malid) != null ? _e : ids.malId) != null ? _f : ids.mal);
          bgmId != null ? bgmId : bgmId = positiveIntString((_i = (_h = (_g = ids.bgmid) != null ? _g : ids.bgmId) != null ? _h : ids.bgm) != null ? _i : ids.bangumi);
        }
        if ((ref == null ? void 0 : ref.providerId) === "caye.anilist:catalog" || (ref == null ? void 0 : ref.providerId) === "anilist" || typeof (ref == null ? void 0 : ref.providerId) === "string" && ref.providerId.includes("anilist")) {
          anilistId != null ? anilistId : anilistId = positiveIntString(ref.nativeId);
        }
      }
    };
    if (preferredNative) inspect(true);
    inspect(false);
    return { anilistId, anidbId, malId, bgmId };
  }
  function extractFieldMap(fieldsValue) {
    const out = {};
    if (!Array.isArray(fieldsValue)) return out;
    for (const rawField of fieldsValue) {
      const entry = asRecord(rawField);
      if (!entry || typeof entry.field !== "string") continue;
      const val = asRecord(entry.value);
      if (val) out[entry.field] = val;
    }
    return out;
  }
  function parseDateParts(raw) {
    if (typeof raw !== "string") return void 0;
    const m = /^(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?/.exec(raw.trim());
    if (!m) return void 0;
    const year = Number.parseInt(m[1], 10);
    if (year < 1900 || year > 2100) return void 0;
    return {
      year,
      month: m[2] ? Number.parseInt(m[2], 10) : void 0,
      day: m[3] ? Number.parseInt(m[3], 10) : void 0
    };
  }
  function safeGetItem(caye2, itemId) {
    return __async(this, null, function* () {
      if (!itemId || typeof caye2.request !== "function") return void 0;
      try {
        const raw = yield caye2.request("getItem", { path: { itemId } });
        return asRecord(raw);
      } catch (e) {
        return void 0;
      }
    });
  }
  function pickPreferredNative(query) {
    var _a;
    const refs = (_a = query.native) != null ? _a : [];
    if (refs.length === 0) return void 0;
    const exact = refs.find((r) => r.itemId === query.itemId);
    if (exact) return exact;
    return refs[0];
  }
  function resolveMediaContext(caye2, query) {
    return __async(this, null, function* () {
      var _a, _b;
      const titles = [];
      let romajiTitle = "";
      let englishTitle = "";
      let originalTitle = "";
      const synonyms = [];
      let anilistId;
      let anidbId;
      let malId;
      let bgmId;
      let isMovie = false;
      let isAnime = false;
      let adult = false;
      let year;
      let startDate;
      let episodeCount;
      let releaseStatus;
      const preferredNative = pickPreferredNative(query);
      const item = yield safeGetItem(caye2, query.itemId || (preferredNative == null ? void 0 : preferredNative.itemId));
      const parentId = typeof (item == null ? void 0 : item.parentId) === "string" ? item.parentId : void 0;
      const parentItem = parentId ? yield safeGetItem(caye2, parentId) : void 0;
      const consumeTitlesObj = (rawTitles) => {
        const t = asRecord(rawTitles);
        if (!t) return;
        if (!romajiTitle && typeof t.romaji === "string") romajiTitle = t.romaji.trim();
        if (!englishTitle && typeof t.english === "string") englishTitle = t.english.trim();
        if (!originalTitle && typeof t.original === "string") originalTitle = t.original.trim();
        addUniqueTitle(titles, t.romaji);
        addUniqueTitle(titles, t.english);
        addUniqueTitle(titles, t.original);
      };
      const inspectRecord = (record) => {
        var _a2, _b2, _c, _d, _e, _f, _g, _h, _i, _j, _k;
        if (!record) return;
        if (record.adult === true) adult = true;
        const kindId = typeof record.kindId === "string" ? record.kindId : "";
        const kindLeaf = (kindId.includes(":") ? kindId.split(":")[1] : kindId).toLowerCase();
        if (kindLeaf === "movie") isMovie = true;
        if (kindLeaf === "anime" || kindId.toLowerCase().includes(":anime")) isAnime = true;
        const ids = extractEntriesIds(record.entries, preferredNative);
        anilistId != null ? anilistId : anilistId = ids.anilistId;
        anidbId != null ? anidbId : anidbId = ids.anidbId;
        malId != null ? malId : malId = ids.malId;
        bgmId != null ? bgmId : bgmId = ids.bgmId;
        if (anilistId || anidbId) isAnime = true;
        const parentSummary = asRecord(record.parent);
        if (parentSummary) {
          consumeTitlesObj(parentSummary.titles);
          addUniqueTitle(titles, parentSummary.name);
        }
        consumeTitlesObj(record.titles);
        addUniqueTitle(titles, record.name);
        const totalChildren = typeof record.totalChildren === "number" ? record.totalChildren : typeof record.childCount === "number" ? record.childCount : void 0;
        if (totalChildren !== void 0 && totalChildren > 0 && episodeCount === void 0) {
          episodeCount = totalChildren;
        }
        const fields = extractFieldMap(record.fields);
        if (((_a2 = fields["caye:adult"]) == null ? void 0 : _a2.boolean) === true) adult = true;
        const formatVal = typeof ((_b2 = fields["caye:format"]) == null ? void 0 : _b2.text) === "string" ? fields["caye:format"].text.trim() : "";
        if (/^movie$/i.test(formatVal)) isMovie = true;
        if (/^(?:tv|tv_short|ova|ona|special|anime)$/i.test(formatVal) && isAnime) isMovie = false;
        const romajiField = typeof ((_c = fields["caye:romaji"]) == null ? void 0 : _c.text) === "string" ? fields["caye:romaji"].text.trim() : "";
        const englishField = typeof ((_d = fields["caye:english"]) == null ? void 0 : _d.text) === "string" ? fields["caye:english"].text.trim() : "";
        const originalField = typeof ((_e = fields["caye:original"]) == null ? void 0 : _e.text) === "string" ? fields["caye:original"].text.trim() : "";
        if (!romajiTitle && romajiField) romajiTitle = romajiField;
        if (!englishTitle && englishField) englishTitle = englishField;
        if (!originalTitle && originalField) originalTitle = originalField;
        addUniqueTitle(titles, romajiField);
        addUniqueTitle(titles, englishField);
        addUniqueTitle(titles, originalField);
        if (!releaseStatus) {
          const statusVal = (_h = (_f = fields["caye:status"]) == null ? void 0 : _f.text) != null ? _h : (_g = fields["caye:releaseStatus"]) == null ? void 0 : _g.text;
          if (typeof statusVal === "string" && statusVal.trim()) releaseStatus = statusVal.trim();
        }
        if (!startDate) {
          const releaseAt = (_i = fields["caye:releaseAt"]) == null ? void 0 : _i.text;
          startDate = parseDateParts(releaseAt);
        }
        if (year === void 0) {
          const yNum = (_j = fields["caye:year"]) == null ? void 0 : _j.number;
          if (typeof yNum === "number" && yNum >= 1900 && yNum <= 2100) {
            year = Math.trunc(yNum);
          } else if (startDate) {
            year = startDate.year;
          }
        }
        for (const key of ["caye:titles", "caye:synonyms", "caye:alternativeTitles"]) {
          const list = (_k = fields[key]) == null ? void 0 : _k.list;
          if (Array.isArray(list)) {
            for (const v of list) {
              const obj = asRecord(v);
              if (typeof (obj == null ? void 0 : obj.text) === "string" && obj.text.trim()) {
                addUniqueTitle(synonyms, obj.text);
                addUniqueTitle(titles, obj.text);
              }
            }
          }
        }
      };
      inspectRecord(parentItem);
      inspectRecord(item);
      const text = ((_a = query.text) == null ? void 0 : _a.trim()) || "";
      if (text) {
        addUniqueTitle(titles, text);
      }
      if (!anilistId) {
        for (const ref of (_b = query.native) != null ? _b : []) {
          if (ref.entry.providerId === "caye.anilist:catalog" || ref.entry.providerId === "anilist" || ref.entry.providerId.includes("anilist")) {
            anilistId = positiveIntString(ref.entry.nativeId);
            if (anilistId) break;
          }
        }
      }
      const season = typeof query.season === "number" && query.season > 0 ? query.season : typeof (item == null ? void 0 : item.season) === "number" && item.season > 0 ? item.season : void 0;
      const number = typeof query.number === "number" && query.number > 0 ? query.number : typeof (item == null ? void 0 : item.number) === "number" && item.number > 0 ? item.number : void 0;
      const absolute = typeof query.absolute === "number" && query.absolute > 0 ? query.absolute : void 0;
      const absoluteSeasonOffset = absolute !== void 0 && number !== void 0 && absolute > number ? absolute - number : 0;
      return {
        text,
        titles,
        romajiTitle: romajiTitle || titles[0] || "",
        englishTitle: englishTitle || "",
        originalTitle,
        synonyms,
        anilistId,
        anidbId,
        malId,
        bgmId,
        season,
        number,
        absolute,
        isMovie,
        isAnime,
        adult,
        year,
        startDate: startDate != null ? startDate : year ? { year } : void 0,
        episodeCount,
        releaseStatus,
        absoluteSeasonOffset
      };
    });
  }

  // src/backend.ts
  var PROVIDER_ID = "backreef.dkb:search";
  var DKB_BASE = "https://dkb.lowpolyfire.com";
  var DAY_MS = 24 * 3600 * 1e3;
  var SHOW_TITLES_TTL = 6 * 3600;
  function pad2(n) {
    return n < 10 ? `0${n}` : String(n);
  }
  function parseReleases(html) {
    const doc = caye.html.parse(html);
    const out = [];
    doc.find(".release_container").each((_, block) => {
      var _a;
      const label = block.find(".episode").first().text().trim().toUpperCase();
      const showTitle = block.find(".title a").first().text().trim();
      const magnet = ((_a = block.find('.links a[href^="magnet:"]').first().attr("href")) == null ? void 0 : _a.trim()) || "";
      if (!magnet) return true;
      let infoHash = "";
      let magnetName = "";
      try {
        const parsed = parseMagnet(magnet);
        infoHash = parsed.infoHash;
        magnetName = parsed.name;
      } catch (e) {
        const m2 = /btih:([a-fA-F0-9]{40})/i.exec(magnet);
        if (m2) infoHash = normalizeInfoHash(m2[1]);
      }
      if (!infoHash) return true;
      const name = magnetName || `[DKB] ${showTitle} - ${label}`;
      let kind = "episode";
      let season = -1;
      let episode = -1;
      let m;
      if (m = /^S(\d+)E(\d+)/.exec(label)) {
        season = Number.parseInt(m[1], 10);
        episode = Number.parseInt(m[2], 10);
        if (season === 0) kind = "special";
      } else if (m = /^S(\d+)\s*-\s*BATCH/.exec(label)) {
        kind = "batch";
        season = Number.parseInt(m[1], 10);
      } else if (label.includes("MOVIE")) {
        kind = "movie";
      } else if (m = /\bS(\d+)E(\d+)\b/i.exec(name)) {
        season = Number.parseInt(m[1], 10);
        episode = Number.parseInt(m[2], 10);
        kind = season === 0 ? "special" : "episode";
      } else if (/batch/i.test(name)) {
        kind = "batch";
        const sm = /Season\s*(\d+)/i.exec(name);
        season = sm ? Number.parseInt(sm[1], 10) : -1;
      } else {
        kind = "movie";
      }
      const dateRaw = block.find(".date").first().text().trim();
      const publishedAt = parseIsoDate(caye, dateRaw, [
        "2006-01-02 15:04",
        "2006-01-02 15:04:05",
        "2006-01-02"
      ]);
      const seeders = Number.parseInt(block.find(".seeders .value").first().text().trim(), 10) || 0;
      const leechers = Number.parseInt(block.find(".leechers .value").first().text().trim(), 10) || 0;
      const sizeText = block.find(".size .value").first().text().trim();
      let torrentUrl = "";
      block.find(".links a").each((_2, a) => {
        var _a2;
        const href = ((_a2 = a.attr("href")) == null ? void 0 : _a2.trim()) || "";
        if (/^https?:\/\/.+\.torrent$/i.test(href)) {
          torrentUrl = href;
          return false;
        }
        return true;
      });
      out.push({
        kind,
        season,
        episode,
        showTitle,
        name,
        publishedAt,
        seeders,
        leechers,
        size: parseSize(sizeText),
        torrentUrl,
        magnet,
        infoHash
      });
      return true;
    });
    return out;
  }
  function fetchReleases(query, filter = "") {
    return __async(this, null, function* () {
      const url = `${DKB_BASE}/index/releases?query=${encodeURIComponent(query)}${filter}`;
      const res = yield fetchText(caye, "DKB", url, {
        headers: { Accept: "text/html", "HX-Request": "true" }
      });
      return parseReleases(res.body);
    });
  }
  function fetchAll(queries, filter = "") {
    return __async(this, null, function* () {
      const lists = yield mapLimit(queries, 3, (q) => fetchReleases(q, filter));
      const seen = /* @__PURE__ */ new Set();
      const out = [];
      for (const list of lists) {
        for (const r of list) {
          if (seen.has(r.infoHash)) continue;
          seen.add(r.infoHash);
          out.push(r);
        }
      }
      return out;
    });
  }
  function getShowTitles() {
    return __async(this, null, function* () {
      const cacheKey = "dkb:show-titles";
      const cached = yield getCachedJson(caye, cacheKey);
      if (Array.isArray(cached) && cached.length > 0) return cached;
      try {
        const res = yield fetchText(caye, "DKB", `${DKB_BASE}/`, {
          headers: { Accept: "text/html" }
        });
        const doc = caye.html.parse(res.body);
        let titles = [];
        doc.find("script").each((_, el) => {
          const txt = el.text();
          const idx = txt.indexOf("shows_titles");
          if (idx < 0) return true;
          const eq = txt.indexOf("=", idx);
          if (eq < 0) return true;
          try {
            const extracted = extractJson(txt.slice(eq + 1).replace(/\\'/g, "'"));
            const first = extracted[0];
            if (Array.isArray(first)) {
              titles = first.filter((t) => typeof t === "string");
              return false;
            }
          } catch (e) {
          }
          return true;
        });
        if (titles.length > 0) {
          yield setCachedJson(caye, cacheKey, titles, SHOW_TITLES_TTL);
        }
        return titles;
      } catch (e) {
        return [];
      }
    });
  }
  function getMapping(anilistId) {
    return __async(this, null, function* () {
      var _a, _b;
      const empty = { episodes: {}, seasons: [], titles: [] };
      if (!anilistId) return empty;
      const cacheKey = `dkb:mapping:${anilistId}`;
      const cached = yield getCachedJson(caye, cacheKey);
      if (cached && cached.episodes) return cached;
      try {
        const data = yield fetchJson(caye, "ani.zip", `https://api.ani.zip/mappings?anilist_id=${anilistId}`, {
          headers: { Accept: "application/json" },
          timeoutMs: 5e3
        });
        for (const val of Object.values((_a = data.titles) != null ? _a : {})) {
          if (typeof val === "string" && /[a-z]/i.test(val)) empty.titles.push(val);
        }
        for (const [k, ep] of Object.entries((_b = data.episodes) != null ? _b : {})) {
          if (!/^\d+$/.test(k)) continue;
          if (typeof ep.seasonNumber !== "number" || typeof ep.episodeNumber !== "number")
            continue;
          empty.episodes[k] = {
            season: ep.seasonNumber,
            episode: ep.episodeNumber,
            airdate: ep.airdate || ep.airDate || ""
          };
          if (!empty.seasons.includes(ep.seasonNumber)) empty.seasons.push(ep.seasonNumber);
        }
        yield setCachedJson(caye, cacheKey, empty, OPTION_CACHE_TTL_SECONDS);
      } catch (e) {
      }
      return empty;
    });
  }
  function related(a, b) {
    const x = normalizeLatinText(a);
    const y = normalizeLatinText(b);
    if (!x || !y) return 0;
    if (x === y) return 1e3;
    const squash = (s) => s.replace(/ /g, "");
    if (squash(x) === squash(y)) return 900;
    const long = (s) => s.length >= 6 || s.includes(" ");
    if (y.startsWith(`${x} `) && long(x)) return 100 + x.length;
    const bx = normalizeLatinText(stripTitleSeason(a));
    const by = normalizeLatinText(stripTitleSeason(b));
    if (bx && long(bx) && squash(bx) === squash(by)) return 500;
    if (squash(x).length >= 10 && squash(y).startsWith(squash(x))) return 100 + x.length;
    if (x.startsWith(`${y} `) && long(y)) return 10;
    return 0;
  }
  function matchShowTitles(showTitles, titles) {
    const scored = [];
    for (const showTitle of showTitles) {
      let score = 0;
      for (const t of titles) score = Math.max(score, related(showTitle, t));
      if (score > 0) scored.push({ title: showTitle, score });
    }
    scored.sort((a, b) => b.score - a.score);
    const strong = scored.filter((x) => x.score >= 100);
    return (strong.length > 0 ? strong : scored).slice(0, 3).map((x) => x.title);
  }
  function ownerOf(release, showTitles) {
    const r = normalizeLatinText(release.showTitle);
    let best = "";
    let bestLen = -1;
    for (const t of showTitles) {
      const s = normalizeLatinText(t);
      if (s === r) return t;
      if (r.startsWith(`${s} `) && s.length > bestLen) {
        best = t;
        bestLen = s.length;
      }
    }
    return best || release.showTitle;
  }
  function tokenOverlap(a, b) {
    const words = normalizeLatinText(a).split(" ").filter((w) => w.length > 1 && !/^(?:movie|the|no|dkb|\d+)$/.test(w));
    if (words.length === 0) return 0;
    const pool = ` ${b.map(normalizeLatinText).join(" ")} `;
    return words.filter((w) => pool.includes(` ${w} `)).length / words.length;
  }
  function timeMs(s) {
    if (!s) return 0;
    const t = Date.parse(s);
    return Number.isNaN(t) ? 0 : t;
  }
  function airsMatch(r, airdate) {
    if (!airdate || !/\bweekly\b/i.test(r.name)) return true;
    const d = timeMs(r.publishedAt) - timeMs(airdate);
    return d > -3 * DAY_MS && d < 180 * DAY_MS;
  }
  function nyaaLink(torrentUrl) {
    var _a;
    const id = (_a = /nyaa\.si\/download\/(\d+)/.exec(torrentUrl)) == null ? void 0 : _a[1];
    if (id) return `https://nyaa.si/view/${id}`;
    return torrentUrl || void 0;
  }
  function toOption(r, confirmed) {
    return createTorrentOption(caye, {
      id: `dkb-${r.infoHash}`,
      key: r.infoHash,
      providerId: PROVIDER_ID,
      name: r.name,
      magnet: r.magnet,
      torrentUrl: r.torrentUrl || void 0,
      pageUrl: nyaaLink(r.torrentUrl),
      size: r.size > 0 ? r.size : void 0,
      seeders: r.seeders,
      leechers: r.leechers,
      publishedAt: r.publishedAt,
      resolution: extractResolution(caye, r.name) || void 0,
      group: "DKB",
      confirmed
    });
  }
  function mediaTitleList(media, extra) {
    const out = [];
    for (const t of [
      media.romajiTitle,
      media.englishTitle,
      ...media.synonyms,
      ...media.titles,
      ...extra
    ]) {
      if (t && /[a-z]/i.test(t) && !out.includes(t)) out.push(t);
    }
    return out;
  }
  function find(_context, query) {
    return __async(this, null, function* () {
      var _a, _b, _c, _d;
      const media = yield resolveMediaContext(caye, query);
      const isSmart = Boolean(query.batch || query.number && query.number > 0 || query.itemId);
      const limit = clampLimit(query.limit, 50, 100);
      if (!isSmart) {
        const text = ((_a = query.text) == null ? void 0 : _a.trim()) || "";
        if (!text) throw failure("unsupported", "Enter a title to search.");
        const releases = yield fetchReleases(text);
        const items2 = releases.slice(0, limit).map((r) => toOption(r, false));
        yield cacheOptions(caye, "dkb", items2);
        return { items: items2, state: "complete" };
      }
      const [showTitles, mapping] = yield Promise.all([getShowTitles(), getMapping(media.anilistId)]);
      const titles = mediaTitleList(media, mapping.titles);
      const customQuery = ((_b = query.text) == null ? void 0 : _b.trim()) || "";
      const matched = matchShowTitles(showTitles, titles);
      let queries;
      if (customQuery) {
        queries = [customQuery];
      } else {
        queries = matched.slice();
        const own = stripTitleSeason(
          (media.romajiTitle || media.englishTitle || "").split(/:\s| - /)[0]
        );
        if (own && !queries.some((q) => normalizeLatinText(q) === normalizeLatinText(own)))
          queries.push(own);
      }
      if (queries.length === 0) {
        throw failure("unsupported", "Enter a title to search.");
      }
      const belongs = (r) => Boolean(customQuery) || matched.includes(ownerOf(r, showTitles)) || titles.some((t) => related(r.showTitle, t) >= 100);
      const wantedRes = parseResolutionNumber(query.resolution);
      const resolutionOk = (r) => {
        if (!wantedRes) return true;
        const got = parseResolutionNumber(extractResolution(caye, r.name));
        return !got || got === wantedRes;
      };
      let chosen = [];
      if (media.isMovie) {
        const releases = yield fetchAll(queries, "&m=1");
        chosen = releases.filter(
          (r) => belongs(r) && resolutionOk(r) && r.kind === "movie" && tokenOverlap(r.showTitle, titles) >= 0.6
        ).map((r) => toOption(r, true));
      } else {
        const fallbackSeason = query.season && query.season > 0 ? query.season : inferSeasonFromTitle(media.romajiTitle || media.englishTitle || "");
        const seasons = mapping.seasons.length > 0 ? mapping.seasons : [fallbackSeason];
        if (query.batch) {
          const releases = yield fetchAll(queries, "&b=1");
          chosen = releases.filter(
            (r) => belongs(r) && resolutionOk(r) && r.kind === "batch" && seasons.includes(r.season)
          ).map((r) => toOption(r, false));
        } else {
          const epNum = query.number && query.number > 0 ? Math.trunc(query.number) : 0;
          const known = epNum > 0 ? mapping.episodes[String(epNum)] : void 0;
          if (known) {
            const releases = (yield fetchAll(
              queries.map((q) => `${q} S${pad2(known.season)}E${pad2(known.episode)}`)
            )).filter(
              (r) => belongs(r) && resolutionOk(r) && r.season === known.season && r.episode === known.episode && airsMatch(r, known.airdate)
            );
            if (releases.length > 0) {
              chosen = releases.map((r) => toOption(r, true));
            }
          }
          if (chosen.length === 0) {
            const reverse = {};
            const offsets = {};
            for (const [epKey, p] of Object.entries(mapping.episodes)) {
              const epInt = Number.parseInt(epKey, 10);
              reverse[`${p.season}x${p.episode}`] = epInt;
              offsets[p.season] = p.episode - epInt;
            }
            const lastKey = Object.keys(mapping.episodes).map((k) => Number.parseInt(k, 10)).sort((a, b) => b - a)[0];
            const lastSeason = lastKey ? mapping.episodes[String(lastKey)].season : fallbackSeason;
            const wantedSeasons = epNum > 0 ? [lastSeason] : seasons.slice(0, 3);
            const episodeOk = (ep) => ep >= 1 && !(media.episodeCount && media.episodeCount > 0 && ep > media.episodeCount) && !(epNum > 0 && ep !== epNum);
            const fetched = yield mapLimit(
              wantedSeasons,
              3,
              (s) => fetchAll(queries.map((q) => `${q} S${pad2(s)}`))
            );
            for (let i = 0; i < wantedSeasons.length; i++) {
              const s = wantedSeasons[i];
              const offset = offsets[s];
              if (offset === void 0) continue;
              for (const r of fetched[i]) {
                if (!belongs(r) || !resolutionOk(r) || r.kind !== "episode" || r.season !== s)
                  continue;
                const mapped = reverse[`${r.season}x${r.episode}`];
                const ep = mapped || r.episode - offset;
                if (!episodeOk(ep)) continue;
                if (mapped && !airsMatch(r, mapping.episodes[String(mapped)].airdate))
                  continue;
                chosen.push(toOption(r, Boolean(mapped)));
              }
            }
            if (chosen.length === 0 && ((_c = media.startDate) == null ? void 0 : _c.year) && media.startDate.month && media.startDate.day) {
              const start = Date.UTC(
                media.startDate.year,
                media.startDate.month - 1,
                media.startDate.day
              );
              const pool = (yield fetchAll(
                queries.concat(queries.map((q) => `${q} S${pad2(fallbackSeason)}`))
              )).filter((r) => belongs(r) && r.kind === "episode" && r.season > 0);
              const firstAfter = pool.filter((r) => timeMs(r.publishedAt) >= start - 2 * DAY_MS).sort((a, b) => timeMs(a.publishedAt) - timeMs(b.publishedAt))[0];
              if (firstAfter && timeMs(firstAfter.publishedAt) - start <= 30 * DAY_MS) {
                const season = firstAfter.season;
                const offset = Math.min(
                  ...pool.filter(
                    (r) => r.season === season && timeMs(r.publishedAt) >= start - 2 * DAY_MS
                  ).map((r) => r.episode)
                ) - 1;
                for (const r of pool) {
                  if (r.season !== season || !resolutionOk(r)) continue;
                  const ep = r.episode - offset;
                  if (!episodeOk(ep)) continue;
                  const air = ((_d = mapping.episodes[String(ep)]) == null ? void 0 : _d.airdate) || "";
                  if (!airsMatch(r, air)) continue;
                  chosen.push(toOption(r, false));
                }
              }
            }
          }
        }
      }
      const items = chosen.slice(0, limit);
      yield cacheOptions(caye, "dkb", items);
      return { items, state: "complete" };
    });
  }
  function resolve(_context, input) {
    return __async(this, null, function* () {
      return yield resolveCachedOrFallback(
        caye,
        "dkb",
        input,
        "Unknown or uncached DKB option.",
        void 0,
        { providerId: PROVIDER_ID, group: "DKB" }
      );
    });
  }
  caye.register(PROVIDER_ID, { acquisition: { find, resolve } });
})();
//# sourceMappingURL=backend.js.map
