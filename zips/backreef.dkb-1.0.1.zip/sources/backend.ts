import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DownloadOption,
} from "../../../../packages/plugin-sdk/src/index"
import {
    cacheOptions,
    clampLimit,
    createTorrentOption,
    extractJson,
    extractResolution,
    fetchJson,
    fetchText,
    inferSeasonFromTitle,
    mapLimit,
    normalizeInfoHash,
    normalizeLatinText,
    OPTION_CACHE_TTL_SECONDS,
    parseIsoDate,
    parseMagnet,
    parseResolutionNumber,
    parseSize,
    resolveCachedOrFallback,
    resolveMediaContext,
    stripTitleSeason,
    type MediaContext,
} from "../../torrent-common/src/index.ts"
import { getCachedJson, setCachedJson } from "../../../../packages/plugin-std/src/cache.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const PROVIDER_ID = "backreef.dkb:search"
const DKB_BASE = "https://dkb.lowpolyfire.com"
const DAY_MS = 24 * 3600 * 1000
const SHOW_TITLES_TTL = 6 * 3600

type DkbKind = "episode" | "batch" | "movie" | "special"

type DkbRelease = {
    kind: DkbKind
    season: number
    episode: number
    showTitle: string
    name: string
    publishedAt?: string
    seeders: number
    leechers: number
    size: number
    torrentUrl: string
    magnet: string
    infoHash: string
}

type TvdbEpisode = {
    season: number
    episode: number
    airdate: string
}

type MediaMapping = {
    episodes: Record<string, TvdbEpisode>
    seasons: number[]
    titles: string[]
}

function pad2(n: number): string {
    return n < 10 ? `0${n}` : String(n)
}

function parseReleases(html: string): DkbRelease[] {
    const doc = caye.html.parse(html)
    const out: DkbRelease[] = []

    doc.find(".release_container").each((_, block) => {
        const label = block.find(".episode").first().text().trim().toUpperCase()
        const showTitle = block.find(".title a").first().text().trim()
        const magnet = block.find('.links a[href^="magnet:"]').first().attr("href")?.trim() || ""
        if (!magnet) return true

        let infoHash = ""
        let magnetName = ""
        try {
            const parsed = parseMagnet(magnet)
            infoHash = parsed.infoHash
            magnetName = parsed.name
        } catch {
            const m = /btih:([a-fA-F0-9]{40})/i.exec(magnet)
            if (m) infoHash = normalizeInfoHash(m[1])
        }
        if (!infoHash) return true

        const name = magnetName || `[DKB] ${showTitle} - ${label}`
        let kind: DkbKind = "episode"
        let season = -1
        let episode = -1
        let m: RegExpMatchArray | null

        if ((m = /^S(\d+)E(\d+)/.exec(label))) {
            season = Number.parseInt(m[1], 10)
            episode = Number.parseInt(m[2], 10)
            if (season === 0) kind = "special"
        } else if ((m = /^S(\d+)\s*-\s*BATCH/.exec(label))) {
            kind = "batch"
            season = Number.parseInt(m[1], 10)
        } else if (label.includes("MOVIE")) {
            kind = "movie"
        } else if ((m = /\bS(\d+)E(\d+)\b/i.exec(name))) {
            season = Number.parseInt(m[1], 10)
            episode = Number.parseInt(m[2], 10)
            kind = season === 0 ? "special" : "episode"
        } else if (/batch/i.test(name)) {
            kind = "batch"
            const sm = /Season\s*(\d+)/i.exec(name)
            season = sm ? Number.parseInt(sm[1], 10) : -1
        } else {
            kind = "movie"
        }

        const dateRaw = block.find(".date").first().text().trim()
        const publishedAt = parseIsoDate(caye, dateRaw, [
            "2006-01-02 15:04",
            "2006-01-02 15:04:05",
            "2006-01-02",
        ])
        const seeders =
            Number.parseInt(block.find(".seeders .value").first().text().trim(), 10) || 0
        const leechers =
            Number.parseInt(block.find(".leechers .value").first().text().trim(), 10) || 0
        const sizeText = block.find(".size .value").first().text().trim()

        let torrentUrl = ""
        block.find(".links a").each((_, a) => {
            const href = a.attr("href")?.trim() || ""
            if (/^https?:\/\/.+\.torrent$/i.test(href)) {
                torrentUrl = href
                return false
            }
            return true
        })

        out.push({
            kind,
            season,
            episode,
            showTitle,
            name,
            publishedAt,
            seeders,
            leechers,
            size: parseSize(sizeText),
            torrentUrl,
            magnet,
            infoHash,
        })
        return true
    })

    return out
}

async function fetchReleases(query: string, filter = ""): Promise<DkbRelease[]> {
    const url = `${DKB_BASE}/index/releases?query=${encodeURIComponent(query)}${filter}`
    const res = await fetchText(caye, "DKB", url, {
        headers: { Accept: "text/html", "HX-Request": "true" },
    })
    return parseReleases(res.body)
}

async function fetchAll(queries: string[], filter = ""): Promise<DkbRelease[]> {
    const lists = await mapLimit(queries, 3, (q) => fetchReleases(q, filter))
    const seen = new Set<string>()
    const out: DkbRelease[] = []
    for (const list of lists) {
        for (const r of list) {
            if (seen.has(r.infoHash)) continue
            seen.add(r.infoHash)
            out.push(r)
        }
    }
    return out
}

async function getShowTitles(): Promise<string[]> {
    const cacheKey = "dkb:show-titles"
    const cached = await getCachedJson<string[]>(caye, cacheKey)
    if (Array.isArray(cached) && cached.length > 0) return cached

    try {
        const res = await fetchText(caye, "DKB", `${DKB_BASE}/`, {
            headers: { Accept: "text/html" },
        })
        const doc = caye.html.parse(res.body)
        let titles: string[] = []
        doc.find("script").each((_, el) => {
            const txt = el.text()
            const idx = txt.indexOf("shows_titles")
            if (idx < 0) return true
            const eq = txt.indexOf("=", idx)
            if (eq < 0) return true
            try {
                const extracted = extractJson(txt.slice(eq + 1).replace(/\\'/g, "'"))
                const first = extracted[0]
                if (Array.isArray(first)) {
                    titles = first.filter((t): t is string => typeof t === "string")
                    return false
                }
            } catch {}
            return true
        })
        if (titles.length > 0) {
            await setCachedJson(caye, cacheKey, titles, SHOW_TITLES_TTL)
        }
        return titles
    } catch {
        return []
    }
}

async function getMapping(anilistId: string | undefined): Promise<MediaMapping> {
    const empty: MediaMapping = { episodes: {}, seasons: [], titles: [] }
    if (!anilistId) return empty
    const cacheKey = `dkb:mapping:${anilistId}`
    const cached = await getCachedJson<MediaMapping>(caye, cacheKey)
    if (cached && cached.episodes) return cached

    try {
        const data = await fetchJson<{
            titles?: Record<string, string>
            episodes?: Record<
                string,
                {
                    seasonNumber?: number
                    episodeNumber?: number
                    airdate?: string
                    airDate?: string
                }
            >
        }>(caye, "ani.zip", `https://api.ani.zip/mappings?anilist_id=${anilistId}`, {
            headers: { Accept: "application/json" },
            timeoutMs: 5000,
        })
        for (const val of Object.values(data.titles ?? {})) {
            if (typeof val === "string" && /[a-z]/i.test(val)) empty.titles.push(val)
        }
        for (const [k, ep] of Object.entries(data.episodes ?? {})) {
            if (!/^\d+$/.test(k)) continue
            if (typeof ep.seasonNumber !== "number" || typeof ep.episodeNumber !== "number")
                continue
            empty.episodes[k] = {
                season: ep.seasonNumber,
                episode: ep.episodeNumber,
                airdate: ep.airdate || ep.airDate || "",
            }
            if (!empty.seasons.includes(ep.seasonNumber)) empty.seasons.push(ep.seasonNumber)
        }
        await setCachedJson(caye, cacheKey, empty, OPTION_CACHE_TTL_SECONDS)
    } catch {}
    return empty
}

function related(a: string, b: string): number {
    const x = normalizeLatinText(a)
    const y = normalizeLatinText(b)
    if (!x || !y) return 0
    if (x === y) return 1000
    const squash = (s: string) => s.replace(/ /g, "")
    if (squash(x) === squash(y)) return 900
    const long = (s: string) => s.length >= 6 || s.includes(" ")
    if (y.startsWith(`${x} `) && long(x)) return 100 + x.length
    const bx = normalizeLatinText(stripTitleSeason(a))
    const by = normalizeLatinText(stripTitleSeason(b))
    if (bx && long(bx) && squash(bx) === squash(by)) return 500
    if (squash(x).length >= 10 && squash(y).startsWith(squash(x))) return 100 + x.length
    if (x.startsWith(`${y} `) && long(y)) return 10
    return 0
}

function matchShowTitles(showTitles: string[], titles: string[]): string[] {
    const scored: { title: string; score: number }[] = []
    for (const showTitle of showTitles) {
        let score = 0
        for (const t of titles) score = Math.max(score, related(showTitle, t))
        if (score > 0) scored.push({ title: showTitle, score })
    }
    scored.sort((a, b) => b.score - a.score)
    const strong = scored.filter((x) => x.score >= 100)
    return (strong.length > 0 ? strong : scored).slice(0, 3).map((x) => x.title)
}

function ownerOf(release: DkbRelease, showTitles: string[]): string {
    const r = normalizeLatinText(release.showTitle)
    let best = ""
    let bestLen = -1
    for (const t of showTitles) {
        const s = normalizeLatinText(t)
        if (s === r) return t
        if (r.startsWith(`${s} `) && s.length > bestLen) {
            best = t
            bestLen = s.length
        }
    }
    return best || release.showTitle
}

function tokenOverlap(a: string, b: string[]): number {
    const words = normalizeLatinText(a)
        .split(" ")
        .filter((w) => w.length > 1 && !/^(?:movie|the|no|dkb|\d+)$/.test(w))
    if (words.length === 0) return 0
    const pool = ` ${b.map(normalizeLatinText).join(" ")} `
    return words.filter((w) => pool.includes(` ${w} `)).length / words.length
}

function timeMs(s: string | undefined): number {
    if (!s) return 0
    const t = Date.parse(s)
    return Number.isNaN(t) ? 0 : t
}

function airsMatch(r: DkbRelease, airdate: string): boolean {
    if (!airdate || !/\bweekly\b/i.test(r.name)) return true
    const d = timeMs(r.publishedAt) - timeMs(airdate)
    return d > -3 * DAY_MS && d < 180 * DAY_MS
}

function nyaaLink(torrentUrl: string): string | undefined {
    const id = /nyaa\.si\/download\/(\d+)/.exec(torrentUrl)?.[1]
    if (id) return `https://nyaa.si/view/${id}`
    return torrentUrl || undefined
}

function toOption(r: DkbRelease, confirmed: boolean): DownloadOption {
    return createTorrentOption(caye, {
        id: `dkb-${r.infoHash}`,
        key: r.infoHash,
        providerId: PROVIDER_ID,
        name: r.name,
        magnet: r.magnet,
        torrentUrl: r.torrentUrl || undefined,
        pageUrl: nyaaLink(r.torrentUrl),
        size: r.size > 0 ? r.size : undefined,
        seeders: r.seeders,
        leechers: r.leechers,
        publishedAt: r.publishedAt,
        resolution: extractResolution(caye, r.name) || undefined,
        group: "DKB",
        confirmed,
    })
}

function mediaTitleList(media: MediaContext, extra: string[]): string[] {
    const out: string[] = []
    for (const t of [
        media.romajiTitle,
        media.englishTitle,
        ...media.synonyms,
        ...media.titles,
        ...extra,
    ]) {
        if (t && /[a-z]/i.test(t) && !out.includes(t)) out.push(t)
    }
    return out
}

async function find(_context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const media = await resolveMediaContext(caye, query)
    const isSmart = Boolean(query.batch || (query.number && query.number > 0) || query.itemId)
    const limit = clampLimit(query.limit, 50, 100)

    if (!isSmart) {
        const text = query.text?.trim() || ""
        if (!text) throw failure("unsupported", "Enter a title to search.")
        const releases = await fetchReleases(text)
        const items = releases.slice(0, limit).map((r) => toOption(r, false))
        await cacheOptions(caye, "dkb", items)
        return { items, state: "complete" }
    }

    const [showTitles, mapping] = await Promise.all([getShowTitles(), getMapping(media.anilistId)])
    const titles = mediaTitleList(media, mapping.titles)
    const customQuery = query.text?.trim() || ""
    const matched = matchShowTitles(showTitles, titles)
    let queries: string[]
    if (customQuery) {
        queries = [customQuery]
    } else {
        queries = matched.slice()
        const own = stripTitleSeason(
            (media.romajiTitle || media.englishTitle || "").split(/:\s| - /)[0],
        )
        if (own && !queries.some((q) => normalizeLatinText(q) === normalizeLatinText(own)))
            queries.push(own)
    }
    if (queries.length === 0) {
        throw failure("unsupported", "Enter a title to search.")
    }

    const belongs = (r: DkbRelease) =>
        Boolean(customQuery) ||
        matched.includes(ownerOf(r, showTitles)) ||
        titles.some((t) => related(r.showTitle, t) >= 100)
    const wantedRes = parseResolutionNumber(query.resolution)
    const resolutionOk = (r: DkbRelease) => {
        if (!wantedRes) return true
        const got = parseResolutionNumber(extractResolution(caye, r.name))
        return !got || got === wantedRes
    }

    let chosen: DownloadOption[] = []

    if (media.isMovie) {
        const releases = await fetchAll(queries, "&m=1")
        chosen = releases
            .filter(
                (r) =>
                    belongs(r) &&
                    resolutionOk(r) &&
                    r.kind === "movie" &&
                    tokenOverlap(r.showTitle, titles) >= 0.6,
            )
            .map((r) => toOption(r, true))
    } else {
        const fallbackSeason =
            query.season && query.season > 0
                ? query.season
                : inferSeasonFromTitle(media.romajiTitle || media.englishTitle || "")
        const seasons = mapping.seasons.length > 0 ? mapping.seasons : [fallbackSeason]

        if (query.batch) {
            const releases = await fetchAll(queries, "&b=1")
            chosen = releases
                .filter(
                    (r) =>
                        belongs(r) &&
                        resolutionOk(r) &&
                        r.kind === "batch" &&
                        seasons.includes(r.season),
                )
                .map((r) => toOption(r, false))
        } else {
            const epNum = query.number && query.number > 0 ? Math.trunc(query.number) : 0
            const known = epNum > 0 ? mapping.episodes[String(epNum)] : undefined
            if (known) {
                const releases = (
                    await fetchAll(
                        queries.map((q) => `${q} S${pad2(known.season)}E${pad2(known.episode)}`),
                    )
                ).filter(
                    (r) =>
                        belongs(r) &&
                        resolutionOk(r) &&
                        r.season === known.season &&
                        r.episode === known.episode &&
                        airsMatch(r, known.airdate),
                )
                if (releases.length > 0) {
                    chosen = releases.map((r) => toOption(r, true))
                }
            }

            if (chosen.length === 0) {
                const reverse: Record<string, number> = {}
                const offsets: Record<number, number> = {}
                for (const [epKey, p] of Object.entries(mapping.episodes)) {
                    const epInt = Number.parseInt(epKey, 10)
                    reverse[`${p.season}x${p.episode}`] = epInt
                    offsets[p.season] = p.episode - epInt
                }
                const lastKey = Object.keys(mapping.episodes)
                    .map((k) => Number.parseInt(k, 10))
                    .sort((a, b) => b - a)[0]
                const lastSeason = lastKey
                    ? mapping.episodes[String(lastKey)].season
                    : fallbackSeason
                const wantedSeasons = epNum > 0 ? [lastSeason] : seasons.slice(0, 3)
                const episodeOk = (ep: number) =>
                    ep >= 1 &&
                    !(media.episodeCount && media.episodeCount > 0 && ep > media.episodeCount) &&
                    !(epNum > 0 && ep !== epNum)

                const fetched = await mapLimit(wantedSeasons, 3, (s) =>
                    fetchAll(queries.map((q) => `${q} S${pad2(s)}`)),
                )
                for (let i = 0; i < wantedSeasons.length; i++) {
                    const s = wantedSeasons[i]
                    const offset = offsets[s]
                    if (offset === undefined) continue
                    for (const r of fetched[i]) {
                        if (
                            !belongs(r) ||
                            !resolutionOk(r) ||
                            r.kind !== "episode" ||
                            r.season !== s
                        )
                            continue
                        const mapped = reverse[`${r.season}x${r.episode}`]
                        const ep = mapped || r.episode - offset
                        if (!episodeOk(ep)) continue
                        if (mapped && !airsMatch(r, mapping.episodes[String(mapped)].airdate))
                            continue
                        chosen.push(toOption(r, Boolean(mapped)))
                    }
                }

                if (
                    chosen.length === 0 &&
                    media.startDate?.year &&
                    media.startDate.month &&
                    media.startDate.day
                ) {
                    const start = Date.UTC(
                        media.startDate.year,
                        media.startDate.month - 1,
                        media.startDate.day,
                    )
                    const pool = (
                        await fetchAll(
                            queries.concat(queries.map((q) => `${q} S${pad2(fallbackSeason)}`)),
                        )
                    ).filter((r) => belongs(r) && r.kind === "episode" && r.season > 0)
                    const firstAfter = pool
                        .filter((r) => timeMs(r.publishedAt) >= start - 2 * DAY_MS)
                        .sort((a, b) => timeMs(a.publishedAt) - timeMs(b.publishedAt))[0]
                    if (firstAfter && timeMs(firstAfter.publishedAt) - start <= 30 * DAY_MS) {
                        const season = firstAfter.season
                        const offset =
                            Math.min(
                                ...pool
                                    .filter(
                                        (r) =>
                                            r.season === season &&
                                            timeMs(r.publishedAt) >= start - 2 * DAY_MS,
                                    )
                                    .map((r) => r.episode),
                            ) - 1
                        for (const r of pool) {
                            if (r.season !== season || !resolutionOk(r)) continue
                            const ep = r.episode - offset
                            if (!episodeOk(ep)) continue
                            const air = mapping.episodes[String(ep)]?.airdate || ""
                            if (!airsMatch(r, air)) continue
                            chosen.push(toOption(r, false))
                        }
                    }
                }
            }
        }
    }

    const items = chosen.slice(0, limit)
    await cacheOptions(caye, "dkb", items)
    return { items, state: "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    return await resolveCachedOrFallback(
        caye,
        "dkb",
        input,
        "Unknown or uncached DKB option.",
        undefined,
        { providerId: PROVIDER_ID, group: "DKB" },
    )
}

caye.register(PROVIDER_ID, { acquisition: { find, resolve } })
