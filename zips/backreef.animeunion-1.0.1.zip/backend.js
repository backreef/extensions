(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/titles.ts
  var YEAR_PAREN_RE = /\((\d{4})\)/;
  var YEAR_STANDALONE_RE = /\b(19\d{2}|20\d{2})\b/;
  function extractYear(title) {
    const paren = title.match(YEAR_PAREN_RE);
    if (paren) {
      const year = Number.parseInt(paren[1], 10);
      if (year >= 1900 && year <= 2100) return year;
    }
    const standalone = title.match(YEAR_STANDALONE_RE);
    if (standalone) {
      return Number.parseInt(standalone[1], 10);
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../../../packages/plugin-std/src/url.ts
  function resolveUrl(raw, base) {
    const trimmed = raw.trim();
    if (!trimmed) return "";
    try {
      const url = new URL(trimmed.startsWith("//") ? `https:${trimmed}` : trimmed, base);
      return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : "";
    } catch (e) {
      return "";
    }
  }
  function cleanBaseUrl(raw, fallback) {
    const resolved = resolveUrl(raw != null ? raw : "");
    if (!resolved) return fallback;
    const url = new URL(resolved);
    return url.origin + url.pathname.replace(/\/+$/, "");
  }

  // ../stream-common/src/common.ts
  function streamOriginOf(url, hint) {
    const lowerUrl = url.toLowerCase();
    const lowerHint = (hint != null ? hint : "").toLowerCase();
    if (lowerHint === "hls" || lowerHint === "m3u8" || /\.m3u8(\?|$|#)/.test(lowerUrl)) {
      return "hls";
    }
    return "http";
  }
  function choiceId(label, fallback = "default") {
    const slug = label.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64);
    return slug || fallback;
  }
  function uniqueChoices(items) {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const item of items) {
      if (!item.id || seen.has(item.id) || out.length >= 200) continue;
      seen.add(item.id);
      out.push({
        id: item.id.slice(0, 200),
        label: (item.label || item.id).slice(0, 200)
      });
    }
    return out;
  }
  function videoRef(providerId2, nativeId) {
    return {
      providerId: providerId2,
      type: "video",
      nativeId
    };
  }
  function sameRef(ref) {
    return ref.scope ? {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId,
      scope: ref.scope
    } : {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId
    };
  }
  function limitItems(items, limit) {
    if (typeof limit === "number" && Number.isFinite(limit) && limit > 0) {
      return items.slice(0, limit);
    }
    return items;
  }
  function futureDeadline(contextDeadline, minutes = 10) {
    const now = Date.now();
    if (contextDeadline) {
      const parsed = Date.parse(contextDeadline);
      if (Number.isFinite(parsed) && parsed > now + 5e3 && parsed <= now + 24 * 3600 * 1e3) {
        return contextDeadline;
      }
    }
    return new Date(now + minutes * 60 * 1e3).toISOString();
  }
  function extractFirstYear(text) {
    const year = extractYear(text != null ? text : "");
    return year > 0 ? year : void 0;
  }

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../../../packages/plugin-std/src/page-data.ts
  function decodeSvelteKitTable(table) {
    if (!Array.isArray(table) || table.length === 0) return null;
    const resolveRef = (value, seen) => {
      if (typeof value === "number" && Number.isInteger(value) && value >= 0 && value < table.length) {
        if (seen.has(value)) return null;
        return resolveNode(table[value], new Set(seen).add(value));
      }
      return resolveNode(value, seen);
    };
    const resolveNode = (value, seen) => {
      if (Array.isArray(value)) return value.map((entry) => resolveRef(entry, seen));
      if (value && typeof value === "object") {
        const out = {};
        for (const [key, entry] of Object.entries(value)) out[key] = resolveRef(entry, seen);
        return out;
      }
      return value;
    };
    return resolveRef(0, /* @__PURE__ */ new Set());
  }
  function decodeSvelteKitPayload(payload) {
    var _a;
    const node = (_a = payload == null ? void 0 : payload.nodes) == null ? void 0 : _a.find(
      (entry) => (entry == null ? void 0 : entry.type) === "data" && Array.isArray(entry.data)
    );
    return (node == null ? void 0 : node.data) ? decodeSvelteKitTable(node.data) : null;
  }

  // src/backend.ts
  var providerId = "backreef.animeunion:source";
  var providerName = "AnimeUnion";
  var site = httpClient(caye, providerName);
  var defaultSiteBase = "https://animeunion.tv";
  var apiBase = "https://api.animeunion.tv";
  function siteBase(context) {
    var _a;
    return cleanBaseUrl((_a = context == null ? void 0 : context.config) == null ? void 0 : _a.url, defaultSiteBase);
  }
  function displayQuality(value) {
    const cleaned = String(value != null ? value : "Auto").replace(/^Q_/i, "").replace(/(\d+)P$/i, "$1p").trim();
    return cleaned || "Auto";
  }
  function parseSeriesNativeId(nativeId) {
    const [slug, countStr] = nativeId.split("|");
    const count = countStr ? Number.parseInt(countStr, 10) : NaN;
    return {
      slug: slug.trim(),
      episodeCount: Number.isInteger(count) && count > 0 ? count : void 0
    };
  }
  function parseEpisodeNativeId(nativeId) {
    const sep = nativeId.lastIndexOf("|");
    if (sep <= 0 || sep >= nativeId.length - 1) {
      throw failure("unavailable", `${providerName} invalid episode reference`);
    }
    const epNumber = Number.parseInt(nativeId.slice(sep + 1), 10);
    if (!Number.isInteger(epNumber) || epNumber < 1) {
      throw failure("unavailable", `${providerName} invalid episode number`);
    }
    return { slug: nativeId.slice(0, sep), epNumber };
  }
  function fetchStreamLinks(base, slug, epNumber) {
    return __async(this, null, function* () {
      var _a;
      const dataUrl = `${base}/anime/${encodeURIComponent(slug)}/${epNumber}/__data.json?x-sveltekit-invalidated=01`;
      const payload = yield site.json({
        url: dataUrl,
        headers: {
          Accept: "application/json",
          Referer: `${base}/`
        }
      });
      const page = decodeSvelteKitPayload(payload);
      const links = (_a = page == null ? void 0 : page.episode) == null ? void 0 : _a.streamLinks;
      if (!Array.isArray(links)) return [];
      const out = [];
      links.forEach((link, index) => {
        var _a2, _b;
        if (!link || link.isActive === false || typeof link.url !== "string") return;
        const resolvedUrl = resolveUrl(link.url, base);
        if (!resolvedUrl) return;
        const lang = String((_a2 = link.language) != null ? _a2 : "").trim().toUpperCase();
        const audio = lang.startsWith("DUB") ? "dub" : "sub";
        const quality = displayQuality(link.quality);
        const qualityId = choiceId(quality, "auto");
        out.push({
          id: `${audio}:${qualityId}:${index}`,
          url: resolvedUrl,
          audio,
          quality: qualityId,
          label: `${quality} \xB7 ${(_b = link.language) != null ? _b : audio.toUpperCase()}`
        });
      });
      return out;
    });
  }
  caye.register(providerId, {
    source: {
      search(_context, query) {
        return __async(this, null, function* () {
          var _a, _b, _c, _d, _e;
          const q = ((_a = query == null ? void 0 : query.q) != null ? _a : "").trim();
          if (!q) return { items: [], nextCursor: "", state: "complete" };
          const limit = typeof (query == null ? void 0 : query.limit) === "number" && query.limit > 0 ? Math.min(20, Math.floor(query.limit)) : 8;
          const url = new URL("/api/v1/anime", apiBase);
          url.searchParams.set("q", q);
          url.searchParams.set("limit", String(limit));
          const payload = yield site.json({
            url: url.toString(),
            headers: { Accept: "application/json" }
          });
          const items = [];
          const seen = /* @__PURE__ */ new Set();
          for (const anime of Array.isArray(payload == null ? void 0 : payload.data) ? payload.data : []) {
            const slug = ((_b = anime == null ? void 0 : anime.slug) != null ? _b : "").trim();
            const epCount = Number(anime == null ? void 0 : anime.episodeCount);
            if (!slug || !Number.isInteger(epCount) || epCount < 1 || seen.has(slug)) continue;
            seen.add(slug);
            const name = (anime.titleEng || anime.title || anime.titleIta || slug).trim();
            const year = extractFirstYear(
              String((_e = (_d = (_c = anime.releaseYear) != null ? _c : anime.year) != null ? _d : anime.startDate) != null ? _e : "")
            );
            items.push(__spreadValues({
              ref: videoRef(providerId, `${slug}|${epCount}`),
              name
            }, year !== void 0 ? { year } : {}));
          }
          return {
            items: limitItems(items, query == null ? void 0 : query.limit),
            nextCursor: "",
            state: "complete"
          };
        });
      },
      read(_context, ref) {
        return __async(this, null, function* () {
          var _a, _b, _c;
          const { slug } = parseSeriesNativeId(ref.nativeId);
          const anime = yield site.json({
            url: `${apiBase}/api/v1/anime/${encodeURIComponent(slug)}`,
            headers: { Accept: "application/json" }
          });
          const name = ((anime == null ? void 0 : anime.titleEng) || (anime == null ? void 0 : anime.title) || (anime == null ? void 0 : anime.titleIta) || "").trim();
          if (!name) {
            throw failure("unavailable", `${providerName} title was not found`);
          }
          const year = extractFirstYear(
            String((_c = (_b = (_a = anime.releaseYear) != null ? _a : anime.year) != null ? _b : anime.startDate) != null ? _c : "")
          );
          return __spreadValues({
            ref: sameRef(ref),
            name
          }, year !== void 0 ? { year } : {});
        });
      },
      list(_context, ref) {
        return __async(this, null, function* () {
          var _a;
          const { slug, episodeCount: refCount } = parseSeriesNativeId(ref.nativeId);
          let count = refCount;
          let hasSub = true;
          let hasDub = true;
          if (!count) {
            const anime = yield site.json({
              url: `${apiBase}/api/v1/anime/${encodeURIComponent(slug)}`,
              headers: { Accept: "application/json" }
            });
            count = Number(anime.episodeCount);
            const langs = ((_a = anime.availableLanguages) != null ? _a : []).map((v) => String(v).toUpperCase());
            if (langs.length > 0) {
              hasSub = langs.some((l) => l.startsWith("SUB"));
              hasDub = langs.some((l) => l.startsWith("DUB"));
            }
          }
          if (!count || !Number.isInteger(count) || count < 1) {
            return {
              installments: [],
              choices: {
                audio: [{ id: "sub", label: "Sub" }],
                server: [{ id: "default", label: "AnimeUnion" }],
                quality: [{ id: "auto", label: "Auto" }]
              }
            };
          }
          const installments = Array.from({ length: count }, (_, idx) => {
            const num = idx + 1;
            return {
              number: num,
              name: `Episode ${num}`,
              ref: videoRef(providerId, `${slug}|${num}`)
            };
          });
          return {
            installments,
            choices: {
              audio: uniqueChoices([
                ...hasSub ? [{ id: "sub", label: "Sub" }] : [],
                ...hasDub ? [{ id: "dub", label: "Dub" }] : []
              ]),
              server: [{ id: "default", label: "AnimeUnion" }],
              quality: [
                { id: "auto", label: "Auto" },
                { id: "1080p", label: "1080p" },
                { id: "720p", label: "720p" },
                { id: "480p", label: "480p" }
              ]
            }
          };
        });
      },
      find(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const { slug, epNumber } = parseEpisodeNativeId(ref.nativeId);
          const links = yield fetchStreamLinks(base, slug, epNumber);
          const deadline = futureDeadline(context == null ? void 0 : context.deadline);
          const items = links.map((link) => ({
            id: link.id,
            origin: streamOriginOf(link.url),
            capabilities: ["video"],
            expiresAt: deadline,
            tracks: [
              {
                id: "main",
                kind: "video",
                language: "it",
                label: link.label
              }
            ],
            ranges: [],
            choices: {
              audio: link.audio,
              server: "default",
              quality: link.quality
            }
          }));
          return { items, state: "complete" };
        });
      },
      resolve(context, input) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const { slug, epNumber } = parseEpisodeNativeId(input.ref.nativeId);
          const links = yield fetchStreamLinks(base, slug, epNumber);
          const selected = links.find((l) => l.id === input.sourceId);
          if (!selected) {
            throw failure("unavailable", `${providerName} stream is unavailable`);
          }
          const handle = yield site.handle({
            url: selected.url,
            headers: {
              Origin: base,
              Referer: `${base}/`
            }
          });
          return {
            id: input.sourceId,
            origin: streamOriginOf(selected.url),
            capabilities: ["video"],
            expiresAt: handle.expiresAt,
            handle,
            tracks: [
              {
                id: "main",
                kind: "video",
                language: "it",
                label: selected.label
              }
            ],
            ranges: [],
            choices: {
              audio: selected.audio,
              server: "default",
              quality: selected.quality
            }
          };
        });
      }
    }
  });
})();
//# sourceMappingURL=backend.js.map
