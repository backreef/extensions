import type {
    API,
    Context,
    Query,
    Ref,
    Source,
    SourceInstallment,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
    SourceResolveInput,
} from "../../../../packages/plugin-sdk/src/index"
import {
    choiceId,
    extractFirstYear,
    futureDeadline,
    limitItems,
    sameRef,
    streamOriginOf,
    uniqueChoices,
    videoRef,
} from "../../stream-common/src/common"
import { failure, httpClient } from "../../../../packages/plugin-std/src/http.ts"
import {
    type SvelteKitPayload,
    decodeSvelteKitPayload,
} from "../../../../packages/plugin-std/src/page-data.ts"
import { cleanBaseUrl, resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.animeunion:source"
const providerName = "AnimeUnion"
const site = httpClient(caye, providerName)
const defaultSiteBase = "https://animeunion.tv"
const apiBase = "https://api.animeunion.tv"

type AnimeRecord = {
    slug?: string
    title?: string
    titleEng?: string
    titleIta?: string
    episodeCount?: number
    availableLanguages?: string[]
    releaseYear?: number | string
    year?: number | string
    startDate?: string
}

type StreamLink = {
    url?: string
    isActive?: boolean
    language?: string
    quality?: string
}

function siteBase(context: Context): string {
    return cleanBaseUrl(context?.config?.url, defaultSiteBase)
}

function displayQuality(value: unknown): string {
    const cleaned = String(value ?? "Auto")
        .replace(/^Q_/i, "")
        .replace(/(\d+)P$/i, "$1p")
        .trim()
    return cleaned || "Auto"
}

function parseSeriesNativeId(nativeId: string): { slug: string; episodeCount?: number } {
    const [slug, countStr] = nativeId.split("|")
    const count = countStr ? Number.parseInt(countStr, 10) : NaN
    return {
        slug: slug.trim(),
        episodeCount: Number.isInteger(count) && count > 0 ? count : undefined,
    }
}

function parseEpisodeNativeId(nativeId: string): { slug: string; epNumber: number } {
    const sep = nativeId.lastIndexOf("|")
    if (sep <= 0 || sep >= nativeId.length - 1) {
        throw failure("unavailable", `${providerName} invalid episode reference`)
    }
    const epNumber = Number.parseInt(nativeId.slice(sep + 1), 10)
    if (!Number.isInteger(epNumber) || epNumber < 1) {
        throw failure("unavailable", `${providerName} invalid episode number`)
    }
    return { slug: nativeId.slice(0, sep), epNumber }
}

async function fetchStreamLinks(
    base: string,
    slug: string,
    epNumber: number,
): Promise<
    Array<{ id: string; url: string; audio: "sub" | "dub"; quality: string; label: string }>
> {
    const dataUrl = `${base}/anime/${encodeURIComponent(slug)}/${epNumber}/__data.json?x-sveltekit-invalidated=01`
    const payload = await site.json<SvelteKitPayload>({
        url: dataUrl,
        headers: {
            Accept: "application/json",
            Referer: `${base}/`,
        },
    })
    const page = decodeSvelteKitPayload(payload) as {
        episode?: { streamLinks?: StreamLink[] }
    } | null
    const links = page?.episode?.streamLinks
    if (!Array.isArray(links)) return []

    const out: Array<{
        id: string
        url: string
        audio: "sub" | "dub"
        quality: string
        label: string
    }> = []
    links.forEach((link, index) => {
        if (!link || link.isActive === false || typeof link.url !== "string") return
        const resolvedUrl = resolveUrl(link.url, base)
        if (!resolvedUrl) return
        const lang = String(link.language ?? "")
            .trim()
            .toUpperCase()
        const audio = lang.startsWith("DUB") ? "dub" : "sub"
        const quality = displayQuality(link.quality)
        const qualityId = choiceId(quality, "auto")
        out.push({
            id: `${audio}:${qualityId}:${index}`,
            url: resolvedUrl,
            audio,
            quality: qualityId,
            label: `${quality} · ${link.language ?? audio.toUpperCase()}`,
        })
    })
    return out
}

caye.register(providerId, {
    source: {
        async search(_context: Context, query: Query): Promise<SourceRecords> {
            const q = (query?.q ?? "").trim()
            if (!q) return { items: [], nextCursor: "", state: "complete" }
            const limit =
                typeof query?.limit === "number" && query.limit > 0
                    ? Math.min(20, Math.floor(query.limit))
                    : 8
            const url = new URL("/api/v1/anime", apiBase)
            url.searchParams.set("q", q)
            url.searchParams.set("limit", String(limit))
            const payload = await site.json<{ data?: AnimeRecord[] }>({
                url: url.toString(),
                headers: { Accept: "application/json" },
            })
            const items: SourceRecord[] = []
            const seen = new Set<string>()
            for (const anime of Array.isArray(payload?.data) ? payload.data : []) {
                const slug = (anime?.slug ?? "").trim()
                const epCount = Number(anime?.episodeCount)
                if (!slug || !Number.isInteger(epCount) || epCount < 1 || seen.has(slug)) continue
                seen.add(slug)
                const name = (anime.titleEng || anime.title || anime.titleIta || slug).trim()
                const year = extractFirstYear(
                    String(anime.releaseYear ?? anime.year ?? anime.startDate ?? ""),
                )
                items.push({
                    ref: videoRef(providerId, `${slug}|${epCount}`),
                    name,
                    ...(year !== undefined ? { year } : {}),
                })
            }
            return {
                items: limitItems(items, query?.limit),
                nextCursor: "",
                state: "complete",
            }
        },

        async read(_context: Context, ref: Ref): Promise<SourceRecord> {
            const { slug } = parseSeriesNativeId(ref.nativeId)
            const anime = await site.json<AnimeRecord>({
                url: `${apiBase}/api/v1/anime/${encodeURIComponent(slug)}`,
                headers: { Accept: "application/json" },
            })
            const name = (anime?.titleEng || anime?.title || anime?.titleIta || "").trim()
            if (!name) {
                throw failure("unavailable", `${providerName} title was not found`)
            }
            const year = extractFirstYear(
                String(anime.releaseYear ?? anime.year ?? anime.startDate ?? ""),
            )
            return {
                ref: sameRef(ref),
                name,
                ...(year !== undefined ? { year } : {}),
            }
        },

        async list(_context: Context, ref: Ref): Promise<SourceListResult> {
            const { slug, episodeCount: refCount } = parseSeriesNativeId(ref.nativeId)
            let count = refCount
            let hasSub = true
            let hasDub = true
            if (!count) {
                const anime = await site.json<AnimeRecord>({
                    url: `${apiBase}/api/v1/anime/${encodeURIComponent(slug)}`,
                    headers: { Accept: "application/json" },
                })
                count = Number(anime.episodeCount)
                const langs = (anime.availableLanguages ?? []).map((v) => String(v).toUpperCase())
                if (langs.length > 0) {
                    hasSub = langs.some((l) => l.startsWith("SUB"))
                    hasDub = langs.some((l) => l.startsWith("DUB"))
                }
            }
            if (!count || !Number.isInteger(count) || count < 1) {
                return {
                    installments: [],
                    choices: {
                        audio: [{ id: "sub", label: "Sub" }],
                        server: [{ id: "default", label: "AnimeUnion" }],
                        quality: [{ id: "auto", label: "Auto" }],
                    },
                }
            }
            const installments: SourceInstallment[] = Array.from({ length: count }, (_, idx) => {
                const num = idx + 1
                return {
                    number: num,
                    name: `Episode ${num}`,
                    ref: videoRef(providerId, `${slug}|${num}`),
                }
            })
            return {
                installments,
                choices: {
                    audio: uniqueChoices([
                        ...(hasSub ? [{ id: "sub", label: "Sub" }] : []),
                        ...(hasDub ? [{ id: "dub", label: "Dub" }] : []),
                    ]),
                    server: [{ id: "default", label: "AnimeUnion" }],
                    quality: [
                        { id: "auto", label: "Auto" },
                        { id: "1080p", label: "1080p" },
                        { id: "720p", label: "720p" },
                        { id: "480p", label: "480p" },
                    ],
                },
            }
        },

        async find(context: Context, ref: Ref): Promise<SourcePage> {
            const base = siteBase(context)
            const { slug, epNumber } = parseEpisodeNativeId(ref.nativeId)
            const links = await fetchStreamLinks(base, slug, epNumber)
            const deadline = futureDeadline(context?.deadline)
            const items: Source[] = links.map((link) => ({
                id: link.id,
                origin: streamOriginOf(link.url),
                capabilities: ["video"],
                expiresAt: deadline,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: "it",
                        label: link.label,
                    },
                ],
                ranges: [],
                choices: {
                    audio: link.audio,
                    server: "default",
                    quality: link.quality,
                },
            }))
            return { items, state: "complete" }
        },

        async resolve(context: Context, input: SourceResolveInput): Promise<Source> {
            const base = siteBase(context)
            const { slug, epNumber } = parseEpisodeNativeId(input.ref.nativeId)
            const links = await fetchStreamLinks(base, slug, epNumber)
            const selected = links.find((l) => l.id === input.sourceId)
            if (!selected) {
                throw failure("unavailable", `${providerName} stream is unavailable`)
            }
            const handle = await site.handle({
                url: selected.url,
                headers: {
                    Origin: base,
                    Referer: `${base}/`,
                },
            })
            return {
                id: input.sourceId,
                origin: streamOriginOf(selected.url),
                capabilities: ["video"],
                expiresAt: handle.expiresAt,
                handle,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: "it",
                        label: selected.label,
                    },
                ],
                ranges: [],
                choices: {
                    audio: selected.audio,
                    server: "default",
                    quality: selected.quality,
                },
            }
        },
    },
})
