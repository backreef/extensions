(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve2, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve2(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/provider-source/src/errors.ts
  function failure(code, message) {
    const error = new Error(message);
    error.code = code;
    return error;
  }

  // src/backend.ts
  var provider = "backreef.animetosho:search";
  var anilistProvider = "caye.movies-shows:anilist";
  var feed = "https://feed.animetosho.net/feed/json";
  var anizip = "https://api.ani.zip/v1/episodes";
  var cacheSeconds = 7 * 24 * 60 * 60;
  function text(value) {
    return { kind: "text", text: value };
  }
  function number(value) {
    return { kind: "number", number: value };
  }
  function native(query) {
    var _a;
    const refs = ((_a = query.native) != null ? _a : []).filter(
      (value) => value.entry.providerId === anilistProvider && value.entry.type === "anime"
    );
    const exact = refs.find((value) => value.itemId === query.itemId);
    if (exact || !query.batch || refs.length === 0) return exact;
    const entry = refs[0].entry;
    return refs.every(
      (value) => value.entry.nativeId === entry.nativeId && value.entry.scope === entry.scope
    ) ? refs[0] : void 0;
  }
  function decodeTable(value, anilist) {
    const data = value;
    const mappings = data.mappings;
    if (Number(mappings == null ? void 0 : mappings.anilist_id) !== anilist || !Number.isInteger(Number(mappings == null ? void 0 : mappings.anidb_id)) || Number(mappings == null ? void 0 : mappings.anidb_id) <= 0 || !data.episodes || typeof data.episodes !== "object")
      throw failure("unavailable", "AniZip returned an invalid episode table.");
    const episodes = {};
    for (const [key, entry] of Object.entries(data.episodes)) {
      const eid = Number(entry == null ? void 0 : entry.anidbEid);
      if (/^[1-9][0-9]*$/.test(key) && Number.isInteger(eid) && eid > 0) episodes[key] = eid;
    }
    return { aid: Number(mappings == null ? void 0 : mappings.anidb_id), episodes };
  }
  function table(anilist, fresh = false) {
    return __async(this, null, function* () {
      const key = `animetosho:anizip:${anilist}`;
      if (!fresh) {
        const cached = yield caye.cache.get({ key });
        if ((cached == null ? void 0 : cached.kind) === "text") {
          try {
            return decodeTable(JSON.parse(cached.text), anilist);
          } catch (e) {
          }
        }
      }
      const response = yield caye.http({
        url: `${anizip}?anilist_id=${anilist}`,
        method: "GET",
        headers: { Accept: "application/json" }
      });
      if (response.status !== 200 || !response.body)
        throw failure("unavailable", `AniZip answered ${response.status}.`);
      let value;
      try {
        value = JSON.parse(response.body);
      } catch (e) {
        throw failure("unavailable", "AniZip returned malformed JSON.");
      }
      const found = decodeTable(value, anilist);
      yield caye.cache.set({
        key,
        value: text(JSON.stringify(value)),
        ttlSeconds: cacheSeconds
      });
      return found;
    });
  }
  function fact(id, field, value) {
    return {
      id,
      producerId: provider,
      field,
      value: number(value),
      locale: "",
      region: "",
      status: "complete",
      at: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  function option(value, confirmed) {
    var _a, _b;
    const uri = value.magnet_uri && Array.from(value.magnet_uri).length <= 2e3 ? value.magnet_uri : value.torrent_url || value.nzb_url || value.magnet_uri || "";
    if (!Number.isInteger(value.id) || value.id <= 0 || !value.title || !uri) return void 0;
    const facts = [];
    if (Number.isFinite(value.total_size) && Number(value.total_size) >= 0)
      facts.push(fact(`size-${value.id}`, "size", Number(value.total_size)));
    if (Number.isFinite(value.seeders) && Number(value.seeders) >= 0)
      facts.push(fact(`seeders-${value.id}`, "seeders", Number(value.seeders)));
    if (Number.isFinite(value.leechers) && Number(value.leechers) >= 0)
      facts.push(fact(`leechers-${value.id}`, "leechers", Number(value.leechers)));
    const found = {
      id: `animetosho-${value.id}`,
      name: value.title,
      kind: value.magnet_uri || value.torrent_url ? "torrent" : "nzb",
      uri,
      files: [],
      facts,
      availability: "available",
      eligible: true,
      reasons: [],
      confirmed
    };
    if (Number.isFinite(value.seeders) && Number(value.seeders) >= 0)
      found.seeders = Number(value.seeders);
    if (Number.isFinite(value.total_size) && Number(value.total_size) >= 0)
      found.size = Number(value.total_size);
    if (Number.isFinite(value.timestamp) && Number(value.timestamp) > 0)
      found.publishedAt = new Date(Number(value.timestamp) * 1e3).toISOString();
    if ((_a = value.link) == null ? void 0 : _a.startsWith("https://")) found.pageUrl = value.link;
    if ((_b = value.magnet_uri) == null ? void 0 : _b.startsWith("magnet:")) found.magnet = value.magnet_uri;
    return found;
  }
  function search(params) {
    return __async(this, null, function* () {
      const encoded = Object.entries(params).map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`).join("&");
      const response = yield caye.http({
        url: `${feed}?${encoded}`,
        method: "GET",
        headers: { Accept: "application/json" }
      });
      if (response.status !== 200 || !response.body)
        throw failure("unavailable", `AnimeTosho New answered ${response.status}.`);
      let body;
      try {
        body = JSON.parse(response.body);
      } catch (e) {
        throw failure("unavailable", "AnimeTosho New returned malformed JSON.");
      }
      if (!Array.isArray(body))
        throw failure("unavailable", "AnimeTosho New returned invalid results.");
      return body;
    });
  }
  function anidbParams(query, ref) {
    return __async(this, null, function* () {
      if (!ref || !Number.isInteger(ref.number) || ref.number <= 0) return;
      const anilist = Number(ref.entry.nativeId);
      if (!Number.isInteger(anilist) || anilist <= 0) return;
      let ids;
      try {
        ids = yield table(anilist);
      } catch (e) {
        return;
      }
      if (query.batch) return { aid: String(ids.aid) };
      let eid = ids.episodes[String(ref.number)];
      if (!eid) {
        try {
          ids = yield table(anilist, true);
        } catch (e) {
          return;
        }
        eid = ids.episodes[String(ref.number)];
      }
      return eid ? { eid: String(eid) } : void 0;
    });
  }
  function titleQueries(query, title) {
    title = `"${title.replace(/"/g, " ").replace(/\s+/g, " ").trim()}"`;
    if (query.batch || query.number === void 0) return [title];
    const numbers = [query.number, query.absolute].filter(
      (n) => n !== void 0 && n > 0
    );
    return [...new Set(numbers.map((n) => `${title} ${String(n).padStart(2, "0")}`))];
  }
  function find(_context, query) {
    return __async(this, null, function* () {
      var _a;
      const base = {
        cat: "2020",
        limit: String(Math.min(Math.max(query.limit || 50, 1), 100)),
        page: "1"
      };
      if (query.batch) base.order = "size-d";
      const ref = native(query);
      const anidb = yield anidbParams(query, ref);
      if (anidb) {
        const found = yield search(__spreadValues(__spreadProps(__spreadValues({}, base), { q: "" }), anidb));
        return {
          items: found.map((value) => option(value, !query.batch)).filter((item) => !!item),
          state: "complete"
        };
      }
      const title = (_a = query.text) == null ? void 0 : _a.trim();
      if (!title) throw failure("unsupported", "Enter a title to search.");
      const seen = /* @__PURE__ */ new Set();
      const items = [];
      for (const q of titleQueries(query, title)) {
        for (const value of yield search(__spreadProps(__spreadValues({}, base), { q }))) {
          if (seen.has(value.id)) continue;
          seen.add(value.id);
          const item = option(value, false);
          if (item) items.push(item);
        }
      }
      return { items, state: "complete" };
    });
  }
  function resolve(_context, input) {
    return __async(this, null, function* () {
      var _a, _b;
      const match = /^animetosho-([1-9][0-9]*)$/.exec((_a = input.optionId) != null ? _a : "");
      if (!match) throw failure("missing", "Unknown AnimeTosho option.");
      const response = yield caye.http({
        url: `${feed}?show=torrent&id=${match[1]}`,
        method: "GET",
        headers: { Accept: "application/json" }
      });
      if (response.status === 404)
        throw failure("missing", "AnimeTosho no longer lists this torrent.");
      if (response.status !== 200 || !response.body)
        throw failure("unavailable", `AnimeTosho New answered ${response.status}.`);
      let value;
      try {
        value = JSON.parse(response.body);
      } catch (e) {
        throw failure("unavailable", "AnimeTosho New returned malformed JSON.");
      }
      const found = (value == null ? void 0 : value.id) === Number(match[1]) ? option(__spreadProps(__spreadValues({}, value), { link: (_b = value.link) != null ? _b : value.article_url }), false) : void 0;
      if (!found) throw failure("unavailable", "AnimeTosho New returned an invalid torrent.");
      return found;
    });
  }
  caye.register(provider, { acquisition: { find, resolve } });
})();
//# sourceMappingURL=backend.js.map
