import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DecisionObservation,
    DownloadOption,
    NativeInstallment,
    Value,
} from "../../../../packages/plugin-sdk/src/index"
import { failure } from "../../../../packages/provider-source/src/errors"

declare const caye: API

const provider = "backreef.animetosho:search"
const anilistProvider = "caye.movies-shows:anilist"

const feed = "https://feed.animetosho.net/feed/json"
const anizip = "https://api.ani.zip/v1/episodes"
const cacheSeconds = 7 * 24 * 60 * 60

function text(value: string): Value {
    return { kind: "text", text: value }
}

function number(value: number): Value {
    return { kind: "number", number: value }
}

type EpisodeTable = { aid: number; episodes: Record<string, number> }
type AniZipEpisode = { anidbEid?: unknown }
type AniZipResponse = {
    mappings?: { anilist_id?: unknown; anidb_id?: unknown }
    episodes?: Record<string, AniZipEpisode>
}

type Torrent = {
    id: number
    title: string
    link?: string
    article_url?: string
    magnet_uri?: string
    torrent_url?: string
    nzb_url?: string
    total_size?: number
    seeders?: number
    leechers?: number
    timestamp?: number
}

function native(query: AcquisitionQuery): NativeInstallment | undefined {
    const refs = (query.native ?? []).filter(
        (value) => value.entry.providerId === anilistProvider && value.entry.type === "anime",
    )
    const exact = refs.find((value) => value.itemId === query.itemId)
    if (exact || !query.batch || refs.length === 0) return exact
    const entry = refs[0].entry
    return refs.every(
        (value) => value.entry.nativeId === entry.nativeId && value.entry.scope === entry.scope,
    )
        ? refs[0]
        : undefined
}

function decodeTable(value: unknown, anilist: number): EpisodeTable {
    const data = value as AniZipResponse
    const mappings = data.mappings
    if (
        Number(mappings?.anilist_id) !== anilist ||
        !Number.isInteger(Number(mappings?.anidb_id)) ||
        Number(mappings?.anidb_id) <= 0 ||
        !data.episodes ||
        typeof data.episodes !== "object"
    )
        throw failure("unavailable", "AniZip returned an invalid episode table.")
    const episodes: Record<string, number> = {}
    for (const [key, entry] of Object.entries(data.episodes)) {
        const eid = Number(entry?.anidbEid)
        if (/^[1-9][0-9]*$/.test(key) && Number.isInteger(eid) && eid > 0) episodes[key] = eid
    }
    return { aid: Number(mappings?.anidb_id), episodes }
}

async function table(anilist: number, fresh = false): Promise<EpisodeTable> {
    const key = `animetosho:anizip:${anilist}`
    if (!fresh) {
        const cached = await caye.cache.get({ key })
        if (cached?.kind === "text") {
            try {
                return decodeTable(JSON.parse(cached.text), anilist)
            } catch {}
        }
    }
    const response = await caye.http({
        url: `${anizip}?anilist_id=${anilist}`,
        method: "GET",
        headers: { Accept: "application/json" },
    })
    if (response.status !== 200 || !response.body)
        throw failure("unavailable", `AniZip answered ${response.status}.`)
    let value: unknown
    try {
        value = JSON.parse(response.body)
    } catch {
        throw failure("unavailable", "AniZip returned malformed JSON.")
    }
    const found = decodeTable(value, anilist)
    await caye.cache.set({
        key,
        value: text(JSON.stringify(value)),
        ttlSeconds: cacheSeconds,
    })
    return found
}

function fact(id: string, field: string, value: number): DecisionObservation {
    return {
        id,
        producerId: provider,
        field,
        value: number(value),
        locale: "",
        region: "",
        status: "complete",
        at: new Date().toISOString(),
    }
}

function option(value: Torrent, confirmed: boolean): DownloadOption | undefined {
    const uri =
        value.magnet_uri && Array.from(value.magnet_uri).length <= 2000
            ? value.magnet_uri
            : value.torrent_url || value.nzb_url || value.magnet_uri || ""
    if (!Number.isInteger(value.id) || value.id <= 0 || !value.title || !uri) return undefined
    const facts: DecisionObservation[] = []
    if (Number.isFinite(value.total_size) && Number(value.total_size) >= 0)
        facts.push(fact(`size-${value.id}`, "size", Number(value.total_size)))
    if (Number.isFinite(value.seeders) && Number(value.seeders) >= 0)
        facts.push(fact(`seeders-${value.id}`, "seeders", Number(value.seeders)))
    if (Number.isFinite(value.leechers) && Number(value.leechers) >= 0)
        facts.push(fact(`leechers-${value.id}`, "leechers", Number(value.leechers)))
    const found: DownloadOption = {
        id: `animetosho-${value.id}`,
        name: value.title,
        kind: value.magnet_uri || value.torrent_url ? "torrent" : "nzb",
        uri,
        files: [],
        facts,
        availability: "available",
        eligible: true,
        reasons: [],
        confirmed,
    }
    if (Number.isFinite(value.seeders) && Number(value.seeders) >= 0)
        found.seeders = Number(value.seeders)
    if (Number.isFinite(value.total_size) && Number(value.total_size) >= 0)
        found.size = Number(value.total_size)
    if (Number.isFinite(value.timestamp) && Number(value.timestamp) > 0)
        found.publishedAt = new Date(Number(value.timestamp) * 1000).toISOString()
    if (value.link?.startsWith("https://")) found.pageUrl = value.link
    if (value.magnet_uri?.startsWith("magnet:")) found.magnet = value.magnet_uri
    return found
}

async function search(params: Record<string, string>): Promise<Torrent[]> {
    const encoded = Object.entries(params)
        .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(value)}`)
        .join("&")
    const response = await caye.http({
        url: `${feed}?${encoded}`,
        method: "GET",
        headers: { Accept: "application/json" },
    })
    if (response.status !== 200 || !response.body)
        throw failure("unavailable", `AnimeTosho New answered ${response.status}.`)
    let body: unknown
    try {
        body = JSON.parse(response.body)
    } catch {
        throw failure("unavailable", "AnimeTosho New returned malformed JSON.")
    }
    if (!Array.isArray(body))
        throw failure("unavailable", "AnimeTosho New returned invalid results.")
    return body as Torrent[]
}

async function anidbParams(
    query: AcquisitionQuery,
    ref: NativeInstallment | undefined,
): Promise<Record<string, string> | undefined> {
    if (!ref || !Number.isInteger(ref.number) || ref.number <= 0) return
    const anilist = Number(ref.entry.nativeId)
    if (!Number.isInteger(anilist) || anilist <= 0) return
    let ids: EpisodeTable
    try {
        ids = await table(anilist)
    } catch {
        return
    }
    if (query.batch) return { aid: String(ids.aid) }
    let eid = ids.episodes[String(ref.number)]
    if (!eid) {
        try {
            ids = await table(anilist, true)
        } catch {
            return
        }
        eid = ids.episodes[String(ref.number)]
    }
    return eid ? { eid: String(eid) } : undefined
}

function titleQueries(query: AcquisitionQuery, title: string): string[] {
    title = `"${title.replace(/"/g, " ").replace(/\s+/g, " ").trim()}"`
    if (query.batch || query.number === undefined) return [title]
    const numbers = [query.number, query.absolute].filter(
        (n): n is number => n !== undefined && n > 0,
    )
    return [...new Set(numbers.map((n) => `${title} ${String(n).padStart(2, "0")}`))]
}

async function find(_context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const base: Record<string, string> = {
        cat: "2020",
        limit: String(Math.min(Math.max(query.limit || 50, 1), 100)),
        page: "1",
    }
    if (query.batch) base.order = "size-d"
    const ref = native(query)
    const anidb = await anidbParams(query, ref)
    if (anidb) {
        const found = await search({ ...base, q: "", ...anidb })
        return {
            items: found
                .map((value) => option(value, !query.batch))
                .filter((item): item is DownloadOption => !!item),
            state: "complete",
        }
    }
    const title = query.text?.trim()
    if (!title) throw failure("unsupported", "Enter a title to search.")
    const seen = new Set<number>()
    const items: DownloadOption[] = []
    for (const q of titleQueries(query, title)) {
        for (const value of await search({ ...base, q })) {
            if (seen.has(value.id)) continue
            seen.add(value.id)
            const item = option(value, false)
            if (item) items.push(item)
        }
    }
    return { items, state: "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    const match = /^animetosho-([1-9][0-9]*)$/.exec(input.optionId ?? "")
    if (!match) throw failure("missing", "Unknown AnimeTosho option.")
    const response = await caye.http({
        url: `${feed}?show=torrent&id=${match[1]}`,
        method: "GET",
        headers: { Accept: "application/json" },
    })
    if (response.status === 404)
        throw failure("missing", "AnimeTosho no longer lists this torrent.")
    if (response.status !== 200 || !response.body)
        throw failure("unavailable", `AnimeTosho New answered ${response.status}.`)
    let value: Torrent
    try {
        value = JSON.parse(response.body) as Torrent
    } catch {
        throw failure("unavailable", "AnimeTosho New returned malformed JSON.")
    }
    const found =
        value?.id === Number(match[1])
            ? option({ ...value, link: value.link ?? value.article_url }, false)
            : undefined
    if (!found) throw failure("unavailable", "AnimeTosho New returned an invalid torrent.")
    return found
}

caye.register(provider, { acquisition: { find, resolve } })
