(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __pow = Math.pow;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __objRest = (source, exclude) => {
    var target = {};
    for (var prop in source)
      if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
        target[prop] = source[prop];
    if (source != null && __getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(source)) {
        if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
          target[prop] = source[prop];
      }
    return target;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve2, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve2(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../../../packages/plugin-std/src/magnet.ts
  var BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  function decodeBase32(input) {
    const cleaned = input.trim().toUpperCase().replace(/=+$/, "");
    if (!cleaned || !/^[A-Z2-7]+$/.test(cleaned)) {
      throw new TypeError("Invalid base32 string");
    }
    const bytes = [];
    let buffer = 0;
    let bitsLeft = 0;
    for (let i = 0; i < cleaned.length; i++) {
      const val = BASE32_ALPHABET.indexOf(cleaned[i]);
      buffer = buffer << 5 | val;
      bitsLeft += 5;
      if (bitsLeft >= 8) {
        bitsLeft -= 8;
        bytes.push(buffer >>> bitsLeft & 255);
      }
    }
    return new Uint8Array(bytes);
  }
  function bytesToHex(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i++) {
      out += bytes[i].toString(16).padStart(2, "0");
    }
    return out;
  }
  function normalizeInfoHash(raw) {
    const trimmed = raw.trim();
    if (/^[0-9a-fA-F]{40}$/.test(trimmed)) {
      return trimmed.toLowerCase();
    }
    if (/^[A-Za-z2-7]{32}=*$/.test(trimmed)) {
      const decoded = decodeBase32(trimmed);
      if (decoded.length === 20) {
        return bytesToHex(decoded);
      }
    }
    throw new TypeError(`Invalid infoHash: ${raw}`);
  }
  function parseMagnet(uri) {
    var _a;
    const trimmed = uri.trim();
    if (!/^magnet:\?/i.test(trimmed)) {
      throw new TypeError("Invalid magnet URI");
    }
    const query = trimmed.slice(trimmed.indexOf("?") + 1);
    const params = new URLSearchParams(query);
    let infoHash = "";
    for (const xt of params.getAll("xt")) {
      const match = xt.match(/^urn:btih:([0-9a-fA-F]{40}|[A-Za-z2-7]{32}=*)$/i);
      if (match) {
        infoHash = normalizeInfoHash(match[1]);
        break;
      }
    }
    if (!infoHash) {
      throw new TypeError("Magnet URI missing valid btih infoHash");
    }
    const name = (_a = params.get("dn")) != null ? _a : "";
    const seen = /* @__PURE__ */ new Set();
    const trackers = [];
    for (const tr of params.getAll("tr")) {
      const t = tr.trim();
      if (t && !seen.has(t)) {
        seen.add(t);
        trackers.push(t);
      }
    }
    const xlRaw = params.get("xl");
    let size = 0;
    if (xlRaw && /^\d+$/.test(xlRaw.trim())) {
      size = Number.parseInt(xlRaw.trim(), 10);
    }
    return { infoHash, name, trackers, size };
  }
  function buildMagnet(options) {
    const infoHash = normalizeInfoHash(options.infoHash);
    const parts = [`magnet:?xt=urn:btih:${infoHash}`];
    if (options.name) {
      parts.push(`dn=${encodeURIComponent(options.name)}`);
    }
    if (options.trackers) {
      const seen = /* @__PURE__ */ new Set();
      for (const tr of options.trackers) {
        const trimmed = tr.trim();
        if (trimmed && !seen.has(trimmed)) {
          seen.add(trimmed);
          parts.push(`tr=${encodeURIComponent(trimmed)}`);
        }
      }
    }
    return parts.join("&");
  }
  function parseTorrent(api, bytes) {
    const infoHash = api.crypto.digest("sha1", api.bencode.raw(bytes, "info"), { output: "hex" }).toLowerCase();
    const trackers = [];
    let name = "";
    try {
      const decoded = api.bencode.decode(bytes);
      const add = (value) => {
        if (typeof value === "string" && value.trim() && !trackers.includes(value.trim())) {
          trackers.push(value.trim());
        }
      };
      add(decoded.announce);
      if (Array.isArray(decoded["announce-list"])) {
        for (const tier of decoded["announce-list"]) {
          if (Array.isArray(tier)) tier.forEach(add);
          else add(tier);
        }
      }
      const info = decoded.info;
      if (typeof (info == null ? void 0 : info.name) === "string") name = info.name.trim();
    } catch (e) {
    }
    return { infoHash, name, trackers };
  }

  // ../../../packages/plugin-std/src/size.ts
  var UNIT_EXPONENTS = {
    B: 0,
    K: 1,
    M: 2,
    G: 3,
    T: 4,
    P: 5
  };
  function parseSize(input) {
    const match = input.trim().match(/^([\d,]+(?:\.\d+)?|\.\d+)\s*([KMGTPE]?i?B)$/i);
    if (!match) {
      const inner = input.match(/([\d,]+(?:\.\d+)?)\s*([KMGT]?i?B)/i);
      if (!inner) return 0;
      return computeBytes(inner[1], inner[2]);
    }
    return computeBytes(match[1], match[2]);
  }
  function computeBytes(numStr, rawUnit) {
    const value = Number.parseFloat(numStr.replace(/,/g, ""));
    if (!Number.isFinite(value) || value < 0) return 0;
    const unit = rawUnit.toUpperCase();
    const base = unit.endsWith("IB") ? 1024 : 1e3;
    const prefix = unit === "B" ? "B" : unit[0];
    const exp = UNIT_EXPONENTS[prefix];
    if (exp === void 0) return 0;
    return Math.round(value * __pow(base, exp));
  }

  // ../../../packages/plugin-std/src/titles.ts
  var NOISE_WORDS = /* @__PURE__ */ new Set([
    "the",
    "a",
    "an",
    "of",
    "to",
    "in",
    "for",
    "on",
    "with",
    "at",
    "by",
    "from",
    "as",
    "is",
    "it",
    "that",
    "this",
    "be",
    "are",
    "was",
    "were",
    "no",
    "wa",
    "wo",
    "ga",
    "ni",
    "de",
    "ka",
    "mo",
    "ya",
    "e",
    "he",
    "anime",
    "ova",
    "ona",
    "oad",
    "tv",
    "movie",
    "nc",
    "nced",
    "ncop",
    "extras",
    "ending",
    "opening",
    "preview",
    "special",
    "specials",
    "sp",
    "finale",
    "season",
    "uncensored",
    "censored",
    "bluray"
  ]);
  var FORMAT_WORDS = /* @__PURE__ */ new Set([
    "ova",
    "ona",
    "oad",
    "oav",
    "sp",
    "special",
    "specials",
    "movie",
    "film",
    "tv",
    "nc",
    "nced",
    "ncop",
    "extras",
    "opening",
    "ending",
    "preview",
    "finale"
  ]);
  var ORDINAL_TO_NUMBER = {
    first: 1,
    "1st": 1,
    second: 2,
    "2nd": 2,
    third: 3,
    "3rd": 3,
    fourth: 4,
    "4th": 4,
    fifth: 5,
    "5th": 5,
    sixth: 6,
    "6th": 6,
    seventh: 7,
    "7th": 7,
    eighth: 8,
    "8th": 8,
    ninth: 9,
    "9th": 9,
    tenth: 10,
    "10th": 10
  };
  var ROMAN_SEASON_MAP = {
    ii: 2,
    iii: 3,
    iv: 4,
    v: 5,
    vi: 6,
    vii: 7,
    viii: 8,
    ix: 9,
    xi: 11,
    xii: 12,
    xiii: 13
  };
  var SEASON_EXPLICIT_RE = /\b(?:season|s|series)\s*0*(\d+)\b/gi;
  var SEASON_ORDINAL_RE = /\b(\d+)(?:st|nd|rd|th)\s*(?:part|season|series)\b/gi;
  var SEASON_WORD_ORDINAL_RE = /\b(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)\s+season\b/gi;
  var SEASON_SUFFIX_RE = /(\d+)\s*(?:期|シーズン)/gi;
  var PART_EXPLICIT_RE = /\b(?:part|cour)\s*0*(\d+)\b/i;
  var PART_ORDINAL_RE = /\b(\d+)(?:st|nd|rd|th)\s*(?:part|cour)\b/i;
  var PART_ROMAN_RE = /\b(?:part|cour)\s+(i{1,3}|iv|vi?i?i?|ix|x)\b/i;
  var YEAR_PAREN_RE = /\((\d{4})\)/;
  var YEAR_STANDALONE_RE = /\b(19\d{2}|20\d{2})\b/;
  function isAlphanumAscii(ch) {
    const code = ch.charCodeAt(0);
    return code >= 97 && code <= 122 || code >= 65 && code <= 90 || code >= 48 && code <= 57;
  }
  function replaceWholeWord(input, word, replacement) {
    if (!input || !word) return input;
    let out = "";
    let pos = 0;
    while (pos < input.length) {
      const idx = input.indexOf(word, pos);
      if (idx === -1) {
        out += input.slice(pos);
        break;
      }
      const beforeOk = idx === 0 || !isAlphanumAscii(input[idx - 1]);
      const afterIdx = idx + word.length;
      const afterOk = afterIdx === input.length || !isAlphanumAscii(input[afterIdx]);
      if (beforeOk && afterOk) {
        out += input.slice(pos, idx) + replacement;
        pos = afterIdx;
      } else {
        out += input.slice(pos, idx + 1);
        pos = idx + 1;
      }
    }
    return out;
  }
  function normalizeString(input) {
    let s = input.toLowerCase();
    s = s.replace(/ō/g, "ou").replace(/ū/g, "uu");
    s = s.replace(/@/g, "a").replace(/×/g, " x ").replace(/꞉/g, ":").replace(/＊/g, " * ");
    s = replaceWholeWord(s, "the animation", "");
    s = replaceWholeWord(s, "the", "");
    s = replaceWholeWord(s, "episode", "");
    s = replaceWholeWord(s, "oad", "ova");
    s = replaceWholeWord(s, "oav", "ova");
    s = replaceWholeWord(s, "specials", "sp");
    s = replaceWholeWord(s, "special", "sp");
    s = s.replace(/\(tv\)/g, "");
    s = replaceWholeWord(s, "&", "and");
    s = s.replace(/'s|’s|`s/g, " ");
    s = s.replace(/['’`"“”]/g, "");
    let cleaned = "";
    let prevSpace = false;
    for (let i = 0; i < s.length; i++) {
      const ch = s[i];
      const code = ch.charCodeAt(0);
      const isLowerAlphaNum = code >= 97 && code <= 122 || code >= 48 && code <= 57 || ch === " ";
      if (!isLowerAlphaNum) {
        if (!prevSpace) {
          cleaned += " ";
          prevSpace = true;
        }
      } else {
        cleaned += ch;
        prevSpace = ch === " ";
      }
    }
    cleaned = cleaned.replace(SEASON_EXPLICIT_RE, " ").replace(SEASON_ORDINAL_RE, " ").replace(SEASON_WORD_ORDINAL_RE, " ").replace(SEASON_SUFFIX_RE, " ").replace(/\b(?:part|cour)\s*0*(\d+)\b/gi, " ").replace(/\b(\d+)(?:st|nd|rd|th)\s*(?:part|cour)\b/gi, " ").replace(/\b(?:part|cour)\s+(i{1,3}|iv|vi?i?i?|ix|x)\b/gi, " ");
    return cleaned.replace(/\s+/g, " ").trim();
  }
  function computeCleanBaseTitle(normalized) {
    const strippedNum = normalized.replace(/\b\d+\b$/, " ").trim();
    const tokens = strippedNum ? strippedNum.split(/\s+/) : [];
    const clean = [];
    const denoised = [];
    for (const token of tokens) {
      if (FORMAT_WORDS.has(token) || ROMAN_SEASON_MAP[token] !== void 0) continue;
      clean.push(token);
      if (!NOISE_WORDS.has(token)) {
        denoised.push(token);
      }
    }
    return {
      cleanBaseTitle: clean.join(" "),
      denoisedTitle: denoised.join(" ")
    };
  }
  function extractSeason(title) {
    const val = title.toLowerCase();
    const explicit = val.match(/season\s*(\d+)/);
    if (explicit) return Number.parseInt(explicit[1], 10);
    const sFmt = val.match(/\bs0?(\d{1,2})(?:e\d|$|\s|\.)/);
    if (sFmt) {
      const num = Number.parseInt(sFmt[1], 10);
      if (num > 0 && num < 20) return num;
    }
    const ordinal = val.match(/(\d+)(?:st|nd|rd|th)\s+season/);
    if (ordinal) return Number.parseInt(ordinal[1], 10);
    const romanCleaned = val.replace(
      /\b((?:act|arc|chapter|saga|hen|part|cour))[\s._:-]+(i{1,3}|iv|vi?i?i?|ix|x)\b/g,
      "$1"
    );
    const romanPatterns = [
      /[\s.](i{1,3}|iv|vi?i?i?|ix|x)(?:\s|$|[:,.]|[''])/,
      /[\s.](i{1,3}|iv|vi?i?i?|ix|x)[.\s]*(?:s\d|e\d|part)/
    ];
    for (const re of romanPatterns) {
      const m = romanCleaned.match(re);
      if (m && ROMAN_SEASON_MAP[m[1]] !== void 0) {
        return ROMAN_SEASON_MAP[m[1]];
      }
    }
    const trailing = val.match(/(?:^|\s)(\d{1,2})\s*$/);
    if (trailing && !/(?:part|cour|specials?|sp|movie|ova|ona|oad)\s*\d{1,2}\s*$/.test(val)) {
      const num = Number.parseInt(trailing[1], 10);
      if (num >= 2 && num <= 10) return num;
    }
    const jp = val.match(/(?:第)?(\d+)\s*期/);
    if (jp) return Number.parseInt(jp[1], 10);
    const wordOrd = val.match(
      /\b(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)\s+season\b/
    );
    if (wordOrd && ORDINAL_TO_NUMBER[wordOrd[1]] !== void 0) {
      return ORDINAL_TO_NUMBER[wordOrd[1]];
    }
    return -1;
  }
  function extractPart(title) {
    const val = title.toLowerCase();
    const explicit = val.match(PART_EXPLICIT_RE);
    if (explicit) return Number.parseInt(explicit[1], 10);
    const ordinal = val.match(PART_ORDINAL_RE);
    if (ordinal) return Number.parseInt(ordinal[1], 10);
    const roman = val.match(PART_ROMAN_RE);
    if (roman) {
      const r = roman[1].toLowerCase();
      if (r === "i" || r === "x") return -1;
      if (ROMAN_SEASON_MAP[r] !== void 0) return ROMAN_SEASON_MAP[r];
    }
    return -1;
  }
  function extractYear(title) {
    const paren = title.match(YEAR_PAREN_RE);
    if (paren) {
      const year = Number.parseInt(paren[1], 10);
      if (year >= 1900 && year <= 2100) return year;
    }
    const standalone = title.match(YEAR_STANDALONE_RE);
    if (standalone) {
      return Number.parseInt(standalone[1], 10);
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];
  function normalizeTitle(title) {
    if (!title) {
      return {
        original: "",
        normalized: "",
        cleanBaseTitle: "",
        denoisedTitle: "",
        tokens: [],
        season: -1,
        part: -1,
        year: -1
      };
    }
    const season = extractSeason(title);
    const part = extractPart(title);
    const year = extractYear(title);
    const normalized = normalizeString(title);
    const { cleanBaseTitle, denoisedTitle } = computeCleanBaseTitle(normalized);
    const tokens = normalized ? normalized.split(" ") : [];
    return {
      original: title,
      normalized,
      cleanBaseTitle,
      denoisedTitle,
      tokens,
      season,
      part,
      year
    };
  }
  function isYearToken(token) {
    return /^(?:19|20)\d{2}$/.test(token);
  }
  function weightedTokenMatchRatio(tokensA, tokensB) {
    if (tokensA.length === 0 || tokensB.length === 0) return 0;
    const setB = new Set(tokensB);
    let totalWeight = 0;
    let matchedWeight = 0;
    for (const token of tokensA) {
      let weight = 1;
      if (NOISE_WORDS.has(token)) weight = 0.3;
      else if (isYearToken(token)) weight = 0.5;
      totalWeight += weight;
      if (setB.has(token)) matchedWeight += weight;
    }
    return totalWeight === 0 ? 0 : matchedWeight / totalWeight;
  }
  function compareTitles(a, b) {
    const normA = normalizeTitle(a);
    const normB = normalizeTitle(b);
    return weightedTokenMatchRatio(normA.tokens, normB.tokens);
  }

  // ../../../packages/plugin-std/src/search-query.ts
  var SEARCH_SYNTAX_RE = /[()[\]{}|"'~*?\\^!]/g;
  function sanitizeQuery(query) {
    return query.replace(SEARCH_SYNTAX_RE, " ").replace(/\s+/g, " ").trim();
  }

  // ../../../packages/plugin-std/src/limit.ts
  function mapLimit(items, limit, fn) {
    return __async(this, null, function* () {
      if (items.length === 0) return [];
      const concurrency = Math.max(1, Math.floor(limit));
      const out = new Array(items.length);
      let next = 0;
      const worker = () => __async(null, null, function* () {
        while (next < items.length) {
          const index = next++;
          out[index] = yield fn(items[index], index);
        }
      });
      yield Promise.all(Array.from({ length: Math.min(concurrency, items.length) }, worker));
      return out;
    });
  }

  // ../torrent-common/src/option.ts
  var DEFAULT_TRACKERS = [
    "http://nyaa.tracker.wf:7777/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce"
  ];
  var MAX_RETRIEVAL_URI_LENGTH = 2e3;
  function numberValue(value) {
    return { kind: "number", number: value };
  }
  function makeFact(producerId, id, field, value, at = (/* @__PURE__ */ new Date()).toISOString()) {
    return {
      id,
      producerId,
      field,
      value: numberValue(value),
      locale: "",
      region: "",
      status: "complete",
      at
    };
  }
  function buildCountsFacts(producerId, key, counts) {
    const at = (/* @__PURE__ */ new Date()).toISOString();
    const facts = [];
    if (counts.size !== void 0 && Number.isFinite(counts.size) && counts.size > 0) {
      facts.push(makeFact(producerId, `size-${key}`, "size", counts.size, at));
    }
    if (counts.seeders !== void 0 && Number.isFinite(counts.seeders) && counts.seeders >= 0) {
      facts.push(makeFact(producerId, `seeders-${key}`, "seeders", counts.seeders, at));
    }
    if (counts.leechers !== void 0 && Number.isFinite(counts.leechers) && counts.leechers >= 0) {
      facts.push(makeFact(producerId, `leechers-${key}`, "leechers", counts.leechers, at));
    }
    if (counts.downloads !== void 0 && Number.isFinite(counts.downloads) && counts.downloads > 0) {
      facts.push(makeFact(producerId, `downloads-${key}`, "downloads", counts.downloads, at));
    }
    return facts;
  }
  function parseIsoDate(caye2, raw, layouts) {
    var _a;
    const trimmed = raw == null ? void 0 : raw.trim();
    if (!trimmed) return void 0;
    if (typeof ((_a = caye2.time) == null ? void 0 : _a.parse) === "function") {
      try {
        const ms = caye2.time.parse(trimmed, layouts ? { layouts } : void 0);
        if (Number.isFinite(ms)) {
          return new Date(ms).toISOString();
        }
      } catch (e) {
      }
    }
    const parsed = Date.parse(trimmed);
    if (Number.isFinite(parsed)) {
      return new Date(parsed).toISOString();
    }
    return void 0;
  }
  function pickUri(magnet, torrentUrl) {
    if (magnet && Array.from(magnet).length <= MAX_RETRIEVAL_URI_LENGTH) {
      return magnet;
    }
    return torrentUrl || magnet || "";
  }
  function createTorrentOption(caye2, input) {
    var _a, _b, _c, _d;
    const uri = pickUri(input.magnet, input.torrentUrl);
    const facts = buildCountsFacts(input.providerId, input.key, {
      size: input.size,
      seeders: input.seeders,
      leechers: input.leechers,
      downloads: input.downloads
    });
    let resolution = ((_a = input.resolution) == null ? void 0 : _a.trim()) || "";
    let group = ((_b = input.group) == null ? void 0 : _b.trim()) || "";
    if ((!resolution || !group) && typeof ((_c = caye2.release) == null ? void 0 : _c.parse) === "function") {
      try {
        const parsed = caye2.release.parse(input.name);
        if (!resolution && parsed.resolution) resolution = parsed.resolution;
        if (!group && parsed.group) group = parsed.group;
      } catch (e) {
      }
    }
    const option = {
      id: input.id,
      name: input.name,
      kind: "torrent",
      uri,
      files: [],
      facts,
      availability: "available",
      eligible: true,
      reasons: [],
      confirmed: Boolean(input.confirmed)
    };
    if (input.seeders !== void 0 && Number.isFinite(input.seeders) && input.seeders >= 0) {
      option.seeders = Math.trunc(input.seeders);
    }
    if (input.size !== void 0 && Number.isFinite(input.size) && input.size > 0) {
      option.size = Math.round(input.size);
    }
    if (input.publishedAt) option.publishedAt = input.publishedAt;
    if (input.pageUrl && /^https?:\/\//i.test(input.pageUrl)) {
      option.pageUrl = input.pageUrl;
    }
    if ((_d = input.magnet) == null ? void 0 : _d.startsWith("magnet:")) {
      option.magnet = input.magnet;
    }
    if (resolution) option.resolution = resolution;
    if (group) option.group = group;
    if (input.best) option.best = true;
    return option;
  }
  var missingMessage = (service) => `${service} no longer lists this torrent.`;
  function fetchText(caye2, service, url, options) {
    return __async(this, null, function* () {
      var _b, _c;
      const _a = options != null ? options : {}, { missingOn404 } = _a, input = __objRest(_a, ["missingOn404"]);
      const response = yield httpClient(caye2, service).send(
        __spreadProps(__spreadValues({}, input), { url }),
        missingOn404 ? { missing: missingMessage(service) } : void 0
      );
      return {
        status: response.status,
        headers: (_b = response.headers) != null ? _b : {},
        body: (_c = response.body) != null ? _c : "",
        url: response.url
      };
    });
  }
  function torrentUrlToMagnet(caye2, service, torrentUrl, options) {
    return __async(this, null, function* () {
      var _a;
      const body = yield httpClient(caye2, service).base64(
        { url: torrentUrl, headers: options == null ? void 0 : options.headers },
        (options == null ? void 0 : options.missingOn404) ? { missing: missingMessage(service) } : void 0
      );
      let torrent;
      try {
        torrent = parseTorrent(caye2, caye2.encoding.base64.decode(body));
      } catch (e) {
        throw failure("unavailable", `${service} returned an invalid torrent file.`);
      }
      const trackers = [...torrent.trackers, ...(_a = options == null ? void 0 : options.extraTrackers) != null ? _a : []];
      return {
        infoHash: torrent.infoHash,
        magnet: buildMagnet({
          infoHash: torrent.infoHash,
          name: (options == null ? void 0 : options.fallbackName) || torrent.name || void 0,
          trackers: trackers.length > 0 ? trackers : DEFAULT_TRACKERS
        })
      };
    });
  }

  // ../../../packages/plugin-std/src/cache.ts
  function getCachedJson(api, key) {
    return __async(this, null, function* () {
      try {
        const value = yield api.cache.get({ key });
        if ((value == null ? void 0 : value.kind) === "text") return JSON.parse(value.text);
      } catch (e) {
      }
      return void 0;
    });
  }
  function setCachedJson(api, key, value, ttlSeconds) {
    return __async(this, null, function* () {
      try {
        yield api.cache.set({
          key,
          value: { kind: "text", text: JSON.stringify(value) },
          ttlSeconds
        });
      } catch (e) {
      }
    });
  }

  // ../torrent-common/src/smart.ts
  var OPTION_CACHE_TTL_SECONDS = 7 * 24 * 60 * 60;
  function parseResolutionNumber(raw) {
    if (!raw) return 0;
    const lower = raw.trim().toLowerCase();
    if (lower === "4k" || lower === "uhd") return 2160;
    if (lower === "8k") return 4320;
    const match = /(\d{3,4})/.exec(lower);
    return match ? Number.parseInt(match[1], 10) : 0;
  }
  function parseEpisodesFromTitle(caye2, title) {
    var _a;
    const out = [];
    try {
      const parsed = caye2.release.parse(title);
      for (const raw of (_a = parsed.episodes) != null ? _a : []) {
        const n = Number.parseInt(raw, 10);
        if (Number.isInteger(n) && n >= 0 && !out.includes(n)) out.push(n);
      }
    } catch (e) {
    }
    return out;
  }
  function extractSingleEpisode(caye2, title) {
    const eps = parseEpisodesFromTitle(caye2, title);
    if (eps.length === 1) return eps[0];
    return -1;
  }
  function isLikelyBatchTitle(title) {
    if (/\b(?:batch|complete(?:\s+series)?|collection|box\s*set|boxset|all\s+seasons|integrale)\b/i.test(
      title
    )) {
      return true;
    }
    if (/(?:合集|全集|完整|全話|全\s*\d+\s*[話话卷]|第\s*\d+\s*[-~～—]\s*\d+\s*[集話话])/.test(
      title
    )) {
      return true;
    }
    if (/S\d{1,2}E\d{1,3}\s*(?:~|-|–|—)\s*E?\d{1,3}/i.test(title)) return true;
    if (/\bS\d{1,2}\s*-\s*BATCH\b/i.test(title)) return true;
    const range = /\b0*(\d{1,3})\s*[-~～—]\s*0*(\d{1,3})\b/.exec(title);
    if (range) {
      const s = Number.parseInt(range[1], 10);
      const e = Number.parseInt(range[2], 10);
      if (e > s && s >= 1 && e <= 300) return true;
    }
    return false;
  }
  function titleMatchesAny(caye2, candidateName, targetTitles, threshold = 0.65) {
    let base = candidateName;
    try {
      const parsed = caye2.release.parse(candidateName);
      base = parsed.title || parsed.formattedTitle || caye2.release.cleanTitle(candidateName) || candidateName;
    } catch (e) {
    }
    const normCandidate = normalizeTitle(base).denoisedTitle || normalizeTitle(base).normalized;
    for (const target of targetTitles) {
      if (!target) continue;
      const normTarget = normalizeTitle(target).denoisedTitle || normalizeTitle(target).normalized;
      if (!normTarget) continue;
      if (compareTitles(normCandidate, normTarget) >= threshold) return true;
      if (normCandidate.includes(normTarget) || normTarget.includes(normCandidate)) return true;
    }
    return false;
  }
  function clampLimit(limit, fallback = 50, max = 100) {
    return Math.min(Math.max(limit || fallback, 1), max);
  }
  function cacheOptions(_0, _1, _2) {
    return __async(this, arguments, function* (caye2, prefix, options, ttlSeconds = OPTION_CACHE_TTL_SECONDS) {
      for (const option of options) {
        yield setCachedJson(caye2, `${prefix}:option:${option.id}`, option, ttlSeconds);
      }
    });
  }
  function validateHttpUrl(raw) {
    const trimmed = (raw == null ? void 0 : raw.trim()) || "";
    if (!trimmed) return void 0;
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol === "http:" || parsed.protocol === "https:") {
        return parsed.toString();
      }
    } catch (e) {
    }
    return void 0;
  }
  function resolveFromRetrievalInput(caye2, providerId, prefix, input, notFoundMessage, defaultGroup) {
    var _a, _b, _c, _d;
    const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
    const rawMagnet = ((_b = input.magnet) == null ? void 0 : _b.trim()) || "";
    const rawInfoHash = ((_c = input.infoHash) == null ? void 0 : _c.trim()) || "";
    const rawTorrentUrl = ((_d = input.torrentUrl) == null ? void 0 : _d.trim()) || "";
    const hasRetrieval = Boolean(rawMagnet || rawInfoHash || rawTorrentUrl);
    if (!hasRetrieval) return void 0;
    if (optionId && !optionId.startsWith(`${prefix}-`)) {
      throw failure("missing", notFoundMessage);
    }
    const validTorrentUrl = rawTorrentUrl ? validateHttpUrl(rawTorrentUrl) : void 0;
    if (rawTorrentUrl && !validTorrentUrl) {
      throw failure("missing", "Invalid torrent retrieval URL.");
    }
    if (rawMagnet) {
      let parsed;
      try {
        parsed = parseMagnet(rawMagnet);
      } catch (e) {
        throw failure("missing", "Invalid magnet retrieval URI.");
      }
      const id = optionId || `${prefix}-${parsed.infoHash}`;
      return createTorrentOption(caye2, {
        id,
        key: parsed.infoHash,
        providerId,
        name: parsed.name || `${prefix} ${parsed.infoHash}`,
        magnet: rawMagnet,
        torrentUrl: validTorrentUrl,
        size: parsed.size > 0 ? parsed.size : void 0,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (rawInfoHash) {
      let infoHash = "";
      try {
        infoHash = normalizeInfoHash(rawInfoHash);
      } catch (e) {
        throw failure("missing", "Invalid torrent info hash.");
      }
      const id = optionId || `${prefix}-${infoHash}`;
      const magnet = buildMagnet({ infoHash, trackers: DEFAULT_TRACKERS });
      return createTorrentOption(caye2, {
        id,
        key: infoHash,
        providerId,
        name: `${prefix} ${infoHash}`,
        magnet,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (validTorrentUrl) {
      const id = optionId || `${prefix}-torrent`;
      const key = id.startsWith(`${prefix}-`) ? id.slice(prefix.length + 1) : id;
      return createTorrentOption(caye2, {
        id,
        key,
        providerId,
        name: `${prefix} ${key}`,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    return void 0;
  }
  function connectionStringConfig(context, key, fallback) {
    var _a;
    const raw = (_a = context.config) == null ? void 0 : _a[key];
    if (typeof raw === "string" && raw.trim()) {
      return raw.trim();
    }
    return fallback;
  }

  // ../torrent-common/src/media.ts
  function asRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return void 0;
    return value;
  }
  function positiveIntString(value) {
    if (typeof value === "number") {
      return Number.isInteger(value) && value > 0 ? String(value) : void 0;
    }
    if (typeof value === "string") {
      const trimmed = value.trim();
      return /^[1-9][0-9]*$/.test(trimmed) ? trimmed : void 0;
    }
    return void 0;
  }
  function addUniqueTitle(target, raw) {
    if (typeof raw !== "string") return;
    const trimmed = raw.trim();
    if (trimmed && !target.includes(trimmed)) {
      target.push(trimmed);
    }
  }
  function extractEntriesIds(entriesValue, preferredNative) {
    if (!Array.isArray(entriesValue)) return {};
    let anilistId;
    let anidbId;
    let malId;
    let bgmId;
    const inspect = (requireMatch) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      for (const rawEntry of entriesValue) {
        const entry = asRecord(rawEntry);
        if (!entry) continue;
        const ref = asRecord(entry.ref);
        if (requireMatch && preferredNative) {
          if ((ref == null ? void 0 : ref.providerId) !== preferredNative.entry.providerId || (ref == null ? void 0 : ref.nativeId) !== preferredNative.entry.nativeId) {
            continue;
          }
        }
        const ids = asRecord(entry.ids);
        if (ids) {
          anilistId != null ? anilistId : anilistId = positiveIntString((_b = (_a = ids.anilistid) != null ? _a : ids.anilistId) != null ? _b : ids.anilist);
          anidbId != null ? anidbId : anidbId = positiveIntString((_d = (_c = ids.anidbid) != null ? _c : ids.anidbId) != null ? _d : ids.anidb);
          malId != null ? malId : malId = positiveIntString((_f = (_e = ids.malid) != null ? _e : ids.malId) != null ? _f : ids.mal);
          bgmId != null ? bgmId : bgmId = positiveIntString((_i = (_h = (_g = ids.bgmid) != null ? _g : ids.bgmId) != null ? _h : ids.bgm) != null ? _i : ids.bangumi);
        }
        if ((ref == null ? void 0 : ref.providerId) === "caye.anilist:catalog" || (ref == null ? void 0 : ref.providerId) === "anilist" || typeof (ref == null ? void 0 : ref.providerId) === "string" && ref.providerId.includes("anilist")) {
          anilistId != null ? anilistId : anilistId = positiveIntString(ref.nativeId);
        }
      }
    };
    if (preferredNative) inspect(true);
    inspect(false);
    return { anilistId, anidbId, malId, bgmId };
  }
  function extractFieldMap(fieldsValue) {
    const out = {};
    if (!Array.isArray(fieldsValue)) return out;
    for (const rawField of fieldsValue) {
      const entry = asRecord(rawField);
      if (!entry || typeof entry.field !== "string") continue;
      const val = asRecord(entry.value);
      if (val) out[entry.field] = val;
    }
    return out;
  }
  function parseDateParts(raw) {
    if (typeof raw !== "string") return void 0;
    const m = /^(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?/.exec(raw.trim());
    if (!m) return void 0;
    const year = Number.parseInt(m[1], 10);
    if (year < 1900 || year > 2100) return void 0;
    return {
      year,
      month: m[2] ? Number.parseInt(m[2], 10) : void 0,
      day: m[3] ? Number.parseInt(m[3], 10) : void 0
    };
  }
  function safeGetItem(caye2, itemId) {
    return __async(this, null, function* () {
      if (!itemId || typeof caye2.request !== "function") return void 0;
      try {
        const raw = yield caye2.request("getItem", { path: { itemId } });
        return asRecord(raw);
      } catch (e) {
        return void 0;
      }
    });
  }
  function pickPreferredNative(query) {
    var _a;
    const refs = (_a = query.native) != null ? _a : [];
    if (refs.length === 0) return void 0;
    const exact = refs.find((r) => r.itemId === query.itemId);
    if (exact) return exact;
    return refs[0];
  }
  function resolveMediaContext(caye2, query) {
    return __async(this, null, function* () {
      var _a, _b;
      const titles = [];
      let romajiTitle = "";
      let englishTitle = "";
      let originalTitle = "";
      const synonyms = [];
      let anilistId;
      let anidbId;
      let malId;
      let bgmId;
      let isMovie = false;
      let isAnime = false;
      let adult = false;
      let year;
      let startDate;
      let episodeCount;
      let releaseStatus;
      const preferredNative = pickPreferredNative(query);
      const item = yield safeGetItem(caye2, query.itemId || (preferredNative == null ? void 0 : preferredNative.itemId));
      const parentId = typeof (item == null ? void 0 : item.parentId) === "string" ? item.parentId : void 0;
      const parentItem = parentId ? yield safeGetItem(caye2, parentId) : void 0;
      const consumeTitlesObj = (rawTitles) => {
        const t = asRecord(rawTitles);
        if (!t) return;
        if (!romajiTitle && typeof t.romaji === "string") romajiTitle = t.romaji.trim();
        if (!englishTitle && typeof t.english === "string") englishTitle = t.english.trim();
        if (!originalTitle && typeof t.original === "string") originalTitle = t.original.trim();
        addUniqueTitle(titles, t.romaji);
        addUniqueTitle(titles, t.english);
        addUniqueTitle(titles, t.original);
      };
      const inspectRecord = (record) => {
        var _a2, _b2, _c, _d, _e, _f, _g, _h, _i, _j, _k;
        if (!record) return;
        if (record.adult === true) adult = true;
        const kindId = typeof record.kindId === "string" ? record.kindId : "";
        const kindLeaf = (kindId.includes(":") ? kindId.split(":")[1] : kindId).toLowerCase();
        if (kindLeaf === "movie") isMovie = true;
        if (kindLeaf === "anime" || kindId.toLowerCase().includes(":anime")) isAnime = true;
        const ids = extractEntriesIds(record.entries, preferredNative);
        anilistId != null ? anilistId : anilistId = ids.anilistId;
        anidbId != null ? anidbId : anidbId = ids.anidbId;
        malId != null ? malId : malId = ids.malId;
        bgmId != null ? bgmId : bgmId = ids.bgmId;
        if (anilistId || anidbId) isAnime = true;
        const parentSummary = asRecord(record.parent);
        if (parentSummary) {
          consumeTitlesObj(parentSummary.titles);
          addUniqueTitle(titles, parentSummary.name);
        }
        consumeTitlesObj(record.titles);
        addUniqueTitle(titles, record.name);
        const totalChildren = typeof record.totalChildren === "number" ? record.totalChildren : typeof record.childCount === "number" ? record.childCount : void 0;
        if (totalChildren !== void 0 && totalChildren > 0 && episodeCount === void 0) {
          episodeCount = totalChildren;
        }
        const fields = extractFieldMap(record.fields);
        if (((_a2 = fields["caye:adult"]) == null ? void 0 : _a2.boolean) === true) adult = true;
        const formatVal = typeof ((_b2 = fields["caye:format"]) == null ? void 0 : _b2.text) === "string" ? fields["caye:format"].text.trim() : "";
        if (/^movie$/i.test(formatVal)) isMovie = true;
        if (/^(?:tv|tv_short|ova|ona|special|anime)$/i.test(formatVal) && isAnime) isMovie = false;
        const romajiField = typeof ((_c = fields["caye:romaji"]) == null ? void 0 : _c.text) === "string" ? fields["caye:romaji"].text.trim() : "";
        const englishField = typeof ((_d = fields["caye:english"]) == null ? void 0 : _d.text) === "string" ? fields["caye:english"].text.trim() : "";
        const originalField = typeof ((_e = fields["caye:original"]) == null ? void 0 : _e.text) === "string" ? fields["caye:original"].text.trim() : "";
        if (!romajiTitle && romajiField) romajiTitle = romajiField;
        if (!englishTitle && englishField) englishTitle = englishField;
        if (!originalTitle && originalField) originalTitle = originalField;
        addUniqueTitle(titles, romajiField);
        addUniqueTitle(titles, englishField);
        addUniqueTitle(titles, originalField);
        if (!releaseStatus) {
          const statusVal = (_h = (_f = fields["caye:status"]) == null ? void 0 : _f.text) != null ? _h : (_g = fields["caye:releaseStatus"]) == null ? void 0 : _g.text;
          if (typeof statusVal === "string" && statusVal.trim()) releaseStatus = statusVal.trim();
        }
        if (!startDate) {
          const releaseAt = (_i = fields["caye:releaseAt"]) == null ? void 0 : _i.text;
          startDate = parseDateParts(releaseAt);
        }
        if (year === void 0) {
          const yNum = (_j = fields["caye:year"]) == null ? void 0 : _j.number;
          if (typeof yNum === "number" && yNum >= 1900 && yNum <= 2100) {
            year = Math.trunc(yNum);
          } else if (startDate) {
            year = startDate.year;
          }
        }
        for (const key of ["caye:titles", "caye:synonyms", "caye:alternativeTitles"]) {
          const list = (_k = fields[key]) == null ? void 0 : _k.list;
          if (Array.isArray(list)) {
            for (const v of list) {
              const obj = asRecord(v);
              if (typeof (obj == null ? void 0 : obj.text) === "string" && obj.text.trim()) {
                addUniqueTitle(synonyms, obj.text);
                addUniqueTitle(titles, obj.text);
              }
            }
          }
        }
      };
      inspectRecord(parentItem);
      inspectRecord(item);
      const text = ((_a = query.text) == null ? void 0 : _a.trim()) || "";
      if (text) {
        addUniqueTitle(titles, text);
      }
      if (!anilistId) {
        for (const ref of (_b = query.native) != null ? _b : []) {
          if (ref.entry.providerId === "caye.anilist:catalog" || ref.entry.providerId === "anilist" || ref.entry.providerId.includes("anilist")) {
            anilistId = positiveIntString(ref.entry.nativeId);
            if (anilistId) break;
          }
        }
      }
      const season = typeof query.season === "number" && query.season > 0 ? query.season : typeof (item == null ? void 0 : item.season) === "number" && item.season > 0 ? item.season : void 0;
      const number = typeof query.number === "number" && query.number > 0 ? query.number : typeof (item == null ? void 0 : item.number) === "number" && item.number > 0 ? item.number : void 0;
      const absolute = typeof query.absolute === "number" && query.absolute > 0 ? query.absolute : void 0;
      const absoluteSeasonOffset = absolute !== void 0 && number !== void 0 && absolute > number ? absolute - number : 0;
      return {
        text,
        titles,
        romajiTitle: romajiTitle || titles[0] || "",
        englishTitle: englishTitle || "",
        originalTitle,
        synonyms,
        anilistId,
        anidbId,
        malId,
        bgmId,
        season,
        number,
        absolute,
        isMovie,
        isAnime,
        adult,
        year,
        startDate: startDate != null ? startDate : year ? { year } : void 0,
        episodeCount,
        releaseStatus,
        absoluteSeasonOffset
      };
    });
  }

  // src/backend.ts
  var PROVIDER_ID = "backreef.anirena:search";
  var DEFAULT_BASE_URL = "https://www.anirena.com";
  function resolveUrl(baseUrl, raw) {
    const val = (raw == null ? void 0 : raw.trim()) || "";
    if (!val) return "";
    if (/^https?:\/\//i.test(val)) return val;
    return `${baseUrl}${val.startsWith("/") ? "" : "/"}${val}`;
  }
  function parseIntDigits(raw) {
    const digits = (raw || "").replace(/\D+/g, "");
    return digits ? Number.parseInt(digits, 10) : 0;
  }
  function parseRows(baseUrl, html) {
    const doc = caye.html.parse(html);
    const rows = [];
    doc.find("tr[data-torrent-id]").each((_, row) => {
      var _a, _b, _c;
      const rawId = ((_a = row.attr("data-torrent-id")) == null ? void 0 : _a.trim()) || "";
      const titleEl = row.find(".tl-torrent-name").first();
      const title = titleEl.text().trim();
      if (!title) return true;
      const linkHref = titleEl.attr("href") || "";
      const magnetHref = row.find('a[href$="/magnet"]').first().attr("href") || "";
      const downloadHref = row.find('a[href$=".torrent"]').first().attr("href") || "";
      let sizeText = row.find(".col-size").first().text().trim();
      if (!sizeText) sizeText = row.find(".tl-meta-size").first().text().trim();
      const seeders = parseIntDigits(row.find(".tl-se").first().text());
      const leechers = parseIntDigits(row.find(".tl-le").first().text());
      let downloads = parseIntDigits(row.find(".col-dl").first().text());
      if (!downloads) {
        const seldText = row.find(".tl-meta-seld").first().text();
        const parts = seldText.split("/");
        if (parts.length >= 3) {
          const m = /^\s*(\d+)/.exec(parts[2]);
          if (m) downloads = Number.parseInt(m[1], 10);
        }
      }
      let publishedAt;
      const utc = (_b = row.find("[data-utc]").first().attr("data-utc")) == null ? void 0 : _b.trim();
      if (utc) {
        publishedAt = parseIsoDate(caye, utc, ["2006-01-02 15:04:05", "2006-01-02 15:04"]);
      }
      if (!publishedAt) {
        const ts = ((_c = row.attr("data-created-ts")) == null ? void 0 : _c.trim()) || "";
        if (/^\d+$/.test(ts)) {
          const ms = Number.parseInt(ts, 10) * 1e3;
          if (Number.isFinite(ms) && ms > 0) publishedAt = new Date(ms).toISOString();
        }
      }
      const pageUrl = resolveUrl(baseUrl, linkHref);
      const torrentUrl = resolveUrl(baseUrl, downloadHref);
      const magnetUrl = resolveUrl(baseUrl, magnetHref);
      const idKey = rawId || String(rows.length + 1);
      let group = row.find(".tl-group").first().text().trim().replace(/^\[|\]$/g, "");
      let resolution = "";
      try {
        const parsed = caye.release.parse(title);
        if (!group && parsed.group) group = parsed.group;
        if (parsed.resolution) resolution = parsed.resolution;
      } catch (e) {
      }
      const isBatch = isLikelyBatchTitle(title);
      const episode = isBatch ? -1 : extractSingleEpisode(caye, title);
      rows.push({
        id: `anirena-${idKey}`,
        rawId: idKey,
        name: title,
        pageUrl,
        torrentUrl,
        magnetHref: magnetUrl,
        size: parseSize(sizeText),
        seeders,
        leechers,
        downloads,
        publishedAt,
        group,
        episode,
        isBatch,
        resolution
      });
      return true;
    });
    return rows;
  }
  function buildSmartQueries(query, media) {
    const res = query.resolution ? ` ${query.resolution}` : "";
    const rawUser = sanitizeQuery(query.text || "");
    const candidates = [];
    if (rawUser) candidates.push(rawUser);
    for (const t of media.titles) {
      const clean = sanitizeQuery(t);
      if (clean && !candidates.includes(clean)) candidates.push(clean);
    }
    if (candidates.length === 0) return [];
    const primary = candidates[0];
    const secondary = candidates[1] || "";
    const queries = [];
    if (query.batch) {
      queries.push(`${primary} Batch${res}`.trim());
      queries.push(`${primary} Complete${res}`.trim());
      if (media.season && media.season > 1) {
        queries.push(`${primary} S${String(media.season).padStart(2, "0")} Batch${res}`.trim());
      }
      if (secondary) queries.push(`${secondary} Batch${res}`.trim());
      queries.push(`${primary}${res}`.trim());
    } else if (query.number && query.number > 0 && !media.isMovie) {
      const ep = String(Math.trunc(query.number)).padStart(2, "0");
      queries.push(`${primary} ${ep}${res}`.trim());
      queries.push(`${primary} E${ep}${res}`.trim());
      if (media.season && media.season > 1) {
        queries.push(`${primary} S${String(media.season).padStart(2, "0")}E${ep}${res}`.trim());
      }
      if (secondary) queries.push(`${secondary} ${ep}${res}`.trim());
      if (query.absolute && query.absolute > 0 && query.absolute !== query.number) {
        queries.push(
          `${primary} ${String(Math.trunc(query.absolute)).padStart(2, "0")}${res}`.trim()
        );
      }
    } else {
      queries.push(`${primary}${res}`.trim());
      if (secondary) queries.push(`${secondary}${res}`.trim());
    }
    return Array.from(new Set(queries.filter(Boolean))).slice(0, 6);
  }
  function rowFitsSmartQuery(row, query, media) {
    const targets = media.titles.length > 0 ? media.titles : query.text ? [query.text] : [];
    if (targets.length > 0 && !titleMatchesAny(caye, row.name, targets, query.batch || media.isMovie ? 0.55 : 0.65)) {
      return false;
    }
    if (query.resolution) {
      const wantRes = parseResolutionNumber(query.resolution);
      const gotRes = parseResolutionNumber(row.resolution || row.name);
      if (wantRes > 0 && gotRes > 0 && wantRes !== gotRes) return false;
    }
    if (query.batch) {
      return row.isBatch || row.episode === -1;
    }
    if (media.isMovie) {
      return !row.isBatch;
    }
    if (query.number && query.number > 0) {
      if (row.episode < 0) return false;
      return row.episode === query.number || query.absolute !== void 0 && query.absolute > 0 && row.episode === query.absolute;
    }
    return true;
  }
  function rowToOption(row, confirmed) {
    return createTorrentOption(caye, {
      id: row.id,
      key: row.rawId,
      providerId: PROVIDER_ID,
      name: row.name,
      torrentUrl: row.torrentUrl || row.magnetHref || row.pageUrl,
      pageUrl: row.pageUrl || void 0,
      size: row.size > 0 ? row.size : void 0,
      seeders: row.seeders,
      leechers: row.leechers,
      downloads: row.downloads > 0 ? row.downloads : void 0,
      publishedAt: row.publishedAt,
      resolution: row.resolution || void 0,
      group: row.group || void 0,
      confirmed
    });
  }
  function find(context, query) {
    return __async(this, null, function* () {
      const baseUrl = connectionStringConfig(context, "apiUrl", DEFAULT_BASE_URL).replace(/\/+$/, "");
      const media = yield resolveMediaContext(caye, query);
      const isSmart = Boolean(query.batch || query.number && query.number > 0 || query.itemId);
      const queries = isSmart ? buildSmartQueries(query, media) : [sanitizeQuery(query.text || media.romajiTitle || "")].filter(Boolean);
      if (queries.length === 0) {
        throw failure("unsupported", "Enter a title to search.");
      }
      const pages = yield mapLimit(queries, 3, (q) => __async(null, null, function* () {
        const res = yield fetchText(caye, "AniRena", `${baseUrl}/?q=${encodeURIComponent(q)}`, {
          headers: { Accept: "text/html" }
        });
        return parseRows(baseUrl, res.body);
      }));
      const deduped = /* @__PURE__ */ new Map();
      for (const list of pages) {
        for (const row of list) {
          if (!deduped.has(row.id)) deduped.set(row.id, row);
        }
      }
      let rows = Array.from(deduped.values());
      if (isSmart && (query.batch || query.number && query.number > 0)) {
        const filtered = rows.filter((row) => rowFitsSmartQuery(row, query, media));
        if (filtered.length > 0 || query.number || query.batch) {
          rows = filtered;
        }
      }
      const limit = clampLimit(query.limit, 50, 100);
      const confirmed = Boolean(!query.batch && query.number && query.number > 0);
      const items = rows.slice(0, limit).map((row) => rowToOption(row, confirmed));
      yield cacheOptions(caye, "anirena", items);
      for (const row of rows.slice(0, limit)) {
        yield setCachedJson(
          caye,
          `anirena:meta:${row.id}`,
          {
            magnetHref: row.magnetHref,
            torrentUrl: row.torrentUrl,
            pageUrl: row.pageUrl,
            name: row.name
          },
          OPTION_CACHE_TTL_SECONDS
        );
      }
      return { items, state: "complete" };
    });
  }
  function resolve(context, input) {
    return __async(this, null, function* () {
      var _a;
      const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
      const match = /^anirena-([a-zA-Z0-9_-]+)$/.exec(optionId);
      if (!match) {
        throw failure("missing", "Unknown AniRena option.");
      }
      const rawId = match[1];
      const cached = yield getCachedJson(caye, `anirena:option:${optionId}`);
      if (cached && cached.magnet) {
        return cached;
      }
      const baseUrl = connectionStringConfig(context, "apiUrl", DEFAULT_BASE_URL).replace(/\/+$/, "");
      const meta = yield getCachedJson(caye, `anirena:meta:${optionId}`);
      const magnetEndpoint = (meta == null ? void 0 : meta.magnetHref) || `${baseUrl}/torrents/${rawId}/magnet`;
      const torrentEndpoint = (meta == null ? void 0 : meta.torrentUrl) || `${baseUrl}/torrents/${rawId}.torrent`;
      const pageUrl = (meta == null ? void 0 : meta.pageUrl) || (cached == null ? void 0 : cached.pageUrl) || `${baseUrl}/torrent/${rawId}`;
      const fallbackName = (cached == null ? void 0 : cached.name) || (meta == null ? void 0 : meta.name) || `AniRena ${rawId}`;
      let magnet = "";
      try {
        const res = yield fetchText(caye, "AniRena", magnetEndpoint, {
          redirect: "manual",
          missingOn404: true
        });
        const loc = res.headers["location"] || "";
        if (loc.startsWith("magnet:")) {
          magnet = loc;
        } else if (res.body.trim().startsWith("magnet:")) {
          magnet = res.body.trim();
        }
      } catch (err) {
        const code = err == null ? void 0 : err.code;
        if (code === "rate-limited") throw err;
      }
      if (!magnet) {
        try {
          const resolvedTorrent = yield torrentUrlToMagnet(caye, "AniRena", torrentEndpoint, {
            fallbackName,
            missingOn404: true
          });
          magnet = resolvedTorrent.magnet;
        } catch (err) {
          const code = err == null ? void 0 : err.code;
          if (code === "rate-limited") throw err;
        }
      }
      if (!magnet) {
        try {
          const pageRes = yield fetchText(caye, "AniRena", pageUrl, {
            headers: { Accept: "text/html" },
            missingOn404: true
          });
          const doc = caye.html.parse(pageRes.body);
          const direct = doc.find('a[href^="magnet:"]').first().attr("href") || "";
          if (direct.startsWith("magnet:")) {
            magnet = direct;
          } else {
            const hashMatch = /\b([a-fA-F0-9]{40})\b/.exec(doc.text());
            if (hashMatch) {
              const infoHash = normalizeInfoHash(hashMatch[1]);
              magnet = buildMagnet({
                infoHash,
                name: fallbackName,
                trackers: DEFAULT_TRACKERS
              });
            }
          }
        } catch (err) {
          const fallback = resolveFromRetrievalInput(
            caye,
            PROVIDER_ID,
            "anirena",
            input,
            "Unknown AniRena option."
          );
          if (fallback) return fallback;
          throw err;
        }
      }
      if (!magnet) {
        const fallback = resolveFromRetrievalInput(
          caye,
          PROVIDER_ID,
          "anirena",
          input,
          "Unknown AniRena option."
        );
        if (fallback) return fallback;
        throw failure("unavailable", "AniRena did not provide a magnet link or torrent.");
      }
      const updated = cached ? __spreadProps(__spreadValues({}, cached), {
        magnet,
        uri: magnet.length <= 2e3 ? magnet : torrentEndpoint || magnet
      }) : createTorrentOption(caye, {
        id: optionId,
        key: rawId,
        providerId: PROVIDER_ID,
        name: fallbackName,
        magnet,
        torrentUrl: torrentEndpoint,
        pageUrl,
        confirmed: false
      });
      yield setCachedJson(caye, `anirena:option:${optionId}`, updated, OPTION_CACHE_TTL_SECONDS);
      return updated;
    });
  }
  caye.register(PROVIDER_ID, { acquisition: { find, resolve } });
})();
//# sourceMappingURL=backend.js.map
