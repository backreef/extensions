import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DownloadOption,
} from "../../../../packages/plugin-sdk/src/index"
import {
    buildMagnet,
    cacheOptions,
    clampLimit,
    connectionStringConfig,
    createTorrentOption,
    DEFAULT_TRACKERS,
    extractSingleEpisode,
    fetchText,
    isLikelyBatchTitle,
    mapLimit,
    normalizeInfoHash,
    OPTION_CACHE_TTL_SECONDS,
    parseIsoDate,
    parseResolutionNumber,
    parseSize,
    resolveFromRetrievalInput,
    resolveMediaContext,
    sanitizeQuery,
    titleMatchesAny,
    torrentUrlToMagnet,
    type MediaContext,
} from "../../torrent-common/src/index.ts"
import { getCachedJson, setCachedJson } from "../../../../packages/plugin-std/src/cache.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const PROVIDER_ID = "backreef.anirena:search"
const DEFAULT_BASE_URL = "https://www.anirena.com"

type ParsedRow = {
    id: string
    rawId: string
    name: string
    pageUrl: string
    torrentUrl: string
    magnetHref: string
    size: number
    seeders: number
    leechers: number
    downloads: number
    publishedAt?: string
    group: string
    episode: number
    isBatch: boolean
    resolution: string
}

function resolveUrl(baseUrl: string, raw: string | undefined): string {
    const val = raw?.trim() || ""
    if (!val) return ""
    if (/^https?:\/\//i.test(val)) return val
    return `${baseUrl}${val.startsWith("/") ? "" : "/"}${val}`
}

function parseIntDigits(raw: string | undefined): number {
    const digits = (raw || "").replace(/\D+/g, "")
    return digits ? Number.parseInt(digits, 10) : 0
}

function parseRows(baseUrl: string, html: string): ParsedRow[] {
    const doc = caye.html.parse(html)
    const rows: ParsedRow[] = []

    doc.find("tr[data-torrent-id]").each((_, row) => {
        const rawId = row.attr("data-torrent-id")?.trim() || ""
        const titleEl = row.find(".tl-torrent-name").first()
        const title = titleEl.text().trim()
        if (!title) return true

        const linkHref = titleEl.attr("href") || ""
        const magnetHref = row.find('a[href$="/magnet"]').first().attr("href") || ""
        const downloadHref = row.find('a[href$=".torrent"]').first().attr("href") || ""

        let sizeText = row.find(".col-size").first().text().trim()
        if (!sizeText) sizeText = row.find(".tl-meta-size").first().text().trim()

        const seeders = parseIntDigits(row.find(".tl-se").first().text())
        const leechers = parseIntDigits(row.find(".tl-le").first().text())
        let downloads = parseIntDigits(row.find(".col-dl").first().text())
        if (!downloads) {
            const seldText = row.find(".tl-meta-seld").first().text()
            const parts = seldText.split("/")
            if (parts.length >= 3) {
                const m = /^\s*(\d+)/.exec(parts[2])
                if (m) downloads = Number.parseInt(m[1], 10)
            }
        }

        let publishedAt: string | undefined
        const utc = row.find("[data-utc]").first().attr("data-utc")?.trim()
        if (utc) {
            publishedAt = parseIsoDate(caye, utc, ["2006-01-02 15:04:05", "2006-01-02 15:04"])
        }
        if (!publishedAt) {
            const ts = row.attr("data-created-ts")?.trim() || ""
            if (/^\d+$/.test(ts)) {
                const ms = Number.parseInt(ts, 10) * 1000
                if (Number.isFinite(ms) && ms > 0) publishedAt = new Date(ms).toISOString()
            }
        }

        const pageUrl = resolveUrl(baseUrl, linkHref)
        const torrentUrl = resolveUrl(baseUrl, downloadHref)
        const magnetUrl = resolveUrl(baseUrl, magnetHref)
        const idKey = rawId || String(rows.length + 1)

        let group = row
            .find(".tl-group")
            .first()
            .text()
            .trim()
            .replace(/^\[|\]$/g, "")
        let resolution = ""
        try {
            const parsed = caye.release.parse(title)
            if (!group && parsed.group) group = parsed.group
            if (parsed.resolution) resolution = parsed.resolution
        } catch {}

        const isBatch = isLikelyBatchTitle(title)
        const episode = isBatch ? -1 : extractSingleEpisode(caye, title)

        rows.push({
            id: `anirena-${idKey}`,
            rawId: idKey,
            name: title,
            pageUrl,
            torrentUrl,
            magnetHref: magnetUrl,
            size: parseSize(sizeText),
            seeders,
            leechers,
            downloads,
            publishedAt,
            group,
            episode,
            isBatch,
            resolution,
        })
        return true
    })

    return rows
}

function buildSmartQueries(query: AcquisitionQuery, media: MediaContext): string[] {
    const res = query.resolution ? ` ${query.resolution}` : ""
    const rawUser = sanitizeQuery(query.text || "")
    const candidates: string[] = []
    if (rawUser) candidates.push(rawUser)
    for (const t of media.titles) {
        const clean = sanitizeQuery(t)
        if (clean && !candidates.includes(clean)) candidates.push(clean)
    }
    if (candidates.length === 0) return []
    const primary = candidates[0]
    const secondary = candidates[1] || ""
    const queries: string[] = []

    if (query.batch) {
        queries.push(`${primary} Batch${res}`.trim())
        queries.push(`${primary} Complete${res}`.trim())
        if (media.season && media.season > 1) {
            queries.push(`${primary} S${String(media.season).padStart(2, "0")} Batch${res}`.trim())
        }
        if (secondary) queries.push(`${secondary} Batch${res}`.trim())
        queries.push(`${primary}${res}`.trim())
    } else if (query.number && query.number > 0 && !media.isMovie) {
        const ep = String(Math.trunc(query.number)).padStart(2, "0")
        queries.push(`${primary} ${ep}${res}`.trim())
        queries.push(`${primary} E${ep}${res}`.trim())
        if (media.season && media.season > 1) {
            queries.push(`${primary} S${String(media.season).padStart(2, "0")}E${ep}${res}`.trim())
        }
        if (secondary) queries.push(`${secondary} ${ep}${res}`.trim())
        if (query.absolute && query.absolute > 0 && query.absolute !== query.number) {
            queries.push(
                `${primary} ${String(Math.trunc(query.absolute)).padStart(2, "0")}${res}`.trim(),
            )
        }
    } else {
        queries.push(`${primary}${res}`.trim())
        if (secondary) queries.push(`${secondary}${res}`.trim())
    }

    return Array.from(new Set(queries.filter(Boolean))).slice(0, 6)
}

function rowFitsSmartQuery(row: ParsedRow, query: AcquisitionQuery, media: MediaContext): boolean {
    const targets = media.titles.length > 0 ? media.titles : query.text ? [query.text] : []
    if (
        targets.length > 0 &&
        !titleMatchesAny(caye, row.name, targets, query.batch || media.isMovie ? 0.55 : 0.65)
    ) {
        return false
    }
    if (query.resolution) {
        const wantRes = parseResolutionNumber(query.resolution)
        const gotRes = parseResolutionNumber(row.resolution || row.name)
        if (wantRes > 0 && gotRes > 0 && wantRes !== gotRes) return false
    }
    if (query.batch) {
        return row.isBatch || row.episode === -1
    }
    if (media.isMovie) {
        return !row.isBatch
    }
    if (query.number && query.number > 0) {
        if (row.episode < 0) return false
        return (
            row.episode === query.number ||
            (query.absolute !== undefined && query.absolute > 0 && row.episode === query.absolute)
        )
    }
    return true
}

function rowToOption(row: ParsedRow, confirmed: boolean): DownloadOption {
    return createTorrentOption(caye, {
        id: row.id,
        key: row.rawId,
        providerId: PROVIDER_ID,
        name: row.name,
        torrentUrl: row.torrentUrl || row.magnetHref || row.pageUrl,
        pageUrl: row.pageUrl || undefined,
        size: row.size > 0 ? row.size : undefined,
        seeders: row.seeders,
        leechers: row.leechers,
        downloads: row.downloads > 0 ? row.downloads : undefined,
        publishedAt: row.publishedAt,
        resolution: row.resolution || undefined,
        group: row.group || undefined,
        confirmed,
    })
}

async function find(context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const baseUrl = connectionStringConfig(context, "apiUrl", DEFAULT_BASE_URL).replace(/\/+$/, "")
    const media = await resolveMediaContext(caye, query)
    const isSmart = Boolean(query.batch || (query.number && query.number > 0) || query.itemId)
    const queries = isSmart
        ? buildSmartQueries(query, media)
        : [sanitizeQuery(query.text || media.romajiTitle || "")].filter(Boolean)

    if (queries.length === 0) {
        throw failure("unsupported", "Enter a title to search.")
    }

    const pages = await mapLimit(queries, 3, async (q) => {
        const res = await fetchText(caye, "AniRena", `${baseUrl}/?q=${encodeURIComponent(q)}`, {
            headers: { Accept: "text/html" },
        })
        return parseRows(baseUrl, res.body)
    })

    const deduped = new Map<string, ParsedRow>()
    for (const list of pages) {
        for (const row of list) {
            if (!deduped.has(row.id)) deduped.set(row.id, row)
        }
    }

    let rows = Array.from(deduped.values())
    if (isSmart && (query.batch || (query.number && query.number > 0))) {
        const filtered = rows.filter((row) => rowFitsSmartQuery(row, query, media))
        if (filtered.length > 0 || query.number || query.batch) {
            rows = filtered
        }
    }

    const limit = clampLimit(query.limit, 50, 100)
    const confirmed = Boolean(!query.batch && query.number && query.number > 0)
    const items = rows.slice(0, limit).map((row) => rowToOption(row, confirmed))
    await cacheOptions(caye, "anirena", items)
    for (const row of rows.slice(0, limit)) {
        await setCachedJson(
            caye,
            `anirena:meta:${row.id}`,
            {
                magnetHref: row.magnetHref,
                torrentUrl: row.torrentUrl,
                pageUrl: row.pageUrl,
                name: row.name,
            },
            OPTION_CACHE_TTL_SECONDS,
        )
    }
    return { items, state: "complete" }
}

async function resolve(context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    const optionId = input.optionId?.trim() || ""
    const match = /^anirena-([a-zA-Z0-9_-]+)$/.exec(optionId)
    if (!match) {
        throw failure("missing", "Unknown AniRena option.")
    }
    const rawId = match[1]
    const cached = await getCachedJson<DownloadOption>(caye, `anirena:option:${optionId}`)
    if (cached && cached.magnet) {
        return cached
    }

    const baseUrl = connectionStringConfig(context, "apiUrl", DEFAULT_BASE_URL).replace(/\/+$/, "")
    const meta = await getCachedJson<{
        magnetHref?: string
        torrentUrl?: string
        pageUrl?: string
        name?: string
    }>(caye, `anirena:meta:${optionId}`)

    const magnetEndpoint = meta?.magnetHref || `${baseUrl}/torrents/${rawId}/magnet`
    const torrentEndpoint = meta?.torrentUrl || `${baseUrl}/torrents/${rawId}.torrent`
    const pageUrl = meta?.pageUrl || cached?.pageUrl || `${baseUrl}/torrent/${rawId}`
    const fallbackName = cached?.name || meta?.name || `AniRena ${rawId}`

    let magnet = ""

    try {
        const res = await fetchText(caye, "AniRena", magnetEndpoint, {
            redirect: "manual",
            missingOn404: true,
        })
        const loc = res.headers["location"] || ""
        if (loc.startsWith("magnet:")) {
            magnet = loc
        } else if (res.body.trim().startsWith("magnet:")) {
            magnet = res.body.trim()
        }
    } catch (err) {
        const code = (err as { code?: string })?.code
        if (code === "rate-limited") throw err
    }

    if (!magnet) {
        try {
            const resolvedTorrent = await torrentUrlToMagnet(caye, "AniRena", torrentEndpoint, {
                fallbackName,
                missingOn404: true,
            })
            magnet = resolvedTorrent.magnet
        } catch (err) {
            const code = (err as { code?: string })?.code
            if (code === "rate-limited") throw err
        }
    }

    if (!magnet) {
        try {
            const pageRes = await fetchText(caye, "AniRena", pageUrl, {
                headers: { Accept: "text/html" },
                missingOn404: true,
            })
            const doc = caye.html.parse(pageRes.body)
            const direct = doc.find('a[href^="magnet:"]').first().attr("href") || ""
            if (direct.startsWith("magnet:")) {
                magnet = direct
            } else {
                const hashMatch = /\b([a-fA-F0-9]{40})\b/.exec(doc.text())
                if (hashMatch) {
                    const infoHash = normalizeInfoHash(hashMatch[1])
                    magnet = buildMagnet({
                        infoHash,
                        name: fallbackName,
                        trackers: DEFAULT_TRACKERS,
                    })
                }
            }
        } catch (err) {
            const fallback = resolveFromRetrievalInput(
                caye,
                PROVIDER_ID,
                "anirena",
                input,
                "Unknown AniRena option.",
            )
            if (fallback) return fallback
            throw err
        }
    }

    if (!magnet) {
        const fallback = resolveFromRetrievalInput(
            caye,
            PROVIDER_ID,
            "anirena",
            input,
            "Unknown AniRena option.",
        )
        if (fallback) return fallback
        throw failure("unavailable", "AniRena did not provide a magnet link or torrent.")
    }

    const updated: DownloadOption = cached
        ? {
              ...cached,
              magnet,
              uri: magnet.length <= 2000 ? magnet : torrentEndpoint || magnet,
          }
        : createTorrentOption(caye, {
              id: optionId,
              key: rawId,
              providerId: PROVIDER_ID,
              name: fallbackName,
              magnet,
              torrentUrl: torrentEndpoint,
              pageUrl,
              confirmed: false,
          })

    await setCachedJson(caye, `anirena:option:${optionId}`, updated, OPTION_CACHE_TTL_SECONDS)
    return updated
}

caye.register(PROVIDER_ID, { acquisition: { find, resolve } })
