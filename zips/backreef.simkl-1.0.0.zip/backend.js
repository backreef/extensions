(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // src/simkl.ts
  var pullFields = ["status", "rating", "progress"];
  var namespaces = {
    anime: { providerId: "caye.movies-shows:anilist", type: "anime" },
    show: { providerId: "backreef.simkl:tracker", type: "show" },
    movie: { providerId: "backreef.simkl:tracker", type: "movie" }
  };
  var toCayeStatus = {
    watching: "in-progress",
    plantowatch: "planning",
    hold: "paused",
    completed: "completed",
    dropped: "dropped"
  };
  var toSimklStatus = {
    "in-progress": "watching",
    planning: "plantowatch",
    paused: "hold",
    completed: "completed",
    dropped: "dropped"
  };
  var defaultPinUrl = "https://simkl.com/pin/";
  function errorWithCode(message, code, extra) {
    return Object.assign(new Error(message), __spreadValues({ code }, extra));
  }
  function needsAuth(message) {
    return errorWithCode(message, "needs-auth");
  }
  function unavailable(message = "Simkl did not answer.") {
    return errorWithCode(message, "unavailable");
  }
  function limited(waitMs) {
    return errorWithCode("Simkl rate limit reached.", "rate-limited", {
      retry_after: Math.max(1, Math.ceil(waitMs / 1e3))
    });
  }
  function resetAt(headers, now = Date.now()) {
    var _a, _b, _c, _d;
    const retryHeader = (_b = (_a = headers["retry-after"]) != null ? _a : headers["Retry-After"]) != null ? _b : "";
    const retry = parseInt(retryHeader, 10);
    if (!Number.isNaN(retry)) return now + (retry + 1) * 1e3;
    const resetHeader = (_d = (_c = headers["x-ratelimit-reset"]) != null ? _c : headers["X-RateLimit-Reset"]) != null ? _d : "";
    const reset = parseInt(resetHeader, 10);
    if (!Number.isNaN(reset) && reset > 0) return reset * 1e3;
    return now + 6e4;
  }
  function resolveClientId(configClientId, fallbackClientId) {
    const trimmed = (configClientId != null ? configClientId : "").trim();
    return trimmed || fallbackClientId.trim();
  }
  function parseAccountSecret(raw) {
    if (!raw) return null;
    try {
      const parsed = JSON.parse(raw);
      if (typeof (parsed == null ? void 0 : parsed.access) !== "string" || parsed.access.length === 0) return null;
      return {
        access: parsed.access,
        clientId: typeof parsed.clientId === "string" ? parsed.clientId : void 0
      };
    } catch (e) {
      return null;
    }
  }
  function parsePinData(data) {
    if (!data) return null;
    try {
      const parsed = JSON.parse(data);
      if (typeof (parsed == null ? void 0 : parsed.userCode) !== "string" || parsed.userCode.length === 0 || typeof (parsed == null ? void 0 : parsed.clientId) !== "string" || parsed.clientId.length === 0) {
        return null;
      }
      return { userCode: parsed.userCode, clientId: parsed.clientId };
    } catch (e) {
      return null;
    }
  }
  function buildPinStartResult(body, clientId) {
    var _a, _b;
    const userCode = typeof body.user_code === "string" ? body.user_code.trim() : "";
    if (!userCode) {
      throw unavailable("Simkl did not return a sign-in code.");
    }
    const candidate = (_b = (_a = body.verification_url) != null ? _a : body.verification_uri) != null ? _b : "";
    const url = candidate.startsWith("https://") ? candidate : defaultPinUrl;
    const result = {
      url,
      code: userCode,
      data: JSON.stringify({ userCode, clientId })
    };
    if (typeof body.interval === "number" && Number.isFinite(body.interval) && body.interval > 0) {
      result.interval = body.interval;
    }
    if (typeof body.expires_in === "number" && Number.isFinite(body.expires_in) && body.expires_in > 0) {
      result.expiresIn = body.expires_in;
    }
    return result;
  }
  function parsePinCompleteResult(status, body, clientId) {
    if (body.result === "OK" && typeof body.access_token === "string" && body.access_token.length > 0) {
      return {
        value: JSON.stringify({ access: body.access_token, clientId })
      };
    }
    const message = typeof body.message === "string" ? body.message : "";
    if (status === 400 || status === 404 || status === 410 || typeof body.error === "string" || /expired|invalid|not found|denied/i.test(message)) {
      throw new Error("The Simkl PIN code expired. Start sign-in again.");
    }
    return { pending: true };
  }
  function positiveIntString(value) {
    if (typeof value === "number") {
      return Number.isInteger(value) && value > 0 ? String(value) : null;
    }
    if (typeof value === "string") {
      const trimmed = value.trim();
      return /^[1-9]\d*$/.test(trimmed) ? trimmed : null;
    }
    return null;
  }
  function itemMedia(item, kind) {
    var _a;
    if (kind === "movie") return item.movie;
    if (kind === "anime") return (_a = item.anime) != null ? _a : item.show;
    return item.show;
  }
  function buildRevision(item) {
    return [item.last_watched_at, item.user_rated_at, item.added_to_watchlist_at].filter((value) => typeof value === "string" && value.trim().length > 0).join("|");
  }
  function posterUrl(poster) {
    if (!poster) return void 0;
    const trimmed = poster.trim();
    if (!trimmed) return void 0;
    if (trimmed.startsWith("https://")) return trimmed;
    const clean = trimmed.replace(/^\/+/, "");
    if (!clean) return void 0;
    return `https://wsrv.nl/?url=https://simkl.in/posters/${clean}_m.jpg`;
  }
  function simklPageUrl(kind, simklId) {
    const id = positiveIntString(simklId);
    if (!id) return void 0;
    const segment = kind === "movie" ? "movies" : kind === "show" ? "tv" : "anime";
    return `https://simkl.com/${segment}/${id}`;
  }
  function entry(item, kind, resolvedAnilistId) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    const media = itemMedia(item, kind);
    let nativeId = null;
    if (kind === "anime") {
      nativeId = (_b = positiveIntString((_a = media == null ? void 0 : media.ids) == null ? void 0 : _a.anilist)) != null ? _b : positiveIntString(resolvedAnilistId);
    } else if (kind === "show") {
      nativeId = positiveIntString((_c = media == null ? void 0 : media.ids) == null ? void 0 : _c.tvdb);
    } else {
      nativeId = positiveIntString((_d = media == null ? void 0 : media.ids) == null ? void 0 : _d.tmdb);
    }
    if (!nativeId) return null;
    const out = {
      ref: __spreadProps(__spreadValues({}, namespaces[kind]), { nativeId }),
      revision: buildRevision(item)
    };
    const status = toCayeStatus[(_e = item.status) != null ? _e : ""];
    if (status) out.status = status;
    if (typeof item.user_rating === "number" && Number.isFinite(item.user_rating) && item.user_rating >= 1 && item.user_rating <= 10) {
      out.rating = item.user_rating;
    }
    if (kind !== "movie") {
      out.progress = typeof item.watched_episodes_count === "number" && item.watched_episodes_count >= 0 ? item.watched_episodes_count : 0;
      if (typeof item.total_episodes_count === "number" && item.total_episodes_count > 0) {
        out.total = item.total_episodes_count;
      }
    }
    const title = (_f = media == null ? void 0 : media.title) == null ? void 0 : _f.trim().slice(0, 300);
    if (title) out.title = title;
    if (typeof (media == null ? void 0 : media.year) === "number" && Number.isInteger(media.year) && media.year > 0 && media.year <= 9999) {
      out.year = media.year;
    }
    const image = posterUrl(media == null ? void 0 : media.poster);
    if (image) out.imageUrl = image;
    const page = simklPageUrl(kind, (_i = (_g = media == null ? void 0 : media.ids) == null ? void 0 : _g.simkl) != null ? _i : (_h = media == null ? void 0 : media.ids) == null ? void 0 : _h.simkl_id);
    if (page) out.url = page;
    const details = [kind === "anime" ? "Anime" : kind === "show" ? "Show" : "Movie"];
    if (kind !== "movie" && out.total && out.total > 0) {
      details.push(`${out.total} episode${out.total === 1 ? "" : "s"}`);
    }
    out.details = details;
    return out;
  }
  function refToKind(ref) {
    const kind = Object.keys(namespaces).find((candidate) => {
      const ns = namespaces[candidate];
      return ref.providerId === ns.providerId && ref.type === ns.type;
    });
    if (!kind) return null;
    const id = Number(ref.nativeId);
    if (!/^[1-9]\d*$/.test(ref.nativeId) || !Number.isSafeInteger(id)) {
      return null;
    }
    return kind;
  }
  function effectivePushFields(kind, fields) {
    if (kind !== "movie" || !("progress" in fields)) return fields;
    const out = {};
    for (const [key, value] of Object.entries(fields)) {
      if (key !== "progress") {
        out[key] = value;
      }
    }
    return out;
  }
  function matches(value, pushed) {
    return Object.entries(pushed).every(([field, want]) => {
      const have = value[field];
      return (want != null ? want : void 0) === (have != null ? have : void 0);
    });
  }
  function newStatus(progress, total) {
    const count = typeof progress === "number" ? progress : 0;
    if (count <= 0) return "plantowatch";
    if (total && total > 0 && count >= total) return "completed";
    return "watching";
  }
  function listKey(kind) {
    if (kind === "show") return "shows";
    if (kind === "movie") return "movies";
    return "anime";
  }
  function simklIdsForEntry(ref, kind, item) {
    var _a, _b, _c;
    const ids = {};
    const media = item ? itemMedia(item, kind) : void 0;
    const simklId = positiveIntString((_c = (_a = media == null ? void 0 : media.ids) == null ? void 0 : _a.simkl) != null ? _c : (_b = media == null ? void 0 : media.ids) == null ? void 0 : _b.simkl_id);
    if (simklId) ids.simkl = Number(simklId);
    const nativeNum = Number(ref.nativeId);
    if (kind === "show") ids.tvdb = nativeNum;
    else if (kind === "movie") ids.tmdb = nativeNum;
    else ids.anilist = nativeNum;
    return ids;
  }
  function buildRemoveBody(kind, ids) {
    return { [listKey(kind)]: [{ ids }] };
  }
  function buildStatusBody(kind, ids, simklStatus) {
    return { [listKey(kind)]: [{ to: simklStatus, ids }] };
  }
  function buildRatingBody(kind, ids, rating) {
    const score = Math.max(1, Math.min(10, Math.round(rating)));
    return { [listKey(kind)]: [{ rating: score, ids }] };
  }
  function buildRemoveRatingBody(kind, ids) {
    return { [listKey(kind)]: [{ ids }] };
  }
  function orderRegularEpisodes(kind, rawEpisodes) {
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const ep of rawEpisodes) {
      if (ep.type === "special") continue;
      if (typeof ep.episode !== "number" || !Number.isInteger(ep.episode) || ep.episode <= 0) {
        continue;
      }
      if (kind === "show") {
        if (typeof ep.season !== "number" || !Number.isInteger(ep.season) || ep.season <= 0) {
          continue;
        }
        const key = `${ep.season}:${ep.episode}`;
        if (seen.has(key)) continue;
        seen.add(key);
        out.push({ season: ep.season, number: ep.episode });
      } else {
        if (ep.season !== void 0 && ep.season <= 0) continue;
        const season = typeof ep.season === "number" && Number.isInteger(ep.season) && ep.season > 0 ? ep.season : void 0;
        const key = `${season != null ? season : 0}:${ep.episode}`;
        if (seen.has(key)) continue;
        seen.add(key);
        out.push(season !== void 0 ? { season, number: ep.episode } : { number: ep.episode });
      }
    }
    out.sort((a, b) => {
      var _a, _b;
      return ((_a = a.season) != null ? _a : 1) - ((_b = b.season) != null ? _b : 1) || a.number - b.number;
    });
    return out;
  }
  function coordKey(ep) {
    var _a;
    return `${(_a = ep.season) != null ? _a : 1}:${ep.number}`;
  }
  function currentWatchedKeys(item, regularEpisodes) {
    var _a;
    const watched = /* @__PURE__ */ new Set();
    if (!item) return watched;
    const seasons = Array.isArray(item.seasons) ? item.seasons : [];
    const hasSeasonEpisodes = seasons.some((season) => Array.isArray(season.episodes));
    if (hasSeasonEpisodes) {
      for (const season of seasons) {
        if (typeof season.number !== "number" || season.number <= 0) continue;
        for (const ep of (_a = season.episodes) != null ? _a : []) {
          if (typeof ep.number === "number" && ep.number > 0) {
            watched.add(`${season.number}:${ep.number}`);
          }
        }
      }
      return watched;
    }
    const directEpisodes = Array.isArray(item.episodes) ? item.episodes : [];
    if (directEpisodes.length > 0) {
      for (const ep of directEpisodes) {
        if (typeof ep.number === "number" && ep.number > 0) {
          const season = typeof ep.season === "number" && ep.season > 0 ? ep.season : 1;
          watched.add(`${season}:${ep.number}`);
        }
      }
      return watched;
    }
    const count = typeof item.watched_episodes_count === "number" && item.watched_episodes_count > 0 ? item.watched_episodes_count : 0;
    for (const ep of regularEpisodes.slice(0, count)) {
      watched.add(coordKey(ep));
    }
    return watched;
  }
  function buildEpisodeHistoryDiff(regularEpisodes, watchedKeys, targetProgress) {
    const count = Math.max(0, Math.floor(targetProgress));
    const target = regularEpisodes.slice(0, count);
    const targetKeys = new Set(target.map(coordKey));
    const add = target.filter((ep) => !watchedKeys.has(coordKey(ep)));
    const remove = regularEpisodes.slice(count).filter((ep) => watchedKeys.has(coordKey(ep)) && !targetKeys.has(coordKey(ep)));
    return { add, remove };
  }
  function buildHistoryBody(kind, ids, episodes) {
    var _a;
    if (kind === "anime" && episodes.every((ep) => ep.season === void 0)) {
      return {
        anime: [
          {
            ids,
            episodes: episodes.map((ep) => ({ number: ep.number }))
          }
        ]
      };
    }
    const bySeason = /* @__PURE__ */ new Map();
    for (const ep of episodes) {
      const season = (_a = ep.season) != null ? _a : 1;
      const list = bySeason.get(season);
      if (list) list.push({ number: ep.number });
      else bySeason.set(season, [{ number: ep.number }]);
    }
    const seasons = [...bySeason.entries()].sort(([a], [b]) => a - b).map(([number, list]) => ({ number, episodes: list }));
    return {
      [listKey(kind)]: [{ ids, seasons }]
    };
  }

  // src/backend.ts
  var backreefClientId = "";
  var simklBase = "https://api.simkl.com";
  var anilistEndpoint = "https://graphql.anilist.co";
  var callBudget = 2e4;
  var malCacheHitTtlSeconds = 30 * 24 * 60 * 60;
  var malCacheMissTtlSeconds = 7 * 24 * 60 * 60;
  var blockedUntil = 0;
  var deadline = 0;
  function startCall() {
    deadline = Date.now() + callBudget;
  }
  function waitForLimit() {
    return __async(this, null, function* () {
      const wait = blockedUntil - Date.now();
      if (wait <= 0) return;
      if (Date.now() + wait > deadline) throw limited(wait);
      yield caye.sleep(wait);
    });
  }
  function parseJSON(body) {
    if (!body) return {};
    try {
      return JSON.parse(body);
    } catch (e) {
      throw unavailable("Simkl returned invalid JSON.");
    }
  }
  function resolveAuth(context) {
    return __async(this, null, function* () {
      const rawSecret = context.config.account ? yield caye.secret(context.config.account) : "";
      const parsed = parseAccountSecret(rawSecret);
      const clientId = resolveClientId(
        context.config.clientId,
        (parsed == null ? void 0 : parsed.clientId) || backreefClientId
      );
      if (!clientId) {
        throw needsAuth("Add a Simkl client ID to this connection.");
      }
      if (!(parsed == null ? void 0 : parsed.access)) {
        throw needsAuth("Sign in to your Simkl account.");
      }
      return { access: parsed.access, clientId };
    });
  }
  function simklRequest(url, options) {
    return __async(this, null, function* () {
      var _a, _b, _c;
      const headers = {
        "Content-Type": "application/json",
        "simkl-api-key": options.clientId
      };
      if (options.access) {
        headers.Authorization = `Bearer ${options.access}`;
      }
      const payload = options.body === void 0 ? void 0 : JSON.stringify(options.body);
      for (let attempt = 0; ; attempt++) {
        yield waitForLimit();
        const response = yield caye.http({
          url,
          method: options.method,
          headers,
          body: payload
        });
        if (response.status === 401) {
          throw needsAuth("Simkl rejected the access token.");
        }
        if (response.status === 429) {
          blockedUntil = Math.max(blockedUntil, resetAt(response.headers));
          if (attempt >= 3) throw limited(blockedUntil - Date.now());
          continue;
        }
        if (response.headers["x-ratelimit-remaining"] === "0") {
          blockedUntil = Math.max(blockedUntil, resetAt(response.headers));
        }
        if ((_a = options.allowErrorStatuses) == null ? void 0 : _a.includes(response.status)) {
          return { status: response.status, data: parseJSON((_b = response.body) != null ? _b : "") };
        }
        if (response.status < 200 || response.status >= 300) {
          throw unavailable();
        }
        return { status: response.status, data: parseJSON((_c = response.body) != null ? _c : "") };
      }
    });
  }
  function malCacheKey(malId) {
    return `simkl:mal-anilist:${malId}`;
  }
  function queryAnilistByMal(malIds) {
    return __async(this, null, function* () {
      var _a, _b, _c, _d;
      const resolved = /* @__PURE__ */ new Map();
      for (let i = 0; i < malIds.length; i += 50) {
        const batch = malIds.slice(i, i + 50);
        for (let attempt = 0; ; attempt++) {
          yield waitForLimit();
          const response = yield caye.http({
            url: anilistEndpoint,
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              Accept: "application/json"
            },
            body: JSON.stringify({
              query: "query ($ids: [Int]) { Page(perPage: 50) { media(idMal_in: $ids, type: ANIME) { id idMal } } }",
              variables: { ids: batch }
            })
          });
          if (response.status === 429) {
            blockedUntil = Math.max(blockedUntil, resetAt(response.headers));
            if (attempt >= 3) throw limited(blockedUntil - Date.now());
            continue;
          }
          if (response.status !== 200) {
            throw unavailable("AniList did not answer.");
          }
          const parsed = parseJSON((_a = response.body) != null ? _a : "");
          if (parsed.errors) {
            throw unavailable("AniList did not answer.");
          }
          for (const item of (_d = (_c = (_b = parsed.data) == null ? void 0 : _b.Page) == null ? void 0 : _c.media) != null ? _d : []) {
            const id = positiveIntString(item.id);
            const mal = positiveIntString(item.idMal);
            if (id && mal) resolved.set(mal, id);
          }
          break;
        }
      }
      return resolved;
    });
  }
  function resolveMalToAnilist(malIds) {
    return __async(this, null, function* () {
      const out = /* @__PURE__ */ new Map();
      const missing = [];
      for (const mal of malIds) {
        const cached = yield caye.cache.get({ key: malCacheKey(mal) });
        if (!cached) {
          missing.push(Number(mal));
          continue;
        }
        if (cached.kind === "text" && positiveIntString(cached.text)) {
          out.set(mal, cached.text);
        }
      }
      if (missing.length === 0) return out;
      const fetched = yield queryAnilistByMal(missing);
      for (const malNum of missing) {
        const mal = String(malNum);
        const anilistId = fetched.get(mal);
        if (anilistId) {
          out.set(mal, anilistId);
          yield caye.cache.set({
            key: malCacheKey(mal),
            value: { kind: "text", text: anilistId },
            ttlSeconds: malCacheHitTtlSeconds
          });
        } else {
          yield caye.cache.set({
            key: malCacheKey(mal),
            value: { kind: "empty" },
            ttlSeconds: malCacheMissTtlSeconds
          });
        }
      }
      return out;
    });
  }
  function fetchAllItems(auth, includeAllEpisodes = false) {
    return __async(this, null, function* () {
      const query = includeAllEpisodes ? "extended=full&include_all_episodes=yes" : "extended=full";
      const { data } = yield simklRequest(
        `${simklBase}/sync/all-items/?${query}`,
        {
          method: "GET",
          clientId: auth.clientId,
          access: auth.access
        }
      );
      return data;
    });
  }
  function buildIndex(all) {
    return __async(this, null, function* () {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      const animeByAnilist = /* @__PURE__ */ new Map();
      const malOnly = [];
      const malNeeded = /* @__PURE__ */ new Set();
      const showsByTvdb = /* @__PURE__ */ new Map();
      const moviesByTmdb = /* @__PURE__ */ new Map();
      for (const item of (_a = all.anime) != null ? _a : []) {
        const media = itemMedia(item, "anime");
        const anilistId = positiveIntString((_b = media == null ? void 0 : media.ids) == null ? void 0 : _b.anilist);
        if (anilistId) {
          animeByAnilist.set(anilistId, item);
          continue;
        }
        const malId = positiveIntString((_c = media == null ? void 0 : media.ids) == null ? void 0 : _c.mal);
        if (malId) {
          malOnly.push({ malId, item });
          malNeeded.add(malId);
        }
      }
      if (malNeeded.size > 0) {
        const mapped = yield resolveMalToAnilist([...malNeeded]);
        for (const { malId, item } of malOnly) {
          const anilistId = mapped.get(malId);
          if (anilistId && !animeByAnilist.has(anilistId)) {
            animeByAnilist.set(anilistId, item);
          }
        }
      }
      for (const item of (_d = all.shows) != null ? _d : []) {
        const tvdbId = positiveIntString((_f = (_e = itemMedia(item, "show")) == null ? void 0 : _e.ids) == null ? void 0 : _f.tvdb);
        if (tvdbId) showsByTvdb.set(tvdbId, item);
      }
      for (const item of (_g = all.movies) != null ? _g : []) {
        const tmdbId = positiveIntString((_i = (_h = itemMedia(item, "movie")) == null ? void 0 : _h.ids) == null ? void 0 : _i.tmdb);
        if (tmdbId) moviesByTmdb.set(tmdbId, item);
      }
      return { animeByAnilist, showsByTvdb, moviesByTmdb };
    });
  }
  function findItemForRef(indexed, ref, kind) {
    var _a, _b, _c;
    if (kind === "show") {
      return (_a = indexed.showsByTvdb.get(ref.nativeId)) != null ? _a : null;
    }
    if (kind === "movie") {
      return (_b = indexed.moviesByTmdb.get(ref.nativeId)) != null ? _b : null;
    }
    return (_c = indexed.animeByAnilist.get(ref.nativeId)) != null ? _c : null;
  }
  function lookupSimklId(auth, kind, nativeId) {
    return __async(this, null, function* () {
      var _a, _b, _c, _d;
      const param = kind === "show" ? "tvdb" : "anilist";
      const { data } = yield simklRequest(
        `${simklBase}/search/id?${param}=${encodeURIComponent(nativeId)}&client_id=${encodeURIComponent(auth.clientId)}`,
        {
          method: "GET",
          clientId: auth.clientId,
          access: auth.access
        }
      );
      const list = Array.isArray(data) ? data : [];
      const preferred = (_a = list.find((item) => item.type === kind)) != null ? _a : list.find((item) => {
        var _a2, _b2, _c2;
        return positiveIntString((_c2 = (_a2 = item.ids) == null ? void 0 : _a2.simkl) != null ? _c2 : (_b2 = item.ids) == null ? void 0 : _b2.simkl_id) !== null;
      });
      return positiveIntString((_d = (_b = preferred == null ? void 0 : preferred.ids) == null ? void 0 : _b.simkl) != null ? _d : (_c = preferred == null ? void 0 : preferred.ids) == null ? void 0 : _c.simkl_id);
    });
  }
  function fetchEpisodes(auth, kind, simklId) {
    return __async(this, null, function* () {
      const path = kind === "show" ? "tv" : "anime";
      const { data } = yield simklRequest(
        `${simklBase}/${path}/episodes/${encodeURIComponent(simklId)}?client_id=${encodeURIComponent(auth.clientId)}`,
        {
          method: "GET",
          clientId: auth.clientId,
          access: auth.access
        }
      );
      return orderRegularEpisodes(kind, Array.isArray(data) ? data : []);
    });
  }
  function pushOne(auth, pushed, getInitialIndex) {
    return __async(this, null, function* () {
      var _a;
      const kind = refToKind(pushed.ref);
      if (!kind) {
        return {
          outcome: {
            ref: pushed.ref,
            outcome: "unsupported",
            reason: "The entry is not a Simkl anime, show or movie."
          },
          wrote: false
        };
      }
      const indexed = yield getInitialIndex();
      const before = findItemForRef(indexed, pushed.ref, kind);
      const beforeEntry = before ? entry(before, kind, pushed.ref.nativeId) : null;
      const fields = effectivePushFields(kind, pushed.fields);
      if (before && beforeEntry && matches(beforeEntry, fields)) {
        return {
          outcome: {
            ref: pushed.ref,
            outcome: "applied",
            revision: beforeEntry.revision
          },
          wrote: false
        };
      }
      if (before && beforeEntry && pushed.baseRevision !== "" && beforeEntry.revision !== pushed.baseRevision) {
        return {
          outcome: { ref: pushed.ref, outcome: "conflict", remote: beforeEntry },
          wrote: false
        };
      }
      const ids = simklIdsForEntry(pushed.ref, kind, before);
      if ("status" in fields && fields.status === null) {
        if (before) {
          yield simklRequest(`${simklBase}/sync/history/remove`, {
            method: "POST",
            clientId: auth.clientId,
            access: auth.access,
            body: buildRemoveBody(kind, ids)
          });
        }
        return {
          outcome: { ref: pushed.ref, outcome: "applied", revision: "" },
          wrote: false
        };
      }
      if (Object.keys(fields).length === 0) {
        return {
          outcome: {
            ref: pushed.ref,
            outcome: "applied",
            revision: (_a = beforeEntry == null ? void 0 : beforeEntry.revision) != null ? _a : ""
          },
          wrote: false
        };
      }
      if (!before && (kind === "show" || kind === "anime")) {
        const simklId = yield lookupSimklId(auth, kind, pushed.ref.nativeId);
        if (!simklId) {
          return {
            outcome: {
              ref: pushed.ref,
              outcome: "unsupported",
              reason: "Could not find this entry on Simkl."
            },
            wrote: false
          };
        }
        ids.simkl = Number(simklId);
      }
      let episodePlan = null;
      if (kind !== "movie" && "progress" in fields) {
        const targetProgress = typeof fields.progress === "number" ? fields.progress : 0;
        let simklId = positiveIntString(ids.simkl);
        if (!simklId) {
          simklId = yield lookupSimklId(auth, kind, pushed.ref.nativeId);
        }
        if (!simklId) {
          return {
            outcome: {
              ref: pushed.ref,
              outcome: "unsupported",
              reason: "Could not find this entry on Simkl."
            },
            wrote: false
          };
        }
        ids.simkl = Number(simklId);
        const regular = yield fetchEpisodes(auth, kind, simklId);
        const watched = currentWatchedKeys(before, regular);
        const diff = buildEpisodeHistoryDiff(regular, watched, targetProgress);
        episodePlan = {
          regularCount: regular.length,
          add: diff.add,
          remove: diff.remove
        };
      }
      if (typeof fields.status === "string") {
        const mapped = toSimklStatus[fields.status];
        if (mapped) {
          yield simklRequest(`${simklBase}/sync/add-to-list`, {
            method: "POST",
            clientId: auth.clientId,
            access: auth.access,
            body: buildStatusBody(kind, ids, mapped)
          });
        }
      } else if (!before) {
        const initialStatus = kind === "movie" ? "plantowatch" : newStatus(fields.progress, episodePlan == null ? void 0 : episodePlan.regularCount);
        yield simklRequest(`${simklBase}/sync/add-to-list`, {
          method: "POST",
          clientId: auth.clientId,
          access: auth.access,
          body: buildStatusBody(kind, ids, initialStatus)
        });
      }
      if ("rating" in fields) {
        if (fields.rating === null || fields.rating === void 0 || fields.rating === 0) {
          yield simklRequest(`${simklBase}/sync/ratings/remove`, {
            method: "POST",
            clientId: auth.clientId,
            access: auth.access,
            body: buildRemoveRatingBody(kind, ids)
          });
        } else {
          yield simklRequest(`${simklBase}/sync/ratings`, {
            method: "POST",
            clientId: auth.clientId,
            access: auth.access,
            body: buildRatingBody(kind, ids, Number(fields.rating))
          });
        }
      }
      if (episodePlan && kind !== "movie") {
        if (episodePlan.add.length > 0) {
          yield simklRequest(`${simklBase}/sync/history`, {
            method: "POST",
            clientId: auth.clientId,
            access: auth.access,
            body: buildHistoryBody(kind, ids, episodePlan.add)
          });
        }
        if (episodePlan.remove.length > 0) {
          yield simklRequest(`${simklBase}/sync/history/remove`, {
            method: "POST",
            clientId: auth.clientId,
            access: auth.access,
            body: buildHistoryBody(kind, ids, episodePlan.remove)
          });
        }
      }
      return {
        outcome: {
          ref: pushed.ref,
          outcome: "applied",
          revision: ""
        },
        wrote: true
      };
    });
  }
  caye.register("backreef.simkl:tracker", {
    connect: {
      start(context, _input) {
        return __async(this, null, function* () {
          startCall();
          const clientId = resolveClientId(context.config.clientId, backreefClientId);
          if (!clientId) {
            throw needsAuth("Add a Simkl client ID to this connection.");
          }
          const { data } = yield simklRequest(
            `${simklBase}/oauth/pin?client_id=${encodeURIComponent(clientId)}`,
            { method: "GET", clientId }
          );
          return buildPinStartResult(data, clientId);
        });
      },
      complete(_context, input) {
        return __async(this, null, function* () {
          startCall();
          const parsed = parsePinData(input.data);
          if (!parsed) {
            throw new Error("Sign-in data is missing or invalid.");
          }
          const { status, data } = yield simklRequest(
            `${simklBase}/oauth/pin/${encodeURIComponent(parsed.userCode)}?client_id=${encodeURIComponent(parsed.clientId)}`,
            {
              method: "GET",
              clientId: parsed.clientId,
              allowErrorStatuses: [400, 404, 410]
            }
          );
          return parsePinCompleteResult(status, data, parsed.clientId);
        });
      }
    },
    tracker: {
      pull(context) {
        return __async(this, null, function* () {
          var _a, _b, _c, _d, _e, _f, _g, _h;
          startCall();
          const auth = yield resolveAuth(context);
          const all = yield fetchAllItems(auth, false);
          const malNeeded = /* @__PURE__ */ new Set();
          for (const item of (_a = all.anime) != null ? _a : []) {
            const media = itemMedia(item, "anime");
            if (positiveIntString((_b = media == null ? void 0 : media.ids) == null ? void 0 : _b.anilist)) continue;
            const mal = positiveIntString((_c = media == null ? void 0 : media.ids) == null ? void 0 : _c.mal);
            if (mal) malNeeded.add(mal);
          }
          const malToAnilist = malNeeded.size > 0 ? yield resolveMalToAnilist([...malNeeded]) : /* @__PURE__ */ new Map();
          const entries = [];
          const seen = /* @__PURE__ */ new Set();
          const addEntry = (item, kind, resolvedAnilistId) => {
            const built = entry(item, kind, resolvedAnilistId);
            if (!built) return;
            const key = `${built.ref.providerId}:${built.ref.type}:${built.ref.nativeId}`;
            if (seen.has(key)) return;
            seen.add(key);
            entries.push(built);
          };
          for (const item of (_d = all.anime) != null ? _d : []) {
            const mal = positiveIntString((_f = (_e = itemMedia(item, "anime")) == null ? void 0 : _e.ids) == null ? void 0 : _f.mal);
            addEntry(item, "anime", mal ? malToAnilist.get(mal) : void 0);
          }
          for (const item of (_g = all.shows) != null ? _g : []) {
            addEntry(item, "show");
          }
          for (const item of (_h = all.movies) != null ? _h : []) {
            addEntry(item, "movie");
          }
          return {
            entries,
            fields: pullFields,
            ratingStep: 1,
            ratingMax: 10
          };
        });
      },
      push(context, input) {
        return __async(this, null, function* () {
          startCall();
          const auth = yield resolveAuth(context);
          let initialIndexPromise = null;
          const getInitialIndex = () => {
            if (!initialIndexPromise) {
              initialIndexPromise = fetchAllItems(auth, true).then(buildIndex);
            }
            return initialIndexPromise;
          };
          const results = [];
          for (const item of input.entries) {
            const res = yield pushOne(auth, item, getInitialIndex);
            results.push({ entry: item, outcome: res.outcome, wrote: res.wrote });
          }
          if (results.some((res) => res.wrote)) {
            const refreshed = yield buildIndex(yield fetchAllItems(auth, false));
            for (const res of results) {
              if (!res.wrote) continue;
              const kind = refToKind(res.entry.ref);
              const after = kind ? findItemForRef(refreshed, res.entry.ref, kind) : null;
              res.outcome.revision = after ? buildRevision(after) : "";
            }
          }
          return { entries: results.map((res) => res.outcome) };
        });
      }
    }
  });
})();
//# sourceMappingURL=backend.js.map
