import type {
    API,
    ConnectCompleteInput,
    ConnectCompleteResult,
    ConnectStartInput,
    ConnectStartResult,
    Context,
    Ref,
    TrackerEntry,
    TrackerPullResult,
    TrackerPushEntry,
    TrackerPushInput,
    TrackerPushOutcome,
    TrackerPushResult,
    TrackerStatus,
} from "../../../../packages/plugin-sdk/src/index"
import {
    buildEpisodeHistoryDiff,
    buildHistoryBody,
    buildPinStartResult,
    buildRatingBody,
    buildRemoveBody,
    buildRemoveRatingBody,
    buildRevision,
    buildStatusBody,
    currentWatchedKeys,
    effectivePushFields,
    entry,
    itemMedia,
    limited,
    matches,
    needsAuth,
    newStatus,
    orderRegularEpisodes,
    parseAccountSecret,
    parsePinCompleteResult,
    parsePinData,
    positiveIntString,
    pullFields,
    refToKind,
    resetAt,
    resolveClientId,
    simklIdsForEntry,
    toSimklStatus,
    unavailable,
    type SimklAllItemsResponse,
    type SimklEpisodeRaw,
    type SimklKind,
    type SimklListItem,
    type SimklPinCompleteResponse,
    type SimklPinStartResponse,
} from "./simkl"

declare const caye: API

const backreefClientId = ""

const simklBase = "https://api.simkl.com"
const anilistEndpoint = "https://graphql.anilist.co"
const callBudget = 20_000
const malCacheHitTtlSeconds = 30 * 24 * 60 * 60
const malCacheMissTtlSeconds = 7 * 24 * 60 * 60

let blockedUntil = 0
let deadline = 0

function startCall() {
    deadline = Date.now() + callBudget
}

async function waitForLimit() {
    const wait = blockedUntil - Date.now()
    if (wait <= 0) return
    if (Date.now() + wait > deadline) throw limited(wait)
    await caye.sleep(wait)
}

function parseJSON<T>(body: string): T {
    if (!body) return {} as T
    try {
        return JSON.parse(body) as T
    } catch {
        throw unavailable("Simkl returned invalid JSON.")
    }
}

async function resolveAuth(context: Context): Promise<{ access: string; clientId: string }> {
    const rawSecret = context.config.account ? await caye.secret(context.config.account) : ""
    const parsed = parseAccountSecret(rawSecret)
    const clientId = resolveClientId(
        context.config.clientId,
        parsed?.clientId || backreefClientId,
    )
    if (!clientId) {
        throw needsAuth("Add a Simkl client ID to this connection.")
    }
    if (!parsed?.access) {
        throw needsAuth("Sign in to your Simkl account.")
    }
    return { access: parsed.access, clientId }
}

async function simklRequest<T>(
    url: string,
    options: {
        method: "GET" | "POST"
        clientId: string
        access?: string
        body?: unknown
        allowErrorStatuses?: number[]
    },
): Promise<{ status: number; data: T }> {
    const headers: Record<string, string> = {
        "Content-Type": "application/json",
        "simkl-api-key": options.clientId,
    }
    if (options.access) {
        headers.Authorization = `Bearer ${options.access}`
    }
    const payload = options.body === undefined ? undefined : JSON.stringify(options.body)

    for (let attempt = 0; ; attempt++) {
        await waitForLimit()
        const response = await caye.http({
            url,
            method: options.method,
            headers,
            body: payload,
        })
        if (response.status === 401) {
            throw needsAuth("Simkl rejected the access token.")
        }
        if (response.status === 429) {
            blockedUntil = Math.max(blockedUntil, resetAt(response.headers))
            if (attempt >= 3) throw limited(blockedUntil - Date.now())
            continue
        }
        if (response.headers["x-ratelimit-remaining"] === "0") {
            blockedUntil = Math.max(blockedUntil, resetAt(response.headers))
        }
        if (options.allowErrorStatuses?.includes(response.status)) {
            return { status: response.status, data: parseJSON<T>(response.body ?? "") }
        }
        if (response.status < 200 || response.status >= 300) {
            throw unavailable()
        }
        return { status: response.status, data: parseJSON<T>(response.body ?? "") }
    }
}

function malCacheKey(malId: string): string {
    return `simkl:mal-anilist:${malId}`
}

async function queryAnilistByMal(malIds: number[]): Promise<Map<string, string>> {
    const resolved = new Map<string, string>()
    for (let i = 0; i < malIds.length; i += 50) {
        const batch = malIds.slice(i, i + 50)
        for (let attempt = 0; ; attempt++) {
            await waitForLimit()
            const response = await caye.http({
                url: anilistEndpoint,
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json",
                },
                body: JSON.stringify({
                    query: "query ($ids: [Int]) { Page(perPage: 50) { media(idMal_in: $ids, type: ANIME) { id idMal } } }",
                    variables: { ids: batch },
                }),
            })
            if (response.status === 429) {
                blockedUntil = Math.max(blockedUntil, resetAt(response.headers))
                if (attempt >= 3) throw limited(blockedUntil - Date.now())
                continue
            }
            if (response.status !== 200) {
                throw unavailable("AniList did not answer.")
            }
            const parsed = parseJSON<{
                data?: { Page?: { media?: { id?: number; idMal?: number }[] } }
                errors?: unknown[]
            }>(response.body ?? "")
            if (parsed.errors) {
                throw unavailable("AniList did not answer.")
            }
            for (const item of parsed.data?.Page?.media ?? []) {
                const id = positiveIntString(item.id)
                const mal = positiveIntString(item.idMal)
                if (id && mal) resolved.set(mal, id)
            }
            break
        }
    }
    return resolved
}

async function resolveMalToAnilist(malIds: string[]): Promise<Map<string, string>> {
    const out = new Map<string, string>()
    const missing: number[] = []
    for (const mal of malIds) {
        const cached = await caye.cache.get({ key: malCacheKey(mal) })
        if (!cached) {
            missing.push(Number(mal))
            continue
        }
        if (cached.kind === "text" && positiveIntString(cached.text)) {
            out.set(mal, cached.text)
        }
    }
    if (missing.length === 0) return out
    const fetched = await queryAnilistByMal(missing)
    for (const malNum of missing) {
        const mal = String(malNum)
        const anilistId = fetched.get(mal)
        if (anilistId) {
            out.set(mal, anilistId)
            await caye.cache.set({
                key: malCacheKey(mal),
                value: { kind: "text", text: anilistId },
                ttlSeconds: malCacheHitTtlSeconds,
            })
        } else {
            await caye.cache.set({
                key: malCacheKey(mal),
                value: { kind: "empty" },
                ttlSeconds: malCacheMissTtlSeconds,
            })
        }
    }
    return out
}

async function fetchAllItems(
    auth: { access: string; clientId: string },
    includeAllEpisodes = false,
): Promise<SimklAllItemsResponse> {
    const query = includeAllEpisodes
        ? "extended=full&include_all_episodes=yes"
        : "extended=full"
    const { data } = await simklRequest<SimklAllItemsResponse>(
        `${simklBase}/sync/all-items/?${query}`,
        {
            method: "GET",
            clientId: auth.clientId,
            access: auth.access,
        },
    )
    return data
}

type IndexedItems = {
    animeByAnilist: Map<string, SimklListItem>
    showsByTvdb: Map<string, SimklListItem>
    moviesByTmdb: Map<string, SimklListItem>
}

async function buildIndex(all: SimklAllItemsResponse): Promise<IndexedItems> {
    const animeByAnilist = new Map<string, SimklListItem>()
    const malOnly: { malId: string; item: SimklListItem }[] = []
    const malNeeded = new Set<string>()
    const showsByTvdb = new Map<string, SimklListItem>()
    const moviesByTmdb = new Map<string, SimklListItem>()

    for (const item of all.anime ?? []) {
        const media = itemMedia(item, "anime")
        const anilistId = positiveIntString(media?.ids?.anilist)
        if (anilistId) {
            animeByAnilist.set(anilistId, item)
            continue
        }
        const malId = positiveIntString(media?.ids?.mal)
        if (malId) {
            malOnly.push({ malId, item })
            malNeeded.add(malId)
        }
    }
    if (malNeeded.size > 0) {
        const mapped = await resolveMalToAnilist([...malNeeded])
        for (const { malId, item } of malOnly) {
            const anilistId = mapped.get(malId)
            if (anilistId && !animeByAnilist.has(anilistId)) {
                animeByAnilist.set(anilistId, item)
            }
        }
    }
    for (const item of all.shows ?? []) {
        const tvdbId = positiveIntString(itemMedia(item, "show")?.ids?.tvdb)
        if (tvdbId) showsByTvdb.set(tvdbId, item)
    }
    for (const item of all.movies ?? []) {
        const tmdbId = positiveIntString(itemMedia(item, "movie")?.ids?.tmdb)
        if (tmdbId) moviesByTmdb.set(tmdbId, item)
    }
    return { animeByAnilist, showsByTvdb, moviesByTmdb }
}

function findItemForRef(
    indexed: IndexedItems,
    ref: Ref,
    kind: SimklKind,
): SimklListItem | null {
    if (kind === "show") {
        return indexed.showsByTvdb.get(ref.nativeId) ?? null
    }
    if (kind === "movie") {
        return indexed.moviesByTmdb.get(ref.nativeId) ?? null
    }
    return indexed.animeByAnilist.get(ref.nativeId) ?? null
}

type SearchIdResult = {
    type?: string
    ids?: { simkl?: number | string; simkl_id?: number | string }
}

async function lookupSimklId(
    auth: { access: string; clientId: string },
    kind: "show" | "anime",
    nativeId: string,
): Promise<string | null> {
    const param = kind === "show" ? "tvdb" : "anilist"
    const { data } = await simklRequest<SearchIdResult[]>(
        `${simklBase}/search/id?${param}=${encodeURIComponent(nativeId)}&client_id=${encodeURIComponent(auth.clientId)}`,
        {
            method: "GET",
            clientId: auth.clientId,
            access: auth.access,
        },
    )
    const list = Array.isArray(data) ? data : []
    const preferred =
        list.find((item) => item.type === kind) ??
        list.find((item) => positiveIntString(item.ids?.simkl ?? item.ids?.simkl_id) !== null)
    return positiveIntString(preferred?.ids?.simkl ?? preferred?.ids?.simkl_id)
}

async function fetchEpisodes(
    auth: { access: string; clientId: string },
    kind: "show" | "anime",
    simklId: string,
) {
    const path = kind === "show" ? "tv" : "anime"
    const { data } = await simklRequest<SimklEpisodeRaw[]>(
        `${simklBase}/${path}/episodes/${encodeURIComponent(simklId)}?client_id=${encodeURIComponent(auth.clientId)}`,
        {
            method: "GET",
            clientId: auth.clientId,
            access: auth.access,
        },
    )
    return orderRegularEpisodes(kind, Array.isArray(data) ? data : [])
}

async function pushOne(
    auth: { access: string; clientId: string },
    pushed: TrackerPushEntry,
    getInitialIndex: () => Promise<IndexedItems>,
): Promise<{ outcome: TrackerPushOutcome; wrote: boolean }> {
    const kind = refToKind(pushed.ref)
    if (!kind) {
        return {
            outcome: {
                ref: pushed.ref,
                outcome: "unsupported",
                reason: "The entry is not a Simkl anime, show or movie.",
            },
            wrote: false,
        }
    }

    const indexed = await getInitialIndex()
    const before = findItemForRef(indexed, pushed.ref, kind)
    const beforeEntry = before ? entry(before, kind, pushed.ref.nativeId) : null
    const fields = effectivePushFields(kind, pushed.fields)

    if (before && beforeEntry && matches(beforeEntry, fields)) {
        return {
            outcome: {
                ref: pushed.ref,
                outcome: "applied",
                revision: beforeEntry.revision,
            },
            wrote: false,
        }
    }
    if (
        before &&
        beforeEntry &&
        pushed.baseRevision !== "" &&
        beforeEntry.revision !== pushed.baseRevision
    ) {
        return {
            outcome: { ref: pushed.ref, outcome: "conflict", remote: beforeEntry },
            wrote: false,
        }
    }

    const ids = simklIdsForEntry(pushed.ref, kind, before)

    if ("status" in fields && fields.status === null) {
        if (before) {
            await simklRequest(`${simklBase}/sync/history/remove`, {
                method: "POST",
                clientId: auth.clientId,
                access: auth.access,
                body: buildRemoveBody(kind, ids),
            })
        }
        return {
            outcome: { ref: pushed.ref, outcome: "applied", revision: "" },
            wrote: false,
        }
    }

    if (Object.keys(fields).length === 0) {
        return {
            outcome: {
                ref: pushed.ref,
                outcome: "applied",
                revision: beforeEntry?.revision ?? "",
            },
            wrote: false,
        }
    }

    if (!before && (kind === "show" || kind === "anime")) {
        const simklId = await lookupSimklId(auth, kind, pushed.ref.nativeId)
        if (!simklId) {
            return {
                outcome: {
                    ref: pushed.ref,
                    outcome: "unsupported",
                    reason: "Could not find this entry on Simkl.",
                },
                wrote: false,
            }
        }
        ids.simkl = Number(simklId)
    }

    let episodePlan: {
        regularCount: number
        add: ReturnType<typeof orderRegularEpisodes>
        remove: ReturnType<typeof orderRegularEpisodes>
    } | null = null

    if (kind !== "movie" && "progress" in fields) {
        const targetProgress = typeof fields.progress === "number" ? fields.progress : 0
        let simklId = positiveIntString(ids.simkl)
        if (!simklId) {
            simklId = await lookupSimklId(auth, kind, pushed.ref.nativeId)
        }
        if (!simklId) {
            return {
                outcome: {
                    ref: pushed.ref,
                    outcome: "unsupported",
                    reason: "Could not find this entry on Simkl.",
                },
                wrote: false,
            }
        }
        ids.simkl = Number(simklId)
        const regular = await fetchEpisodes(auth, kind, simklId)
        const watched = currentWatchedKeys(before, regular)
        const diff = buildEpisodeHistoryDiff(regular, watched, targetProgress)
        episodePlan = {
            regularCount: regular.length,
            add: diff.add,
            remove: diff.remove,
        }
    }

    if (typeof fields.status === "string") {
        const mapped = toSimklStatus[fields.status as TrackerStatus]
        if (mapped) {
            await simklRequest(`${simklBase}/sync/add-to-list`, {
                method: "POST",
                clientId: auth.clientId,
                access: auth.access,
                body: buildStatusBody(kind, ids, mapped),
            })
        }
    } else if (!before) {
        const initialStatus =
            kind === "movie" ? "plantowatch" : newStatus(fields.progress, episodePlan?.regularCount)
        await simklRequest(`${simklBase}/sync/add-to-list`, {
            method: "POST",
            clientId: auth.clientId,
            access: auth.access,
            body: buildStatusBody(kind, ids, initialStatus),
        })
    }

    if ("rating" in fields) {
        if (fields.rating === null || fields.rating === undefined || fields.rating === 0) {
            await simklRequest(`${simklBase}/sync/ratings/remove`, {
                method: "POST",
                clientId: auth.clientId,
                access: auth.access,
                body: buildRemoveRatingBody(kind, ids),
            })
        } else {
            await simklRequest(`${simklBase}/sync/ratings`, {
                method: "POST",
                clientId: auth.clientId,
                access: auth.access,
                body: buildRatingBody(kind, ids, Number(fields.rating)),
            })
        }
    }

    if (episodePlan && kind !== "movie") {
        if (episodePlan.add.length > 0) {
            await simklRequest(`${simklBase}/sync/history`, {
                method: "POST",
                clientId: auth.clientId,
                access: auth.access,
                body: buildHistoryBody(kind, ids, episodePlan.add),
            })
        }
        if (episodePlan.remove.length > 0) {
            await simklRequest(`${simklBase}/sync/history/remove`, {
                method: "POST",
                clientId: auth.clientId,
                access: auth.access,
                body: buildHistoryBody(kind, ids, episodePlan.remove),
            })
        }
    }

    return {
        outcome: {
            ref: pushed.ref,
            outcome: "applied",
            revision: "",
        },
        wrote: true,
    }
}

caye.register("backreef.simkl:tracker", {
    connect: {
        async start(context: Context, _input: ConnectStartInput): Promise<ConnectStartResult> {
            startCall()
            const clientId = resolveClientId(context.config.clientId, backreefClientId)
            if (!clientId) {
                throw needsAuth("Add a Simkl client ID to this connection.")
            }
            const { data } = await simklRequest<SimklPinStartResponse>(
                `${simklBase}/oauth/pin?client_id=${encodeURIComponent(clientId)}`,
                { method: "GET", clientId },
            )
            return buildPinStartResult(data, clientId)
        },
        async complete(
            _context: Context,
            input: ConnectCompleteInput,
        ): Promise<ConnectCompleteResult> {
            startCall()
            const parsed = parsePinData(input.data)
            if (!parsed) {
                throw new Error("Sign-in data is missing or invalid.")
            }
            const { status, data } = await simklRequest<SimklPinCompleteResponse>(
                `${simklBase}/oauth/pin/${encodeURIComponent(parsed.userCode)}?client_id=${encodeURIComponent(parsed.clientId)}`,
                {
                    method: "GET",
                    clientId: parsed.clientId,
                    allowErrorStatuses: [400, 404, 410],
                },
            )
            return parsePinCompleteResult(status, data, parsed.clientId)
        },
    },
    tracker: {
        async pull(context: Context): Promise<TrackerPullResult> {
            startCall()
            const auth = await resolveAuth(context)
            const all = await fetchAllItems(auth, false)

            const malNeeded = new Set<string>()
            for (const item of all.anime ?? []) {
                const media = itemMedia(item, "anime")
                if (positiveIntString(media?.ids?.anilist)) continue
                const mal = positiveIntString(media?.ids?.mal)
                if (mal) malNeeded.add(mal)
            }
            const malToAnilist =
                malNeeded.size > 0 ? await resolveMalToAnilist([...malNeeded]) : new Map<string, string>()

            const entries: TrackerEntry[] = []
            const seen = new Set<string>()
            const addEntry = (item: SimklListItem, kind: SimklKind, resolvedAnilistId?: string) => {
                const built = entry(item, kind, resolvedAnilistId)
                if (!built) return
                const key = `${built.ref.providerId}:${built.ref.type}:${built.ref.nativeId}`
                if (seen.has(key)) return
                seen.add(key)
                entries.push(built)
            }

            for (const item of all.anime ?? []) {
                const mal = positiveIntString(itemMedia(item, "anime")?.ids?.mal)
                addEntry(item, "anime", mal ? malToAnilist.get(mal) : undefined)
            }
            for (const item of all.shows ?? []) {
                addEntry(item, "show")
            }
            for (const item of all.movies ?? []) {
                addEntry(item, "movie")
            }

            return {
                entries,
                fields: pullFields,
                ratingStep: 1,
                ratingMax: 10,
            }
        },
        async push(context: Context, input: TrackerPushInput): Promise<TrackerPushResult> {
            startCall()
            const auth = await resolveAuth(context)
            let initialIndexPromise: Promise<IndexedItems> | null = null
            const getInitialIndex = () => {
                if (!initialIndexPromise) {
                    initialIndexPromise = fetchAllItems(auth, true).then(buildIndex)
                }
                return initialIndexPromise
            }
            const results: { entry: TrackerPushEntry; outcome: TrackerPushOutcome; wrote: boolean }[] = []
            for (const item of input.entries) {
                const res = await pushOne(auth, item, getInitialIndex)
                results.push({ entry: item, outcome: res.outcome, wrote: res.wrote })
            }
            if (results.some((res) => res.wrote)) {
                const refreshed = await buildIndex(await fetchAllItems(auth, false))
                for (const res of results) {
                    if (!res.wrote) continue
                    const kind = refToKind(res.entry.ref)
                    const after = kind ? findItemForRef(refreshed, res.entry.ref, kind) : null
                    res.outcome.revision = after ? buildRevision(after) : ""
                }
            }
            return { entries: results.map((res) => res.outcome) }
        },
    },
})
