import type {
    ConnectCompleteResult,
    ConnectStartResult,
    Ref,
    TrackerEntry,
    TrackerField,
    TrackerPushEntry,
    TrackerStatus,
} from "../../../../packages/plugin-sdk/src/index"

export type SimklKind = "anime" | "show" | "movie"

export type SimklIds = {
    simkl?: number | string
    simkl_id?: number | string
    tvdb?: number | string
    tmdb?: number | string
    mal?: number | string
    anilist?: number | string
    imdb?: string
    slug?: string
}

export type SimklMedia = {
    title?: string
    year?: number
    poster?: string
    ids?: SimklIds
}

export type SimklWatchedEpisode = {
    season?: number
    number?: number
    watched_at?: string
}

export type SimklWatchedSeason = {
    number?: number
    watched_episodes_count?: number
    episodes?: SimklWatchedEpisode[]
}

export type SimklListItem = {
    status?: string
    last_watched_at?: string
    user_rating?: number
    user_rated_at?: string
    added_to_watchlist_at?: string
    watched_episodes_count?: number
    total_episodes_count?: number
    show?: SimklMedia
    anime?: SimklMedia
    movie?: SimklMedia
    seasons?: SimklWatchedSeason[]
    episodes?: SimklWatchedEpisode[]
}

export type SimklAllItemsResponse = {
    movies?: SimklListItem[]
    shows?: SimklListItem[]
    anime?: SimklListItem[]
}

export type SimklPinStartResponse = {
    result?: string
    user_code?: string
    verification_url?: string
    verification_uri?: string
    expires_in?: number
    interval?: number
    error?: string
    message?: string
}

export type SimklPinCompleteResponse = {
    result?: string
    access_token?: string
    error?: string
    message?: string
}

export type SimklEpisodeRaw = {
    season?: number
    episode?: number
    type?: string
    title?: string
}

export type SimklEpisodeCoord = {
    season?: number
    number: number
}

export type SimklAccountSecret = {
    access: string
    clientId?: string
}

export const pullFields: TrackerField[] = ["status", "rating", "progress"]

export const namespaces: Record<SimklKind, { providerId: string; type: string }> = {
    anime: { providerId: "caye.movies-shows:anilist", type: "anime" },
    show: { providerId: "backreef.simkl:tracker", type: "show" },
    movie: { providerId: "backreef.simkl:tracker", type: "movie" },
}

export const toCayeStatus: Record<string, TrackerStatus> = {
    watching: "in-progress",
    plantowatch: "planning",
    hold: "paused",
    completed: "completed",
    dropped: "dropped",
}

export const toSimklStatus: Record<TrackerStatus, string> = {
    "in-progress": "watching",
    planning: "plantowatch",
    paused: "hold",
    completed: "completed",
    dropped: "dropped",
}

const defaultPinUrl = "https://simkl.com/pin/"

export function errorWithCode(
    message: string,
    code: string,
    extra?: Record<string, unknown>,
): Error {
    return Object.assign(new Error(message), { code, ...extra })
}

export function needsAuth(message: string): Error {
    return errorWithCode(message, "needs-auth")
}

export function unavailable(message = "Simkl did not answer."): Error {
    return errorWithCode(message, "unavailable")
}

export function limited(waitMs: number): Error {
    return errorWithCode("Simkl rate limit reached.", "rate-limited", {
        retry_after: Math.max(1, Math.ceil(waitMs / 1000)),
    })
}

export function resetAt(headers: Record<string, string>, now = Date.now()): number {
    const retryHeader = headers["retry-after"] ?? headers["Retry-After"] ?? ""
    const retry = parseInt(retryHeader, 10)
    if (!Number.isNaN(retry)) return now + (retry + 1) * 1000
    const resetHeader = headers["x-ratelimit-reset"] ?? headers["X-RateLimit-Reset"] ?? ""
    const reset = parseInt(resetHeader, 10)
    if (!Number.isNaN(reset) && reset > 0) return reset * 1000
    return now + 60_000
}

export function resolveClientId(
    configClientId: string | undefined,
    fallbackClientId: string,
): string {
    const trimmed = (configClientId ?? "").trim()
    return trimmed || fallbackClientId.trim()
}

export function parseAccountSecret(raw: string | undefined): SimklAccountSecret | null {
    if (!raw) return null
    try {
        const parsed = JSON.parse(raw) as Partial<SimklAccountSecret>
        if (typeof parsed?.access !== "string" || parsed.access.length === 0) return null
        return {
            access: parsed.access,
            clientId: typeof parsed.clientId === "string" ? parsed.clientId : undefined,
        }
    } catch {
        return null
    }
}

export function parsePinData(data: string): { userCode: string; clientId: string } | null {
    if (!data) return null
    try {
        const parsed = JSON.parse(data) as { userCode?: unknown; clientId?: unknown }
        if (
            typeof parsed?.userCode !== "string" ||
            parsed.userCode.length === 0 ||
            typeof parsed?.clientId !== "string" ||
            parsed.clientId.length === 0
        ) {
            return null
        }
        return { userCode: parsed.userCode, clientId: parsed.clientId }
    } catch {
        return null
    }
}

export function buildPinStartResult(
    body: SimklPinStartResponse,
    clientId: string,
): ConnectStartResult {
    const userCode = typeof body.user_code === "string" ? body.user_code.trim() : ""
    if (!userCode) {
        throw unavailable("Simkl did not return a sign-in code.")
    }
    const candidate = body.verification_url ?? body.verification_uri ?? ""
    const url = candidate.startsWith("https://") ? candidate : defaultPinUrl
    const result: ConnectStartResult = {
        url,
        code: userCode,
        data: JSON.stringify({ userCode, clientId }),
    }
    if (typeof body.interval === "number" && Number.isFinite(body.interval) && body.interval > 0) {
        result.interval = body.interval
    }
    if (
        typeof body.expires_in === "number" &&
        Number.isFinite(body.expires_in) &&
        body.expires_in > 0
    ) {
        result.expiresIn = body.expires_in
    }
    return result
}

export function parsePinCompleteResult(
    status: number,
    body: SimklPinCompleteResponse,
    clientId: string,
): ConnectCompleteResult {
    if (body.result === "OK" && typeof body.access_token === "string" && body.access_token.length > 0) {
        return {
            value: JSON.stringify({ access: body.access_token, clientId }),
        }
    }
    const message = typeof body.message === "string" ? body.message : ""
    if (
        status === 400 ||
        status === 404 ||
        status === 410 ||
        typeof body.error === "string" ||
        /expired|invalid|not found|denied/i.test(message)
    ) {
        throw new Error("The Simkl PIN code expired. Start sign-in again.")
    }
    return { pending: true }
}

export function positiveIntString(value: unknown): string | null {
    if (typeof value === "number") {
        return Number.isInteger(value) && value > 0 ? String(value) : null
    }
    if (typeof value === "string") {
        const trimmed = value.trim()
        return /^[1-9]\d*$/.test(trimmed) ? trimmed : null
    }
    return null
}

export function itemMedia(item: SimklListItem, kind: SimklKind): SimklMedia | undefined {
    if (kind === "movie") return item.movie
    if (kind === "anime") return item.anime ?? item.show
    return item.show
}

export function buildRevision(item: SimklListItem): string {
    return [item.last_watched_at, item.user_rated_at, item.added_to_watchlist_at]
        .filter((value): value is string => typeof value === "string" && value.trim().length > 0)
        .join("|")
}

export function posterUrl(poster: string | undefined): string | undefined {
    if (!poster) return undefined
    const trimmed = poster.trim()
    if (!trimmed) return undefined
    if (trimmed.startsWith("https://")) return trimmed
    const clean = trimmed.replace(/^\/+/, "")
    if (!clean) return undefined
    return `https://wsrv.nl/?url=https://simkl.in/posters/${clean}_m.jpg`
}

export function simklPageUrl(
    kind: SimklKind,
    simklId: number | string | undefined,
): string | undefined {
    const id = positiveIntString(simklId)
    if (!id) return undefined
    const segment = kind === "movie" ? "movies" : kind === "show" ? "tv" : "anime"
    return `https://simkl.com/${segment}/${id}`
}

export function entry(
    item: SimklListItem,
    kind: SimklKind,
    resolvedAnilistId?: string,
): TrackerEntry | null {
    const media = itemMedia(item, kind)
    let nativeId: string | null = null
    if (kind === "anime") {
        nativeId =
            positiveIntString(media?.ids?.anilist) ?? positiveIntString(resolvedAnilistId)
    } else if (kind === "show") {
        nativeId = positiveIntString(media?.ids?.tvdb)
    } else {
        nativeId = positiveIntString(media?.ids?.tmdb)
    }
    if (!nativeId) return null

    const out: TrackerEntry = {
        ref: { ...namespaces[kind], nativeId },
        revision: buildRevision(item),
    }
    const status = toCayeStatus[item.status ?? ""]
    if (status) out.status = status
    if (
        typeof item.user_rating === "number" &&
        Number.isFinite(item.user_rating) &&
        item.user_rating >= 1 &&
        item.user_rating <= 10
    ) {
        out.rating = item.user_rating
    }
    if (kind !== "movie") {
        out.progress =
            typeof item.watched_episodes_count === "number" && item.watched_episodes_count >= 0
                ? item.watched_episodes_count
                : 0
        if (typeof item.total_episodes_count === "number" && item.total_episodes_count > 0) {
            out.total = item.total_episodes_count
        }
    }
    const title = media?.title?.trim().slice(0, 300)
    if (title) out.title = title
    if (
        typeof media?.year === "number" &&
        Number.isInteger(media.year) &&
        media.year > 0 &&
        media.year <= 9999
    ) {
        out.year = media.year
    }
    const image = posterUrl(media?.poster)
    if (image) out.imageUrl = image
    const page = simklPageUrl(kind, media?.ids?.simkl ?? media?.ids?.simkl_id)
    if (page) out.url = page

    const details: string[] = [kind === "anime" ? "Anime" : kind === "show" ? "Show" : "Movie"]
    if (kind !== "movie" && out.total && out.total > 0) {
        details.push(`${out.total} episode${out.total === 1 ? "" : "s"}`)
    }
    out.details = details
    return out
}

export function refToKind(ref: Ref): SimklKind | null {
    const kind = (Object.keys(namespaces) as SimklKind[]).find((candidate) => {
        const ns = namespaces[candidate]
        return ref.providerId === ns.providerId && ref.type === ns.type
    })
    if (!kind) return null
    const id = Number(ref.nativeId)
    if (!/^[1-9]\d*$/.test(ref.nativeId) || !Number.isSafeInteger(id)) {
        return null
    }
    return kind
}

export function effectivePushFields(
    kind: SimklKind,
    fields: TrackerPushEntry["fields"],
): TrackerPushEntry["fields"] {
    if (kind !== "movie" || !("progress" in fields)) return fields
    const out: TrackerPushEntry["fields"] = {}
    for (const [key, value] of Object.entries(fields)) {
        if (key !== "progress") {
            (out as Record<string, unknown>)[key] = value
        }
    }
    return out
}

export function matches(value: TrackerEntry, pushed: TrackerPushEntry["fields"]): boolean {
    return Object.entries(pushed).every(([field, want]) => {
        const have = (value as Record<string, unknown>)[field]
        return (want ?? undefined) === (have ?? undefined)
    })
}

export function newStatus(progress: unknown, total?: number): string {
    const count = typeof progress === "number" ? progress : 0
    if (count <= 0) return "plantowatch"
    if (total && total > 0 && count >= total) return "completed"
    return "watching"
}

export function listKey(kind: SimklKind): "anime" | "shows" | "movies" {
    if (kind === "show") return "shows"
    if (kind === "movie") return "movies"
    return "anime"
}

export function simklIdsForEntry(
    ref: Ref,
    kind: SimklKind,
    item?: SimklListItem | null,
): Record<string, number> {
    const ids: Record<string, number> = {}
    const media = item ? itemMedia(item, kind) : undefined
    const simklId = positiveIntString(media?.ids?.simkl ?? media?.ids?.simkl_id)
    if (simklId) ids.simkl = Number(simklId)
    const nativeNum = Number(ref.nativeId)
    if (kind === "show") ids.tvdb = nativeNum
    else if (kind === "movie") ids.tmdb = nativeNum
    else ids.anilist = nativeNum
    return ids
}

export function buildRemoveBody(
    kind: SimklKind,
    ids: Record<string, number>,
): Record<string, unknown> {
    return { [listKey(kind)]: [{ ids }] }
}

export function buildStatusBody(
    kind: SimklKind,
    ids: Record<string, number>,
    simklStatus: string,
): Record<string, unknown> {
    return { [listKey(kind)]: [{ to: simklStatus, ids }] }
}

export function buildRatingBody(
    kind: SimklKind,
    ids: Record<string, number>,
    rating: number,
): Record<string, unknown> {
    const score = Math.max(1, Math.min(10, Math.round(rating)))
    return { [listKey(kind)]: [{ rating: score, ids }] }
}

export function buildRemoveRatingBody(
    kind: SimklKind,
    ids: Record<string, number>,
): Record<string, unknown> {
    return { [listKey(kind)]: [{ ids }] }
}

export function orderRegularEpisodes(
    kind: "show" | "anime",
    rawEpisodes: SimklEpisodeRaw[],
): SimklEpisodeCoord[] {
    const out: SimklEpisodeCoord[] = []
    const seen = new Set<string>()
    for (const ep of rawEpisodes) {
        if (ep.type === "special") continue
        if (typeof ep.episode !== "number" || !Number.isInteger(ep.episode) || ep.episode <= 0) {
            continue
        }
        if (kind === "show") {
            if (typeof ep.season !== "number" || !Number.isInteger(ep.season) || ep.season <= 0) {
                continue
            }
            const key = `${ep.season}:${ep.episode}`
            if (seen.has(key)) continue
            seen.add(key)
            out.push({ season: ep.season, number: ep.episode })
        } else {
            if (ep.season !== undefined && ep.season <= 0) continue
            const season =
                typeof ep.season === "number" && Number.isInteger(ep.season) && ep.season > 0
                    ? ep.season
                    : undefined
            const key = `${season ?? 0}:${ep.episode}`
            if (seen.has(key)) continue
            seen.add(key)
            out.push(season !== undefined ? { season, number: ep.episode } : { number: ep.episode })
        }
    }
    out.sort((a, b) => (a.season ?? 1) - (b.season ?? 1) || a.number - b.number)
    return out
}

function coordKey(ep: SimklEpisodeCoord): string {
    return `${ep.season ?? 1}:${ep.number}`
}

export function currentWatchedKeys(
    item: SimklListItem | null | undefined,
    regularEpisodes: SimklEpisodeCoord[],
): Set<string> {
    const watched = new Set<string>()
    if (!item) return watched
    const seasons = Array.isArray(item.seasons) ? item.seasons : []
    const hasSeasonEpisodes = seasons.some((season) => Array.isArray(season.episodes))
    if (hasSeasonEpisodes) {
        for (const season of seasons) {
            if (typeof season.number !== "number" || season.number <= 0) continue
            for (const ep of season.episodes ?? []) {
                if (typeof ep.number === "number" && ep.number > 0) {
                    watched.add(`${season.number}:${ep.number}`)
                }
            }
        }
        return watched
    }
    const directEpisodes = Array.isArray(item.episodes) ? item.episodes : []
    if (directEpisodes.length > 0) {
        for (const ep of directEpisodes) {
            if (typeof ep.number === "number" && ep.number > 0) {
                const season = typeof ep.season === "number" && ep.season > 0 ? ep.season : 1
                watched.add(`${season}:${ep.number}`)
            }
        }
        return watched
    }
    const count =
        typeof item.watched_episodes_count === "number" && item.watched_episodes_count > 0
            ? item.watched_episodes_count
            : 0
    for (const ep of regularEpisodes.slice(0, count)) {
        watched.add(coordKey(ep))
    }
    return watched
}

export function buildEpisodeHistoryDiff(
    regularEpisodes: SimklEpisodeCoord[],
    watchedKeys: Set<string>,
    targetProgress: number,
): { add: SimklEpisodeCoord[]; remove: SimklEpisodeCoord[] } {
    const count = Math.max(0, Math.floor(targetProgress))
    const target = regularEpisodes.slice(0, count)
    const targetKeys = new Set(target.map(coordKey))
    const add = target.filter((ep) => !watchedKeys.has(coordKey(ep)))
    const remove = regularEpisodes
        .slice(count)
        .filter((ep) => watchedKeys.has(coordKey(ep)) && !targetKeys.has(coordKey(ep)))
    return { add, remove }
}

export function buildHistoryBody(
    kind: "show" | "anime",
    ids: Record<string, number>,
    episodes: SimklEpisodeCoord[],
): Record<string, unknown> {
    if (kind === "anime" && episodes.every((ep) => ep.season === undefined)) {
        return {
            anime: [
                {
                    ids,
                    episodes: episodes.map((ep) => ({ number: ep.number })),
                },
            ],
        }
    }
    const bySeason = new Map<number, { number: number }[]>()
    for (const ep of episodes) {
        const season = ep.season ?? 1
        const list = bySeason.get(season)
        if (list) list.push({ number: ep.number })
        else bySeason.set(season, [{ number: ep.number }])
    }
    const seasons = [...bySeason.entries()]
        .sort(([a], [b]) => a - b)
        .map(([number, list]) => ({ number, episodes: list }))
    return {
        [listKey(kind)]: [{ ids, seasons }],
    }
}
