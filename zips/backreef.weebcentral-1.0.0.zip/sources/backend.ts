import type {
    API,
    Context,
    HTTPOutput,
    Query,
    Ref,
    Source,
    SourceChoicesDef,
    SourceInstallment,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
    SourceResolveInput,
} from "../../../../packages/plugin-sdk/src/index"
import { unescapeHTML } from "../../../../packages/provider-source/src/text"
import { withYear } from "./year"

declare const caye: API

const weebcentralProviderId = "backreef.weebcentral:source"
const weebcentralBaseUrl = "https://weebcentral.com"

const defaultUserAgent =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

const pageCache = new Map<string, string[]>()

async function pageUrl(chapterId: string, pageId: string | undefined): Promise<string | undefined> {
    const images = await fetchChapterImages(chapterId)
    const index = pageId ? Math.max(0, parseInt(pageId, 10) - 1) : 0
    return images[index] ?? images[0]
}

async function weebcentralFetch(
    url: string,
    options: {
        method?: "GET" | "POST"
        headers?: Record<string, string>
        body?: string
    } = {},
): Promise<string> {
    let response: HTTPOutput
    try {
        response = await caye.http({
            url,
            method: options.method ?? "GET",
            headers: {
                "User-Agent": defaultUserAgent,
                ...(options.headers ?? {}),
            },
            body: options.body,
        })
    } catch {
        throw Object.assign(new Error("WeebCentral is unavailable"), {
            code: "unavailable",
        })
    }

    if (response.status < 200 || response.status >= 300) {
        throw Object.assign(new Error(`WeebCentral returned HTTP ${response.status}`), {
            code: "unavailable",
        })
    }

    return response.body ?? ""
}

async function fetchChapterImages(chapterId: string): Promise<string[]> {
    const cached = pageCache.get(chapterId)
    if (cached && cached.length > 0) return cached

    const url = `${weebcentralBaseUrl}/chapters/${chapterId}/images?is_prev=False&reading_style=long_strip`
    const html = await weebcentralFetch(url, {
        headers: {
            "HX-Request": "true",
            "HX-Current-URL": `${weebcentralBaseUrl}/chapters/${chapterId}`,
            Referer: `${weebcentralBaseUrl}/chapters/${chapterId}`,
        },
    })

    if (!html.includes("chapter-images")) {
        throw Object.assign(new Error("site changed"), {
            code: "site changed",
            reason: "site changed",
        })
    }

    const images: string[] = []
    const imgRegex = /<img\s+[^>]*src="([^">]+)"/gi
    for (const match of html.matchAll(imgRegex)) {
        const src = match[1]
        if (src && src.startsWith("http") && !src.includes("broken_image.jpg")) {
            images.push(src)
        }
    }

    if (images.length === 0) {
        throw Object.assign(new Error("site changed"), {
            code: "site changed",
            reason: "site changed",
        })
    }

    pageCache.set(chapterId, images)
    return images
}

const weebcentralSource = {
    async search(_context: Context, query: Query): Promise<SourceRecords> {
        const searchUrl = `${weebcentralBaseUrl}/search/simple?location=main`
        const text = (query.q ?? "").trim()
        if (!text) {
            return { items: [], nextCursor: "", state: "complete" }
        }

        const body = `text=${encodeURIComponent(text)}`
        const html = await weebcentralFetch(searchUrl, {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                "HX-Request": "true",
                "HX-Trigger": "quick-search-input",
                "HX-Trigger-Name": "text",
                "HX-Target": "quick-search-result",
                "HX-Current-URL": `${weebcentralBaseUrl}/`,
            },
            body,
        })

        if (!html.includes("quick-search-result")) {
            throw Object.assign(new Error("site changed"), {
                code: "site changed",
                reason: "site changed",
            })
        }

        if (html.includes("No results found")) {
            return { items: [], nextCursor: "", state: "complete" }
        }

        const items: SourceRecord[] = []
        const itemRegex =
            /<a\s+[^>]*href="https:\/\/weebcentral\.com\/series\/([^/"\s]+)(?:\/[^"\s]*)?"[^>]*>([\s\S]*?)<\/a>/gi
        for (const match of html.matchAll(itemRegex)) {
            const nativeId = match[1]
            const inner = match[2]
            const titleMatch = inner.match(/<div class="[^"]*flex-1[^"]*"[^>]*>([\s\S]*?)<\/div>/i)
            const title = titleMatch ? unescapeHTML(titleMatch[1]).trim() : ""

            if (nativeId && title) {
                items.push(
                    withYear(
                        {
                            ref: {
                                providerId: weebcentralProviderId,
                                type: "manga",
                                nativeId,
                            },
                            name: title,
                        },
                        match[0],
                    ),
                )
            }
        }

        if (items.length === 0) {
            throw Object.assign(new Error("site changed"), {
                code: "site changed",
                reason: "site changed",
            })
        }

        return { items, nextCursor: "", state: "complete" }
    },

    async read(_context: Context, ref: Ref): Promise<SourceRecord> {
        const url = `${weebcentralBaseUrl}/series/${ref.nativeId}`
        const html = await weebcentralFetch(url)

        const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i)
        if (!titleMatch) {
            throw Object.assign(new Error("site changed"), {
                code: "site changed",
                reason: "site changed",
            })
        }
        const name = unescapeHTML(titleMatch[1]).trim()

        const yearMatch = html.match(/<strong>Released:\s*<\/strong>\s*<span>(\d{4})<\/span>/i)

        return withYear(
            {
                ref: {
                    providerId: weebcentralProviderId,
                    type: "manga",
                    nativeId: ref.nativeId,
                },
                name,
            },
            yearMatch?.[1] ?? html,
        )
    },

    async list(_context: Context, ref: Ref): Promise<SourceListResult> {
        const url = `${weebcentralBaseUrl}/series/${ref.nativeId}/full-chapter-list`
        const html = await weebcentralFetch(url, {
            headers: {
                "HX-Request": "true",
                "HX-Target": "chapter-list",
                "HX-Current-URL": `${weebcentralBaseUrl}/series/${ref.nativeId}`,
                Referer: `${weebcentralBaseUrl}/series/${ref.nativeId}`,
            },
        })

        if (!html.includes("/chapters/")) {
            throw Object.assign(new Error("site changed"), {
                code: "site changed",
                reason: "site changed",
            })
        }

        type ParsedChapter = {
            id: string
            title: string
            number?: number
            group: string
        }

        const parsed: ParsedChapter[] = []
        const rowRegex = /<div class="flex items-center"[^>]*>([\s\S]*?)<\/div>/gi
        for (const rowMatch of html.matchAll(rowRegex)) {
            const rowHtml = rowMatch[1]
            const aMatch = rowHtml.match(
                /<a\s+[^>]*href="(?:\/chapters\/|https:\/\/weebcentral\.com\/chapters\/)([^/"\s]+)"[^>]*>([\s\S]*?)<\/a>/i,
            )
            if (!aMatch) continue

            const chapterId = aMatch[1]
            const aInner = aMatch[2]

            const badgeMatch = aInner.match(
                /<img\s+[^>]*src="[^"]*chapter-badge(-official)?\.svg"/i,
            )
            const group = badgeMatch?.[1] ? "Official" : "Scanlation"

            const titleMatch = aInner.match(
                /<span class="grow[^"]*">[\s\S]*?<span class="[^"]*">([\s\S]*?)<\/span>/i,
            )
            const title = titleMatch ? unescapeHTML(titleMatch[1]).trim() : ""
            if (!title) continue

            let number: number | undefined
            const chMatch = title.match(/(?:Chapter|Ch\.)\s*(\d+(?:\.\d+)?)/i)
            if (chMatch) {
                number = parseFloat(chMatch[1])
            } else if (/^\d+(?:\.\d+)?$/.test(title)) {
                number = parseFloat(title)
            } else {
                const firstMatch = title.match(/(\d+(?:\.\d+)?)/)
                if (firstMatch) {
                    number = parseFloat(firstMatch[1])
                }
            }

            parsed.push({
                id: chapterId,
                title,
                number,
                group,
            })
        }

        if (parsed.length === 0) {
            throw Object.assign(new Error("site changed"), {
                code: "site changed",
                reason: "site changed",
            })
        }

        // WeebCentral lists chapters newest-first; reverse to chronological reading order
        parsed.reverse()

        const numCounts = new Map<number, number>()
        for (const item of parsed) {
            if (item.number !== undefined) {
                numCounts.set(item.number, (numCounts.get(item.number) ?? 0) + 1)
            }
        }
        const hasDuplicates = Array.from(numCounts.values()).some((c) => c > 1)

        let choices: SourceChoicesDef = {}
        if (hasDuplicates) {
            const distinctGroups = Array.from(new Set(parsed.map((p) => p.group)))
            choices = {
                groups: [
                    {
                        id: "group",
                        label: "Group",
                        options: distinctGroups.map((g) => ({
                            id: g.toLowerCase(),
                            label: g,
                        })),
                    },
                ],
            }
        }

        const installments: SourceInstallment[] = parsed.map((item) => {
            const installment: SourceInstallment = {
                ref: {
                    providerId: weebcentralProviderId,
                    type: "chapter",
                    nativeId: item.id,
                    ...(hasDuplicates ? { scope: item.group.toLowerCase() } : {}),
                },
                number: item.number as number,
                name: item.title,
            }
            if (item.number === undefined) {
                delete (installment as { number?: number }).number
            }
            return installment
        })

        return { installments, choices }
    },

    async find(context: Context, ref: Ref): Promise<SourcePage> {
        const images = await fetchChapterImages(ref.nativeId)
        return {
            items: [
                {
                    id: "pages",
                    capabilities: ["pages"],
                    origin: "pages",
                    expiresAt: context.deadline,
                    tracks: [],
                    ranges: [],
                    pages: images.map((url, i) => ({
                        id: url.length <= 200 ? url : String(i + 1),
                        name: `Page ${i + 1}`,
                    })),
                },
            ],
            state: "complete",
        }
    },

    async resolve(_context: Context, input: SourceResolveInput): Promise<Source> {
        const imageUrl = input.pageId?.startsWith("https://")
            ? input.pageId
            : await pageUrl(input.ref.nativeId, input.pageId)
        if (!imageUrl) {
            throw Object.assign(new Error("Page not found"), {
                code: "unavailable",
            })
        }

        const response = await caye.http({
            url: imageUrl,
            mode: "handle",
            headers: {
                "User-Agent": defaultUserAgent,
                Referer: "https://weebcentral.com/",
            },
        })

        if (!response.handle) {
            throw Object.assign(new Error("Page handle unavailable"), {
                code: "unavailable",
            })
        }

        return {
            id: input.sourceId,
            capabilities: ["pages"],
            origin: "pages",
            expiresAt: response.handle.expiresAt,
            tracks: [],
            ranges: [],
            handle: response.handle,
        }
    },
}

caye.register(weebcentralProviderId, {
    source: weebcentralSource,
})
