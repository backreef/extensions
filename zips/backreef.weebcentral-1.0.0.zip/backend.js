(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/provider-source/src/text.ts
  function unescapeHTML(str) {
    return str.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#x27;/g, "'").replace(/&#x2F;/g, "/").replace(/&nbsp;/g, " ");
  }

  // src/year.ts
  function yearOf(value) {
    var _a, _b, _c, _d;
    if (typeof value === "number") {
      return Number.isInteger(value) && value >= 1e3 && value <= 9999 ? value : void 0;
    }
    if (typeof value !== "string") return void 0;
    const text = value.trim();
    const direct = (_a = text.match(/^(\d{4})(?:-\d{2}-\d{2})?$/)) == null ? void 0 : _a[1];
    const field = (_b = text.match(
      /(?:first_air_date|release_date|firstAired|airedOn|data-year|datetime|released|premiere|year)["']?\s*(?::|=)\s*["']?(\d{4})(?=$|[^\w.])/i
    )) == null ? void 0 : _b[1];
    const startDate = (_c = text.match(
      /\bstartDate\b.{0,40}?\byear\b["']?\s*:\s*["']?(\d{4})(?=$|[^\w.])/i
    )) == null ? void 0 : _c[1];
    const year = Number((_d = direct != null ? direct : field) != null ? _d : startDate);
    return Number.isInteger(year) && year >= 1e3 && year <= 9999 ? year : void 0;
  }
  function withYear(record, source) {
    const year = yearOf(source);
    return year === void 0 ? record : __spreadProps(__spreadValues({}, record), { year });
  }

  // src/backend.ts
  var weebcentralProviderId = "backreef.weebcentral:source";
  var weebcentralBaseUrl = "https://weebcentral.com";
  var defaultUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
  var pageCache = /* @__PURE__ */ new Map();
  function pageUrl(chapterId, pageId) {
    return __async(this, null, function* () {
      var _a;
      const images = yield fetchChapterImages(chapterId);
      const index = pageId ? Math.max(0, parseInt(pageId, 10) - 1) : 0;
      return (_a = images[index]) != null ? _a : images[0];
    });
  }
  function weebcentralFetch(_0) {
    return __async(this, arguments, function* (url, options = {}) {
      var _a, _b, _c;
      let response;
      try {
        response = yield caye.http({
          url,
          method: (_a = options.method) != null ? _a : "GET",
          headers: __spreadValues({
            "User-Agent": defaultUserAgent
          }, (_b = options.headers) != null ? _b : {}),
          body: options.body
        });
      } catch (e) {
        throw Object.assign(new Error("WeebCentral is unavailable"), {
          code: "unavailable"
        });
      }
      if (response.status < 200 || response.status >= 300) {
        throw Object.assign(new Error(`WeebCentral returned HTTP ${response.status}`), {
          code: "unavailable"
        });
      }
      return (_c = response.body) != null ? _c : "";
    });
  }
  function fetchChapterImages(chapterId) {
    return __async(this, null, function* () {
      const cached = pageCache.get(chapterId);
      if (cached && cached.length > 0) return cached;
      const url = `${weebcentralBaseUrl}/chapters/${chapterId}/images?is_prev=False&reading_style=long_strip`;
      const html = yield weebcentralFetch(url, {
        headers: {
          "HX-Request": "true",
          "HX-Current-URL": `${weebcentralBaseUrl}/chapters/${chapterId}`,
          Referer: `${weebcentralBaseUrl}/chapters/${chapterId}`
        }
      });
      if (!html.includes("chapter-images")) {
        throw Object.assign(new Error("site changed"), {
          code: "site changed",
          reason: "site changed"
        });
      }
      const images = [];
      const imgRegex = /<img\s+[^>]*src="([^">]+)"/gi;
      for (const match of html.matchAll(imgRegex)) {
        const src = match[1];
        if (src && src.startsWith("http") && !src.includes("broken_image.jpg")) {
          images.push(src);
        }
      }
      if (images.length === 0) {
        throw Object.assign(new Error("site changed"), {
          code: "site changed",
          reason: "site changed"
        });
      }
      pageCache.set(chapterId, images);
      return images;
    });
  }
  var weebcentralSource = {
    search(_context, query) {
      return __async(this, null, function* () {
        var _a;
        const searchUrl = `${weebcentralBaseUrl}/search/simple?location=main`;
        const text = ((_a = query.q) != null ? _a : "").trim();
        if (!text) {
          return { items: [], nextCursor: "", state: "complete" };
        }
        const body = `text=${encodeURIComponent(text)}`;
        const html = yield weebcentralFetch(searchUrl, {
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            "HX-Request": "true",
            "HX-Trigger": "quick-search-input",
            "HX-Trigger-Name": "text",
            "HX-Target": "quick-search-result",
            "HX-Current-URL": `${weebcentralBaseUrl}/`
          },
          body
        });
        if (!html.includes("quick-search-result")) {
          throw Object.assign(new Error("site changed"), {
            code: "site changed",
            reason: "site changed"
          });
        }
        if (html.includes("No results found")) {
          return { items: [], nextCursor: "", state: "complete" };
        }
        const items = [];
        const itemRegex = /<a\s+[^>]*href="https:\/\/weebcentral\.com\/series\/([^/"\s]+)(?:\/[^"\s]*)?"[^>]*>([\s\S]*?)<\/a>/gi;
        for (const match of html.matchAll(itemRegex)) {
          const nativeId = match[1];
          const inner = match[2];
          const titleMatch = inner.match(/<div class="[^"]*flex-1[^"]*"[^>]*>([\s\S]*?)<\/div>/i);
          const title = titleMatch ? unescapeHTML(titleMatch[1]).trim() : "";
          if (nativeId && title) {
            items.push(
              withYear(
                {
                  ref: {
                    providerId: weebcentralProviderId,
                    type: "manga",
                    nativeId
                  },
                  name: title
                },
                match[0]
              )
            );
          }
        }
        if (items.length === 0) {
          throw Object.assign(new Error("site changed"), {
            code: "site changed",
            reason: "site changed"
          });
        }
        return { items, nextCursor: "", state: "complete" };
      });
    },
    read(_context, ref) {
      return __async(this, null, function* () {
        var _a;
        const url = `${weebcentralBaseUrl}/series/${ref.nativeId}`;
        const html = yield weebcentralFetch(url);
        const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
        if (!titleMatch) {
          throw Object.assign(new Error("site changed"), {
            code: "site changed",
            reason: "site changed"
          });
        }
        const name = unescapeHTML(titleMatch[1]).trim();
        const yearMatch = html.match(/<strong>Released:\s*<\/strong>\s*<span>(\d{4})<\/span>/i);
        return withYear(
          {
            ref: {
              providerId: weebcentralProviderId,
              type: "manga",
              nativeId: ref.nativeId
            },
            name
          },
          (_a = yearMatch == null ? void 0 : yearMatch[1]) != null ? _a : html
        );
      });
    },
    list(_context, ref) {
      return __async(this, null, function* () {
        var _a;
        const url = `${weebcentralBaseUrl}/series/${ref.nativeId}/full-chapter-list`;
        const html = yield weebcentralFetch(url, {
          headers: {
            "HX-Request": "true",
            "HX-Target": "chapter-list",
            "HX-Current-URL": `${weebcentralBaseUrl}/series/${ref.nativeId}`,
            Referer: `${weebcentralBaseUrl}/series/${ref.nativeId}`
          }
        });
        if (!html.includes("/chapters/")) {
          throw Object.assign(new Error("site changed"), {
            code: "site changed",
            reason: "site changed"
          });
        }
        const parsed = [];
        const rowRegex = /<div class="flex items-center"[^>]*>([\s\S]*?)<\/div>/gi;
        for (const rowMatch of html.matchAll(rowRegex)) {
          const rowHtml = rowMatch[1];
          const aMatch = rowHtml.match(
            /<a\s+[^>]*href="(?:\/chapters\/|https:\/\/weebcentral\.com\/chapters\/)([^/"\s]+)"[^>]*>([\s\S]*?)<\/a>/i
          );
          if (!aMatch) continue;
          const chapterId = aMatch[1];
          const aInner = aMatch[2];
          const badgeMatch = aInner.match(
            /<img\s+[^>]*src="[^"]*chapter-badge(-official)?\.svg"/i
          );
          const group = (badgeMatch == null ? void 0 : badgeMatch[1]) ? "Official" : "Scanlation";
          const titleMatch = aInner.match(
            /<span class="grow[^"]*">[\s\S]*?<span class="[^"]*">([\s\S]*?)<\/span>/i
          );
          const title = titleMatch ? unescapeHTML(titleMatch[1]).trim() : "";
          if (!title) continue;
          let number;
          const chMatch = title.match(/(?:Chapter|Ch\.)\s*(\d+(?:\.\d+)?)/i);
          if (chMatch) {
            number = parseFloat(chMatch[1]);
          } else if (/^\d+(?:\.\d+)?$/.test(title)) {
            number = parseFloat(title);
          } else {
            const firstMatch = title.match(/(\d+(?:\.\d+)?)/);
            if (firstMatch) {
              number = parseFloat(firstMatch[1]);
            }
          }
          parsed.push({
            id: chapterId,
            title,
            number,
            group
          });
        }
        if (parsed.length === 0) {
          throw Object.assign(new Error("site changed"), {
            code: "site changed",
            reason: "site changed"
          });
        }
        parsed.reverse();
        const numCounts = /* @__PURE__ */ new Map();
        for (const item of parsed) {
          if (item.number !== void 0) {
            numCounts.set(item.number, ((_a = numCounts.get(item.number)) != null ? _a : 0) + 1);
          }
        }
        const hasDuplicates = Array.from(numCounts.values()).some((c) => c > 1);
        let choices = {};
        if (hasDuplicates) {
          const distinctGroups = Array.from(new Set(parsed.map((p) => p.group)));
          choices = {
            groups: [
              {
                id: "group",
                label: "Group",
                options: distinctGroups.map((g) => ({
                  id: g.toLowerCase(),
                  label: g
                }))
              }
            ]
          };
        }
        const installments = parsed.map((item) => {
          const installment = {
            ref: __spreadValues({
              providerId: weebcentralProviderId,
              type: "chapter",
              nativeId: item.id
            }, hasDuplicates ? { scope: item.group.toLowerCase() } : {}),
            number: item.number,
            name: item.title
          };
          if (item.number === void 0) {
            delete installment.number;
          }
          return installment;
        });
        return { installments, choices };
      });
    },
    find(context, ref) {
      return __async(this, null, function* () {
        const images = yield fetchChapterImages(ref.nativeId);
        return {
          items: [
            {
              id: "pages",
              capabilities: ["pages"],
              origin: "pages",
              expiresAt: context.deadline,
              tracks: [],
              ranges: [],
              pages: images.map((url, i) => ({
                id: url.length <= 200 ? url : String(i + 1),
                name: `Page ${i + 1}`
              }))
            }
          ],
          state: "complete"
        };
      });
    },
    resolve(_context, input) {
      return __async(this, null, function* () {
        var _a;
        const imageUrl = ((_a = input.pageId) == null ? void 0 : _a.startsWith("https://")) ? input.pageId : yield pageUrl(input.ref.nativeId, input.pageId);
        if (!imageUrl) {
          throw Object.assign(new Error("Page not found"), {
            code: "unavailable"
          });
        }
        const response = yield caye.http({
          url: imageUrl,
          mode: "handle",
          headers: {
            "User-Agent": defaultUserAgent,
            Referer: "https://weebcentral.com/"
          }
        });
        if (!response.handle) {
          throw Object.assign(new Error("Page handle unavailable"), {
            code: "unavailable"
          });
        }
        return {
          id: input.sourceId,
          capabilities: ["pages"],
          origin: "pages",
          expiresAt: response.handle.expiresAt,
          tracks: [],
          ranges: [],
          handle: response.handle
        };
      });
    }
  };
  caye.register(weebcentralProviderId, {
    source: weebcentralSource
  });
})();
//# sourceMappingURL=backend.js.map
