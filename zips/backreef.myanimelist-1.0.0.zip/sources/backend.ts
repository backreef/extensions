import type {
    API,
    ConnectCompleteInput,
    ConnectCompleteResult,
    ConnectStartInput,
    ConnectStartResult,
    Context,
    TrackerEntry,
    TrackerPullResult,
    TrackerPushEntry,
    TrackerPushInput,
    TrackerPushOutcome,
    TrackerPushResult,
} from "../../../../packages/plugin-sdk/src/index"
import {
    backreefClientId,
    buildAuthorizeUrl,
    buildPushForm,
    codedError,
    encodeForm,
    entry,
    isAllowedMalApiUrl,
    type ConnectFlowData,
    type MalDetailResponse,
    type MalKind,
    type MalListStatus,
    type MalNode,
    matches,
    namespaces,
    parseCompleteQuery,
    pkceVerifierFromHex,
    safeMalError,
    type StoredAuth,
    trackedFields,
} from "./mal"

declare const caye: API

const malApiBase = "https://api.myanimelist.net/v2"
const malTokenUrl = "https://myanimelist.net/v1/oauth2/token"
const anilistGraphqlUrl = "https://graphql.anilist.co"

const callBudget = 20_000
const refreshWindowMs = 5 * 60 * 1000
const foundCacheSeconds = 30 * 24 * 60 * 60
const missingCacheSeconds = 7 * 24 * 60 * 60

const animeListFields =
    "list_status{status,score,num_episodes_watched,is_rewatching,num_times_rewatched,start_date,finish_date,updated_at},num_episodes,media_type,start_season,alternative_titles,main_picture,title"
const mangaListFields =
    "list_status{status,score,num_chapters_read,is_rereading,num_times_reread,start_date,finish_date,updated_at},num_chapters,media_type,alternative_titles,main_picture,title"
const animeDetailFields =
    "my_list_status{status,score,num_episodes_watched,is_rewatching,num_times_rewatched,start_date,finish_date,updated_at},num_episodes,media_type,start_season,alternative_titles,main_picture,title"
const mangaDetailFields =
    "my_list_status{status,score,num_chapters_read,is_rereading,num_times_reread,start_date,finish_date,updated_at},num_chapters,media_type,alternative_titles,main_picture,title"

let malBlockedUntil = 0
let anilistBlockedUntil = 0
let deadline = 0

function startCall() {
    deadline = Date.now() + callBudget
}

function limited(provider: string, waitMs: number): Error {
    return codedError(`${provider} rate limit reached.`, "rate-limited", {
        retry_after: Math.max(1, Math.ceil(waitMs / 1000)),
    })
}

async function waitForLimit(provider: string, blockedUntil: number) {
    const wait = blockedUntil - Date.now()
    if (wait <= 0) return
    if (Date.now() + wait > deadline) throw limited(provider, wait)
    await caye.sleep(wait)
}

function resetAt(headers: Record<string, string>): number {
    const retry = parseInt(headers["retry-after"] ?? "", 10)
    if (!Number.isNaN(retry)) return Date.now() + (retry + 1) * 1000
    const reset = parseInt(headers["x-ratelimit-reset"] ?? "", 10)
    if (!Number.isNaN(reset) && reset > 0) return reset * 1000
    return Date.now() + 60_000
}

type TokenResponse = {
    access_token?: string
    refresh_token?: string
    expires_in?: number
}

async function postToken(params: Record<string, string>): Promise<TokenResponse> {
    let response: Awaited<ReturnType<API["http"]>>
    try {
        response = await caye.http({
            url: malTokenUrl,
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded",
                Accept: "application/json",
            },
            body: encodeForm(params),
        })
    } catch {
        throw codedError("MyAnimeList sign-in did not answer.", "needs-auth")
    }
    if (response.status < 200 || response.status >= 300) {
        throw codedError(
            safeMalError(response.body ?? "", "MyAnimeList rejected the sign-in."),
            "needs-auth",
        )
    }
    const parsed = (response.body ? JSON.parse(response.body) : {}) as TokenResponse
    if (!parsed.access_token || !parsed.refresh_token) {
        throw codedError("MyAnimeList returned an incomplete token.", "needs-auth")
    }
    return parsed
}

type AuthSession = {
    recordKey: string
    auth: StoredAuth
}

function parseStoredAuth(raw: string): StoredAuth | null {
    try {
        const parsed = JSON.parse(raw) as Partial<StoredAuth>
        if (
            typeof parsed.access === "string" &&
            parsed.access &&
            typeof parsed.refresh === "string" &&
            parsed.refresh
        ) {
            return {
                access: parsed.access,
                refresh: parsed.refresh,
                expiresAt: typeof parsed.expiresAt === "number" ? parsed.expiresAt : 0,
                clientId: typeof parsed.clientId === "string" ? parsed.clientId : "",
            }
        }
        return null
    } catch {
        return null
    }
}

async function loadAuthSession(context: Context): Promise<AuthSession> {
    if (!context.config.account) {
        throw codedError("Sign in to MyAnimeList.", "needs-auth")
    }
    const secretText = await caye.secret(context.config.account)
    const baseAuth = parseStoredAuth(secretText)
    if (!baseAuth) {
        throw codedError("Sign in to MyAnimeList.", "needs-auth")
    }
    const hash = await caye.crypto.hash({
        algorithm: "sha256",
        data: baseAuth.refresh,
        encoding: "text",
        output: "hex",
    })
    const recordKey = `token:${hash.value.slice(0, 32)}`
    let current = baseAuth
    try {
        const record = await caye.records.get({ key: recordKey, scope: "connection" })
        if (record.value.kind === "text") {
            const stored = parseStoredAuth(record.value.text)
            if (stored) current = stored
        }
    } catch {
        current = baseAuth
    }
    const session: AuthSession = { recordKey, auth: current }
    if (session.auth.expiresAt <= Date.now() + refreshWindowMs) {
        await refreshSession(context, session)
    }
    return session
}

async function refreshSession(context: Context, session: AuthSession): Promise<void> {
    const clientId =
        session.auth.clientId || (context.config.clientId ?? "").trim() || backreefClientId
    if (!clientId) {
        throw codedError("Add a MyAnimeList client ID to this connection.", "needs-auth")
    }
    const token = await postToken({
        client_id: clientId,
        grant_type: "refresh_token",
        refresh_token: session.auth.refresh,
    })
    const next: StoredAuth = {
        access: token.access_token!,
        refresh: token.refresh_token!,
        expiresAt: Date.now() + Math.max(0, Number(token.expires_in ?? 0)) * 1000,
        clientId,
    }
    session.auth = next
    await caye.records.set({
        key: session.recordKey,
        value: { kind: "text", text: JSON.stringify(next) },
        scope: "connection",
    })
}

async function malRequest(
    context: Context,
    session: AuthSession,
    method: "GET" | "PATCH" | "DELETE",
    url: string,
    body?: string,
    allowNotFound = false,
): Promise<{ status: number; body: string }> {
    let refreshed = false
    for (let attempt = 0; ; attempt++) {
        await waitForLimit("MyAnimeList", malBlockedUntil)
        const headers: Record<string, string> = {
            Authorization: `Bearer ${session.auth.access}`,
            Accept: "application/json",
        }
        if (body !== undefined) {
            headers["Content-Type"] = "application/x-www-form-urlencoded"
        }
        const response = await caye.http({ url, method, headers, body })
        if (response.status === 401) {
            if (refreshed) {
                throw codedError("MyAnimeList rejected the access token.", "needs-auth")
            }
            refreshed = true
            await refreshSession(context, session)
            continue
        }
        if (response.status === 403) {
            throw codedError("MyAnimeList rejected the access token.", "needs-auth")
        }
        if (response.status === 429) {
            malBlockedUntil = Math.max(malBlockedUntil, resetAt(response.headers))
            if (attempt >= 3) throw limited("MyAnimeList", malBlockedUntil - Date.now())
            continue
        }
        if (allowNotFound && response.status === 404) {
            return { status: 404, body: response.body ?? "" }
        }
        if (response.status < 200 || response.status >= 300) {
            throw codedError("MyAnimeList did not answer.", "unavailable")
        }
        return { status: response.status, body: response.body ?? "" }
    }
}

async function anilistGraphql<T>(
    query: string,
    variables: Record<string, unknown>,
): Promise<T> {
    for (let attempt = 0; ; attempt++) {
        await waitForLimit("AniList", anilistBlockedUntil)
        const response = await caye.http({
            url: anilistGraphqlUrl,
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                Accept: "application/json",
            },
            body: JSON.stringify({ query, variables }),
        })
        if (response.status === 429) {
            anilistBlockedUntil = Math.max(anilistBlockedUntil, resetAt(response.headers))
            if (attempt >= 3) throw limited("AniList", anilistBlockedUntil - Date.now())
            continue
        }
        if (response.headers["x-ratelimit-remaining"] === "0") {
            anilistBlockedUntil = Math.max(anilistBlockedUntil, resetAt(response.headers))
        }
        const parsed = response.body ? JSON.parse(response.body) : {}
        if (response.status !== 200 || parsed.errors) {
            throw codedError("AniList did not answer.", "unavailable")
        }
        return parsed.data as T
    }
}

function cacheKey(direction: "mal2al" | "al2mal", kind: MalKind, id: number): string {
    return `${direction}:${kind}:${id}`
}

async function readCachedId(key: string): Promise<number | undefined> {
    const cached = await caye.cache.get({ key })
    if (cached && cached.kind === "number") return cached.number
    return undefined
}

async function writeCachedId(key: string, id: number): Promise<void> {
    await caye.cache.set({
        key,
        value: { kind: "number", number: id },
        ttlSeconds: id > 0 ? foundCacheSeconds : missingCacheSeconds,
    })
}

async function mapMalToAniList(kind: MalKind, malIds: number[]): Promise<Map<number, number>> {
    const out = new Map<number, number>()
    const missing: number[] = []
    for (const malId of malIds) {
        if (out.has(malId)) continue
        const cached = await readCachedId(cacheKey("mal2al", kind, malId))
        if (cached !== undefined) {
            if (cached > 0) out.set(malId, cached)
        } else {
            out.set(malId, 0)
            missing.push(malId)
        }
    }
    const mediaType = kind === "anime" ? "ANIME" : "MANGA"
    for (let i = 0; i < missing.length; i += 50) {
        const chunk = missing.slice(i, i + 50)
        const data = await anilistGraphql<{
            Page?: { media?: { id?: number | null; idMal?: number | null }[] | null } | null
        }>(
            `query($ids:[Int]){Page(perPage:50){media(idMal_in:$ids,type:${mediaType}){id idMal}}}`,
            { ids: chunk },
        )
        const found = new Map<number, number>()
        for (const item of data.Page?.media ?? []) {
            if (typeof item.idMal === "number" && typeof item.id === "number" && item.idMal > 0 && item.id > 0) {
                if (!found.has(item.idMal)) found.set(item.idMal, item.id)
            }
        }
        for (const malId of chunk) {
            const alId = found.get(malId) ?? 0
            await writeCachedId(cacheKey("mal2al", kind, malId), alId)
            if (alId > 0) {
                out.set(malId, alId)
                await writeCachedId(cacheKey("al2mal", kind, alId), malId)
            } else {
                out.delete(malId)
            }
        }
    }
    for (const [k, v] of out.entries()) {
        if (v <= 0) out.delete(k)
    }
    return out
}

async function mapAniListToMal(kind: MalKind, anilistIds: number[]): Promise<Map<number, number>> {
    const out = new Map<number, number>()
    const missing: number[] = []
    for (const alId of anilistIds) {
        if (out.has(alId)) continue
        const cached = await readCachedId(cacheKey("al2mal", kind, alId))
        if (cached !== undefined) {
            if (cached > 0) out.set(alId, cached)
        } else {
            out.set(alId, 0)
            missing.push(alId)
        }
    }
    const mediaType = kind === "anime" ? "ANIME" : "MANGA"
    for (let i = 0; i < missing.length; i += 50) {
        const chunk = missing.slice(i, i + 50)
        const data = await anilistGraphql<{
            Page?: { media?: { id?: number | null; idMal?: number | null }[] | null } | null
        }>(
            `query($ids:[Int]){Page(perPage:50){media(id_in:$ids,type:${mediaType}){id idMal}}}`,
            { ids: chunk },
        )
        const found = new Map<number, number>()
        for (const item of data.Page?.media ?? []) {
            if (typeof item.id === "number" && typeof item.idMal === "number" && item.id > 0 && item.idMal > 0) {
                if (!found.has(item.id)) found.set(item.id, item.idMal)
            }
        }
        for (const alId of chunk) {
            const malId = found.get(alId) ?? 0
            await writeCachedId(cacheKey("al2mal", kind, alId), malId)
            if (malId > 0) {
                out.set(alId, malId)
                await writeCachedId(cacheKey("mal2al", kind, malId), alId)
            } else {
                out.delete(alId)
            }
        }
    }
    for (const [k, v] of out.entries()) {
        if (v <= 0) out.delete(k)
    }
    return out
}

type MalListItem = {
    node: MalNode
    list_status: MalListStatus
}

type MalListPage = {
    data?: MalListItem[]
    paging?: { next?: string }
}

async function fetchUserList(
    context: Context,
    session: AuthSession,
    kind: MalKind,
): Promise<MalListItem[]> {
    const listFields = kind === "anime" ? animeListFields : mangaListFields
    let nextUrl: string | undefined =
        `${malApiBase}/users/@me/${kind}list?fields=${encodeURIComponent(listFields)}&limit=1000&nsfw=true`
    const items: MalListItem[] = []
    const visited = new Set<string>()
    while (nextUrl) {
        if (!isAllowedMalApiUrl(nextUrl) || visited.has(nextUrl)) break
        visited.add(nextUrl)
        const res = await malRequest(context, session, "GET", nextUrl)
        const page = (res.body ? JSON.parse(res.body) : {}) as MalListPage
        for (const item of page.data ?? []) {
            if (item?.node && item?.list_status) items.push(item)
        }
        const candidate: string | undefined = page.paging?.next
        nextUrl = candidate && isAllowedMalApiUrl(candidate) ? candidate : undefined
    }
    return items
}

async function pushOne(
    context: Context,
    session: AuthSession,
    pushed: TrackerPushEntry,
    alToMal: Record<MalKind, Map<number, number>>,
): Promise<TrackerPushOutcome> {
    const kind = (Object.keys(namespaces) as MalKind[]).find((k) => {
        const ns = namespaces[k]
        return pushed.ref.providerId === ns.providerId && pushed.ref.type === ns.type
    })
    const anilistId = Number(pushed.ref.nativeId)
    if (
        !kind ||
        !/^[1-9]\d*$/.test(pushed.ref.nativeId) ||
        !Number.isInteger(anilistId) ||
        anilistId > 2147483647
    ) {
        return {
            ref: pushed.ref,
            outcome: "unsupported",
            reason: "The entry is not an AniList anime or manga.",
        }
    }
    const malId = alToMal[kind].get(anilistId)
    if (!malId) {
        return {
            ref: pushed.ref,
            outcome: "unsupported",
            reason: "No MyAnimeList entry matches this title.",
        }
    }
    const fieldsParam = kind === "anime" ? animeDetailFields : mangaDetailFields
    const detailUrl = `${malApiBase}/${kind}/${malId}?fields=${encodeURIComponent(fieldsParam)}`
    const detailRes = await malRequest(context, session, "GET", detailUrl, undefined, true)
    if (detailRes.status === 404) {
        return {
            ref: pushed.ref,
            outcome: "unsupported",
            reason: "The entry is not on MyAnimeList.",
        }
    }
    const detail = (detailRes.body ? JSON.parse(detailRes.body) : {}) as MalDetailResponse
    const before = detail.my_list_status ?? null
    if (before) {
        const remote = entry(detail, before, kind, anilistId)
        if (matches(remote, pushed.fields)) {
            return {
                ref: pushed.ref,
                outcome: "applied",
                revision: remote.revision,
            }
        }
        if (pushed.baseRevision !== "" && remote.revision !== pushed.baseRevision) {
            return {
                ref: pushed.ref,
                outcome: "conflict",
                remote,
            }
        }
    }
    const statusUrl = `${malApiBase}/${kind}/${malId}/my_list_status`
    if ("status" in pushed.fields && pushed.fields.status === null) {
        if (before) {
            await malRequest(context, session, "DELETE", statusUrl, undefined, true)
        }
        return { ref: pushed.ref, outcome: "applied", revision: "" }
    }
    const total = (kind === "anime" ? detail.num_episodes : detail.num_chapters) ?? 0
    const form = buildPushForm(kind, total, Boolean(before), pushed.fields)
    const patchRes = await malRequest(context, session, "PATCH", statusUrl, encodeForm(form))
    const saved = (patchRes.body ? JSON.parse(patchRes.body) : {}) as MalListStatus
    return {
        ref: pushed.ref,
        outcome: "applied",
        revision: String(saved.updated_at ?? ""),
    }
}

caye.register("backreef.myanimelist:tracker", {
    connect: {
        async start(context: Context, input: ConnectStartInput): Promise<ConnectStartResult> {
            const rand = await caye.crypto.random({ bytes: 128, output: "hex" })
            const verifier = pkceVerifierFromHex(rand.value)
            return buildAuthorizeUrl(
                context.config.clientId,
                input.redirectUrl,
                input.state,
                verifier,
            )
        },
        async complete(_context: Context, input: ConnectCompleteInput): Promise<ConnectCompleteResult> {
            const parsed = parseCompleteQuery(input.query)
            if (parsed.action === "pending") return parsed.result
            let flow: ConnectFlowData
            try {
                flow = JSON.parse(input.data) as ConnectFlowData
            } catch {
                throw codedError("MyAnimeList sign-in state is invalid.", "needs-auth")
            }
            if (!flow.verifier || !flow.redirectUri || !flow.clientId) {
                throw codedError("MyAnimeList sign-in state is incomplete.", "needs-auth")
            }
            const token = await postToken({
                client_id: flow.clientId,
                grant_type: "authorization_code",
                code: parsed.code,
                redirect_uri: flow.redirectUri,
                code_verifier: flow.verifier,
            })
            const stored: StoredAuth = {
                access: token.access_token!,
                refresh: token.refresh_token!,
                expiresAt: Date.now() + Math.max(0, Number(token.expires_in ?? 0)) * 1000,
                clientId: flow.clientId,
            }
            return { value: JSON.stringify(stored) }
        },
    },
    tracker: {
        async pull(context: Context): Promise<TrackerPullResult> {
            startCall()
            const session = await loadAuthSession(context)
            const entries: TrackerEntry[] = []
            for (const kind of Object.keys(namespaces) as MalKind[]) {
                const list = await fetchUserList(context, session, kind)
                const malIds = list.map((item) => item.node.id).filter((id) => id > 0)
                const malToAl = await mapMalToAniList(kind, malIds)
                const seen = new Set<number>()
                for (const item of list) {
                    const anilistId = malToAl.get(item.node.id)
                    if (!anilistId || seen.has(anilistId)) continue
                    seen.add(anilistId)
                    entries.push(entry(item.node, item.list_status, kind, anilistId))
                }
            }
            return {
                entries,
                fields: trackedFields,
                ratingStep: 1,
                ratingMax: 10,
                datePrecision: "day",
            }
        },
        async push(context: Context, input: TrackerPushInput): Promise<TrackerPushResult> {
            startCall()
            const session = await loadAuthSession(context)
            const idsByKind: Record<MalKind, number[]> = { anime: [], manga: [] }
            for (const pushed of input.entries) {
                const kind = (Object.keys(namespaces) as MalKind[]).find((k) => {
                    const ns = namespaces[k]
                    return pushed.ref.providerId === ns.providerId && pushed.ref.type === ns.type
                })
                const anilistId = Number(pushed.ref.nativeId)
                if (
                    kind &&
                    /^[1-9]\d*$/.test(pushed.ref.nativeId) &&
                    Number.isInteger(anilistId) &&
                    anilistId > 0 &&
                    anilistId <= 2147483647
                ) {
                    idsByKind[kind].push(anilistId)
                }
            }
            const alToMal: Record<MalKind, Map<number, number>> = {
                anime: await mapAniListToMal("anime", idsByKind.anime),
                manga: await mapAniListToMal("manga", idsByKind.manga),
            }
            const entries: TrackerPushOutcome[] = []
            for (const pushed of input.entries) {
                entries.push(await pushOne(context, session, pushed, alToMal))
            }
            return { entries }
        },
    },
})
