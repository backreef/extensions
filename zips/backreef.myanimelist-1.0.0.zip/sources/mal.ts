import type {
    ConnectCompleteResult,
    TrackerEntry,
    TrackerField,
    TrackerPushEntry,
    TrackerStatus,
} from "../../../../packages/plugin-sdk/src/index"

export const backreefClientId = ""
export const relayUrl = "https://backreef.github.io/extensions/oauth/"

export type MalKind = "anime" | "manga"

export type MalListStatus = {
    status?: string | null
    score?: number | null
    num_episodes_watched?: number | null
    num_chapters_read?: number | null
    is_rewatching?: boolean | null
    is_rereading?: boolean | null
    num_times_rewatched?: number | null
    num_times_reread?: number | null
    start_date?: string | null
    finish_date?: string | null
    updated_at?: string | null
}

export type MalNode = {
    id: number
    title?: string | null
    main_picture?: {
        medium?: string | null
        large?: string | null
    } | null
    alternative_titles?: {
        synonyms?: (string | null)[] | null
        en?: string | null
        ja?: string | null
    } | null
    media_type?: string | null
    num_episodes?: number | null
    num_chapters?: number | null
    start_season?: {
        year?: number | null
        season?: string | null
    } | null
}

export type MalDetailResponse = MalNode & {
    my_list_status?: MalListStatus | null
}

export type StoredAuth = {
    access: string
    refresh: string
    expiresAt: number
    clientId: string
}

export type ConnectFlowData = {
    verifier: string
    redirectUri: string
    clientId: string
}

export const namespaces: Record<MalKind, { providerId: string; type: string }> = {
    anime: { providerId: "caye.movies-shows:anilist", type: "anime" },
    manga: { providerId: "backreef.myanimelist:tracker", type: "manga" },
}

export const trackedFields: TrackerField[] = [
    "status",
    "rating",
    "progress",
    "started",
    "completed",
    "repeats",
]

const mediaTypeLabels: Record<string, string> = {
    tv: "TV",
    tv_special: "TV special",
    ova: "OVA",
    movie: "Movie",
    special: "Special",
    ona: "ONA",
    music: "Music",
    cm: "CM",
    pv: "PV",
    manga: "Manga",
    novel: "Novel",
    light_novel: "Light novel",
    one_shot: "One-shot",
    doujinshi: "Doujinshi",
    manhwa: "Manhwa",
    manhua: "Manhua",
    oel: "OEL",
}

const malToCayeStatus: Record<string, TrackerStatus> = {
    watching: "in-progress",
    reading: "in-progress",
    plan_to_watch: "planning",
    plan_to_read: "planning",
    completed: "completed",
    on_hold: "paused",
    dropped: "dropped",
}

const cayeToMalStatus: Record<MalKind, Record<TrackerStatus, string>> = {
    anime: {
        "in-progress": "watching",
        planning: "plan_to_watch",
        completed: "completed",
        paused: "on_hold",
        dropped: "dropped",
    },
    manga: {
        "in-progress": "reading",
        planning: "plan_to_read",
        completed: "completed",
        paused: "on_hold",
        dropped: "dropped",
    },
}

const pkceAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~"
const base64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"

export function codedError(message: string, code: string, extra?: Record<string, unknown>): Error {
    return Object.assign(new Error(message), { code, ...extra })
}

export function utf8Bytes(text: string): number[] {
    const out: number[] = []
    for (let i = 0; i < text.length; i++) {
        let code = text.charCodeAt(i)
        if (code >= 0xd800 && code <= 0xdbff && i + 1 < text.length) {
            const next = text.charCodeAt(i + 1)
            if (next >= 0xdc00 && next <= 0xdfff) {
                code = 0x10000 + ((code - 0xd800) << 10) + (next - 0xdc00)
                i++
            }
        }
        if (code < 0x80) {
            out.push(code)
        } else if (code < 0x800) {
            out.push(0xc0 | (code >> 6), 0x80 | (code & 0x3f))
        } else if (code < 0x10000) {
            out.push(0xe0 | (code >> 12), 0x80 | ((code >> 6) & 0x3f), 0x80 | (code & 0x3f))
        } else {
            out.push(
                0xf0 | (code >> 18),
                0x80 | ((code >> 12) & 0x3f),
                0x80 | ((code >> 6) & 0x3f),
                0x80 | (code & 0x3f),
            )
        }
    }
    return out
}

export function base64UrlEncode(text: string): string {
    const bytes = utf8Bytes(text)
    let out = ""
    for (let i = 0; i < bytes.length; i += 3) {
        const b0 = bytes[i]
        const has1 = i + 1 < bytes.length
        const has2 = i + 2 < bytes.length
        const b1 = has1 ? bytes[i + 1] : 0
        const b2 = has2 ? bytes[i + 2] : 0
        const n = (b0 << 16) | (b1 << 8) | b2
        out += base64Chars[(n >> 18) & 63]
        out += base64Chars[(n >> 12) & 63]
        if (has1) out += base64Chars[(n >> 6) & 63]
        if (has2) out += base64Chars[n & 63]
    }
    return out.replace(/\+/g, "-").replace(/\//g, "_")
}

export function base64UrlDecode(encoded: string): string {
    const clean = encoded.replace(/-/g, "+").replace(/_/g, "/").replace(/=+$/g, "")
    const bytes: number[] = []
    for (let i = 0; i < clean.length; i += 4) {
        const c0 = base64Chars.indexOf(clean[i])
        const c1 = i + 1 < clean.length ? base64Chars.indexOf(clean[i + 1]) : -1
        const c2 = i + 2 < clean.length ? base64Chars.indexOf(clean[i + 2]) : -1
        const c3 = i + 3 < clean.length ? base64Chars.indexOf(clean[i + 3]) : -1
        if (c0 < 0 || c1 < 0) break
        bytes.push((c0 << 2) | (c1 >> 4))
        if (c2 >= 0) bytes.push(((c1 & 15) << 4) | (c2 >> 2))
        if (c3 >= 0) bytes.push(((c2 & 3) << 6) | c3)
    }
    let out = ""
    for (let i = 0; i < bytes.length; ) {
        const b0 = bytes[i++]
        if (b0 < 0x80) {
            out += String.fromCharCode(b0)
        } else if (b0 < 0xe0 && i < bytes.length) {
            out += String.fromCharCode(((b0 & 0x1f) << 6) | (bytes[i++] & 0x3f))
        } else if (b0 < 0xf0 && i + 1 < bytes.length) {
            out += String.fromCharCode(
                ((b0 & 0x0f) << 12) | ((bytes[i++] & 0x3f) << 6) | (bytes[i++] & 0x3f),
            )
        } else if (i + 2 < bytes.length) {
            const cp =
                (((b0 & 0x07) << 18) |
                    ((bytes[i++] & 0x3f) << 12) |
                    ((bytes[i++] & 0x3f) << 6) |
                    (bytes[i++] & 0x3f)) -
                0x10000
            out += String.fromCharCode(0xd800 + (cp >> 10), 0xdc00 + (cp & 0x3ff))
        }
    }
    return out
}

export function pkceVerifierFromHex(hex: string): string {
    let out = ""
    const maxByte = Math.floor(256 / pkceAlphabet.length) * pkceAlphabet.length
    for (let i = 0; i + 1 < hex.length && out.length < 64; i += 2) {
        const byte = parseInt(hex.slice(i, i + 2), 16)
        if (!Number.isNaN(byte) && byte < maxByte) {
            out += pkceAlphabet[byte % pkceAlphabet.length]
        }
    }
    for (let i = 0; i + 1 < hex.length && out.length < 64; i += 2) {
        const byte = parseInt(hex.slice(i, i + 2), 16)
        if (!Number.isNaN(byte)) {
            out += pkceAlphabet[byte % pkceAlphabet.length]
        }
    }
    return out
}

export function encodeForm(params: Record<string, string>): string {
    return Object.entries(params)
        .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`)
        .join("&")
}

export function parseQuery(query: string): Map<string, string> {
    const out = new Map<string, string>()
    const raw = query.startsWith("?") ? query.slice(1) : query
    if (!raw) return out
    for (const part of raw.split("&")) {
        if (!part) continue
        const eq = part.indexOf("=")
        const rawKey = eq >= 0 ? part.slice(0, eq) : part
        const rawVal = eq >= 0 ? part.slice(eq + 1) : ""
        const key = decodeQueryComponent(rawKey)
        if (!out.has(key)) {
            out.set(key, decodeQueryComponent(rawVal))
        }
    }
    return out
}

function decodeQueryComponent(value: string): string {
    const spaced = value.replace(/\+/g, " ")
    try {
        return decodeURIComponent(spaced)
    } catch {
        return spaced
    }
}

export function resolveClientConfig(
    configuredClientId: string | undefined,
    redirectUrl: string,
    state: string,
    defaultClientId: string = backreefClientId,
): { clientId: string; redirectUri: string; malState: string } {
    const trimmed = (configuredClientId ?? "").trim()
    if (trimmed) {
        return {
            clientId: trimmed,
            redirectUri: redirectUrl,
            malState: state,
        }
    }
    if (!defaultClientId) {
        throw codedError("Add a MyAnimeList client ID to this connection.", "needs-auth")
    }
    return {
        clientId: defaultClientId,
        redirectUri: relayUrl,
        malState: base64UrlEncode(JSON.stringify({ r: redirectUrl, s: state })),
    }
}

export function buildAuthorizeUrl(
    configuredClientId: string | undefined,
    redirectUrl: string,
    state: string,
    verifier: string,
    defaultClientId: string = backreefClientId,
): { url: string; data: string } {
    const { clientId, redirectUri, malState } = resolveClientConfig(
        configuredClientId,
        redirectUrl,
        state,
        defaultClientId,
    )
    const query = encodeForm({
        response_type: "code",
        client_id: clientId,
        state: malState,
        redirect_uri: redirectUri,
        code_challenge: verifier,
        code_challenge_method: "plain",
    })
    return {
        url: `https://myanimelist.net/v1/oauth2/authorize?${query}`,
        data: JSON.stringify({ verifier, redirectUri, clientId }),
    }
}

export function parseCompleteQuery(
    query: string,
): { action: "complete"; code: string } | { action: "pending"; result: ConnectCompleteResult } {
    const params = parseQuery(query)
    if (params.has("error")) {
        const desc = (params.get("error_description") ?? params.get("error") ?? "")
            .trim()
            .slice(0, 300)
        throw codedError(desc || "MyAnimeList sign-in failed.", "needs-auth")
    }
    const code = (params.get("code") ?? "").trim()
    if (!code) {
        return { action: "pending", result: { pending: true } }
    }
    return { action: "complete", code }
}

export function isAllowedMalApiUrl(url: string): boolean {
    if (!url.startsWith("https://")) return false
    const rest = url.slice("https://".length)
    let end = rest.length
    for (const sep of ["/", "?", "#"]) {
        const idx = rest.indexOf(sep)
        if (idx >= 0 && idx < end) end = idx
    }
    const authority = rest.slice(0, end)
    return authority === "api.myanimelist.net"
}

export function toCayeStatus(kind: MalKind, listStatus: MalListStatus): TrackerStatus | undefined {
    const repeating = kind === "anime" ? listStatus.is_rewatching : listStatus.is_rereading
    if (repeating) return "in-progress"
    return malToCayeStatus[listStatus.status ?? ""]
}

export function toMalStatus(kind: MalKind, status: TrackerStatus): string {
    return cayeToMalStatus[kind][status]
}

export function fullDate(value: string | null | undefined): string {
    if (typeof value !== "string") return ""
    const trimmed = value.trim()
    return /^\d{4}-\d{2}-\d{2}$/.test(trimmed) ? trimmed : ""
}

export function altTitles(node: MalNode, shown: string | null | undefined): string[] {
    const names = node.alternative_titles
    const out: string[] = []
    for (const name of [names?.en, names?.ja, ...(names?.synonyms ?? [])]) {
        const text = name?.trim().slice(0, 300)
        if (text && text !== shown && !out.includes(text)) out.push(text)
    }
    return out.slice(0, 10)
}

export function entry(
    node: MalNode,
    listStatus: MalListStatus,
    kind: MalKind,
    anilistId: number,
): TrackerEntry {
    const out: TrackerEntry = {
        ref: { ...namespaces[kind], nativeId: String(anilistId) },
        revision: listStatus.updated_at ?? "",
    }
    const status = toCayeStatus(kind, listStatus)
    if (status) out.status = status
    if (typeof listStatus.score === "number" && listStatus.score > 0) {
        out.rating = listStatus.score
    }
    const progress =
        kind === "anime" ? listStatus.num_episodes_watched : listStatus.num_chapters_read
    out.progress = typeof progress === "number" ? progress : 0
    const repeats = kind === "anime" ? listStatus.num_times_rewatched : listStatus.num_times_reread
    out.repeats = typeof repeats === "number" ? repeats : 0
    const title = node.title?.trim().slice(0, 300)
    if (title) out.title = title
    const others = altTitles(node, title)
    if (others.length) out.altTitles = others
    const image = node.main_picture?.medium ?? node.main_picture?.large
    if (image?.startsWith("https://")) out.imageUrl = image
    out.url = `https://myanimelist.net/${kind}/${node.id}`
    const details: string[] = []
    const label = mediaTypeLabels[node.media_type ?? ""]
    if (label) details.push(label)
    const total = kind === "anime" ? node.num_episodes : node.num_chapters
    if (typeof total === "number" && total > 0) {
        out.total = total
        const unit = kind === "anime" ? "episode" : "chapter"
        details.push(`${total} ${unit}${total === 1 ? "" : "s"}`)
    }
    if (details.length) out.details = details
    const year = node.start_season?.year
    if (typeof year === "number" && year > 0 && year <= 9999) out.year = year
    const started = fullDate(listStatus.start_date)
    if (started) out.started = started
    const completed = fullDate(listStatus.finish_date)
    if (completed) out.completed = completed
    return out
}

export function matches(value: TrackerEntry, pushed: TrackerPushEntry["fields"]): boolean {
    return Object.entries(pushed).every(([field, want]) => {
        const have = (value as Record<string, unknown>)[field]
        return (want ?? undefined) === (have ?? undefined)
    })
}

export function newEntryStatus(kind: MalKind, total: number, progress: unknown): string {
    const count = typeof progress === "number" ? progress : 0
    if (count <= 0) return kind === "anime" ? "plan_to_watch" : "plan_to_read"
    if (total > 0 && count >= total) return "completed"
    return kind === "anime" ? "watching" : "reading"
}

export function buildPushForm(
    kind: MalKind,
    total: number,
    hasBefore: boolean,
    pushed: TrackerPushEntry["fields"],
): Record<string, string> {
    const form: Record<string, string> = {}
    if (typeof pushed.status === "string") {
        form.status = toMalStatus(kind, pushed.status as TrackerStatus)
    } else if (!hasBefore) {
        form.status = newEntryStatus(kind, total, pushed.progress)
    }
    if ("rating" in pushed) {
        const raw = pushed.rating == null ? 0 : Math.round(Number(pushed.rating))
        const clamped = Number.isNaN(raw) ? 0 : Math.max(0, Math.min(10, raw))
        form.score = String(clamped)
    }
    if ("progress" in pushed) {
        const raw = pushed.progress == null ? 0 : Math.round(Number(pushed.progress))
        const count = Number.isNaN(raw) ? 0 : Math.max(0, raw)
        const key = kind === "anime" ? "num_watched_episodes" : "num_chapters_read"
        form[key] = String(count)
    }
    if ("repeats" in pushed) {
        const raw = pushed.repeats == null ? 0 : Math.round(Number(pushed.repeats))
        const count = Number.isNaN(raw) ? 0 : Math.max(0, raw)
        const key = kind === "anime" ? "num_times_rewatched" : "num_times_reread"
        form[key] = String(count)
    }
    if ("started" in pushed) {
        form.start_date = fullDate(typeof pushed.started === "string" ? pushed.started : "")
    }
    if ("completed" in pushed) {
        form.finish_date = fullDate(typeof pushed.completed === "string" ? pushed.completed : "")
    }
    return form
}

export function safeMalError(body: string, fallback: string): string {
    try {
        const parsed = body ? JSON.parse(body) : {}
        const msg =
            (typeof parsed.error_description === "string" && parsed.error_description) ||
            (typeof parsed.message === "string" && parsed.message) ||
            (typeof parsed.error === "string" && parsed.error) ||
            ""
        const clean = msg.trim().slice(0, 300)
        return clean || fallback
    } catch {
        return fallback
    }
}
