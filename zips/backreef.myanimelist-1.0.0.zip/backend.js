(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // src/mal.ts
  var backreefClientId = "";
  var relayUrl = "https://backreef.github.io/extensions/oauth/";
  var namespaces = {
    anime: { providerId: "caye.movies-shows:anilist", type: "anime" },
    manga: { providerId: "backreef.myanimelist:tracker", type: "manga" }
  };
  var trackedFields = [
    "status",
    "rating",
    "progress",
    "started",
    "completed",
    "repeats"
  ];
  var mediaTypeLabels = {
    tv: "TV",
    tv_special: "TV special",
    ova: "OVA",
    movie: "Movie",
    special: "Special",
    ona: "ONA",
    music: "Music",
    cm: "CM",
    pv: "PV",
    manga: "Manga",
    novel: "Novel",
    light_novel: "Light novel",
    one_shot: "One-shot",
    doujinshi: "Doujinshi",
    manhwa: "Manhwa",
    manhua: "Manhua",
    oel: "OEL"
  };
  var malToCayeStatus = {
    watching: "in-progress",
    reading: "in-progress",
    plan_to_watch: "planning",
    plan_to_read: "planning",
    completed: "completed",
    on_hold: "paused",
    dropped: "dropped"
  };
  var cayeToMalStatus = {
    anime: {
      "in-progress": "watching",
      planning: "plan_to_watch",
      completed: "completed",
      paused: "on_hold",
      dropped: "dropped"
    },
    manga: {
      "in-progress": "reading",
      planning: "plan_to_read",
      completed: "completed",
      paused: "on_hold",
      dropped: "dropped"
    }
  };
  var pkceAlphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-._~";
  var base64Chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
  function codedError(message, code, extra) {
    return Object.assign(new Error(message), __spreadValues({ code }, extra));
  }
  function utf8Bytes(text) {
    const out = [];
    for (let i = 0; i < text.length; i++) {
      let code = text.charCodeAt(i);
      if (code >= 55296 && code <= 56319 && i + 1 < text.length) {
        const next = text.charCodeAt(i + 1);
        if (next >= 56320 && next <= 57343) {
          code = 65536 + (code - 55296 << 10) + (next - 56320);
          i++;
        }
      }
      if (code < 128) {
        out.push(code);
      } else if (code < 2048) {
        out.push(192 | code >> 6, 128 | code & 63);
      } else if (code < 65536) {
        out.push(224 | code >> 12, 128 | code >> 6 & 63, 128 | code & 63);
      } else {
        out.push(
          240 | code >> 18,
          128 | code >> 12 & 63,
          128 | code >> 6 & 63,
          128 | code & 63
        );
      }
    }
    return out;
  }
  function base64UrlEncode(text) {
    const bytes = utf8Bytes(text);
    let out = "";
    for (let i = 0; i < bytes.length; i += 3) {
      const b0 = bytes[i];
      const has1 = i + 1 < bytes.length;
      const has2 = i + 2 < bytes.length;
      const b1 = has1 ? bytes[i + 1] : 0;
      const b2 = has2 ? bytes[i + 2] : 0;
      const n = b0 << 16 | b1 << 8 | b2;
      out += base64Chars[n >> 18 & 63];
      out += base64Chars[n >> 12 & 63];
      if (has1) out += base64Chars[n >> 6 & 63];
      if (has2) out += base64Chars[n & 63];
    }
    return out.replace(/\+/g, "-").replace(/\//g, "_");
  }
  function pkceVerifierFromHex(hex) {
    let out = "";
    const maxByte = Math.floor(256 / pkceAlphabet.length) * pkceAlphabet.length;
    for (let i = 0; i + 1 < hex.length && out.length < 64; i += 2) {
      const byte = parseInt(hex.slice(i, i + 2), 16);
      if (!Number.isNaN(byte) && byte < maxByte) {
        out += pkceAlphabet[byte % pkceAlphabet.length];
      }
    }
    for (let i = 0; i + 1 < hex.length && out.length < 64; i += 2) {
      const byte = parseInt(hex.slice(i, i + 2), 16);
      if (!Number.isNaN(byte)) {
        out += pkceAlphabet[byte % pkceAlphabet.length];
      }
    }
    return out;
  }
  function encodeForm(params) {
    return Object.entries(params).map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(v)}`).join("&");
  }
  function parseQuery(query) {
    const out = /* @__PURE__ */ new Map();
    const raw = query.startsWith("?") ? query.slice(1) : query;
    if (!raw) return out;
    for (const part of raw.split("&")) {
      if (!part) continue;
      const eq = part.indexOf("=");
      const rawKey = eq >= 0 ? part.slice(0, eq) : part;
      const rawVal = eq >= 0 ? part.slice(eq + 1) : "";
      const key = decodeQueryComponent(rawKey);
      if (!out.has(key)) {
        out.set(key, decodeQueryComponent(rawVal));
      }
    }
    return out;
  }
  function decodeQueryComponent(value) {
    const spaced = value.replace(/\+/g, " ");
    try {
      return decodeURIComponent(spaced);
    } catch (e) {
      return spaced;
    }
  }
  function resolveClientConfig(configuredClientId, redirectUrl, state, defaultClientId = backreefClientId) {
    const trimmed = (configuredClientId != null ? configuredClientId : "").trim();
    if (trimmed) {
      return {
        clientId: trimmed,
        redirectUri: redirectUrl,
        malState: state
      };
    }
    if (!defaultClientId) {
      throw codedError("Add a MyAnimeList client ID to this connection.", "needs-auth");
    }
    return {
      clientId: defaultClientId,
      redirectUri: relayUrl,
      malState: base64UrlEncode(JSON.stringify({ r: redirectUrl, s: state }))
    };
  }
  function buildAuthorizeUrl(configuredClientId, redirectUrl, state, verifier, defaultClientId = backreefClientId) {
    const { clientId, redirectUri, malState } = resolveClientConfig(
      configuredClientId,
      redirectUrl,
      state,
      defaultClientId
    );
    const query = encodeForm({
      response_type: "code",
      client_id: clientId,
      state: malState,
      redirect_uri: redirectUri,
      code_challenge: verifier,
      code_challenge_method: "plain"
    });
    return {
      url: `https://myanimelist.net/v1/oauth2/authorize?${query}`,
      data: JSON.stringify({ verifier, redirectUri, clientId })
    };
  }
  function parseCompleteQuery(query) {
    var _a, _b, _c;
    const params = parseQuery(query);
    if (params.has("error")) {
      const desc = ((_b = (_a = params.get("error_description")) != null ? _a : params.get("error")) != null ? _b : "").trim().slice(0, 300);
      throw codedError(desc || "MyAnimeList sign-in failed.", "needs-auth");
    }
    const code = ((_c = params.get("code")) != null ? _c : "").trim();
    if (!code) {
      return { action: "pending", result: { pending: true } };
    }
    return { action: "complete", code };
  }
  function isAllowedMalApiUrl(url) {
    if (!url.startsWith("https://")) return false;
    const rest = url.slice("https://".length);
    let end = rest.length;
    for (const sep of ["/", "?", "#"]) {
      const idx = rest.indexOf(sep);
      if (idx >= 0 && idx < end) end = idx;
    }
    const authority = rest.slice(0, end);
    return authority === "api.myanimelist.net";
  }
  function toCayeStatus(kind, listStatus) {
    var _a;
    const repeating = kind === "anime" ? listStatus.is_rewatching : listStatus.is_rereading;
    if (repeating) return "in-progress";
    return malToCayeStatus[(_a = listStatus.status) != null ? _a : ""];
  }
  function toMalStatus(kind, status) {
    return cayeToMalStatus[kind][status];
  }
  function fullDate(value) {
    if (typeof value !== "string") return "";
    const trimmed = value.trim();
    return /^\d{4}-\d{2}-\d{2}$/.test(trimmed) ? trimmed : "";
  }
  function altTitles(node, shown) {
    var _a;
    const names = node.alternative_titles;
    const out = [];
    for (const name of [names == null ? void 0 : names.en, names == null ? void 0 : names.ja, ...(_a = names == null ? void 0 : names.synonyms) != null ? _a : []]) {
      const text = name == null ? void 0 : name.trim().slice(0, 300);
      if (text && text !== shown && !out.includes(text)) out.push(text);
    }
    return out.slice(0, 10);
  }
  function entry(node, listStatus, kind, anilistId) {
    var _a, _b, _c, _d, _e, _f, _g;
    const out = {
      ref: __spreadProps(__spreadValues({}, namespaces[kind]), { nativeId: String(anilistId) }),
      revision: (_a = listStatus.updated_at) != null ? _a : ""
    };
    const status = toCayeStatus(kind, listStatus);
    if (status) out.status = status;
    if (typeof listStatus.score === "number" && listStatus.score > 0) {
      out.rating = listStatus.score;
    }
    const progress = kind === "anime" ? listStatus.num_episodes_watched : listStatus.num_chapters_read;
    out.progress = typeof progress === "number" ? progress : 0;
    const repeats = kind === "anime" ? listStatus.num_times_rewatched : listStatus.num_times_reread;
    out.repeats = typeof repeats === "number" ? repeats : 0;
    const title = (_b = node.title) == null ? void 0 : _b.trim().slice(0, 300);
    if (title) out.title = title;
    const others = altTitles(node, title);
    if (others.length) out.altTitles = others;
    const image = (_e = (_c = node.main_picture) == null ? void 0 : _c.medium) != null ? _e : (_d = node.main_picture) == null ? void 0 : _d.large;
    if (image == null ? void 0 : image.startsWith("https://")) out.imageUrl = image;
    out.url = `https://myanimelist.net/${kind}/${node.id}`;
    const details = [];
    const label = mediaTypeLabels[(_f = node.media_type) != null ? _f : ""];
    if (label) details.push(label);
    const total = kind === "anime" ? node.num_episodes : node.num_chapters;
    if (typeof total === "number" && total > 0) {
      out.total = total;
      const unit = kind === "anime" ? "episode" : "chapter";
      details.push(`${total} ${unit}${total === 1 ? "" : "s"}`);
    }
    if (details.length) out.details = details;
    const year = (_g = node.start_season) == null ? void 0 : _g.year;
    if (typeof year === "number" && year > 0 && year <= 9999) out.year = year;
    const started = fullDate(listStatus.start_date);
    if (started) out.started = started;
    const completed = fullDate(listStatus.finish_date);
    if (completed) out.completed = completed;
    return out;
  }
  function matches(value, pushed) {
    return Object.entries(pushed).every(([field, want]) => {
      const have = value[field];
      return (want != null ? want : void 0) === (have != null ? have : void 0);
    });
  }
  function newEntryStatus(kind, total, progress) {
    const count = typeof progress === "number" ? progress : 0;
    if (count <= 0) return kind === "anime" ? "plan_to_watch" : "plan_to_read";
    if (total > 0 && count >= total) return "completed";
    return kind === "anime" ? "watching" : "reading";
  }
  function buildPushForm(kind, total, hasBefore, pushed) {
    const form = {};
    if (typeof pushed.status === "string") {
      form.status = toMalStatus(kind, pushed.status);
    } else if (!hasBefore) {
      form.status = newEntryStatus(kind, total, pushed.progress);
    }
    if ("rating" in pushed) {
      const raw = pushed.rating == null ? 0 : Math.round(Number(pushed.rating));
      const clamped = Number.isNaN(raw) ? 0 : Math.max(0, Math.min(10, raw));
      form.score = String(clamped);
    }
    if ("progress" in pushed) {
      const raw = pushed.progress == null ? 0 : Math.round(Number(pushed.progress));
      const count = Number.isNaN(raw) ? 0 : Math.max(0, raw);
      const key = kind === "anime" ? "num_watched_episodes" : "num_chapters_read";
      form[key] = String(count);
    }
    if ("repeats" in pushed) {
      const raw = pushed.repeats == null ? 0 : Math.round(Number(pushed.repeats));
      const count = Number.isNaN(raw) ? 0 : Math.max(0, raw);
      const key = kind === "anime" ? "num_times_rewatched" : "num_times_reread";
      form[key] = String(count);
    }
    if ("started" in pushed) {
      form.start_date = fullDate(typeof pushed.started === "string" ? pushed.started : "");
    }
    if ("completed" in pushed) {
      form.finish_date = fullDate(typeof pushed.completed === "string" ? pushed.completed : "");
    }
    return form;
  }
  function safeMalError(body, fallback) {
    try {
      const parsed = body ? JSON.parse(body) : {};
      const msg = typeof parsed.error_description === "string" && parsed.error_description || typeof parsed.message === "string" && parsed.message || typeof parsed.error === "string" && parsed.error || "";
      const clean = msg.trim().slice(0, 300);
      return clean || fallback;
    } catch (e) {
      return fallback;
    }
  }

  // src/backend.ts
  var malApiBase = "https://api.myanimelist.net/v2";
  var malTokenUrl = "https://myanimelist.net/v1/oauth2/token";
  var anilistGraphqlUrl = "https://graphql.anilist.co";
  var callBudget = 2e4;
  var refreshWindowMs = 5 * 60 * 1e3;
  var foundCacheSeconds = 30 * 24 * 60 * 60;
  var missingCacheSeconds = 7 * 24 * 60 * 60;
  var animeListFields = "list_status{status,score,num_episodes_watched,is_rewatching,num_times_rewatched,start_date,finish_date,updated_at},num_episodes,media_type,start_season,alternative_titles,main_picture,title";
  var mangaListFields = "list_status{status,score,num_chapters_read,is_rereading,num_times_reread,start_date,finish_date,updated_at},num_chapters,media_type,alternative_titles,main_picture,title";
  var animeDetailFields = "my_list_status{status,score,num_episodes_watched,is_rewatching,num_times_rewatched,start_date,finish_date,updated_at},num_episodes,media_type,start_season,alternative_titles,main_picture,title";
  var mangaDetailFields = "my_list_status{status,score,num_chapters_read,is_rereading,num_times_reread,start_date,finish_date,updated_at},num_chapters,media_type,alternative_titles,main_picture,title";
  var malBlockedUntil = 0;
  var anilistBlockedUntil = 0;
  var deadline = 0;
  function startCall() {
    deadline = Date.now() + callBudget;
  }
  function limited(provider, waitMs) {
    return codedError(`${provider} rate limit reached.`, "rate-limited", {
      retry_after: Math.max(1, Math.ceil(waitMs / 1e3))
    });
  }
  function waitForLimit(provider, blockedUntil) {
    return __async(this, null, function* () {
      const wait = blockedUntil - Date.now();
      if (wait <= 0) return;
      if (Date.now() + wait > deadline) throw limited(provider, wait);
      yield caye.sleep(wait);
    });
  }
  function resetAt(headers) {
    var _a, _b;
    const retry = parseInt((_a = headers["retry-after"]) != null ? _a : "", 10);
    if (!Number.isNaN(retry)) return Date.now() + (retry + 1) * 1e3;
    const reset = parseInt((_b = headers["x-ratelimit-reset"]) != null ? _b : "", 10);
    if (!Number.isNaN(reset) && reset > 0) return reset * 1e3;
    return Date.now() + 6e4;
  }
  function postToken(params) {
    return __async(this, null, function* () {
      var _a;
      let response;
      try {
        response = yield caye.http({
          url: malTokenUrl,
          method: "POST",
          headers: {
            "Content-Type": "application/x-www-form-urlencoded",
            Accept: "application/json"
          },
          body: encodeForm(params)
        });
      } catch (e) {
        throw codedError("MyAnimeList sign-in did not answer.", "needs-auth");
      }
      if (response.status < 200 || response.status >= 300) {
        throw codedError(
          safeMalError((_a = response.body) != null ? _a : "", "MyAnimeList rejected the sign-in."),
          "needs-auth"
        );
      }
      const parsed = response.body ? JSON.parse(response.body) : {};
      if (!parsed.access_token || !parsed.refresh_token) {
        throw codedError("MyAnimeList returned an incomplete token.", "needs-auth");
      }
      return parsed;
    });
  }
  function parseStoredAuth(raw) {
    try {
      const parsed = JSON.parse(raw);
      if (typeof parsed.access === "string" && parsed.access && typeof parsed.refresh === "string" && parsed.refresh) {
        return {
          access: parsed.access,
          refresh: parsed.refresh,
          expiresAt: typeof parsed.expiresAt === "number" ? parsed.expiresAt : 0,
          clientId: typeof parsed.clientId === "string" ? parsed.clientId : ""
        };
      }
      return null;
    } catch (e) {
      return null;
    }
  }
  function loadAuthSession(context) {
    return __async(this, null, function* () {
      if (!context.config.account) {
        throw codedError("Sign in to MyAnimeList.", "needs-auth");
      }
      const secretText = yield caye.secret(context.config.account);
      const baseAuth = parseStoredAuth(secretText);
      if (!baseAuth) {
        throw codedError("Sign in to MyAnimeList.", "needs-auth");
      }
      const hash = yield caye.crypto.hash({
        algorithm: "sha256",
        data: baseAuth.refresh,
        encoding: "text",
        output: "hex"
      });
      const recordKey = `token:${hash.value.slice(0, 32)}`;
      let current = baseAuth;
      try {
        const record = yield caye.records.get({ key: recordKey, scope: "connection" });
        if (record.value.kind === "text") {
          const stored = parseStoredAuth(record.value.text);
          if (stored) current = stored;
        }
      } catch (e) {
        current = baseAuth;
      }
      const session = { recordKey, auth: current };
      if (session.auth.expiresAt <= Date.now() + refreshWindowMs) {
        yield refreshSession(context, session);
      }
      return session;
    });
  }
  function refreshSession(context, session) {
    return __async(this, null, function* () {
      var _a, _b;
      const clientId = session.auth.clientId || ((_a = context.config.clientId) != null ? _a : "").trim() || backreefClientId;
      if (!clientId) {
        throw codedError("Add a MyAnimeList client ID to this connection.", "needs-auth");
      }
      const token = yield postToken({
        client_id: clientId,
        grant_type: "refresh_token",
        refresh_token: session.auth.refresh
      });
      const next = {
        access: token.access_token,
        refresh: token.refresh_token,
        expiresAt: Date.now() + Math.max(0, Number((_b = token.expires_in) != null ? _b : 0)) * 1e3,
        clientId
      };
      session.auth = next;
      yield caye.records.set({
        key: session.recordKey,
        value: { kind: "text", text: JSON.stringify(next) },
        scope: "connection"
      });
    });
  }
  function malRequest(context, session, method, url, body, allowNotFound = false) {
    return __async(this, null, function* () {
      var _a, _b;
      let refreshed = false;
      for (let attempt = 0; ; attempt++) {
        yield waitForLimit("MyAnimeList", malBlockedUntil);
        const headers = {
          Authorization: `Bearer ${session.auth.access}`,
          Accept: "application/json"
        };
        if (body !== void 0) {
          headers["Content-Type"] = "application/x-www-form-urlencoded";
        }
        const response = yield caye.http({ url, method, headers, body });
        if (response.status === 401) {
          if (refreshed) {
            throw codedError("MyAnimeList rejected the access token.", "needs-auth");
          }
          refreshed = true;
          yield refreshSession(context, session);
          continue;
        }
        if (response.status === 403) {
          throw codedError("MyAnimeList rejected the access token.", "needs-auth");
        }
        if (response.status === 429) {
          malBlockedUntil = Math.max(malBlockedUntil, resetAt(response.headers));
          if (attempt >= 3) throw limited("MyAnimeList", malBlockedUntil - Date.now());
          continue;
        }
        if (allowNotFound && response.status === 404) {
          return { status: 404, body: (_a = response.body) != null ? _a : "" };
        }
        if (response.status < 200 || response.status >= 300) {
          throw codedError("MyAnimeList did not answer.", "unavailable");
        }
        return { status: response.status, body: (_b = response.body) != null ? _b : "" };
      }
    });
  }
  function anilistGraphql(query, variables) {
    return __async(this, null, function* () {
      for (let attempt = 0; ; attempt++) {
        yield waitForLimit("AniList", anilistBlockedUntil);
        const response = yield caye.http({
          url: anilistGraphqlUrl,
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Accept: "application/json"
          },
          body: JSON.stringify({ query, variables })
        });
        if (response.status === 429) {
          anilistBlockedUntil = Math.max(anilistBlockedUntil, resetAt(response.headers));
          if (attempt >= 3) throw limited("AniList", anilistBlockedUntil - Date.now());
          continue;
        }
        if (response.headers["x-ratelimit-remaining"] === "0") {
          anilistBlockedUntil = Math.max(anilistBlockedUntil, resetAt(response.headers));
        }
        const parsed = response.body ? JSON.parse(response.body) : {};
        if (response.status !== 200 || parsed.errors) {
          throw codedError("AniList did not answer.", "unavailable");
        }
        return parsed.data;
      }
    });
  }
  function cacheKey(direction, kind, id) {
    return `${direction}:${kind}:${id}`;
  }
  function readCachedId(key) {
    return __async(this, null, function* () {
      const cached = yield caye.cache.get({ key });
      if (cached && cached.kind === "number") return cached.number;
      return void 0;
    });
  }
  function writeCachedId(key, id) {
    return __async(this, null, function* () {
      yield caye.cache.set({
        key,
        value: { kind: "number", number: id },
        ttlSeconds: id > 0 ? foundCacheSeconds : missingCacheSeconds
      });
    });
  }
  function mapMalToAniList(kind, malIds) {
    return __async(this, null, function* () {
      var _a, _b, _c;
      const out = /* @__PURE__ */ new Map();
      const missing = [];
      for (const malId of malIds) {
        if (out.has(malId)) continue;
        const cached = yield readCachedId(cacheKey("mal2al", kind, malId));
        if (cached !== void 0) {
          if (cached > 0) out.set(malId, cached);
        } else {
          out.set(malId, 0);
          missing.push(malId);
        }
      }
      const mediaType = kind === "anime" ? "ANIME" : "MANGA";
      for (let i = 0; i < missing.length; i += 50) {
        const chunk = missing.slice(i, i + 50);
        const data = yield anilistGraphql(
          `query($ids:[Int]){Page(perPage:50){media(idMal_in:$ids,type:${mediaType}){id idMal}}}`,
          { ids: chunk }
        );
        const found = /* @__PURE__ */ new Map();
        for (const item of (_b = (_a = data.Page) == null ? void 0 : _a.media) != null ? _b : []) {
          if (typeof item.idMal === "number" && typeof item.id === "number" && item.idMal > 0 && item.id > 0) {
            if (!found.has(item.idMal)) found.set(item.idMal, item.id);
          }
        }
        for (const malId of chunk) {
          const alId = (_c = found.get(malId)) != null ? _c : 0;
          yield writeCachedId(cacheKey("mal2al", kind, malId), alId);
          if (alId > 0) {
            out.set(malId, alId);
            yield writeCachedId(cacheKey("al2mal", kind, alId), malId);
          } else {
            out.delete(malId);
          }
        }
      }
      for (const [k, v] of out.entries()) {
        if (v <= 0) out.delete(k);
      }
      return out;
    });
  }
  function mapAniListToMal(kind, anilistIds) {
    return __async(this, null, function* () {
      var _a, _b, _c;
      const out = /* @__PURE__ */ new Map();
      const missing = [];
      for (const alId of anilistIds) {
        if (out.has(alId)) continue;
        const cached = yield readCachedId(cacheKey("al2mal", kind, alId));
        if (cached !== void 0) {
          if (cached > 0) out.set(alId, cached);
        } else {
          out.set(alId, 0);
          missing.push(alId);
        }
      }
      const mediaType = kind === "anime" ? "ANIME" : "MANGA";
      for (let i = 0; i < missing.length; i += 50) {
        const chunk = missing.slice(i, i + 50);
        const data = yield anilistGraphql(
          `query($ids:[Int]){Page(perPage:50){media(id_in:$ids,type:${mediaType}){id idMal}}}`,
          { ids: chunk }
        );
        const found = /* @__PURE__ */ new Map();
        for (const item of (_b = (_a = data.Page) == null ? void 0 : _a.media) != null ? _b : []) {
          if (typeof item.id === "number" && typeof item.idMal === "number" && item.id > 0 && item.idMal > 0) {
            if (!found.has(item.id)) found.set(item.id, item.idMal);
          }
        }
        for (const alId of chunk) {
          const malId = (_c = found.get(alId)) != null ? _c : 0;
          yield writeCachedId(cacheKey("al2mal", kind, alId), malId);
          if (malId > 0) {
            out.set(alId, malId);
            yield writeCachedId(cacheKey("mal2al", kind, malId), alId);
          } else {
            out.delete(alId);
          }
        }
      }
      for (const [k, v] of out.entries()) {
        if (v <= 0) out.delete(k);
      }
      return out;
    });
  }
  function fetchUserList(context, session, kind) {
    return __async(this, null, function* () {
      var _a, _b;
      const listFields = kind === "anime" ? animeListFields : mangaListFields;
      let nextUrl = `${malApiBase}/users/@me/${kind}list?fields=${encodeURIComponent(listFields)}&limit=1000&nsfw=true`;
      const items = [];
      const visited = /* @__PURE__ */ new Set();
      while (nextUrl) {
        if (!isAllowedMalApiUrl(nextUrl) || visited.has(nextUrl)) break;
        visited.add(nextUrl);
        const res = yield malRequest(context, session, "GET", nextUrl);
        const page = res.body ? JSON.parse(res.body) : {};
        for (const item of (_a = page.data) != null ? _a : []) {
          if ((item == null ? void 0 : item.node) && (item == null ? void 0 : item.list_status)) items.push(item);
        }
        const candidate = (_b = page.paging) == null ? void 0 : _b.next;
        nextUrl = candidate && isAllowedMalApiUrl(candidate) ? candidate : void 0;
      }
      return items;
    });
  }
  function pushOne(context, session, pushed, alToMal) {
    return __async(this, null, function* () {
      var _a, _b, _c;
      const kind = Object.keys(namespaces).find((k) => {
        const ns = namespaces[k];
        return pushed.ref.providerId === ns.providerId && pushed.ref.type === ns.type;
      });
      const anilistId = Number(pushed.ref.nativeId);
      if (!kind || !/^[1-9]\d*$/.test(pushed.ref.nativeId) || !Number.isInteger(anilistId) || anilistId > 2147483647) {
        return {
          ref: pushed.ref,
          outcome: "unsupported",
          reason: "The entry is not an AniList anime or manga."
        };
      }
      const malId = alToMal[kind].get(anilistId);
      if (!malId) {
        return {
          ref: pushed.ref,
          outcome: "unsupported",
          reason: "No MyAnimeList entry matches this title."
        };
      }
      const fieldsParam = kind === "anime" ? animeDetailFields : mangaDetailFields;
      const detailUrl = `${malApiBase}/${kind}/${malId}?fields=${encodeURIComponent(fieldsParam)}`;
      const detailRes = yield malRequest(context, session, "GET", detailUrl, void 0, true);
      if (detailRes.status === 404) {
        return {
          ref: pushed.ref,
          outcome: "unsupported",
          reason: "The entry is not on MyAnimeList."
        };
      }
      const detail = detailRes.body ? JSON.parse(detailRes.body) : {};
      const before = (_a = detail.my_list_status) != null ? _a : null;
      if (before) {
        const remote = entry(detail, before, kind, anilistId);
        if (matches(remote, pushed.fields)) {
          return {
            ref: pushed.ref,
            outcome: "applied",
            revision: remote.revision
          };
        }
        if (pushed.baseRevision !== "" && remote.revision !== pushed.baseRevision) {
          return {
            ref: pushed.ref,
            outcome: "conflict",
            remote
          };
        }
      }
      const statusUrl = `${malApiBase}/${kind}/${malId}/my_list_status`;
      if ("status" in pushed.fields && pushed.fields.status === null) {
        if (before) {
          yield malRequest(context, session, "DELETE", statusUrl, void 0, true);
        }
        return { ref: pushed.ref, outcome: "applied", revision: "" };
      }
      const total = (_b = kind === "anime" ? detail.num_episodes : detail.num_chapters) != null ? _b : 0;
      const form = buildPushForm(kind, total, Boolean(before), pushed.fields);
      const patchRes = yield malRequest(context, session, "PATCH", statusUrl, encodeForm(form));
      const saved = patchRes.body ? JSON.parse(patchRes.body) : {};
      return {
        ref: pushed.ref,
        outcome: "applied",
        revision: String((_c = saved.updated_at) != null ? _c : "")
      };
    });
  }
  caye.register("backreef.myanimelist:tracker", {
    connect: {
      start(context, input) {
        return __async(this, null, function* () {
          const rand = yield caye.crypto.random({ bytes: 128, output: "hex" });
          const verifier = pkceVerifierFromHex(rand.value);
          return buildAuthorizeUrl(
            context.config.clientId,
            input.redirectUrl,
            input.state,
            verifier
          );
        });
      },
      complete(_context, input) {
        return __async(this, null, function* () {
          var _a;
          const parsed = parseCompleteQuery(input.query);
          if (parsed.action === "pending") return parsed.result;
          let flow;
          try {
            flow = JSON.parse(input.data);
          } catch (e) {
            throw codedError("MyAnimeList sign-in state is invalid.", "needs-auth");
          }
          if (!flow.verifier || !flow.redirectUri || !flow.clientId) {
            throw codedError("MyAnimeList sign-in state is incomplete.", "needs-auth");
          }
          const token = yield postToken({
            client_id: flow.clientId,
            grant_type: "authorization_code",
            code: parsed.code,
            redirect_uri: flow.redirectUri,
            code_verifier: flow.verifier
          });
          const stored = {
            access: token.access_token,
            refresh: token.refresh_token,
            expiresAt: Date.now() + Math.max(0, Number((_a = token.expires_in) != null ? _a : 0)) * 1e3,
            clientId: flow.clientId
          };
          return { value: JSON.stringify(stored) };
        });
      }
    },
    tracker: {
      pull(context) {
        return __async(this, null, function* () {
          startCall();
          const session = yield loadAuthSession(context);
          const entries = [];
          for (const kind of Object.keys(namespaces)) {
            const list = yield fetchUserList(context, session, kind);
            const malIds = list.map((item) => item.node.id).filter((id) => id > 0);
            const malToAl = yield mapMalToAniList(kind, malIds);
            const seen = /* @__PURE__ */ new Set();
            for (const item of list) {
              const anilistId = malToAl.get(item.node.id);
              if (!anilistId || seen.has(anilistId)) continue;
              seen.add(anilistId);
              entries.push(entry(item.node, item.list_status, kind, anilistId));
            }
          }
          return {
            entries,
            fields: trackedFields,
            ratingStep: 1,
            ratingMax: 10,
            datePrecision: "day"
          };
        });
      },
      push(context, input) {
        return __async(this, null, function* () {
          startCall();
          const session = yield loadAuthSession(context);
          const idsByKind = { anime: [], manga: [] };
          for (const pushed of input.entries) {
            const kind = Object.keys(namespaces).find((k) => {
              const ns = namespaces[k];
              return pushed.ref.providerId === ns.providerId && pushed.ref.type === ns.type;
            });
            const anilistId = Number(pushed.ref.nativeId);
            if (kind && /^[1-9]\d*$/.test(pushed.ref.nativeId) && Number.isInteger(anilistId) && anilistId > 0 && anilistId <= 2147483647) {
              idsByKind[kind].push(anilistId);
            }
          }
          const alToMal = {
            anime: yield mapAniListToMal("anime", idsByKind.anime),
            manga: yield mapAniListToMal("manga", idsByKind.manga)
          };
          const entries = [];
          for (const pushed of input.entries) {
            entries.push(yield pushOne(context, session, pushed, alToMal));
          }
          return { entries };
        });
      }
    }
  });
})();
//# sourceMappingURL=backend.js.map
