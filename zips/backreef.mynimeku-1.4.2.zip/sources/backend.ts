import type {
    API,
    Context,
    Query,
    Ref,
    Source,
    SourceInstallment,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
    SourceResolveInput,
} from "../../../../packages/plugin-sdk/src/index"
import {
    choiceId,
    extractFirstYear,
    firstText,
    futureDeadline,
    limitItems,
    parseEpisodeNumber,
    sameRef,
    streamOriginOf,
    uniqueChoices,
    videoRef,
} from "../../stream-common/src/common"
import { failure, httpClient } from "../../../../packages/plugin-std/src/http.ts"
import { cleanBaseUrl, resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.mynimeku:source"
const providerName = "MyNimeKu"
const site = httpClient(caye, providerName)
const defaultBaseUrl = "https://www.mynimeku.com"

type LiveSearchItem = {
    type?: string
    title?: string
    url?: string
}

type ServerCandidate = {
    id: string
    url: string
    host: string
    serverId: string
    quality: string
    resolution: number
}

function siteBase(context: Context): string {
    return cleanBaseUrl(context?.config?.url, defaultBaseUrl)
}

function pathOf(rawUrl: string, base: string): string {
    const resolved = resolveUrl(rawUrl, base)
    if (!resolved) return ""
    try {
        return new URL(resolved).pathname.replace(/^\/+|\/+$/g, "")
    } catch {
        return ""
    }
}

async function fetchCandidates(base: string, epPath: string): Promise<ServerCandidate[]> {
    const epUrl = `${base}/${epPath}/`
    const html = await site.text({ url: epUrl, headers: { Referer: `${base}/` } })
    const doc = caye.html.parse(html)
    const out: ServerCandidate[] = []
    doc.find("button.mynimeku-episode-server-btn").each((index, el) => {
        const rawUrl = (el.attr("data-player-url") ?? "").trim()
        const resolved = resolveUrl(rawUrl, epUrl)
        if (!resolved) return
        const host = (el.attr("data-player-host") || el.text() || "Default").trim()
        const resMatch = /(\d+)p\b/i.exec(host)
        const resolution = resMatch ? Number.parseInt(resMatch[1], 10) : 0
        const quality = resolution ? `${resolution}p` : "auto"
        const serverLabel = host.replace(/\s*\d+p\b/gi, "").trim() || "Default"
        const serverId = choiceId(serverLabel, "default")
        out.push({
            id: `${index}:${serverId}:${quality}`,
            url: resolved,
            host,
            serverId,
            quality,
            resolution,
        })
    })
    out.sort((a, b) => b.resolution - a.resolution)
    return out
}

caye.register(providerId, {
    source: {
        async search(context: Context, query: Query): Promise<SourceRecords> {
            const base = siteBase(context)
            const q = (query?.q ?? "").trim()
            if (!q) return { items: [], nextCursor: "", state: "complete" }

            const homeHtml = await site.text({ url: `${base}/` })
            const homeDoc = caye.html.parse(homeHtml)
            const nonce = (
                homeDoc.find("form[data-live-search-form]").first().attr("data-nonce") ?? ""
            ).trim()
            if (!nonce) {
                throw failure("unavailable", `${providerName} live-search nonce was not found`)
            }

            const body = new URLSearchParams({
                action: "mynimeku_live_search",
                nonce,
                keyword: q,
            }).toString()
            const payload = await site.json<{
                success?: boolean
                data?: { items?: LiveSearchItem[] }
            }>({
                url: `${base}/wp-admin/admin-ajax.php`,
                method: "POST",
                headers: {
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
                    Origin: base,
                    Referer: `${base}/`,
                },
                body,
            })

            const rawItems = payload?.success === false ? [] : (payload?.data?.items ?? [])
            const items: SourceRecord[] = []
            const seen = new Set<string>()
            for (const item of rawItems) {
                if (!item || item.type === "MANGA" || typeof item.url !== "string") continue
                if (!item.url.includes("/series/")) continue
                const nativeId = pathOf(item.url, base)
                const title = (item.title ?? "").trim()
                if (!nativeId || !title || nativeId.length > 200 || seen.has(nativeId)) continue
                seen.add(nativeId)
                const year = extractFirstYear(title)
                items.push({
                    ref: videoRef(providerId, nativeId),
                    name: title,
                    ...(year !== undefined ? { year } : {}),
                })
            }
            return {
                items: limitItems(items, query?.limit),
                nextCursor: "",
                state: "complete",
            }
        },

        async read(context: Context, ref: Ref): Promise<SourceRecord> {
            const base = siteBase(context)
            const html = await site.text({
                url: `${base}/${ref.nativeId}/`,
                headers: { Referer: `${base}/` },
            })
            const doc = caye.html.parse(html)
            const name = firstText(doc, ["h1.komik-series-title", "h1.entry-title", "h1", "title"])
                .replace(/\s*[-|]\s*MyNimeKu.*$/i, "")
                .trim()
            if (!name) {
                throw failure("unavailable", `${providerName} title was not found`)
            }
            const year = extractFirstYear(name)
            return {
                ref: sameRef(ref),
                name,
                ...(year !== undefined ? { year } : {}),
            }
        },

        async list(context: Context, ref: Ref): Promise<SourceListResult> {
            const base = siteBase(context)
            const seriesUrl = `${base}/${ref.nativeId}/`
            const html = await site.text({ url: seriesUrl, headers: { Referer: `${base}/` } })
            const doc = caye.html.parse(html)
            const installments: SourceInstallment[] = []
            const seen = new Set<string>()
            doc.find("a.komik-series-chapter-item").each((_i, el) => {
                const rawNum = el.attr("data-episode-number")
                const num = parseEpisodeNumber(rawNum)
                const href = (el.attr("href") ?? "").trim()
                const epPath = pathOf(href, seriesUrl)
                if (num === undefined || !epPath || epPath.length > 200 || seen.has(epPath)) return
                seen.add(epPath)
                const epTitle = el.find(".komik-series-chapter-item__title").first().text().trim()
                installments.push({
                    number: num,
                    name: epTitle ? epTitle.slice(0, 500) : `Episode ${num}`,
                    ref: videoRef(providerId, epPath),
                })
            })
            installments.sort((a, b) => a.number - b.number)
            return {
                installments,
                choices: {
                    audio: [{ id: "sub", label: "Sub" }],
                    server: uniqueChoices([
                        { id: "default", label: "Default" },
                        { id: "mp4", label: "MP4" },
                    ]),
                    quality: [
                        { id: "auto", label: "Auto" },
                        { id: "1080p", label: "1080p" },
                        { id: "720p", label: "720p" },
                        { id: "480p", label: "480p" },
                    ],
                },
            }
        },

        async find(context: Context, ref: Ref): Promise<SourcePage> {
            const base = siteBase(context)
            const candidates = await fetchCandidates(base, ref.nativeId)
            const deadline = futureDeadline(context?.deadline)
            const items: Source[] = candidates.map((c) => ({
                id: c.id,
                origin: streamOriginOf(c.url, "mp4"),
                capabilities: ["video"],
                expiresAt: deadline,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: "id",
                        label: `Sub · ${c.host}`,
                    },
                ],
                ranges: [],
                choices: {
                    audio: "sub",
                    server: c.serverId,
                    quality: c.quality,
                },
            }))
            return { items, state: "complete" }
        },

        async resolve(context: Context, input: SourceResolveInput): Promise<Source> {
            const base = siteBase(context)
            const candidates = await fetchCandidates(base, input.ref.nativeId)
            const selected = candidates.find((c) => c.id === input.sourceId)
            if (!selected) {
                throw failure("unavailable", `${providerName} server is unavailable`)
            }
            const handle = await site.handle({
                url: selected.url,
                headers: { Referer: `${base}/` },
            })
            return {
                id: input.sourceId,
                origin: streamOriginOf(selected.url, "mp4"),
                capabilities: ["video"],
                expiresAt: handle.expiresAt,
                handle,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: "id",
                        label: `Sub · ${selected.host}`,
                    },
                ],
                ranges: [],
                choices: {
                    audio: "sub",
                    server: selected.serverId,
                    quality: selected.quality,
                },
            }
        },
    },
})
