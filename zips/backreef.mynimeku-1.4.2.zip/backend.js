(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/titles.ts
  var YEAR_PAREN_RE = /\((\d{4})\)/;
  var YEAR_STANDALONE_RE = /\b(19\d{2}|20\d{2})\b/;
  function extractYear(title) {
    const paren = title.match(YEAR_PAREN_RE);
    if (paren) {
      const year = Number.parseInt(paren[1], 10);
      if (year >= 1900 && year <= 2100) return year;
    }
    const standalone = title.match(YEAR_STANDALONE_RE);
    if (standalone) {
      return Number.parseInt(standalone[1], 10);
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../../../packages/plugin-std/src/url.ts
  function resolveUrl(raw, base) {
    const trimmed = raw.trim();
    if (!trimmed) return "";
    try {
      const url = new URL(trimmed.startsWith("//") ? `https:${trimmed}` : trimmed, base);
      return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : "";
    } catch (e) {
      return "";
    }
  }
  function cleanBaseUrl(raw, fallback) {
    const resolved = resolveUrl(raw != null ? raw : "");
    if (!resolved) return fallback;
    const url = new URL(resolved);
    return url.origin + url.pathname.replace(/\/+$/, "");
  }

  // ../stream-common/src/common.ts
  function streamOriginOf(url, hint) {
    const lowerUrl = url.toLowerCase();
    const lowerHint = (hint != null ? hint : "").toLowerCase();
    if (lowerHint === "hls" || lowerHint === "m3u8" || /\.m3u8(\?|$|#)/.test(lowerUrl)) {
      return "hls";
    }
    return "http";
  }
  function choiceId(label, fallback = "default") {
    const slug = label.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64);
    return slug || fallback;
  }
  function uniqueChoices(items) {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const item of items) {
      if (!item.id || seen.has(item.id) || out.length >= 200) continue;
      seen.add(item.id);
      out.push({
        id: item.id.slice(0, 200),
        label: (item.label || item.id).slice(0, 200)
      });
    }
    return out;
  }
  function firstText(doc, selectors) {
    for (const selector of selectors) {
      const text = doc.find(selector).first().text().trim();
      if (text) return text;
    }
    return "";
  }
  function videoRef(providerId2, nativeId) {
    return {
      providerId: providerId2,
      type: "video",
      nativeId
    };
  }
  function sameRef(ref) {
    return ref.scope ? {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId,
      scope: ref.scope
    } : {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId
    };
  }
  function limitItems(items, limit) {
    if (typeof limit === "number" && Number.isFinite(limit) && limit > 0) {
      return items.slice(0, limit);
    }
    return items;
  }
  function futureDeadline(contextDeadline, minutes = 10) {
    const now = Date.now();
    if (contextDeadline) {
      const parsed = Date.parse(contextDeadline);
      if (Number.isFinite(parsed) && parsed > now + 5e3 && parsed <= now + 24 * 3600 * 1e3) {
        return contextDeadline;
      }
    }
    return new Date(now + minutes * 60 * 1e3).toISOString();
  }
  function parseEpisodeNumber(raw) {
    if (typeof raw === "number") {
      return Number.isFinite(raw) && raw >= 0 ? raw : void 0;
    }
    if (typeof raw !== "string") return void 0;
    const cleaned = raw.trim().replace(",", ".");
    if (!cleaned) return void 0;
    const match = /\d+(?:\.\d+)?/.exec(cleaned);
    if (!match) return void 0;
    const num = Number(match[0]);
    return Number.isFinite(num) && num >= 0 ? num : void 0;
  }
  function extractFirstYear(text) {
    const year = extractYear(text != null ? text : "");
    return year > 0 ? year : void 0;
  }

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // src/backend.ts
  var providerId = "backreef.mynimeku:source";
  var providerName = "MyNimeKu";
  var site = httpClient(caye, providerName);
  var defaultBaseUrl = "https://www.mynimeku.com";
  function siteBase(context) {
    var _a;
    return cleanBaseUrl((_a = context == null ? void 0 : context.config) == null ? void 0 : _a.url, defaultBaseUrl);
  }
  function pathOf(rawUrl, base) {
    const resolved = resolveUrl(rawUrl, base);
    if (!resolved) return "";
    try {
      return new URL(resolved).pathname.replace(/^\/+|\/+$/g, "");
    } catch (e) {
      return "";
    }
  }
  function fetchCandidates(base, epPath) {
    return __async(this, null, function* () {
      const epUrl = `${base}/${epPath}/`;
      const html = yield site.text({ url: epUrl, headers: { Referer: `${base}/` } });
      const doc = caye.html.parse(html);
      const out = [];
      doc.find("button.mynimeku-episode-server-btn").each((index, el) => {
        var _a;
        const rawUrl = ((_a = el.attr("data-player-url")) != null ? _a : "").trim();
        const resolved = resolveUrl(rawUrl, epUrl);
        if (!resolved) return;
        const host = (el.attr("data-player-host") || el.text() || "Default").trim();
        const resMatch = /(\d+)p\b/i.exec(host);
        const resolution = resMatch ? Number.parseInt(resMatch[1], 10) : 0;
        const quality = resolution ? `${resolution}p` : "auto";
        const serverLabel = host.replace(/\s*\d+p\b/gi, "").trim() || "Default";
        const serverId = choiceId(serverLabel, "default");
        out.push({
          id: `${index}:${serverId}:${quality}`,
          url: resolved,
          host,
          serverId,
          quality,
          resolution
        });
      });
      out.sort((a, b) => b.resolution - a.resolution);
      return out;
    });
  }
  caye.register(providerId, {
    source: {
      search(context, query) {
        return __async(this, null, function* () {
          var _a, _b, _c, _d, _e;
          const base = siteBase(context);
          const q = ((_a = query == null ? void 0 : query.q) != null ? _a : "").trim();
          if (!q) return { items: [], nextCursor: "", state: "complete" };
          const homeHtml = yield site.text({ url: `${base}/` });
          const homeDoc = caye.html.parse(homeHtml);
          const nonce = ((_b = homeDoc.find("form[data-live-search-form]").first().attr("data-nonce")) != null ? _b : "").trim();
          if (!nonce) {
            throw failure("unavailable", `${providerName} live-search nonce was not found`);
          }
          const body = new URLSearchParams({
            action: "mynimeku_live_search",
            nonce,
            keyword: q
          }).toString();
          const payload = yield site.json({
            url: `${base}/wp-admin/admin-ajax.php`,
            method: "POST",
            headers: {
              "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
              Origin: base,
              Referer: `${base}/`
            },
            body
          });
          const rawItems = (payload == null ? void 0 : payload.success) === false ? [] : (_d = (_c = payload == null ? void 0 : payload.data) == null ? void 0 : _c.items) != null ? _d : [];
          const items = [];
          const seen = /* @__PURE__ */ new Set();
          for (const item of rawItems) {
            if (!item || item.type === "MANGA" || typeof item.url !== "string") continue;
            if (!item.url.includes("/series/")) continue;
            const nativeId = pathOf(item.url, base);
            const title = ((_e = item.title) != null ? _e : "").trim();
            if (!nativeId || !title || nativeId.length > 200 || seen.has(nativeId)) continue;
            seen.add(nativeId);
            const year = extractFirstYear(title);
            items.push(__spreadValues({
              ref: videoRef(providerId, nativeId),
              name: title
            }, year !== void 0 ? { year } : {}));
          }
          return {
            items: limitItems(items, query == null ? void 0 : query.limit),
            nextCursor: "",
            state: "complete"
          };
        });
      },
      read(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const html = yield site.text({
            url: `${base}/${ref.nativeId}/`,
            headers: { Referer: `${base}/` }
          });
          const doc = caye.html.parse(html);
          const name = firstText(doc, ["h1.komik-series-title", "h1.entry-title", "h1", "title"]).replace(/\s*[-|]\s*MyNimeKu.*$/i, "").trim();
          if (!name) {
            throw failure("unavailable", `${providerName} title was not found`);
          }
          const year = extractFirstYear(name);
          return __spreadValues({
            ref: sameRef(ref),
            name
          }, year !== void 0 ? { year } : {});
        });
      },
      list(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const seriesUrl = `${base}/${ref.nativeId}/`;
          const html = yield site.text({ url: seriesUrl, headers: { Referer: `${base}/` } });
          const doc = caye.html.parse(html);
          const installments = [];
          const seen = /* @__PURE__ */ new Set();
          doc.find("a.komik-series-chapter-item").each((_i, el) => {
            var _a;
            const rawNum = el.attr("data-episode-number");
            const num = parseEpisodeNumber(rawNum);
            const href = ((_a = el.attr("href")) != null ? _a : "").trim();
            const epPath = pathOf(href, seriesUrl);
            if (num === void 0 || !epPath || epPath.length > 200 || seen.has(epPath)) return;
            seen.add(epPath);
            const epTitle = el.find(".komik-series-chapter-item__title").first().text().trim();
            installments.push({
              number: num,
              name: epTitle ? epTitle.slice(0, 500) : `Episode ${num}`,
              ref: videoRef(providerId, epPath)
            });
          });
          installments.sort((a, b) => a.number - b.number);
          return {
            installments,
            choices: {
              audio: [{ id: "sub", label: "Sub" }],
              server: uniqueChoices([
                { id: "default", label: "Default" },
                { id: "mp4", label: "MP4" }
              ]),
              quality: [
                { id: "auto", label: "Auto" },
                { id: "1080p", label: "1080p" },
                { id: "720p", label: "720p" },
                { id: "480p", label: "480p" }
              ]
            }
          };
        });
      },
      find(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const candidates = yield fetchCandidates(base, ref.nativeId);
          const deadline = futureDeadline(context == null ? void 0 : context.deadline);
          const items = candidates.map((c) => ({
            id: c.id,
            origin: streamOriginOf(c.url, "mp4"),
            capabilities: ["video"],
            expiresAt: deadline,
            tracks: [
              {
                id: "main",
                kind: "video",
                language: "id",
                label: `Sub \xB7 ${c.host}`
              }
            ],
            ranges: [],
            choices: {
              audio: "sub",
              server: c.serverId,
              quality: c.quality
            }
          }));
          return { items, state: "complete" };
        });
      },
      resolve(context, input) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const candidates = yield fetchCandidates(base, input.ref.nativeId);
          const selected = candidates.find((c) => c.id === input.sourceId);
          if (!selected) {
            throw failure("unavailable", `${providerName} server is unavailable`);
          }
          const handle = yield site.handle({
            url: selected.url,
            headers: { Referer: `${base}/` }
          });
          return {
            id: input.sourceId,
            origin: streamOriginOf(selected.url, "mp4"),
            capabilities: ["video"],
            expiresAt: handle.expiresAt,
            handle,
            tracks: [
              {
                id: "main",
                kind: "video",
                language: "id",
                label: `Sub \xB7 ${selected.host}`
              }
            ],
            ranges: [],
            choices: {
              audio: "sub",
              server: selected.serverId,
              quality: selected.quality
            }
          };
        });
      }
    }
  });
})();
//# sourceMappingURL=backend.js.map
