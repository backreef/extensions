import type { API, Ref, SourceRecord } from "../../../../packages/plugin-sdk/src/index.ts"
import {
    buildChapterList,
    createMangaSource,
    fetchText,
    makeDirectPageResolver,
    parseChapterNumber,
    parseYear,
    type ParsedChapterInput,
    type RawPageInput,
} from "../../manga-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"
import { resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.mangapill:source"
const providerName = "Mangapill"
const siteUrl = "https://mangapill.com"

function decodeSlashId(id: string): string {
    return id.replace(/\$/g, "/").replace(/^\/+/, "")
}

async function findPages(_context: unknown, ref: Ref): Promise<RawPageInput[]> {
    const pageUrl = `${siteUrl}/chapters/${decodeSlashId(ref.nativeId)}`
    const { text: html } = await fetchText(providerName, pageUrl, {
        headers: { Referer: `${siteUrl}/` },
    })
    const doc = caye.html.parse(html)

    const items: { url: string; index: number }[] = []
    doc.find("chapter-page").each((i, el) => {
        const img = el.find("div picture img").first()
        const rawSrc = img.attr("data-src") || img.attr("src") || ""
        const url = resolveUrl(rawSrc, pageUrl)
        if (!url) return
        const summary = el.find("div[data-summary] > div").first().text()
        const match = summary.match(/page\s+(\d+)/i)
        const index = match ? Number.parseInt(match[1], 10) - 1 : i
        items.push({ url, index })
    })

    items.sort((a, b) => a.index - b.index)
    return items.map((item) => ({ url: item.url }))
}

const mangapillSource = createMangaSource({
    providerId,
    providerName,

    async search(_context, text) {
        const url = new URL("/search", siteUrl)
        url.searchParams.set("q", text)
        const { text: html } = await fetchText(providerName, url.toString(), {
            headers: { Referer: `${siteUrl}/` },
        })
        const doc = caye.html.parse(html)

        const records: SourceRecord[] = []
        const seen = new Set<string>()
        doc.find("div.container div.my-3.justify-end > div").each((_, el) => {
            const href = el.find("a").first().attr("href") || ""
            const after = href.split("/manga/")[1]
            if (!after) return
            const nativeId = after.replace(/^\/+|\/+$/g, "").replace(/\//g, "$")
            const title = el.find("div > a > div.mt-3").first().text().trim()
            if (!nativeId || !title || seen.has(nativeId)) return
            seen.add(nativeId)
            const yearText = el.find("div > div.flex > div").eq(1).text().trim()
            const year = parseYear(yearText)
            records.push({
                ref: { providerId, type: "manga", nativeId },
                name: title,
                ...(year !== undefined ? { year } : {}),
            })
        })

        if (records.length === 0 && !html.toLowerCase().includes("mangapill")) {
            throw failure("unavailable", `${providerName} returned unexpected search page`)
        }
        return records
    },

    async read(_context, ref) {
        const url = `${siteUrl}/manga/${decodeSlashId(ref.nativeId)}`
        const { text: html } = await fetchText(providerName, url, {
            headers: { Referer: `${siteUrl}/` },
        })
        const doc = caye.html.parse(html)
        const name = doc.find("h1").first().text().trim()
        if (!name) {
            throw failure("unavailable", `${providerName} title not found`)
        }
        return { name }
    },

    async list(_context, ref) {
        const url = `${siteUrl}/manga/${decodeSlashId(ref.nativeId)}`
        const { text: html } = await fetchText(providerName, url, {
            headers: { Referer: `${siteUrl}/` },
        })
        const doc = caye.html.parse(html)

        const entries: ParsedChapterInput[] = []
        doc.find("div.container div.border-border div#chapters div.grid-cols-1 a").each((_, el) => {
            const href = el.attr("href") || ""
            const after = href.split("/chapters/")[1]
            if (!after) return
            const nativeId = after.replace(/^\/+|\/+$/g, "").replace(/\//g, "$")
            const title = el.text().trim()
            if (!nativeId || !title) return
            entries.push({
                nativeId,
                name: title,
                number: parseChapterNumber(title),
            })
        })

        if (entries.length === 0 && !doc.find("h1").first().text().trim()) {
            throw failure("unavailable", `${providerName} chapters page unavailable`)
        }
        return buildChapterList(providerId, entries, { reverse: true })
    },

    findPages,

    resolveTarget: makeDirectPageResolver(() => ({ Referer: `${siteUrl}/` }), findPages),
})

caye.register(providerId, { source: mangapillSource })
