import type { API, Ref } from "../../../../packages/plugin-sdk/src/index.ts"
import {
    buildChapterList,
    createMangaSource,
    fetchJson,
    makeDirectPageResolver,
    parseChapterNumber,
    parseYear,
    type RawPageInput,
} from "../../manga-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"
import { resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.atsumaru:source"
const providerName = "Atsumaru"
const siteUrl = "https://atsu.moe"
const imgCdn = "https://cdn.atsu.moe"

type AtsuSearchResponse = {
    hits?: {
        document?: {
            id?: string
            title?: string
            released?: number
        }
    }[]
}

type AtsuPageResponse = {
    mangaPage?: {
        id?: string
        title?: string
        released?: number
        scanlators?: { id?: string; name?: string }[]
    }
}

type AtsuChaptersResponse = {
    chapters?: {
        id?: string
        scanlationMangaId?: string
        title?: string
        number?: number | string
        index?: number
    }[]
}

type AtsuReadChapterResponse = {
    readChapter?: {
        pages?: {
            image?: string
            number?: number
        }[]
    }
}

function yearFromEpoch(ms: unknown): number | undefined {
    if (typeof ms !== "number" || !Number.isFinite(ms)) return undefined
    return parseYear(new Date(ms).getUTCFullYear())
}

function splitChapterId(nativeId: string): { mangaId: string; chapId: string } {
    const idx = nativeId.indexOf("|")
    if (idx === -1) {
        throw failure("unavailable", `${providerName} invalid chapter ID`)
    }
    return {
        mangaId: nativeId.slice(0, idx),
        chapId: nativeId.slice(idx + 1),
    }
}

function chapterReferer(ref: Ref): string {
    const { mangaId, chapId } = splitChapterId(ref.nativeId)
    return `${siteUrl}/read/${mangaId}/${chapId}`
}

async function findPages(_context: unknown, ref: Ref): Promise<RawPageInput[]> {
    const { mangaId, chapId } = splitChapterId(ref.nativeId)
    const url = new URL("/api/read/chapter", siteUrl)
    url.searchParams.set("mangaId", mangaId)
    url.searchParams.set("chapterId", chapId)

    const { data } = await fetchJson<AtsuReadChapterResponse>(providerName, url.toString(), {
        headers: { Referer: chapterReferer(ref) },
    })
    const rawPages = data.readChapter?.pages
    if (!Array.isArray(rawPages)) {
        throw failure("unavailable", `${providerName} returned unexpected chapter pages payload`)
    }
    const sorted = rawPages
        .filter((p) => typeof p.image === "string" && p.image.trim())
        .slice()
        .sort((a, b) => (a.number ?? 0) - (b.number ?? 0))

    return sorted.flatMap((page) => {
        const raw = page.image!.trim()
        const resolved = raw.startsWith("http") ? raw : resolveUrl(raw, imgCdn)
        return resolved ? [{ url: resolved }] : []
    })
}

const atsumaruSource = createMangaSource({
    providerId,
    providerName,

    async search(_context, text) {
        const url = new URL("/collections/manga/documents/search", siteUrl)
        url.searchParams.set("q", text)
        url.searchParams.set("query_by", "title,englishTitle,otherNames")
        const { data } = await fetchJson<AtsuSearchResponse>(providerName, url.toString(), {
            headers: { Referer: `${siteUrl}/` },
        })
        if (!Array.isArray(data.hits)) {
            throw failure("unavailable", `${providerName} returned unexpected search payload`)
        }
        return data.hits.flatMap((hit) => {
            const doc = hit.document
            if (!doc?.id || !doc.title?.trim()) return []
            const year = yearFromEpoch(doc.released)
            return [
                {
                    ref: { providerId, type: "manga", nativeId: String(doc.id) },
                    name: doc.title.trim(),
                    ...(year !== undefined ? { year } : {}),
                },
            ]
        })
    },

    async read(_context, ref) {
        const url = new URL("/api/manga/page", siteUrl)
        url.searchParams.set("id", ref.nativeId)
        const { data } = await fetchJson<AtsuPageResponse>(providerName, url.toString(), {
            headers: { Referer: `${siteUrl}/` },
        })
        const page = data.mangaPage
        if (!page?.title?.trim()) {
            throw failure("unavailable", `${providerName} title not found`)
        }
        return {
            name: page.title.trim(),
            year: yearFromEpoch(page.released),
        }
    },

    async list(_context, ref) {
        const pageUrl = new URL("/api/manga/page", siteUrl)
        pageUrl.searchParams.set("id", ref.nativeId)
        const chaptersUrl = new URL("/api/manga/allChapters", siteUrl)
        chaptersUrl.searchParams.set("mangaId", ref.nativeId)

        const [pageRes, chaptersRes] = await Promise.all([
            fetchJson<AtsuPageResponse>(providerName, pageUrl.toString(), {
                headers: { Referer: `${siteUrl}/` },
            }),
            fetchJson<AtsuChaptersResponse>(providerName, chaptersUrl.toString(), {
                headers: { Referer: `${siteUrl}/` },
            }),
        ])

        if (!Array.isArray(chaptersRes.data.chapters)) {
            throw failure("unavailable", `${providerName} returned unexpected chapters payload`)
        }

        const scanlators = new Map<string, string>()
        for (const s of pageRes?.data.mangaPage?.scanlators ?? []) {
            if (s.id && s.name?.trim()) {
                scanlators.set(s.id, s.name.trim())
            }
        }

        const entries = chaptersRes.data.chapters.flatMap((ch) => {
            if (!ch.id) return []
            const number = parseChapterNumber(ch.number ?? ch.title)
            const name =
                ch.title?.trim() || (number !== undefined ? `Chapter ${number}` : undefined)
            const scanlator = ch.scanlationMangaId
                ? scanlators.get(ch.scanlationMangaId)
                : undefined
            return [
                {
                    nativeId: `${ref.nativeId}|${ch.id}`,
                    name,
                    number,
                    scanlator,
                },
            ]
        })

        return buildChapterList(providerId, entries, { reverse: true, sortByNumber: true })
    },

    findPages,

    resolveTarget: makeDirectPageResolver((ref) => ({ Referer: chapterReferer(ref) }), findPages),
})

caye.register(providerId, { source: atsumaruSource })
