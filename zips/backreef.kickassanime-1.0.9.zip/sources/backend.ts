import type {
    API,
    Context,
    Query,
    Ref,
    Source,
    SourceChoiceDef,
    SourceInstallment,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
    SourceResolveInput,
} from "../../../../packages/plugin-sdk/src/index"
import { pooled } from "../../../../packages/provider-source/src/concurrency"
import {
    choiceId,
    extractFirstYear,
    futureDeadline,
    limitItems,
    normalizeSubtitles,
    parseEpisodeNumber,
    sameRef,
    streamOriginOf,
    uniqueChoices,
    videoRef,
} from "../../stream-common/src/common"
import { failure, httpClient } from "../../../../packages/plugin-std/src/http.ts"
import { astroProps } from "../../../../packages/plugin-std/src/page-data.ts"
import { cleanBaseUrl, originOf, resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.kickassanime:source"
const providerName = "KickAssAnime"
const site = httpClient(caye, providerName)
const defaultBaseUrl = "https://kaa.lt"

type SearchItem = {
    slug?: string
    title?: string
    title_en?: string
    start_date?: string
    year?: number | string
}

type EpisodeItem = {
    slug?: string
    title?: string
    episode_number?: number
    episode_string?: string
}

type EpisodesPage = {
    pages?: Array<{ number?: number }>
    result?: EpisodeItem[]
}

type ServerItem = {
    name?: string
    src?: string
}

function siteUrl(context: Context): string {
    return cleanBaseUrl(context?.config?.url, defaultBaseUrl)
}

function orderLanguages(locales: string[]): string[] {
    const preferred = ["ja-JP", "zh-CN", "en-US"]
    const rank = (lang: string) => {
        const idx = preferred.indexOf(lang)
        return idx === -1 ? preferred.length : idx
    }
    return [...locales].sort((a, b) => rank(a) - rank(b))
}

function audioChoiceLabel(lang: string): string {
    if (lang === "ja-JP" || lang === "zh-CN") return `Sub (${lang})`
    if (lang === "en-US") return `Dub (${lang})`
    return lang
}

function isIntegerOrFraction(ep: EpisodeItem): number | undefined {
    if (
        typeof ep.episode_number === "number" &&
        Number.isFinite(ep.episode_number) &&
        ep.episode_number >= 0
    ) {
        return ep.episode_number
    }
    return parseEpisodeNumber(ep.episode_string)
}

async function fetchLanguages(base: string, slug: string): Promise<string[]> {
    const res = await site.json<{ result?: string[] }>({
        url: `${base}/api/show/${encodeURIComponent(slug)}/language`,
    })
    return Array.isArray(res.result) ? res.result.filter((v) => typeof v === "string" && v) : []
}

async function fetchLanguageEpisodes(
    base: string,
    slug: string,
    lang: string,
): Promise<EpisodeItem[]> {
    const firstUrl = new URL(`/api/show/${encodeURIComponent(slug)}/episodes`, base)
    firstUrl.searchParams.set("ep", "1")
    firstUrl.searchParams.set("lang", lang)
    firstUrl.searchParams.set("page", "1")
    const first = await site.json<EpisodesPage>({ url: firstUrl.toString() })
    const pages = Array.isArray(first.pages)
        ? first.pages
              .map((p) => p.number)
              .filter((n): n is number => typeof n === "number" && n > 1)
        : []
    const rest = await pooled(pages, 4, async (page) => {
        const pageUrl = new URL(firstUrl.toString())
        pageUrl.searchParams.set("page", String(page))
        return site.json<EpisodesPage>({ url: pageUrl.toString() })
    })
    return [first, ...rest].flatMap((p) => (Array.isArray(p.result) ? p.result : []))
}

async function findEpisodeSlugForLang(
    base: string,
    slug: string,
    lang: string,
    epStr: string,
): Promise<EpisodeItem | undefined> {
    const firstUrl = new URL(`/api/show/${encodeURIComponent(slug)}/episodes`, base)
    firstUrl.searchParams.set("ep", "1")
    firstUrl.searchParams.set("lang", lang)
    firstUrl.searchParams.set("page", "1")
    const first = await site.json<EpisodesPage>({ url: firstUrl.toString() })
    const matchFrom = (items: EpisodeItem[] | undefined) =>
        (items ?? []).find(
            (ep) => String(ep.episode_string ?? ep.episode_number ?? "") === epStr && ep.slug,
        )
    const direct = matchFrom(first.result)
    if (direct) return direct
    const pages = Array.isArray(first.pages)
        ? first.pages
              .map((p) => p.number)
              .filter((n): n is number => typeof n === "number" && n > 1)
        : []
    for (const page of pages) {
        const pageUrl = new URL(firstUrl.toString())
        pageUrl.searchParams.set("page", String(page))
        const next = await site.json<EpisodesPage>({ url: pageUrl.toString() })
        const hit = matchFrom(next.result)
        if (hit) return hit
    }
    return undefined
}

function parseEpisodeNativeId(nativeId: string): { slug: string; epStr: string } {
    const sep = nativeId.lastIndexOf("|")
    if (sep <= 0 || sep >= nativeId.length - 1) {
        throw failure("unavailable", `${providerName} invalid episode reference`)
    }
    return { slug: nativeId.slice(0, sep), epStr: nativeId.slice(sep + 1) }
}

function parseAstroPlayer(
    html: string,
    playerUrl: string,
): { manifestUrl: string; subtitles: Source["subtitles"] } {
    const islands = astroProps(caye, html)
    for (const props of islands) {
        const manifestField = props.manifest
        if (!Array.isArray(manifestField) || typeof manifestField[1] !== "string") continue
        const manifestUrl = resolveUrl(manifestField[1], playerUrl)
        if (!manifestUrl) continue
        const subField = props.subtitles
        const rawSubs = Array.isArray(subField) && Array.isArray(subField[1]) ? subField[1] : []
        const subEntries: Array<{
            url?: string
            language?: string
            label?: string
            default?: boolean
        }> = []
        for (const item of rawSubs) {
            if (!Array.isArray(item) || !item[1] || typeof item[1] !== "object") continue
            const entry = item[1] as Record<string, unknown[]>
            const src = Array.isArray(entry.src) ? String(entry.src[1] ?? "") : ""
            const langCode = Array.isArray(entry.language) ? String(entry.language[1] ?? "") : ""
            const langName = Array.isArray(entry.name) ? String(entry.name[1] ?? "") : ""
            if (!src) continue
            const fixedSrc = src.startsWith("https:///")
                ? src.replace("https:///", "https://")
                : src
            subEntries.push({
                url: fixedSrc,
                language: langCode || langName,
                label: langName || langCode || undefined,
                default: langCode === "en",
            })
        }
        return {
            manifestUrl,
            subtitles: normalizeSubtitles(caye, subEntries, playerUrl),
        }
    }
    throw failure("unavailable", `${providerName} player manifest was not found`)
}

caye.register(providerId, {
    source: {
        async search(context: Context, query: Query): Promise<SourceRecords> {
            const base = siteUrl(context)
            const q = (query?.q ?? "").trim()
            if (!q) {
                return { items: [], nextCursor: "", state: "complete" }
            }
            const data = await site.json<{ result?: SearchItem[] }>({
                url: `${base}/api/fsearch`,
                method: "POST",
                headers: { "Content-Type": "application/json", Accept: "application/json" },
                body: JSON.stringify({ query: q, page: 1 }),
            })
            const items: SourceRecord[] = []
            const seen = new Set<string>()
            for (const item of Array.isArray(data.result) ? data.result : []) {
                const slug = (item.slug ?? "").trim()
                const name = (item.title_en || item.title || "").trim()
                if (!slug || !name || seen.has(slug)) continue
                seen.add(slug)
                const year = extractFirstYear(
                    item.year !== undefined ? String(item.year) : item.start_date,
                )
                items.push({
                    ref: videoRef(providerId, slug),
                    name,
                    ...(year !== undefined ? { year } : {}),
                })
            }
            return {
                items: limitItems(items, query?.limit),
                nextCursor: "",
                state: "complete",
            }
        },

        async read(context: Context, ref: Ref): Promise<SourceRecord> {
            const base = siteUrl(context)
            const slug = ref.nativeId.split("|")[0]
            const data = await site.json<SearchItem>({
                url: `${base}/api/show/${encodeURIComponent(slug)}`,
            })
            const name = (data.title_en || data.title || "").trim()
            if (!name) {
                throw failure("unavailable", `${providerName} show details are unavailable`)
            }
            const year = extractFirstYear(
                data.year !== undefined ? String(data.year) : data.start_date,
            )
            return {
                ref: sameRef(ref),
                name,
                ...(year !== undefined ? { year } : {}),
            }
        },

        async list(context: Context, ref: Ref): Promise<SourceListResult> {
            const base = siteUrl(context)
            const slug = ref.nativeId.split("|")[0]
            const languages = orderLanguages(await fetchLanguages(base, slug))
            let rawEpisodes: EpisodeItem[] = []
            for (const lang of languages) {
                const eps = await fetchLanguageEpisodes(base, slug, lang)
                if (eps.length > 0) {
                    rawEpisodes = eps
                    break
                }
            }
            const installments: SourceInstallment[] = []
            const seen = new Set<string>()
            for (const ep of rawEpisodes) {
                const num = isIntegerOrFraction(ep)
                const epStr = String(ep.episode_string ?? (num !== undefined ? num : "")).trim()
                if (num === undefined || !epStr || !ep.slug || seen.has(epStr)) continue
                seen.add(epStr)
                installments.push({
                    number: num,
                    ...(ep.title ? { name: ep.title.trim().slice(0, 500) } : {}),
                    ref: videoRef(providerId, `${slug}|${epStr}`),
                })
            }
            installments.sort((a, b) => a.number - b.number)
            const audio: SourceChoiceDef[] = uniqueChoices(
                languages.map((lang) => ({
                    id: choiceId(lang),
                    label: audioChoiceLabel(lang),
                })),
            )
            return {
                installments,
                choices: {
                    audio: audio.length > 0 ? audio : [{ id: "sub", label: "Sub" }],
                    server: [
                        { id: "vidstreaming", label: "VidStreaming" },
                        { id: "catstream", label: "CatStream" },
                    ],
                    quality: [{ id: "auto", label: "Auto" }],
                },
            }
        },

        async find(context: Context, ref: Ref): Promise<SourcePage> {
            const base = siteUrl(context)
            const { slug, epStr } = parseEpisodeNativeId(ref.nativeId)
            const languages = orderLanguages(await fetchLanguages(base, slug))
            const deadline = futureDeadline(context?.deadline)
            const items: Source[] = []
            const langResults = await pooled(languages, 3, async (lang) => {
                const ep = await findEpisodeSlugForLang(base, slug, lang, epStr)
                if (!ep?.slug) return []
                const epUrl = `${base}/api/show/${encodeURIComponent(slug)}/episode/ep-${encodeURIComponent(epStr)}-${encodeURIComponent(ep.slug)}`
                const detail = await site.json<{ servers?: ServerItem[] }>({ url: epUrl })
                return { lang, servers: Array.isArray(detail.servers) ? detail.servers : [] }
            })

            for (const entry of langResults) {
                if (Array.isArray(entry)) continue
                const audioId = choiceId(entry.lang)
                for (const srv of entry.servers) {
                    const serverName = (srv.name ?? "").trim()
                    const src = (srv.src ?? "").trim()
                    if (!serverName || !src) continue
                    const serverId = choiceId(serverName)
                    items.push({
                        id: `${audioId}:${serverId}`,
                        origin: "hls",
                        capabilities: ["video"],
                        expiresAt: deadline,
                        tracks: [
                            {
                                id: "main",
                                kind: "video",
                                language: caye.language.toISO1(entry.lang) || "ja",
                                label: `${audioChoiceLabel(entry.lang)} · ${serverName}`,
                            },
                        ],
                        ranges: [],
                        choices: {
                            audio: audioId,
                            server: serverId,
                            quality: "auto",
                        },
                    })
                }
            }
            return { items, state: "complete" }
        },

        async resolve(context: Context, input: SourceResolveInput): Promise<Source> {
            const base = siteUrl(context)
            const { slug, epStr } = parseEpisodeNativeId(input.ref.nativeId)
            const [wantAudio, wantServer] = input.sourceId.split(":")
            const languages = orderLanguages(await fetchLanguages(base, slug))
            const matchedLang = languages.find((lang) => choiceId(lang) === wantAudio)
            if (!matchedLang) {
                throw failure("unavailable", `${providerName} audio track is unavailable`)
            }
            const ep = await findEpisodeSlugForLang(base, slug, matchedLang, epStr)
            if (!ep?.slug) {
                throw failure("unavailable", `${providerName} episode is unavailable`)
            }
            const epUrl = `${base}/api/show/${encodeURIComponent(slug)}/episode/ep-${encodeURIComponent(epStr)}-${encodeURIComponent(ep.slug)}`
            const detail = await site.json<{ servers?: ServerItem[] }>({ url: epUrl })
            const srv = (detail.servers ?? []).find(
                (item) => choiceId(item.name ?? "") === wantServer && item.src,
            )
            if (!srv?.src) {
                throw failure("unavailable", `${providerName} server is unavailable`)
            }
            const playerUrl = srv.src.replace("vast", "player")
            const playerHtml = await site.text({ url: playerUrl })
            const { manifestUrl, subtitles } = parseAstroPlayer(playerHtml, playerUrl)
            const origin = originOf(playerUrl) || "https://krussdomi.com"
            const handle = await site.handle({
                url: manifestUrl,
                headers: {
                    Origin: origin,
                    Referer: srv.src,
                },
            })
            return {
                id: input.sourceId,
                origin: streamOriginOf(manifestUrl, "hls"),
                capabilities: ["video"],
                expiresAt: handle.expiresAt,
                handle,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: caye.language.toISO1(matchedLang) || "ja",
                        label: `${audioChoiceLabel(matchedLang)} · ${(srv.name ?? wantServer).trim()}`,
                    },
                ],
                ranges: [],
                subtitles,
                choices: {
                    audio: wantAudio,
                    server: wantServer,
                    quality: "auto",
                },
            }
        },
    },
})
