(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/provider-source/src/concurrency.ts
  function pooled(values, size, fn) {
    return __async(this, null, function* () {
      const out = new Array(values.length);
      let next = 0;
      const run = () => __async(null, null, function* () {
        while (next < values.length) {
          const i = next++;
          out[i] = yield fn(values[i]);
        }
      });
      yield Promise.all(Array.from({ length: Math.min(size, values.length) }, run));
      return out;
    });
  }

  // ../../../packages/plugin-std/src/titles.ts
  var YEAR_PAREN_RE = /\((\d{4})\)/;
  var YEAR_STANDALONE_RE = /\b(19\d{2}|20\d{2})\b/;
  function extractYear(title) {
    const paren = title.match(YEAR_PAREN_RE);
    if (paren) {
      const year = Number.parseInt(paren[1], 10);
      if (year >= 1900 && year <= 2100) return year;
    }
    const standalone = title.match(YEAR_STANDALONE_RE);
    if (standalone) {
      return Number.parseInt(standalone[1], 10);
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../../../packages/plugin-std/src/url.ts
  function resolveUrl(raw, base) {
    const trimmed = raw.trim();
    if (!trimmed) return "";
    try {
      const url = new URL(trimmed.startsWith("//") ? `https:${trimmed}` : trimmed, base);
      return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : "";
    } catch (e) {
      return "";
    }
  }
  function cleanBaseUrl(raw, fallback) {
    const resolved = resolveUrl(raw != null ? raw : "");
    if (!resolved) return fallback;
    const url = new URL(resolved);
    return url.origin + url.pathname.replace(/\/+$/, "");
  }
  function originOf(raw) {
    const resolved = resolveUrl(raw, "https://invalid.local");
    return resolved ? new URL(resolved).origin : "";
  }

  // ../stream-common/src/common.ts
  var nonEnglishLanguageAliases = {
    latin: "es-419",
    espanol: "es",
    francais: "fr",
    deutsch: "de",
    italiano: "it",
    portugues: "pt",
    indonesia: "id"
  };
  function streamOriginOf(url, hint) {
    const lowerUrl = url.toLowerCase();
    const lowerHint = (hint != null ? hint : "").toLowerCase();
    if (lowerHint === "hls" || lowerHint === "m3u8" || /\.m3u8(\?|$|#)/.test(lowerUrl)) {
      return "hls";
    }
    return "http";
  }
  function choiceId(label, fallback = "default") {
    const slug = label.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64);
    return slug || fallback;
  }
  function uniqueChoices(items) {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const item of items) {
      if (!item.id || seen.has(item.id) || out.length >= 200) continue;
      seen.add(item.id);
      out.push({
        id: item.id.slice(0, 200),
        label: (item.label || item.id).slice(0, 200)
      });
    }
    return out;
  }
  function subtitleFormatOf(url, hint) {
    const lowerHint = (hint != null ? hint : "").trim().toLowerCase();
    if (lowerHint === "vtt" || lowerHint === "webvtt") return "vtt";
    if (lowerHint === "srt") return "srt";
    if (lowerHint === "ass" || lowerHint === "ssa") return "ass";
    const pathPart = url.split(/[?#]/)[0].toLowerCase();
    if (pathPart.endsWith(".vtt")) return "vtt";
    if (pathPart.endsWith(".srt")) return "srt";
    if (pathPart.endsWith(".ass") || pathPart.endsWith(".ssa")) return "ass";
    return void 0;
  }
  function tryLanguageApi(api, candidate) {
    const trimmed = candidate.trim();
    if (!trimmed) return void 0;
    try {
      const iso = api.language.toISO1(trimmed);
      if (iso) return iso;
    } catch (e) {
    }
    try {
      const normalized = api.language.normalize(trimmed);
      if (normalized) {
        const iso = api.language.toISO1(normalized);
        return iso || api.language.parse(normalized).language || normalized;
      }
    } catch (e) {
    }
    return void 0;
  }
  function subtitleLanguageOf(api, raw) {
    const text = (raw != null ? raw : "").trim();
    if (!text) return void 0;
    const direct = tryLanguageApi(api, text);
    if (direct) return direct;
    const firstWord = text.split(/[^a-zA-Z0-9-]+/)[0];
    if (firstWord && firstWord !== text) {
      const resolved = tryLanguageApi(api, firstWord);
      if (resolved) return resolved;
    }
    const lowerWord = (firstWord || text).toLowerCase();
    return nonEnglishLanguageAliases[lowerWord];
  }
  function normalizeSubtitles(api, tracks, baseUrl = "https://invalid.local") {
    var _a, _b, _c;
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const track of tracks) {
      const url = resolveUrl((_a = track.url) != null ? _a : "", baseUrl);
      if (!url || url.length > 2048 || seen.has(url)) continue;
      const format = subtitleFormatOf(url, track.format);
      if (!format) continue;
      seen.add(url);
      const label = ((_b = track.label) != null ? _b : "").trim().slice(0, 200);
      const language = (_c = subtitleLanguageOf(api, track.language || label)) == null ? void 0 : _c.slice(0, 35);
      out.push({
        url,
        format,
        language: language || void 0,
        label: label || void 0,
        default: track.default === true ? true : void 0
      });
      if (out.length === 32) break;
    }
    return out.length > 0 ? out : void 0;
  }
  function videoRef(providerId2, nativeId) {
    return {
      providerId: providerId2,
      type: "video",
      nativeId
    };
  }
  function sameRef(ref) {
    return ref.scope ? {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId,
      scope: ref.scope
    } : {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId
    };
  }
  function limitItems(items, limit) {
    if (typeof limit === "number" && Number.isFinite(limit) && limit > 0) {
      return items.slice(0, limit);
    }
    return items;
  }
  function futureDeadline(contextDeadline, minutes = 10) {
    const now = Date.now();
    if (contextDeadline) {
      const parsed = Date.parse(contextDeadline);
      if (Number.isFinite(parsed) && parsed > now + 5e3 && parsed <= now + 24 * 3600 * 1e3) {
        return contextDeadline;
      }
    }
    return new Date(now + minutes * 60 * 1e3).toISOString();
  }
  function parseEpisodeNumber(raw) {
    if (typeof raw === "number") {
      return Number.isFinite(raw) && raw >= 0 ? raw : void 0;
    }
    if (typeof raw !== "string") return void 0;
    const cleaned = raw.trim().replace(",", ".");
    if (!cleaned) return void 0;
    const match = /\d+(?:\.\d+)?/.exec(cleaned);
    if (!match) return void 0;
    const num = Number(match[0]);
    return Number.isFinite(num) && num >= 0 ? num : void 0;
  }
  function extractFirstYear(text) {
    const year = extractYear(text != null ? text : "");
    return year > 0 ? year : void 0;
  }

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../../../packages/plugin-std/src/page-data.ts
  function astroProps(api, html) {
    const out = [];
    api.html.parse(html).find("astro-island[props]").each((_index, element) => {
      const raw = element.attr("props");
      if (!raw) return;
      try {
        const parsed = JSON.parse(
          raw.includes("&quot;") ? api.html.unescape(raw) : raw
        );
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          out.push(parsed);
        }
      } catch (e) {
      }
    });
    return out;
  }

  // src/backend.ts
  var providerId = "backreef.kickassanime:source";
  var providerName = "KickAssAnime";
  var site = httpClient(caye, providerName);
  var defaultBaseUrl = "https://kaa.lt";
  function siteUrl(context) {
    var _a;
    return cleanBaseUrl((_a = context == null ? void 0 : context.config) == null ? void 0 : _a.url, defaultBaseUrl);
  }
  function orderLanguages(locales) {
    const preferred = ["ja-JP", "zh-CN", "en-US"];
    const rank = (lang) => {
      const idx = preferred.indexOf(lang);
      return idx === -1 ? preferred.length : idx;
    };
    return [...locales].sort((a, b) => rank(a) - rank(b));
  }
  function audioChoiceLabel(lang) {
    if (lang === "ja-JP" || lang === "zh-CN") return `Sub (${lang})`;
    if (lang === "en-US") return `Dub (${lang})`;
    return lang;
  }
  function isIntegerOrFraction(ep) {
    if (typeof ep.episode_number === "number" && Number.isFinite(ep.episode_number) && ep.episode_number >= 0) {
      return ep.episode_number;
    }
    return parseEpisodeNumber(ep.episode_string);
  }
  function fetchLanguages(base, slug) {
    return __async(this, null, function* () {
      const res = yield site.json({
        url: `${base}/api/show/${encodeURIComponent(slug)}/language`
      });
      return Array.isArray(res.result) ? res.result.filter((v) => typeof v === "string" && v) : [];
    });
  }
  function fetchLanguageEpisodes(base, slug, lang) {
    return __async(this, null, function* () {
      const firstUrl = new URL(`/api/show/${encodeURIComponent(slug)}/episodes`, base);
      firstUrl.searchParams.set("ep", "1");
      firstUrl.searchParams.set("lang", lang);
      firstUrl.searchParams.set("page", "1");
      const first = yield site.json({ url: firstUrl.toString() });
      const pages = Array.isArray(first.pages) ? first.pages.map((p) => p.number).filter((n) => typeof n === "number" && n > 1) : [];
      const rest = yield pooled(pages, 4, (page) => __async(null, null, function* () {
        const pageUrl = new URL(firstUrl.toString());
        pageUrl.searchParams.set("page", String(page));
        return site.json({ url: pageUrl.toString() });
      }));
      return [first, ...rest].flatMap((p) => Array.isArray(p.result) ? p.result : []);
    });
  }
  function findEpisodeSlugForLang(base, slug, lang, epStr) {
    return __async(this, null, function* () {
      const firstUrl = new URL(`/api/show/${encodeURIComponent(slug)}/episodes`, base);
      firstUrl.searchParams.set("ep", "1");
      firstUrl.searchParams.set("lang", lang);
      firstUrl.searchParams.set("page", "1");
      const first = yield site.json({ url: firstUrl.toString() });
      const matchFrom = (items) => (items != null ? items : []).find(
        (ep) => {
          var _a, _b;
          return String((_b = (_a = ep.episode_string) != null ? _a : ep.episode_number) != null ? _b : "") === epStr && ep.slug;
        }
      );
      const direct = matchFrom(first.result);
      if (direct) return direct;
      const pages = Array.isArray(first.pages) ? first.pages.map((p) => p.number).filter((n) => typeof n === "number" && n > 1) : [];
      for (const page of pages) {
        const pageUrl = new URL(firstUrl.toString());
        pageUrl.searchParams.set("page", String(page));
        const next = yield site.json({ url: pageUrl.toString() });
        const hit = matchFrom(next.result);
        if (hit) return hit;
      }
      return void 0;
    });
  }
  function parseEpisodeNativeId(nativeId) {
    const sep = nativeId.lastIndexOf("|");
    if (sep <= 0 || sep >= nativeId.length - 1) {
      throw failure("unavailable", `${providerName} invalid episode reference`);
    }
    return { slug: nativeId.slice(0, sep), epStr: nativeId.slice(sep + 1) };
  }
  function parseAstroPlayer(html, playerUrl) {
    var _a, _b, _c;
    const islands = astroProps(caye, html);
    for (const props of islands) {
      const manifestField = props.manifest;
      if (!Array.isArray(manifestField) || typeof manifestField[1] !== "string") continue;
      const manifestUrl = resolveUrl(manifestField[1], playerUrl);
      if (!manifestUrl) continue;
      const subField = props.subtitles;
      const rawSubs = Array.isArray(subField) && Array.isArray(subField[1]) ? subField[1] : [];
      const subEntries = [];
      for (const item of rawSubs) {
        if (!Array.isArray(item) || !item[1] || typeof item[1] !== "object") continue;
        const entry = item[1];
        const src = Array.isArray(entry.src) ? String((_a = entry.src[1]) != null ? _a : "") : "";
        const langCode = Array.isArray(entry.language) ? String((_b = entry.language[1]) != null ? _b : "") : "";
        const langName = Array.isArray(entry.name) ? String((_c = entry.name[1]) != null ? _c : "") : "";
        if (!src) continue;
        const fixedSrc = src.startsWith("https:///") ? src.replace("https:///", "https://") : src;
        subEntries.push({
          url: fixedSrc,
          language: langCode || langName,
          label: langName || langCode || void 0,
          default: langCode === "en"
        });
      }
      return {
        manifestUrl,
        subtitles: normalizeSubtitles(caye, subEntries, playerUrl)
      };
    }
    throw failure("unavailable", `${providerName} player manifest was not found`);
  }
  caye.register(providerId, {
    source: {
      search(context, query) {
        return __async(this, null, function* () {
          var _a, _b;
          const base = siteUrl(context);
          const q = ((_a = query == null ? void 0 : query.q) != null ? _a : "").trim();
          if (!q) {
            return { items: [], nextCursor: "", state: "complete" };
          }
          const data = yield site.json({
            url: `${base}/api/fsearch`,
            method: "POST",
            headers: { "Content-Type": "application/json", Accept: "application/json" },
            body: JSON.stringify({ query: q, page: 1 })
          });
          const items = [];
          const seen = /* @__PURE__ */ new Set();
          for (const item of Array.isArray(data.result) ? data.result : []) {
            const slug = ((_b = item.slug) != null ? _b : "").trim();
            const name = (item.title_en || item.title || "").trim();
            if (!slug || !name || seen.has(slug)) continue;
            seen.add(slug);
            const year = extractFirstYear(
              item.year !== void 0 ? String(item.year) : item.start_date
            );
            items.push(__spreadValues({
              ref: videoRef(providerId, slug),
              name
            }, year !== void 0 ? { year } : {}));
          }
          return {
            items: limitItems(items, query == null ? void 0 : query.limit),
            nextCursor: "",
            state: "complete"
          };
        });
      },
      read(context, ref) {
        return __async(this, null, function* () {
          const base = siteUrl(context);
          const slug = ref.nativeId.split("|")[0];
          const data = yield site.json({
            url: `${base}/api/show/${encodeURIComponent(slug)}`
          });
          const name = (data.title_en || data.title || "").trim();
          if (!name) {
            throw failure("unavailable", `${providerName} show details are unavailable`);
          }
          const year = extractFirstYear(
            data.year !== void 0 ? String(data.year) : data.start_date
          );
          return __spreadValues({
            ref: sameRef(ref),
            name
          }, year !== void 0 ? { year } : {});
        });
      },
      list(context, ref) {
        return __async(this, null, function* () {
          var _a;
          const base = siteUrl(context);
          const slug = ref.nativeId.split("|")[0];
          const languages = orderLanguages(yield fetchLanguages(base, slug));
          let rawEpisodes = [];
          for (const lang of languages) {
            const eps = yield fetchLanguageEpisodes(base, slug, lang);
            if (eps.length > 0) {
              rawEpisodes = eps;
              break;
            }
          }
          const installments = [];
          const seen = /* @__PURE__ */ new Set();
          for (const ep of rawEpisodes) {
            const num = isIntegerOrFraction(ep);
            const epStr = String((_a = ep.episode_string) != null ? _a : num !== void 0 ? num : "").trim();
            if (num === void 0 || !epStr || !ep.slug || seen.has(epStr)) continue;
            seen.add(epStr);
            installments.push(__spreadProps(__spreadValues({
              number: num
            }, ep.title ? { name: ep.title.trim().slice(0, 500) } : {}), {
              ref: videoRef(providerId, `${slug}|${epStr}`)
            }));
          }
          installments.sort((a, b) => a.number - b.number);
          const audio = uniqueChoices(
            languages.map((lang) => ({
              id: choiceId(lang),
              label: audioChoiceLabel(lang)
            }))
          );
          return {
            installments,
            choices: {
              audio: audio.length > 0 ? audio : [{ id: "sub", label: "Sub" }],
              server: [
                { id: "vidstreaming", label: "VidStreaming" },
                { id: "catstream", label: "CatStream" }
              ],
              quality: [{ id: "auto", label: "Auto" }]
            }
          };
        });
      },
      find(context, ref) {
        return __async(this, null, function* () {
          var _a, _b;
          const base = siteUrl(context);
          const { slug, epStr } = parseEpisodeNativeId(ref.nativeId);
          const languages = orderLanguages(yield fetchLanguages(base, slug));
          const deadline = futureDeadline(context == null ? void 0 : context.deadline);
          const items = [];
          const langResults = yield pooled(languages, 3, (lang) => __async(null, null, function* () {
            const ep = yield findEpisodeSlugForLang(base, slug, lang, epStr);
            if (!(ep == null ? void 0 : ep.slug)) return [];
            const epUrl = `${base}/api/show/${encodeURIComponent(slug)}/episode/ep-${encodeURIComponent(epStr)}-${encodeURIComponent(ep.slug)}`;
            const detail = yield site.json({ url: epUrl });
            return { lang, servers: Array.isArray(detail.servers) ? detail.servers : [] };
          }));
          for (const entry of langResults) {
            if (Array.isArray(entry)) continue;
            const audioId = choiceId(entry.lang);
            for (const srv of entry.servers) {
              const serverName = ((_a = srv.name) != null ? _a : "").trim();
              const src = ((_b = srv.src) != null ? _b : "").trim();
              if (!serverName || !src) continue;
              const serverId = choiceId(serverName);
              items.push({
                id: `${audioId}:${serverId}`,
                origin: "hls",
                capabilities: ["video"],
                expiresAt: deadline,
                tracks: [
                  {
                    id: "main",
                    kind: "video",
                    language: caye.language.toISO1(entry.lang) || "ja",
                    label: `${audioChoiceLabel(entry.lang)} \xB7 ${serverName}`
                  }
                ],
                ranges: [],
                choices: {
                  audio: audioId,
                  server: serverId,
                  quality: "auto"
                }
              });
            }
          }
          return { items, state: "complete" };
        });
      },
      resolve(context, input) {
        return __async(this, null, function* () {
          var _a, _b;
          const base = siteUrl(context);
          const { slug, epStr } = parseEpisodeNativeId(input.ref.nativeId);
          const [wantAudio, wantServer] = input.sourceId.split(":");
          const languages = orderLanguages(yield fetchLanguages(base, slug));
          const matchedLang = languages.find((lang) => choiceId(lang) === wantAudio);
          if (!matchedLang) {
            throw failure("unavailable", `${providerName} audio track is unavailable`);
          }
          const ep = yield findEpisodeSlugForLang(base, slug, matchedLang, epStr);
          if (!(ep == null ? void 0 : ep.slug)) {
            throw failure("unavailable", `${providerName} episode is unavailable`);
          }
          const epUrl = `${base}/api/show/${encodeURIComponent(slug)}/episode/ep-${encodeURIComponent(epStr)}-${encodeURIComponent(ep.slug)}`;
          const detail = yield site.json({ url: epUrl });
          const srv = ((_a = detail.servers) != null ? _a : []).find(
            (item) => {
              var _a2;
              return choiceId((_a2 = item.name) != null ? _a2 : "") === wantServer && item.src;
            }
          );
          if (!(srv == null ? void 0 : srv.src)) {
            throw failure("unavailable", `${providerName} server is unavailable`);
          }
          const playerUrl = srv.src.replace("vast", "player");
          const playerHtml = yield site.text({ url: playerUrl });
          const { manifestUrl, subtitles } = parseAstroPlayer(playerHtml, playerUrl);
          const origin = originOf(playerUrl) || "https://krussdomi.com";
          const handle = yield site.handle({
            url: manifestUrl,
            headers: {
              Origin: origin,
              Referer: srv.src
            }
          });
          return {
            id: input.sourceId,
            origin: streamOriginOf(manifestUrl, "hls"),
            capabilities: ["video"],
            expiresAt: handle.expiresAt,
            handle,
            tracks: [
              {
                id: "main",
                kind: "video",
                language: caye.language.toISO1(matchedLang) || "ja",
                label: `${audioChoiceLabel(matchedLang)} \xB7 ${((_b = srv.name) != null ? _b : wantServer).trim()}`
              }
            ],
            ranges: [],
            subtitles,
            choices: {
              audio: wantAudio,
              server: wantServer,
              quality: "auto"
            }
          };
        });
      }
    }
  });
})();
//# sourceMappingURL=backend.js.map
