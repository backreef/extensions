import type { API, Ref, SourceRecord } from "../../../../packages/plugin-sdk/src/index.ts"
import {
    buildChapterList,
    createMangaSource,
    fetchText,
    makeDirectPageResolver,
    parseChapterNumber,
    type ParsedChapterInput,
    type RawPageInput,
} from "../../manga-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"
import { resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.fanfox:source"
const providerName = "FanFox"
const siteUrl = "https://m.fanfox.net"

function chapterUrlFromId(nativeId: string): string {
    return nativeId.startsWith("http") ? nativeId : `https://${nativeId}`
}

function cleanChapterText(rawHtml: string): string {
    const inner = caye.html.parse(rawHtml)
    inner.find(".chdate, .chnew, .new, .label, span.hot").remove()
    let text = inner.text().replace(/\s+/g, " ").trim()
    text = text
        .replace(/\s*(?:[A-Z][a-z]{2}\s+\d{1,2},\s+\d{4}|\d{4}-\d{2}-\d{2})\s*$/, "")
        .replace(
            /\s*\b(?:new|hot|updated|yesterday|today)\b(?:\s+\d+\s*(?:second|minute|hour|day|week|month|year)s?\s*ago)?\s*$/i,
            "",
        )
        .replace(/\s*\b\d+\s*(?:second|minute|hour|day|week|month|year)s?\s*ago\b\s*$/i, "")
        .trim()
    const prefix = text.match(/^(Ch\s*\d+(?:\.\d+)?)/i)
    return prefix ? prefix[1] : text
}

function extractTitle(html: string): string {
    const doc = caye.html.parse(html)
    return (
        doc.find("p.title").first().text().trim() ||
        doc.find("span.detail-info-title").first().text().trim() ||
        doc.find("h1").first().text().trim() ||
        doc.find("title").first().text().trim()
    )
}

async function findPages(_context: unknown, ref: Ref): Promise<RawPageInput[]> {
    const chapterUrl = chapterUrlFromId(ref.nativeId)
    const rollUrl = chapterUrl.replace("/manga/", "/roll_manga/")
    const { text: html } = await fetchText(providerName, rollUrl, {
        headers: { Referer: chapterUrl },
    })
    const doc = caye.html.parse(html)

    const pages: RawPageInput[] = []
    doc.find("img.reader-page").each((_, el) => {
        const rawSrc = el.attr("data-original") || el.attr("src") || ""
        const resolved = resolveUrl(rawSrc, chapterUrl)
        if (resolved) pages.push({ url: resolved })
    })
    return pages
}

const fanfoxSource = createMangaSource({
    providerId,
    providerName,

    async search(_context, text) {
        const url = new URL("/search", siteUrl)
        url.searchParams.set("k", text)
        const { text: html } = await fetchText(providerName, url.toString())
        const doc = caye.html.parse(html)

        const records: SourceRecord[] = []
        const seen = new Set<string>()
        doc.find("li div.post-one.clearfix").each((_, el) => {
            const href = el.find("a").first().attr("href") || ""
            const title = el.find("p.title").first().text().trim()
            const nativeId = href.replace(/^.*\/manga\//, "").replace(/\/$/, "")
            if (!nativeId || !title || seen.has(nativeId)) return
            seen.add(nativeId)
            records.push({
                ref: { providerId, type: "manga", nativeId },
                name: title,
            })
        })

        if (records.length === 0 && !html.toLowerCase().includes("fanfox")) {
            throw failure("unavailable", `${providerName} returned unexpected search page.`)
        }
        return records
    },

    async read(_context, ref) {
        const url = `${siteUrl}/manga/${ref.nativeId.replace(/^\/+|\/+$/g, "")}`
        const { text: html } = await fetchText(providerName, url)
        const name = extractTitle(html)
        if (!name) {
            throw failure("unavailable", `${providerName} title not found.`)
        }
        return { name }
    },

    async list(_context, ref) {
        const url = `${siteUrl}/manga/${ref.nativeId.replace(/^\/+|\/+$/g, "")}`
        const { text: html } = await fetchText(providerName, url)
        const doc = caye.html.parse(html)

        const entries: ParsedChapterInput[] = []
        doc.find("dd.chlist a").each((_, el) => {
            const href = el.attr("href") || ""
            if (!href) return
            const chapterText = cleanChapterText(el.html())
            const abs = resolveUrl(href, `${siteUrl}/`)
            if (!abs) return
            const nativeId = abs.replace(/^https?:\/\//, "")
            entries.push({
                nativeId,
                name: chapterText || undefined,
                number: parseChapterNumber(chapterText),
            })
        })

        if (entries.length === 0 && !extractTitle(html)) {
            throw failure("unavailable", `${providerName} chapters page unavailable.`)
        }
        return buildChapterList(providerId, entries, { reverse: true, sortByNumber: true })
    },

    findPages,

    resolveTarget: makeDirectPageResolver(
        (ref) => ({ Referer: chapterUrlFromId(ref.nativeId) }),
        findPages,
    ),
})

caye.register(providerId, { source: fanfoxSource })
