(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/json.ts
  function parseJson5(text) {
    let pos = 0;
    const len = text.length;
    const skipWhitespaceAndComments = () => {
      while (pos < len) {
        const ch = text[pos];
        if (/\s/.test(ch)) {
          pos++;
          continue;
        }
        if (ch === "/" && text[pos + 1] === "/") {
          pos += 2;
          while (pos < len && text[pos] !== "\n" && text[pos] !== "\r") pos++;
          continue;
        }
        if (ch === "/" && text[pos + 1] === "*") {
          const closeIdx = text.indexOf("*/", pos + 2);
          if (closeIdx === -1) throw new SyntaxError("Unterminated block comment in JSON5");
          pos = closeIdx + 2;
          continue;
        }
        break;
      }
    };
    const parseString = (quote) => {
      pos++;
      let out = "";
      while (pos < len) {
        const ch = text[pos++];
        if (ch === quote) return out;
        if (ch === "\n" || ch === "\r") {
          throw new SyntaxError("Unescaped newline in JSON5 string");
        }
        if (ch !== "\\") {
          out += ch;
          continue;
        }
        if (pos >= len) throw new SyntaxError("Unterminated escape in JSON5 string");
        const esc = text[pos++];
        switch (esc) {
          case "\r":
            if (text[pos] === "\n") pos++;
            break;
          case "\n":
          case "\u2028":
          case "\u2029":
            break;
          case "n":
            out += "\n";
            break;
          case "r":
            out += "\r";
            break;
          case "t":
            out += "	";
            break;
          case "b":
            out += "\b";
            break;
          case "f":
            out += "\f";
            break;
          case "v":
            out += "\v";
            break;
          case "0":
            if (pos < len && /[0-9]/.test(text[pos])) {
              throw new SyntaxError("Invalid octal escape in JSON5 string");
            }
            out += "\0";
            break;
          case "x": {
            const hex = text.slice(pos, pos + 2);
            if (!/^[0-9a-fA-F]{2}$/.test(hex)) {
              throw new SyntaxError("Invalid hex escape in JSON5 string");
            }
            out += String.fromCharCode(Number.parseInt(hex, 16));
            pos += 2;
            break;
          }
          case "u": {
            const hex = text.slice(pos, pos + 4);
            if (!/^[0-9a-fA-F]{4}$/.test(hex)) {
              throw new SyntaxError("Invalid unicode escape in JSON5 string");
            }
            out += String.fromCharCode(Number.parseInt(hex, 16));
            pos += 4;
            break;
          }
          default:
            out += esc;
            break;
        }
      }
      throw new SyntaxError("Unterminated JSON5 string");
    };
    const parseIdentifier = () => {
      const start = pos;
      while (pos < len && /[\w$\\]/.test(text[pos])) {
        pos++;
      }
      if (pos === start) {
        throw new SyntaxError(`Unexpected token at position ${pos}`);
      }
      return text.slice(start, pos);
    };
    const parseNumberOrKeyword = () => {
      const start = pos;
      if (text[pos] === "+" || text[pos] === "-") pos++;
      if (text.startsWith("Infinity", pos)) {
        pos += 8;
        return text[start] === "-" ? Number.NEGATIVE_INFINITY : Number.POSITIVE_INFINITY;
      }
      if (text.startsWith("NaN", pos)) {
        pos += 3;
        return Number.NaN;
      }
      if (text[pos] === "0" && (text[pos + 1] === "x" || text[pos + 1] === "X")) {
        pos += 2;
        const hexStart = pos;
        while (pos < len && /[0-9a-fA-F]/.test(text[pos])) pos++;
        if (pos === hexStart) throw new SyntaxError(`Invalid hex number at ${start}`);
        const num = Number.parseInt(text.slice(hexStart, pos), 16);
        return text[start] === "-" ? -num : num;
      }
      let hasDigit = false;
      while (pos < len && /[0-9]/.test(text[pos])) {
        hasDigit = true;
        pos++;
      }
      if (text[pos] === ".") {
        pos++;
        while (pos < len && /[0-9]/.test(text[pos])) {
          hasDigit = true;
          pos++;
        }
      }
      if (!hasDigit) throw new SyntaxError(`Invalid number at ${start}`);
      if (text[pos] === "e" || text[pos] === "E") {
        pos++;
        if (text[pos] === "+" || text[pos] === "-") pos++;
        const expStart = pos;
        while (pos < len && /[0-9]/.test(text[pos])) pos++;
        if (pos === expStart) throw new SyntaxError(`Invalid exponent at ${start}`);
      }
      return Number(text.slice(start, pos));
    };
    const parseValue = () => {
      var _a, _b, _c;
      skipWhitespaceAndComments();
      if (pos >= len) throw new SyntaxError("Unexpected end of JSON5 input");
      const ch = text[pos];
      if (ch === "{") return parseObject();
      if (ch === "[") return parseArray();
      if (ch === '"' || ch === "'") return parseString(ch);
      if (text.startsWith("true", pos) && !/[\w$]/.test((_a = text[pos + 4]) != null ? _a : "")) {
        pos += 4;
        return true;
      }
      if (text.startsWith("false", pos) && !/[\w$]/.test((_b = text[pos + 5]) != null ? _b : "")) {
        pos += 5;
        return false;
      }
      if (text.startsWith("null", pos) && !/[\w$]/.test((_c = text[pos + 4]) != null ? _c : "")) {
        pos += 4;
        return null;
      }
      if (ch === "+" || ch === "-" || ch === "." || ch >= "0" && ch <= "9" || text.startsWith("Infinity", pos) || text.startsWith("NaN", pos)) {
        return parseNumberOrKeyword();
      }
      throw new SyntaxError(`Unexpected character '${ch}' at position ${pos}`);
    };
    const parseArray = () => {
      pos++;
      const arr = [];
      while (true) {
        skipWhitespaceAndComments();
        if (text[pos] === "]") {
          pos++;
          return arr;
        }
        arr.push(parseValue());
        skipWhitespaceAndComments();
        if (text[pos] === ",") {
          pos++;
          continue;
        }
        if (text[pos] === "]") {
          pos++;
          return arr;
        }
        throw new SyntaxError(`Expected ',' or ']' at position ${pos}`);
      }
    };
    const parseObject = () => {
      pos++;
      const obj = {};
      while (true) {
        skipWhitespaceAndComments();
        if (text[pos] === "}") {
          pos++;
          return obj;
        }
        const ch = text[pos];
        const key = ch === '"' || ch === "'" ? parseString(ch) : parseIdentifier();
        skipWhitespaceAndComments();
        if (text[pos] !== ":") {
          throw new SyntaxError(`Expected ':' at position ${pos}`);
        }
        pos++;
        obj[key] = parseValue();
        skipWhitespaceAndComments();
        if (text[pos] === ",") {
          pos++;
          continue;
        }
        if (text[pos] === "}") {
          pos++;
          return obj;
        }
        throw new SyntaxError(`Expected ',' or '}' at position ${pos}`);
      }
    };
    const result = parseValue();
    skipWhitespaceAndComments();
    if (pos < len) {
      throw new SyntaxError(`Unexpected trailing character at position ${pos}`);
    }
    return result;
  }

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../manga-common/src/http.ts
  function fetchText(_0, _1) {
    return __async(this, arguments, function* (providerName2, url, options = {}) {
      var _a, _b, _c;
      const response = yield httpClient(caye, providerName2).send(__spreadProps(__spreadValues({}, options), { url, mode: "text" }));
      return {
        text: (_a = response.body) != null ? _a : "",
        url: (_b = response.url) != null ? _b : url,
        redirected: Boolean(response.redirected),
        headers: (_c = response.headers) != null ? _c : {}
      };
    });
  }
  function fetchHandle(_0, _1) {
    return __async(this, arguments, function* (providerName2, url, headers = {}) {
      const handle = yield httpClient(caye, providerName2).handle({ url, headers });
      if (handle.mediaType.toLowerCase().startsWith("text/html")) {
        throw failure("unavailable", `${providerName2} returned HTML instead of image.`);
      }
      return handle;
    });
  }

  // ../../../packages/plugin-std/src/titles.ts
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];
  function extractChapter(title) {
    for (const re of CHAPTER_PATTERNS) {
      const match = title.match(re);
      if (match) {
        const val = Number.parseFloat(match[1].replace(/[,-]/, "."));
        if (Number.isFinite(val)) return val;
      }
    }
    return -1;
  }

  // ../manga-common/src/manga.ts
  function parseChapterNumber(value) {
    if (typeof value === "number") return Number.isFinite(value) && value >= 0 ? value : void 0;
    if (typeof value !== "string" || !value.trim()) return void 0;
    const chapter = extractChapter(value);
    if (chapter >= 0) return chapter;
    const fallback = value.replace(/\bvol(?:ume)?\.?\s*\d+(?:[.,-]\d+)?/gi, " ").match(/\b(\d+(?:[.,]\d+)?)\b/);
    return fallback ? Number.parseFloat(fallback[1].replace(",", ".")) : void 0;
  }
  function boundedDeadline(deadline) {
    const now = Date.now();
    const parsed = deadline ? Date.parse(deadline) : Number.NaN;
    if (Number.isFinite(parsed) && parsed > now + 1e3 && parsed <= now + 23 * 3600 * 1e3) {
      return new Date(parsed).toISOString();
    }
    return new Date(now + 3600 * 1e3).toISOString();
  }
  function paginateSearch(records, query) {
    const limit = Math.max(1, Math.min(200, query.limit || 25));
    const parsedOffset = query.cursor ? Number.parseInt(query.cursor, 10) : 0;
    const offset = Number.isFinite(parsedOffset) && parsedOffset > 0 ? parsedOffset : 0;
    const items = records.slice(offset, offset + limit);
    const nextCursor = offset + limit < records.length ? String(offset + limit) : "";
    return {
      items,
      nextCursor,
      state: "complete"
    };
  }
  function sanitizeScopePart(value) {
    return value.trim().toLowerCase().replace(/\s+/g, "-").slice(0, 80);
  }
  function addDistinctOption(seen, raw) {
    const trimmed = raw == null ? void 0 : raw.trim();
    if (!trimmed) return void 0;
    const id = sanitizeScopePart(trimmed);
    if (!id) return void 0;
    if (!seen.has(id)) {
      seen.set(id, trimmed.slice(0, 200));
    }
    return id;
  }
  function sortChaptersForReading(entries, options) {
    const list = options.reverse ? entries.slice().reverse() : entries.slice();
    if (!options.sortByNumber) {
      return list;
    }
    let lastAnchor = -1;
    let unnumberedOffset = 0;
    const keyed = list.map((item, idx) => {
      if (item.number !== void 0) {
        lastAnchor = item.number;
        unnumberedOffset = 0;
        return { item, key: item.number, sub: 0, idx };
      }
      unnumberedOffset += 1;
      return {
        item,
        key: lastAnchor >= 0 ? lastAnchor : Number.MAX_SAFE_INTEGER,
        sub: unnumberedOffset,
        idx
      };
    });
    keyed.sort((a, b) => {
      if (a.key !== b.key) return a.key - b.key;
      if (a.sub !== b.sub) return a.sub - b.sub;
      return a.idx - b.idx;
    });
    return keyed.map((entry) => entry.item);
  }
  function buildChapterList(providerId2, entries, options = {}) {
    var _a;
    const ordered = sortChaptersForReading(entries, options);
    const numberCounts = /* @__PURE__ */ new Map();
    const languages = /* @__PURE__ */ new Map();
    const scanlators = /* @__PURE__ */ new Map();
    for (const entry of ordered) {
      if (entry.number !== void 0) {
        numberCounts.set(entry.number, ((_a = numberCounts.get(entry.number)) != null ? _a : 0) + 1);
      }
      addDistinctOption(languages, entry.language);
      addDistinctOption(scanlators, entry.scanlator);
    }
    const hasDuplicates = Array.from(numberCounts.values()).some((count) => count > 1);
    const multiLanguage = languages.size > 1;
    const multiScanlator = scanlators.size > 1;
    const needsScope = hasDuplicates && (multiLanguage || multiScanlator);
    const groups = [];
    if (needsScope && multiLanguage) {
      groups.push({
        id: "language",
        label: "Language",
        options: Array.from(languages.entries()).slice(0, 200).map(([id, label]) => ({ id, label }))
      });
    }
    if (needsScope && multiScanlator) {
      groups.push({
        id: "scanlator",
        label: "Scanlator",
        options: Array.from(scanlators.entries()).slice(0, 200).map(([id, label]) => ({ id, label }))
      });
    }
    const choices = groups.length > 0 ? { groups: groups.slice(0, 8) } : {};
    const seenKeys = /* @__PURE__ */ new Set();
    const installments = [];
    for (const entry of ordered) {
      const nativeId = entry.nativeId.trim();
      if (!nativeId) continue;
      if (nativeId.length > 200) {
        throw failure("unavailable", "Chapter ID is too long.");
      }
      const langId = entry.language ? sanitizeScopePart(entry.language) : "";
      const scanId = entry.scanlator ? sanitizeScopePart(entry.scanlator) : "";
      let scope;
      if (needsScope) {
        const parts = [];
        if (multiLanguage && langId) parts.push(langId);
        if (multiScanlator && scanId) parts.push(scanId);
        if (parts.length > 0) scope = parts.join(":").slice(0, 200);
      }
      const dedupeKey = `${nativeId}\0${scope != null ? scope : ""}`;
      if (seenKeys.has(dedupeKey)) continue;
      seenKeys.add(dedupeKey);
      const installment = __spreadValues(__spreadValues(__spreadValues({
        ref: __spreadValues({
          providerId: providerId2,
          type: "chapter",
          nativeId
        }, scope ? { scope } : {}),
        number: entry.number
      }, entry.name ? { name: entry.name.trim().slice(0, 500) } : {}), entry.language ? { language: entry.language.trim().slice(0, 35) } : {}), entry.scanlator ? { scanlator: entry.scanlator.trim().slice(0, 200) } : {});
      if (entry.number === void 0) {
        delete installment.number;
      }
      installments.push(installment);
    }
    return { installments, choices };
  }
  function buildSourcePage(context, rawPages) {
    const seenIds = /* @__PURE__ */ new Set();
    const pages = rawPages.slice(0, 5e3).map((page, index) => {
      var _a;
      const candidateId = !page.forceIndexId && page.url.length > 0 && page.url.length <= 200 ? page.url : String(index + 1);
      const id = !seenIds.has(candidateId) ? candidateId : String(index + 1);
      seenIds.add(id);
      const name = (((_a = page.name) == null ? void 0 : _a.trim()) || `Page ${index + 1}`).slice(0, 200);
      return __spreadValues(__spreadValues({
        id,
        name
      }, typeof page.width === "number" && Number.isInteger(page.width) && page.width > 0 ? { width: page.width } : {}), typeof page.height === "number" && Number.isInteger(page.height) && page.height > 0 ? { height: page.height } : {});
    });
    return {
      items: [
        {
          id: "pages",
          capabilities: ["pages"],
          origin: "pages",
          expiresAt: boundedDeadline(context.deadline),
          tracks: [],
          ranges: [],
          pages
        }
      ],
      state: "complete"
    };
  }
  function resolvePageSource(providerName2, input, target) {
    return __async(this, null, function* () {
      if (!target) {
        throw failure("unavailable", `${providerName2} page not found.`);
      }
      const handle = "resolveHandle" in target ? yield target.resolveHandle() : yield fetchHandle(providerName2, target.url, target.headers);
      return {
        id: input.sourceId,
        capabilities: ["pages"],
        origin: "pages",
        expiresAt: handle.expiresAt,
        tracks: [],
        ranges: [],
        handle
      };
    });
  }
  function createMangaSource(adapter) {
    return {
      search(context, query) {
        return __async(this, null, function* () {
          var _a2;
          const text = ((_a2 = query.q) != null ? _a2 : "").trim();
          if (!text) {
            return { items: [], nextCursor: "", state: "complete" };
          }
          const records = yield adapter.search(context, text, query);
          return paginateSearch(records, query);
        });
      },
      read(context, ref) {
        return __async(this, null, function* () {
          var _a2, _b;
          if (!((_a2 = ref == null ? void 0 : ref.nativeId) == null ? void 0 : _a2.trim())) {
            throw failure("unavailable", `${adapter.providerName} record ID is required.`);
          }
          const info = yield adapter.read(context, ref);
          if (!((_b = info.name) == null ? void 0 : _b.trim())) {
            throw failure("unavailable", `${adapter.providerName} record title is missing.`);
          }
          return __spreadValues({
            ref,
            name: info.name.trim()
          }, info.year !== void 0 ? { year: info.year } : {});
        });
      },
      list(context, ref) {
        return __async(this, null, function* () {
          var _a2;
          if (!((_a2 = ref == null ? void 0 : ref.nativeId) == null ? void 0 : _a2.trim())) {
            throw failure("unavailable", `${adapter.providerName} record ID is required.`);
          }
          return adapter.list(context, ref);
        });
      },
      find(context, ref) {
        return __async(this, null, function* () {
          var _a2;
          if (!((_a2 = ref == null ? void 0 : ref.nativeId) == null ? void 0 : _a2.trim())) {
            throw failure("unavailable", `${adapter.providerName} chapter ID is required.`);
          }
          const pages = yield adapter.findPages(context, ref);
          if (pages.length === 0) {
            throw failure("unavailable", `${adapter.providerName} returned no chapter pages.`);
          }
          return buildSourcePage(context, pages);
        });
      },
      resolve(context, input) {
        return __async(this, null, function* () {
          var _a2, _b;
          if (!((_b = (_a2 = input == null ? void 0 : input.ref) == null ? void 0 : _a2.nativeId) == null ? void 0 : _b.trim())) {
            throw failure("unavailable", `${adapter.providerName} chapter ID is required.`);
          }
          const target = yield adapter.resolveTarget(context, input);
          return resolvePageSource(adapter.providerName, input, target);
        });
      }
    };
  }
  function pickPageFromList(pages, pageId) {
    if (!pages.length) return void 0;
    if (!pageId) return pages[0];
    const byUrl = pages.find((p) => p.url === pageId);
    if (byUrl) return byUrl;
    if (/^\d+$/.test(pageId)) {
      const index = Number.parseInt(pageId, 10) - 1;
      return pages[index];
    }
    return void 0;
  }
  function makeDirectPageResolver(headersFor, findPages2) {
    return (context, input) => __async(null, null, function* () {
      var _a;
      if (input.pageId && /^https?:\/\//i.test(input.pageId)) {
        return {
          url: input.pageId,
          headers: headersFor(input.ref)
        };
      }
      const pages = yield findPages2(context, input.ref);
      const target = pickPageFromList(pages, input.pageId);
      if (!target) return void 0;
      return {
        url: target.url,
        headers: (_a = target.headers) != null ? _a : headersFor(input.ref)
      };
    });
  }

  // ../../../packages/plugin-std/src/url.ts
  function resolveUrl(raw, base) {
    const trimmed = raw.trim();
    if (!trimmed) return "";
    try {
      const url = new URL(trimmed.startsWith("//") ? `https:${trimmed}` : trimmed, base);
      return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : "";
    } catch (e) {
      return "";
    }
  }

  // src/backend.ts
  var providerId = "backreef.mangakatana:source";
  var providerName = "MangaKatana";
  var siteUrl = "https://mangakatana.com";
  function extractMangaSlug(rawUrl) {
    var _a, _b;
    try {
      const parsed = new URL(rawUrl, siteUrl);
      const match = parsed.pathname.match(/^\/manga\/([^/?#]+)/i);
      return (_b = (_a = match == null ? void 0 : match[1]) == null ? void 0 : _a.trim()) != null ? _b : "";
    } catch (e) {
      return "";
    }
  }
  function readTitleFromDoc(html) {
    var _a;
    const doc = caye.html.parse(html);
    return doc.find("h1.heading").first().text().trim() || doc.find("h1").first().text().trim() || ((_a = doc.find('meta[property="og:title"]').attr("content")) == null ? void 0 : _a.trim()) || "";
  }
  function extractArrayLiteral(script, varName) {
    const re = new RegExp(`\\b${varName}\\s*=\\s*\\[`, "i");
    const match = re.exec(script);
    if (!match) return "";
    const start = match.index + match[0].length - 1;
    let depth = 0;
    let quote = "";
    let escaped = false;
    for (let i = start; i < script.length; i++) {
      const ch = script[i];
      if (quote) {
        if (escaped) {
          escaped = false;
        } else if (ch === "\\") {
          escaped = true;
        } else if (ch === quote) {
          quote = "";
        }
        continue;
      }
      if (ch === "'" || ch === '"') {
        quote = ch;
      } else if (ch === "[") {
        depth++;
      } else if (ch === "]") {
        depth--;
        if (depth === 0) {
          return script.slice(start, i + 1);
        }
      }
    }
    return "";
  }
  function findPages(_context, ref) {
    return __async(this, null, function* () {
      const chapterUrl = ref.nativeId.startsWith("http") ? ref.nativeId : `${siteUrl}/manga/${ref.nativeId.replace(/^\/+/, "")}`;
      const { text: html } = yield fetchText(providerName, chapterUrl, {
        headers: { Referer: `${siteUrl}/` }
      });
      const doc = caye.html.parse(html);
      let rawLiteral = "";
      doc.find("script").each((_, el) => {
        if (rawLiteral) return;
        const body = el.text();
        if (/\bthzq\s*=/i.test(body)) {
          rawLiteral = extractArrayLiteral(body, "thzq");
        }
      });
      if (!rawLiteral) {
        throw failure("unavailable", `${providerName} page images script not found`);
      }
      let parsed;
      try {
        parsed = parseJson5(rawLiteral);
      } catch (e) {
        throw failure("unavailable", `${providerName} failed to parse image list`);
      }
      if (!Array.isArray(parsed)) {
        throw failure("unavailable", `${providerName} returned unexpected image list`);
      }
      const pages = [];
      for (const entry of parsed) {
        if (typeof entry !== "string") continue;
        const resolved = resolveUrl(entry, chapterUrl);
        if (resolved) pages.push({ url: resolved });
      }
      return pages;
    });
  }
  var mangakatanaSource = createMangaSource({
    providerId,
    providerName,
    search(_context, text) {
      return __async(this, null, function* () {
        const url = new URL("/", siteUrl);
        url.searchParams.set("search", text);
        url.searchParams.set("search_by", "m_name");
        const res = yield fetchText(providerName, url.toString(), {
          headers: { Referer: `${siteUrl}/` }
        });
        if (res.redirected && /\/manga\//i.test(res.url)) {
          const slug = extractMangaSlug(res.url);
          const title = readTitleFromDoc(res.text);
          if (!slug || !title) {
            throw failure("unavailable", `${providerName} returned incomplete redirect page`);
          }
          return [{ ref: { providerId, type: "manga", nativeId: slug }, name: title }];
        }
        const doc = caye.html.parse(res.text);
        const records = [];
        const seen = /* @__PURE__ */ new Set();
        doc.find("div.item").each((_, el) => {
          const link = el.find("h3.title a").first();
          const href = link.attr("href") || "";
          const slug = extractMangaSlug(href);
          const title = link.text().trim();
          if (!slug || !title || seen.has(slug)) return;
          seen.add(slug);
          records.push({
            ref: { providerId, type: "manga", nativeId: slug },
            name: title
          });
        });
        if (records.length === 0 && !res.text.toLowerCase().includes("mangakatana")) {
          throw failure("unavailable", `${providerName} returned unexpected search page`);
        }
        return records;
      });
    },
    read(_context, ref) {
      return __async(this, null, function* () {
        const url = `${siteUrl}/manga/${ref.nativeId}`;
        const { text: html } = yield fetchText(providerName, url, {
          headers: { Referer: `${siteUrl}/` }
        });
        const name = readTitleFromDoc(html);
        if (!name) {
          throw failure("unavailable", `${providerName} title not found`);
        }
        return { name };
      });
    },
    list(_context, ref) {
      return __async(this, null, function* () {
        const url = `${siteUrl}/manga/${ref.nativeId}`;
        const { text: html } = yield fetchText(providerName, url, {
          headers: { Referer: `${siteUrl}/` }
        });
        const doc = caye.html.parse(html);
        const entries = [];
        doc.find("tr").each((_, row) => {
          var _a;
          const link = row.find("div.chapter a").first();
          const href = link.attr("href") || "";
          const chMatch = href.match(/\/manga\/[^/?#]+\/c([^/?#]+)/i);
          if (!(chMatch == null ? void 0 : chMatch[1])) return;
          const rawTitle = link.text().trim();
          const updated = row.find("div.update_time").first().text().trim();
          const number = (_a = parseChapterNumber(rawTitle)) != null ? _a : parseChapterNumber(`c${chMatch[1]}`);
          entries.push({
            nativeId: `${ref.nativeId}/c${chMatch[1]}`,
            name: updated ? `${rawTitle} - ${updated}` : rawTitle,
            number
          });
        });
        if (entries.length === 0 && !readTitleFromDoc(html)) {
          throw failure("unavailable", `${providerName} chapters page unavailable`);
        }
        return buildChapterList(providerId, entries, { reverse: true, sortByNumber: true });
      });
    },
    findPages,
    resolveTarget: makeDirectPageResolver(() => ({ Referer: siteUrl }), findPages)
  });
  caye.register(providerId, { source: mangakatanaSource });
})();
//# sourceMappingURL=backend.js.map
