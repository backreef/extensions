import type { API, Ref, SourceRecord } from "../../../../packages/plugin-sdk/src/index.ts"
import { parseJson5 } from "../../../../packages/plugin-std/src/json.ts"
import {
    buildChapterList,
    createMangaSource,
    fetchText,
    makeDirectPageResolver,
    parseChapterNumber,
    type ParsedChapterInput,
    type RawPageInput,
} from "../../manga-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"
import { resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.mangakatana:source"
const providerName = "MangaKatana"
const siteUrl = "https://mangakatana.com"

function extractMangaSlug(rawUrl: string): string {
    try {
        const parsed = new URL(rawUrl, siteUrl)
        const match = parsed.pathname.match(/^\/manga\/([^/?#]+)/i)
        return match?.[1]?.trim() ?? ""
    } catch {
        return ""
    }
}

function readTitleFromDoc(html: string): string {
    const doc = caye.html.parse(html)
    return (
        doc.find("h1.heading").first().text().trim() ||
        doc.find("h1").first().text().trim() ||
        doc.find('meta[property="og:title"]').attr("content")?.trim() ||
        ""
    )
}

function extractArrayLiteral(script: string, varName: string): string {
    const re = new RegExp(`\\b${varName}\\s*=\\s*\\[`, "i")
    const match = re.exec(script)
    if (!match) return ""
    const start = match.index + match[0].length - 1
    let depth = 0
    let quote = ""
    let escaped = false
    for (let i = start; i < script.length; i++) {
        const ch = script[i]
        if (quote) {
            if (escaped) {
                escaped = false
            } else if (ch === "\\") {
                escaped = true
            } else if (ch === quote) {
                quote = ""
            }
            continue
        }
        if (ch === "'" || ch === '"') {
            quote = ch
        } else if (ch === "[") {
            depth++
        } else if (ch === "]") {
            depth--
            if (depth === 0) {
                return script.slice(start, i + 1)
            }
        }
    }
    return ""
}

async function findPages(_context: unknown, ref: Ref): Promise<RawPageInput[]> {
    const chapterUrl = ref.nativeId.startsWith("http")
        ? ref.nativeId
        : `${siteUrl}/manga/${ref.nativeId.replace(/^\/+/, "")}`
    const { text: html } = await fetchText(providerName, chapterUrl, {
        headers: { Referer: `${siteUrl}/` },
    })
    const doc = caye.html.parse(html)

    let rawLiteral = ""
    doc.find("script").each((_, el) => {
        if (rawLiteral) return
        const body = el.text()
        if (/\bthzq\s*=/i.test(body)) {
            rawLiteral = extractArrayLiteral(body, "thzq")
        }
    })
    if (!rawLiteral) {
        throw failure("unavailable", `${providerName} page images script not found`)
    }

    let parsed: unknown
    try {
        parsed = parseJson5(rawLiteral)
    } catch {
        throw failure("unavailable", `${providerName} failed to parse image list`)
    }
    if (!Array.isArray(parsed)) {
        throw failure("unavailable", `${providerName} returned unexpected image list`)
    }

    const pages: RawPageInput[] = []
    for (const entry of parsed) {
        if (typeof entry !== "string") continue
        const resolved = resolveUrl(entry, chapterUrl)
        if (resolved) pages.push({ url: resolved })
    }
    return pages
}

const mangakatanaSource = createMangaSource({
    providerId,
    providerName,

    async search(_context, text) {
        const url = new URL("/", siteUrl)
        url.searchParams.set("search", text)
        url.searchParams.set("search_by", "m_name")
        const res = await fetchText(providerName, url.toString(), {
            headers: { Referer: `${siteUrl}/` },
        })

        if (res.redirected && /\/manga\//i.test(res.url)) {
            const slug = extractMangaSlug(res.url)
            const title = readTitleFromDoc(res.text)
            if (!slug || !title) {
                throw failure("unavailable", `${providerName} returned incomplete redirect page`)
            }
            return [{ ref: { providerId, type: "manga", nativeId: slug }, name: title }]
        }

        const doc = caye.html.parse(res.text)
        const records: SourceRecord[] = []
        const seen = new Set<string>()
        doc.find("div.item").each((_, el) => {
            const link = el.find("h3.title a").first()
            const href = link.attr("href") || ""
            const slug = extractMangaSlug(href)
            const title = link.text().trim()
            if (!slug || !title || seen.has(slug)) return
            seen.add(slug)
            records.push({
                ref: { providerId, type: "manga", nativeId: slug },
                name: title,
            })
        })

        if (records.length === 0 && !res.text.toLowerCase().includes("mangakatana")) {
            throw failure("unavailable", `${providerName} returned unexpected search page`)
        }
        return records
    },

    async read(_context, ref) {
        const url = `${siteUrl}/manga/${ref.nativeId}`
        const { text: html } = await fetchText(providerName, url, {
            headers: { Referer: `${siteUrl}/` },
        })
        const name = readTitleFromDoc(html)
        if (!name) {
            throw failure("unavailable", `${providerName} title not found`)
        }
        return { name }
    },

    async list(_context, ref) {
        const url = `${siteUrl}/manga/${ref.nativeId}`
        const { text: html } = await fetchText(providerName, url, {
            headers: { Referer: `${siteUrl}/` },
        })
        const doc = caye.html.parse(html)

        const entries: ParsedChapterInput[] = []
        doc.find("tr").each((_, row) => {
            const link = row.find("div.chapter a").first()
            const href = link.attr("href") || ""
            const chMatch = href.match(/\/manga\/[^/?#]+\/c([^/?#]+)/i)
            if (!chMatch?.[1]) return
            const rawTitle = link.text().trim()
            const updated = row.find("div.update_time").first().text().trim()
            const number = parseChapterNumber(rawTitle) ?? parseChapterNumber(`c${chMatch[1]}`)
            entries.push({
                nativeId: `${ref.nativeId}/c${chMatch[1]}`,
                name: updated ? `${rawTitle} - ${updated}` : rawTitle,
                number,
            })
        })

        if (entries.length === 0 && !readTitleFromDoc(html)) {
            throw failure("unavailable", `${providerName} chapters page unavailable`)
        }
        return buildChapterList(providerId, entries, { reverse: true, sortByNumber: true })
    },

    findPages,

    resolveTarget: makeDirectPageResolver(() => ({ Referer: siteUrl }), findPages),
})

caye.register(providerId, { source: mangakatanaSource })
