(() => {
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve2, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve2(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/provider-source/src/errors.ts
  function failure(code, message) {
    const error = new Error(message);
    error.code = code;
    return error;
  }

  // src/backend.ts
  function count(value) {
    if (typeof value !== "string" && typeof value !== "number") return void 0;
    if (!/^\d+$/.test(String(value))) return void 0;
    const n = Number(value);
    return Number.isSafeInteger(n) && n >= 0 ? n : void 0;
  }
  function option(value) {
    if (!value || typeof value !== "object") return void 0;
    const row = value;
    const id = String(row.id);
    if (!/^[1-9][0-9]*$/.test(id) || typeof row.name !== "string" || !row.name.trim()) {
      return void 0;
    }
    if (typeof row.info_hash !== "string" || !/^[a-f0-9]{40}$/i.test(row.info_hash)) {
      return void 0;
    }
    const hash = row.info_hash.toLowerCase();
    if (/^0+$/.test(hash)) return void 0;
    const magnet = `magnet:?xt=urn:btih:${hash}&dn=${encodeURIComponent(row.name)}&tr=${encodeURIComponent("udp://tracker.opentrackr.org:1337/announce")}`;
    const result = {
      id: `thepiratebay-${id}`,
      name: row.name,
      kind: "torrent",
      uri: magnet,
      magnet,
      pageUrl: `https://thepiratebay.org/description.php?id=${id}`,
      files: [],
      facts: [],
      availability: "available",
      eligible: true,
      reasons: [],
      confirmed: false
    };
    result.seeders = count(row.seeders);
    result.size = count(row.size);
    const added = count(row.added);
    if (added !== void 0) {
      const date = new Date(added * 1e3);
      if (!Number.isNaN(date.getTime())) result.publishedAt = date.toISOString();
    }
    return result;
  }
  function read(path) {
    return __async(this, null, function* () {
      const response = yield caye.http({
        url: `https://apibay.org/${path}`,
        method: "GET",
        headers: { Accept: "application/json" }
      });
      if (response.status === 404 && path.startsWith("t.php")) {
        throw failure("missing", "The Pirate Bay no longer lists this torrent.");
      }
      if (response.status !== 200 || !response.body) {
        throw failure("unavailable", `The Pirate Bay answered ${response.status}.`);
      }
      try {
        return JSON.parse(response.body);
      } catch (e) {
        throw failure("unavailable", "The Pirate Bay returned an invalid response.");
      }
    });
  }
  function find(_context, query) {
    return __async(this, null, function* () {
      var _a;
      const text = (_a = query.text) == null ? void 0 : _a.trim();
      if (!text) throw failure("unsupported", "Enter a title to search.");
      const rows = yield read(`q.php?q=${encodeURIComponent(text)}&cat=0`);
      if (!Array.isArray(rows)) {
        throw failure("unavailable", "The Pirate Bay returned an invalid search response.");
      }
      const items = [];
      const seen = /* @__PURE__ */ new Set();
      let invalid = false;
      for (const row of rows) {
        if (row && String(row.id) === "0") continue;
        const item = option(row);
        if (!item) {
          invalid = true;
          continue;
        }
        if (seen.has(item.id)) continue;
        seen.add(item.id);
        items.push(item);
      }
      if (invalid && items.length === 0) {
        throw failure("unavailable", "The Pirate Bay returned invalid torrents.");
      }
      items.sort((a, b) => {
        var _a2, _b;
        return ((_a2 = b.seeders) != null ? _a2 : 0) - ((_b = a.seeders) != null ? _b : 0);
      });
      const limit = Math.min(Math.max(query.limit || 50, 1), 100);
      const selected = items.slice(0, limit);
      for (const item of selected) {
        yield caye.cache.set({
          key: item.id,
          value: { kind: "text", text: JSON.stringify(item) },
          ttlSeconds: 3600
        });
      }
      return { items: selected, state: invalid ? "partial" : "complete" };
    });
  }
  function resolve(_context, input) {
    return __async(this, null, function* () {
      var _a;
      const match = /^thepiratebay-([1-9][0-9]*)$/.exec((_a = input.optionId) != null ? _a : "");
      if (!match) throw failure("missing", "Unknown The Pirate Bay option.");
      const cached = yield caye.cache.get({ key: `thepiratebay-${match[1]}` });
      if ((cached == null ? void 0 : cached.kind) === "text") {
        try {
          return JSON.parse(cached.text);
        } catch (e) {
        }
      }
      const row = yield read(`t.php?id=${match[1]}`);
      if (row && typeof row === "object" && String(row.id) === "0") {
        throw failure("missing", "The Pirate Bay no longer lists this torrent.");
      }
      const item = option(row);
      if (!item || item.id !== input.optionId) {
        throw failure("unavailable", "The Pirate Bay returned an invalid torrent.");
      }
      return item;
    });
  }
  caye.register("backreef.thepiratebay:search", { acquisition: { find, resolve } });
})();
//# sourceMappingURL=backend.js.map
