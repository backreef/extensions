import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DownloadOption,
} from "../../../../packages/plugin-sdk/src/index"
import { failure } from "../../../../packages/provider-source/src/errors"

declare const caye: API

function count(value: unknown): number | undefined {
    if (typeof value !== "string" && typeof value !== "number") return undefined
    if (!/^\d+$/.test(String(value))) return undefined
    const n = Number(value)
    return Number.isSafeInteger(n) && n >= 0 ? n : undefined
}

function option(value: unknown): DownloadOption | undefined {
    if (!value || typeof value !== "object") return undefined
    const row = value as Record<string, unknown>
    const id = String(row.id)
    if (!/^[1-9][0-9]*$/.test(id) || typeof row.name !== "string" || !row.name.trim()) {
        return undefined
    }
    if (typeof row.info_hash !== "string" || !/^[a-f0-9]{40}$/i.test(row.info_hash)) {
        return undefined
    }
    const hash = row.info_hash.toLowerCase()
    if (/^0+$/.test(hash)) return undefined
    const magnet = `magnet:?xt=urn:btih:${hash}&dn=${encodeURIComponent(row.name)}&tr=${encodeURIComponent("udp://tracker.opentrackr.org:1337/announce")}`
    const result: DownloadOption = {
        id: `thepiratebay-${id}`,
        name: row.name,
        kind: "torrent",
        uri: magnet,
        magnet,
        pageUrl: `https://thepiratebay.org/description.php?id=${id}`,
        files: [],
        facts: [],
        availability: "available",
        eligible: true,
        reasons: [],
        confirmed: false,
    }
    result.seeders = count(row.seeders)
    result.size = count(row.size)
    const added = count(row.added)
    if (added !== undefined) {
        const date = new Date(added * 1000)
        if (!Number.isNaN(date.getTime())) result.publishedAt = date.toISOString()
    }
    return result
}

async function read(path: string): Promise<unknown> {
    const response = await caye.http({
        url: `https://apibay.org/${path}`,
        method: "GET",
        headers: { Accept: "application/json" },
    })
    if (response.status === 404 && path.startsWith("t.php")) {
        throw failure("missing", "The Pirate Bay no longer lists this torrent.")
    }
    if (response.status !== 200 || !response.body) {
        throw failure("unavailable", `The Pirate Bay answered ${response.status}.`)
    }
    try {
        return JSON.parse(response.body) as unknown
    } catch {
        throw failure("unavailable", "The Pirate Bay returned an invalid response.")
    }
}

async function find(_context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const text = query.text?.trim()
    if (!text) throw failure("unsupported", "Enter a title to search.")
    const rows = await read(`q.php?q=${encodeURIComponent(text)}&cat=0`)
    if (!Array.isArray(rows)) {
        throw failure("unavailable", "The Pirate Bay returned an invalid search response.")
    }
    const items: DownloadOption[] = []
    const seen = new Set<string>()
    let invalid = false
    for (const row of rows) {
        if (row && String(row.id) === "0") continue
        const item = option(row)
        if (!item) {
            invalid = true
            continue
        }
        if (seen.has(item.id)) continue
        seen.add(item.id)
        items.push(item)
    }
    if (invalid && items.length === 0) {
        throw failure("unavailable", "The Pirate Bay returned invalid torrents.")
    }
    items.sort((a, b) => (b.seeders ?? 0) - (a.seeders ?? 0))
    const limit = Math.min(Math.max(query.limit || 50, 1), 100)
    const selected = items.slice(0, limit)
    for (const item of selected) {
        await caye.cache.set({
            key: item.id,
            value: { kind: "text", text: JSON.stringify(item) },
            ttlSeconds: 3600,
        })
    }
    return { items: selected, state: invalid ? "partial" : "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    const match = /^thepiratebay-([1-9][0-9]*)$/.exec(input.optionId ?? "")
    if (!match) throw failure("missing", "Unknown The Pirate Bay option.")
    const cached = await caye.cache.get({ key: `thepiratebay-${match[1]}` })
    if (cached?.kind === "text") {
        try {
            return JSON.parse(cached.text) as DownloadOption
        } catch {}
    }
    const row = await read(`t.php?id=${match[1]}`)
    if (row && typeof row === "object" && String((row as Record<string, unknown>).id) === "0") {
        throw failure("missing", "The Pirate Bay no longer lists this torrent.")
    }
    const item = option(row)
    if (!item || item.id !== input.optionId) {
        throw failure("unavailable", "The Pirate Bay returned an invalid torrent.")
    }
    return item
}

caye.register("backreef.thepiratebay:search", { acquisition: { find, resolve } })
