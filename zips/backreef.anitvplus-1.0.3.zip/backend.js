(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/unpack.ts
  var PACKER_RE = /eval\(function\(p,a,c,k,e,[dr]\)\{[\s\S]*?\}\s*\(\s*(['"])((?:\\.|(?!\1)[\s\S])*)\1\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(['"])((?:\\.|(?!\5)[\s\S])*)\5\.split\((['"])\|\7\)(?:\s*,\s*\d+\s*,\s*\{\s*\})?\s*\)\)/;
  function unescapeJsString(raw) {
    let out = "";
    for (let i = 0; i < raw.length; i++) {
      const ch = raw[i];
      if (ch !== "\\" || i + 1 >= raw.length) {
        out += ch;
        continue;
      }
      const next = raw[i + 1];
      if (next === "x" && i + 3 < raw.length) {
        const hex = raw.slice(i + 2, i + 4);
        if (/^[0-9a-fA-F]{2}$/.test(hex)) {
          out += String.fromCharCode(Number.parseInt(hex, 16));
          i += 3;
          continue;
        }
      }
      if (next === "u" && i + 5 < raw.length) {
        const hex = raw.slice(i + 2, i + 6);
        if (/^[0-9a-fA-F]{4}$/.test(hex)) {
          out += String.fromCharCode(Number.parseInt(hex, 16));
          i += 5;
          continue;
        }
      }
      switch (next) {
        case "n":
          out += "\n";
          break;
        case "r":
          out += "\r";
          break;
        case "t":
          out += "	";
          break;
        case "\\":
          out += "\\";
          break;
        case "'":
          out += "'";
          break;
        case '"':
          out += '"';
          break;
        default:
          out += next;
          break;
      }
      i += 1;
    }
    return out;
  }
  function encodeBase(value, base) {
    const prefix = value < base ? "" : encodeBase(Math.floor(value / base), base);
    const rem = value % base;
    if (rem > 35) {
      return prefix + String.fromCharCode(rem + 29);
    }
    return prefix + rem.toString(36);
  }
  function isPacked(code) {
    return PACKER_RE.test(code);
  }
  function unpack(code) {
    const match = code.match(PACKER_RE);
    if (!match) return code;
    const payload = unescapeJsString(match[2]);
    const base = Number.parseInt(match[3], 10);
    const count = Number.parseInt(match[4], 10);
    const symtab = unescapeJsString(match[6]).split("|");
    if (!Number.isFinite(base) || base < 2 || base > 62 || symtab.length === 0) {
      return code;
    }
    const dict = /* @__PURE__ */ new Map();
    const limit = Math.min(count, symtab.length);
    for (let i = 0; i < limit; i++) {
      const key = encodeBase(i, base);
      const replacement = symtab[i];
      dict.set(key, replacement || key);
    }
    const unpacked = payload.replace(/\b[0-9A-Za-z]+\b/g, (word) => {
      var _a;
      return (_a = dict.get(word)) != null ? _a : word;
    });
    return code.slice(0, match.index) + unpacked + code.slice(match.index + match[0].length);
  }
  function unpackAll(code) {
    let current = code;
    for (let i = 0; i < 32; i++) {
      if (!isPacked(current)) break;
      const next = unpack(current);
      if (next === current) break;
      current = next;
    }
    return current;
  }

  // ../../../packages/plugin-std/src/titles.ts
  var YEAR_PAREN_RE = /\((\d{4})\)/;
  var YEAR_STANDALONE_RE = /\b(19\d{2}|20\d{2})\b/;
  function extractYear(title) {
    const paren = title.match(YEAR_PAREN_RE);
    if (paren) {
      const year = Number.parseInt(paren[1], 10);
      if (year >= 1900 && year <= 2100) return year;
    }
    const standalone = title.match(YEAR_STANDALONE_RE);
    if (standalone) {
      return Number.parseInt(standalone[1], 10);
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../../../packages/plugin-std/src/url.ts
  function resolveUrl(raw, base) {
    const trimmed = raw.trim();
    if (!trimmed) return "";
    try {
      const url = new URL(trimmed.startsWith("//") ? `https:${trimmed}` : trimmed, base);
      return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : "";
    } catch (e) {
      return "";
    }
  }
  function cleanBaseUrl(raw, fallback) {
    const resolved = resolveUrl(raw != null ? raw : "");
    if (!resolved) return fallback;
    const url = new URL(resolved);
    return url.origin + url.pathname.replace(/\/+$/, "");
  }
  function originOf(raw) {
    const resolved = resolveUrl(raw, "https://invalid.local");
    return resolved ? new URL(resolved).origin : "";
  }

  // ../stream-common/src/common.ts
  var nonEnglishLanguageAliases = {
    latin: "es-419",
    espanol: "es",
    francais: "fr",
    deutsch: "de",
    italiano: "it",
    portugues: "pt",
    indonesia: "id"
  };
  function streamOriginOf(url, hint) {
    const lowerUrl = url.toLowerCase();
    const lowerHint = (hint != null ? hint : "").toLowerCase();
    if (lowerHint === "hls" || lowerHint === "m3u8" || /\.m3u8(\?|$|#)/.test(lowerUrl)) {
      return "hls";
    }
    return "http";
  }
  function subtitleFormatOf(url, hint) {
    const lowerHint = (hint != null ? hint : "").trim().toLowerCase();
    if (lowerHint === "vtt" || lowerHint === "webvtt") return "vtt";
    if (lowerHint === "srt") return "srt";
    if (lowerHint === "ass" || lowerHint === "ssa") return "ass";
    const pathPart = url.split(/[?#]/)[0].toLowerCase();
    if (pathPart.endsWith(".vtt")) return "vtt";
    if (pathPart.endsWith(".srt")) return "srt";
    if (pathPart.endsWith(".ass") || pathPart.endsWith(".ssa")) return "ass";
    return void 0;
  }
  function tryLanguageApi(api, candidate) {
    const trimmed = candidate.trim();
    if (!trimmed) return void 0;
    try {
      const iso = api.language.toISO1(trimmed);
      if (iso) return iso;
    } catch (e) {
    }
    try {
      const normalized = api.language.normalize(trimmed);
      if (normalized) {
        const iso = api.language.toISO1(normalized);
        return iso || api.language.parse(normalized).language || normalized;
      }
    } catch (e) {
    }
    return void 0;
  }
  function subtitleLanguageOf(api, raw) {
    const text = (raw != null ? raw : "").trim();
    if (!text) return void 0;
    const direct = tryLanguageApi(api, text);
    if (direct) return direct;
    const firstWord = text.split(/[^a-zA-Z0-9-]+/)[0];
    if (firstWord && firstWord !== text) {
      const resolved = tryLanguageApi(api, firstWord);
      if (resolved) return resolved;
    }
    const lowerWord = (firstWord || text).toLowerCase();
    return nonEnglishLanguageAliases[lowerWord];
  }
  function normalizeSubtitles(api, tracks, baseUrl = "https://invalid.local") {
    var _a, _b, _c;
    const out = [];
    const seen = /* @__PURE__ */ new Set();
    for (const track of tracks) {
      const url = resolveUrl((_a = track.url) != null ? _a : "", baseUrl);
      if (!url || url.length > 2048 || seen.has(url)) continue;
      const format = subtitleFormatOf(url, track.format);
      if (!format) continue;
      seen.add(url);
      const label = ((_b = track.label) != null ? _b : "").trim().slice(0, 200);
      const language = (_c = subtitleLanguageOf(api, track.language || label)) == null ? void 0 : _c.slice(0, 35);
      out.push({
        url,
        format,
        language: language || void 0,
        label: label || void 0,
        default: track.default === true ? true : void 0
      });
      if (out.length === 32) break;
    }
    return out.length > 0 ? out : void 0;
  }
  function videoRef(providerId2, nativeId) {
    return {
      providerId: providerId2,
      type: "video",
      nativeId
    };
  }
  function sameRef(ref) {
    return ref.scope ? {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId,
      scope: ref.scope
    } : {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId
    };
  }
  function limitItems(items, limit) {
    if (typeof limit === "number" && Number.isFinite(limit) && limit > 0) {
      return items.slice(0, limit);
    }
    return items;
  }
  function futureDeadline(contextDeadline, minutes = 10) {
    const now = Date.now();
    if (contextDeadline) {
      const parsed = Date.parse(contextDeadline);
      if (Number.isFinite(parsed) && parsed > now + 5e3 && parsed <= now + 24 * 3600 * 1e3) {
        return contextDeadline;
      }
    }
    return new Date(now + minutes * 60 * 1e3).toISOString();
  }
  function parseEpisodeNumber(raw) {
    if (typeof raw === "number") {
      return Number.isFinite(raw) && raw >= 0 ? raw : void 0;
    }
    if (typeof raw !== "string") return void 0;
    const cleaned = raw.trim().replace(",", ".");
    if (!cleaned) return void 0;
    const match = /\d+(?:\.\d+)?/.exec(cleaned);
    if (!match) return void 0;
    const num = Number(match[0]);
    return Number.isFinite(num) && num >= 0 ? num : void 0;
  }
  function extractFirstYear(text) {
    const year = extractYear(text != null ? text : "");
    return year > 0 ? year : void 0;
  }

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../../../packages/plugin-std/src/page-data.ts
  function decodeAstroValue(value) {
    if (Array.isArray(value)) {
      if (value.length === 2 && Number.isInteger(value[0])) {
        const [kind, payload] = value;
        if (kind === 1 && Array.isArray(payload)) return payload.map(decodeAstroValue);
        return decodeAstroValue(payload);
      }
      return value.map(decodeAstroValue);
    }
    if (value && typeof value === "object") {
      const out = {};
      for (const [key, entry] of Object.entries(value)) out[key] = decodeAstroValue(entry);
      return out;
    }
    return value;
  }
  function astroProps(api, html) {
    const out = [];
    api.html.parse(html).find("astro-island[props]").each((_index, element) => {
      const raw = element.attr("props");
      if (!raw) return;
      try {
        const parsed = JSON.parse(
          raw.includes("&quot;") ? api.html.unescape(raw) : raw
        );
        if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
          out.push(parsed);
        }
      } catch (e) {
      }
    });
    return out;
  }

  // src/backend.ts
  var providerId = "backreef.anitvplus:source";
  var providerName = "AniTVPlus";
  var site = httpClient(caye, providerName);
  var searchBase = "https://search.animetvplus.site";
  var defaultSiteBase = "https://animetvplus.xyz";
  var embedBase = "https://embed.animetvplus.site";
  function siteBase(context) {
    var _a;
    return cleanBaseUrl((_a = context == null ? void 0 : context.config) == null ? void 0 : _a.url, defaultSiteBase);
  }
  function extractCard(html) {
    var _a;
    for (const props of astroProps(caye, html)) {
      const decoded = decodeAstroValue(props);
      const card = (_a = decoded == null ? void 0 : decoded.initialCrCard) != null ? _a : decoded == null ? void 0 : decoded.initial_cr_card;
      if (card && typeof card === "object") return card;
    }
    return void 0;
  }
  function selectSeason(card, malId) {
    var _a, _b, _c, _d, _e, _f, _g, _h, _i;
    const seasons = Array.isArray(card.seasons) ? card.seasons : [];
    return (_i = (_h = (_g = (_f = (_e = seasons.find(
      (s) => {
        var _a2, _b2;
        return String((_b2 = (_a2 = s == null ? void 0 : s.owner_mal) != null ? _a2 : s == null ? void 0 : s.mal_id) != null ? _b2 : "") === malId && Array.isArray(s == null ? void 0 : s.episodes);
      }
    )) != null ? _e : String((_d = (_c = (_a = card.selected_season) == null ? void 0 : _a.owner_mal) != null ? _c : (_b = card.selected_season) == null ? void 0 : _b.mal_id) != null ? _d : "") === malId ? card.selected_season : void 0) != null ? _f : card.selected_season) != null ? _g : seasons.find((s) => {
      var _a2, _b2;
      return String((_b2 = (_a2 = s == null ? void 0 : s.owner_mal) != null ? _a2 : s == null ? void 0 : s.mal_id) != null ? _b2 : "") === malId;
    })) != null ? _h : seasons.find((s) => s == null ? void 0 : s.is_primary)) != null ? _i : seasons[0];
  }
  function extractSubtitlesFromScript(unpacked, embedUrl) {
    var _a;
    const tracksMatch = /\btracks\s*:\s*\[([\s\S]*?)\]/.exec(unpacked);
    if (!tracksMatch) return void 0;
    const trackObjects = (_a = tracksMatch[1].match(/\{[^{}]*\}/g)) != null ? _a : [];
    const entries = [];
    for (const track of trackObjects) {
      const readStr = (key) => {
        var _a2, _b;
        const prop = new RegExp(`(?:["']?${key}["']?)\\s*:\\s*(["'])([\\s\\S]*?)\\1`);
        return (_b = (_a2 = prop.exec(track)) == null ? void 0 : _a2[2]) == null ? void 0 : _b.replace(/\\([\\"'])/g, "$1");
      };
      const file = readStr("file");
      const kind = readStr("kind");
      const label = readStr("label");
      if (!file || !/^(?:captions|subtitles)$/i.test(kind != null ? kind : "")) continue;
      if (/upload captions/i.test(label != null ? label : "") || /\/empty\.srt(?:$|[?#])/i.test(file)) continue;
      entries.push({
        url: file,
        language: label,
        label: label || void 0,
        default: /(?:["']?default["']?)\s*:\s*true\b/i.test(track)
      });
    }
    return normalizeSubtitles(caye, entries, embedUrl);
  }
  function parseEpisodeRef(nativeId) {
    const match = /^(\d+):(\d+(?:\.\d+)?)$/.exec(nativeId.trim());
    if (!match) {
      throw failure("unavailable", `${providerName} invalid episode reference`);
    }
    return { malId: match[1], streamEp: match[2] };
  }
  function resolveEmbedUrl(malId, streamEp) {
    return __async(this, null, function* () {
      var _a;
      const url = new URL("/home/api/v1/resolve", embedBase);
      url.searchParams.set("mal", malId);
      url.searchParams.set("ep", streamEp);
      const payload = yield site.json({
        url: url.toString(),
        headers: { Accept: "application/json" }
      });
      if (!(payload == null ? void 0 : payload.ok) || !((_a = payload.uqload) == null ? void 0 : _a.embed_url)) return void 0;
      return resolveUrl(payload.uqload.embed_url, embedBase) || void 0;
    });
  }
  caye.register(providerId, {
    source: {
      search(_context, query) {
        return __async(this, null, function* () {
          var _a, _b;
          const q = ((_a = query == null ? void 0 : query.q) != null ? _a : "").trim();
          if (!q) return { items: [], nextCursor: "", state: "complete" };
          const limit = typeof (query == null ? void 0 : query.limit) === "number" && query.limit > 0 ? Math.min(20, Math.floor(query.limit)) : 20;
          const url = new URL("/v1/search", searchBase);
          url.searchParams.set("q", q);
          url.searchParams.set("offset", "0");
          url.searchParams.set("limit", String(limit));
          const payload = yield site.json({
            url: url.toString(),
            headers: { Accept: "application/json" }
          });
          const items = [];
          const seen = /* @__PURE__ */ new Set();
          for (const item of Array.isArray(payload == null ? void 0 : payload.data) ? payload.data : []) {
            if ((item == null ? void 0 : item.mal_id) == null || !item.title) continue;
            const malId = String(item.mal_id).trim();
            if (!malId || seen.has(malId)) continue;
            seen.add(malId);
            const year = extractFirstYear(
              item.year !== void 0 ? String(item.year) : (_b = item.aired) == null ? void 0 : _b.from
            );
            items.push(__spreadValues({
              ref: videoRef(providerId, malId),
              name: String(item.title).trim()
            }, year !== void 0 ? { year } : {}));
          }
          return {
            items: limitItems(items, query == null ? void 0 : query.limit),
            nextCursor: "",
            state: "complete"
          };
        });
      },
      read(context, ref) {
        return __async(this, null, function* () {
          const malId = ref.nativeId.split(":")[0];
          const base = siteBase(context);
          const html = yield site.text({
            url: `${base}/anime/${encodeURIComponent(malId)}`,
            headers: { Accept: "text/html,application/xhtml+xml" }
          });
          const card = extractCard(html);
          const doc = caye.html.parse(html);
          const fallbackTitle = doc.find("h1").first().text().trim() || doc.find("title").first().text().trim();
          const name = ((card == null ? void 0 : card.title) || (card == null ? void 0 : card.canonical_title) || fallbackTitle).trim();
          if (!name) {
            throw failure("unavailable", `${providerName} title metadata was not found`);
          }
          const year = extractFirstYear(
            (card == null ? void 0 : card.year) !== void 0 ? String(card.year) : card == null ? void 0 : card.start_date
          );
          return __spreadValues({
            ref: sameRef(ref),
            name
          }, year !== void 0 ? { year } : {});
        });
      },
      list(context, ref) {
        return __async(this, null, function* () {
          const malId = ref.nativeId.split(":")[0];
          if (!/^\d+$/.test(malId)) {
            throw failure("unavailable", `${providerName} invalid anime identifier`);
          }
          const base = siteBase(context);
          const html = yield site.text({
            url: `${base}/anime/${encodeURIComponent(malId)}`,
            headers: { Accept: "text/html,application/xhtml+xml" }
          });
          const card = extractCard(html);
          if (!card) {
            throw failure("unavailable", `${providerName} anime data was not found`);
          }
          const season = selectSeason(card, malId);
          const sourceEpisodes = Array.isArray(season == null ? void 0 : season.episodes) ? season.episodes : [];
          const installments = [];
          for (const item of sourceEpisodes) {
            if (!item || item.has_stream === false || item.stream_ep == null) continue;
            const num = parseEpisodeNumber(item.ep);
            const streamEp = parseEpisodeNumber(item.stream_ep);
            if (num === void 0 || streamEp === void 0) continue;
            installments.push(__spreadProps(__spreadValues({
              number: num
            }, item.title ? { name: String(item.title).trim().slice(0, 500) } : {}), {
              ref: videoRef(providerId, `${malId}:${streamEp}`)
            }));
          }
          installments.sort((a, b) => a.number - b.number);
          return {
            installments,
            choices: {
              audio: [{ id: "sub", label: "Sub" }],
              server: [{ id: "uqload", label: "UQLoad" }],
              quality: [{ id: "auto", label: "Auto" }]
            }
          };
        });
      },
      find(context, ref) {
        return __async(this, null, function* () {
          const { malId, streamEp } = parseEpisodeRef(ref.nativeId);
          const embedUrl = yield resolveEmbedUrl(malId, streamEp);
          if (!embedUrl) {
            return { items: [], state: "complete" };
          }
          return {
            items: [
              {
                id: "sub:uqload",
                origin: "hls",
                capabilities: ["video"],
                expiresAt: futureDeadline(context == null ? void 0 : context.deadline),
                tracks: [
                  {
                    id: "main",
                    kind: "video",
                    language: "ja",
                    label: "Sub \xB7 UQLoad"
                  }
                ],
                ranges: [],
                choices: {
                  audio: "sub",
                  server: "uqload",
                  quality: "auto"
                }
              }
            ],
            state: "complete"
          };
        });
      },
      resolve(_context, input) {
        return __async(this, null, function* () {
          const { malId, streamEp } = parseEpisodeRef(input.ref.nativeId);
          const embedUrl = yield resolveEmbedUrl(malId, streamEp);
          if (!embedUrl) {
            throw failure("unavailable", `${providerName} embed URL is unavailable`);
          }
          const html = yield site.text({
            url: embedUrl,
            headers: {
              Accept: "text/html,application/xhtml+xml",
              Referer: `${embedBase}/`
            }
          });
          const doc = caye.html.parse(html);
          let playlistUrl = "";
          let subtitles;
          doc.find("script").each((_i, el) => {
            if (playlistUrl) return;
            const unpacked = unpackAll(el.text());
            const match = /https?:\/\/[^"'\s<>]+?\.m3u8(?:\?[^"'\s<>]*)?/i.exec(unpacked);
            if (match) {
              playlistUrl = caye.html.unescape(match[0]);
              subtitles = extractSubtitlesFromScript(unpacked, embedUrl);
            }
          });
          if (!playlistUrl) {
            throw failure("unavailable", `${providerName} playlist was not found`);
          }
          const headers = {
            Referer: embedUrl,
            Origin: originOf(embedUrl)
          };
          const handle = yield site.handle({ url: playlistUrl, headers });
          return {
            id: input.sourceId,
            origin: streamOriginOf(playlistUrl, "hls"),
            capabilities: ["video"],
            expiresAt: handle.expiresAt,
            handle,
            tracks: [
              {
                id: "main",
                kind: "video",
                language: "ja",
                label: "Sub \xB7 UQLoad"
              }
            ],
            ranges: [],
            subtitles,
            choices: {
              audio: "sub",
              server: "uqload",
              quality: "auto"
            }
          };
        });
      }
    }
  });
})();
//# sourceMappingURL=backend.js.map
