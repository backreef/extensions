import type {
    API,
    Context,
    Query,
    Ref,
    Source,
    SourceInstallment,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
    SourceResolveInput,
} from "../../../../packages/plugin-sdk/src/index"
import { unpackAll } from "../../../../packages/plugin-std/src/unpack"
import {
    extractFirstYear,
    futureDeadline,
    limitItems,
    normalizeSubtitles,
    parseEpisodeNumber,
    sameRef,
    streamOriginOf,
    videoRef,
} from "../../stream-common/src/common"
import { failure, httpClient } from "../../../../packages/plugin-std/src/http.ts"
import { astroProps, decodeAstroValue } from "../../../../packages/plugin-std/src/page-data.ts"
import { cleanBaseUrl, originOf, resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.anitvplus:source"
const providerName = "AniTVPlus"
const site = httpClient(caye, providerName)
const searchBase = "https://search.animetvplus.site"
const defaultSiteBase = "https://animetvplus.xyz"
const embedBase = "https://embed.animetvplus.site"

type SearchItem = {
    mal_id?: string | number
    title?: string
    year?: number | string
    aired?: { from?: string }
}

type AstroEpisode = {
    ep?: number | string
    stream_ep?: number | string
    has_stream?: boolean
    title?: string
}

type AstroSeason = {
    owner_mal?: string | number
    mal_id?: string | number
    is_primary?: boolean
    episodes?: AstroEpisode[]
}

type AstroCard = {
    title?: string
    canonical_title?: string
    year?: number | string
    start_date?: string
    seasons?: AstroSeason[]
    selected_season?: AstroSeason
}

function siteBase(context: Context): string {
    return cleanBaseUrl(context?.config?.url, defaultSiteBase)
}

function extractCard(html: string): AstroCard | undefined {
    for (const props of astroProps(caye, html)) {
        const decoded = decodeAstroValue(props) as Record<string, unknown>
        const card = (decoded?.initialCrCard ?? decoded?.initial_cr_card) as AstroCard | undefined
        if (card && typeof card === "object") return card
    }
    return undefined
}

function selectSeason(card: AstroCard, malId: string): AstroSeason | undefined {
    const seasons = Array.isArray(card.seasons) ? card.seasons : []
    return (
        seasons.find(
            (s) => String(s?.owner_mal ?? s?.mal_id ?? "") === malId && Array.isArray(s?.episodes),
        ) ??
        (String(card.selected_season?.owner_mal ?? card.selected_season?.mal_id ?? "") === malId
            ? card.selected_season
            : undefined) ??
        card.selected_season ??
        seasons.find((s) => String(s?.owner_mal ?? s?.mal_id ?? "") === malId) ??
        seasons.find((s) => s?.is_primary) ??
        seasons[0]
    )
}

function extractSubtitlesFromScript(unpacked: string, embedUrl: string): Source["subtitles"] {
    const tracksMatch = /\btracks\s*:\s*\[([\s\S]*?)\]/.exec(unpacked)
    if (!tracksMatch) return undefined
    const trackObjects = tracksMatch[1].match(/\{[^{}]*\}/g) ?? []
    const entries: Array<{
        url?: string
        language?: string
        label?: string
        default?: boolean
    }> = []
    for (const track of trackObjects) {
        const readStr = (key: string) => {
            const prop = new RegExp(`(?:["']?${key}["']?)\\s*:\\s*(["'])([\\s\\S]*?)\\1`)
            return prop.exec(track)?.[2]?.replace(/\\([\\"'])/g, "$1")
        }
        const file = readStr("file")
        const kind = readStr("kind")
        const label = readStr("label")
        if (!file || !/^(?:captions|subtitles)$/i.test(kind ?? "")) continue
        if (/upload captions/i.test(label ?? "") || /\/empty\.srt(?:$|[?#])/i.test(file)) continue
        entries.push({
            url: file,
            language: label,
            label: label || undefined,
            default: /(?:["']?default["']?)\s*:\s*true\b/i.test(track),
        })
    }
    return normalizeSubtitles(caye, entries, embedUrl)
}

function parseEpisodeRef(nativeId: string): { malId: string; streamEp: string } {
    const match = /^(\d+):(\d+(?:\.\d+)?)$/.exec(nativeId.trim())
    if (!match) {
        throw failure("unavailable", `${providerName} invalid episode reference`)
    }
    return { malId: match[1], streamEp: match[2] }
}

async function resolveEmbedUrl(malId: string, streamEp: string): Promise<string | undefined> {
    const url = new URL("/home/api/v1/resolve", embedBase)
    url.searchParams.set("mal", malId)
    url.searchParams.set("ep", streamEp)
    const payload = await site.json<{ ok?: boolean; uqload?: { embed_url?: string } }>({
        url: url.toString(),
        headers: { Accept: "application/json" },
    })
    if (!payload?.ok || !payload.uqload?.embed_url) return undefined
    return resolveUrl(payload.uqload.embed_url, embedBase) || undefined
}

caye.register(providerId, {
    source: {
        async search(_context: Context, query: Query): Promise<SourceRecords> {
            const q = (query?.q ?? "").trim()
            if (!q) return { items: [], nextCursor: "", state: "complete" }
            const limit =
                typeof query?.limit === "number" && query.limit > 0
                    ? Math.min(20, Math.floor(query.limit))
                    : 20
            const url = new URL("/v1/search", searchBase)
            url.searchParams.set("q", q)
            url.searchParams.set("offset", "0")
            url.searchParams.set("limit", String(limit))
            const payload = await site.json<{ data?: SearchItem[] }>({
                url: url.toString(),
                headers: { Accept: "application/json" },
            })
            const items: SourceRecord[] = []
            const seen = new Set<string>()
            for (const item of Array.isArray(payload?.data) ? payload.data : []) {
                if (item?.mal_id == null || !item.title) continue
                const malId = String(item.mal_id).trim()
                if (!malId || seen.has(malId)) continue
                seen.add(malId)
                const year = extractFirstYear(
                    item.year !== undefined ? String(item.year) : item.aired?.from,
                )
                items.push({
                    ref: videoRef(providerId, malId),
                    name: String(item.title).trim(),
                    ...(year !== undefined ? { year } : {}),
                })
            }
            return {
                items: limitItems(items, query?.limit),
                nextCursor: "",
                state: "complete",
            }
        },

        async read(context: Context, ref: Ref): Promise<SourceRecord> {
            const malId = ref.nativeId.split(":")[0]
            const base = siteBase(context)
            const html = await site.text({
                url: `${base}/anime/${encodeURIComponent(malId)}`,
                headers: { Accept: "text/html,application/xhtml+xml" },
            })
            const card = extractCard(html)
            const doc = caye.html.parse(html)
            const fallbackTitle =
                doc.find("h1").first().text().trim() || doc.find("title").first().text().trim()
            const name = (card?.title || card?.canonical_title || fallbackTitle).trim()
            if (!name) {
                throw failure("unavailable", `${providerName} title metadata was not found`)
            }
            const year = extractFirstYear(
                card?.year !== undefined ? String(card.year) : card?.start_date,
            )
            return {
                ref: sameRef(ref),
                name,
                ...(year !== undefined ? { year } : {}),
            }
        },

        async list(context: Context, ref: Ref): Promise<SourceListResult> {
            const malId = ref.nativeId.split(":")[0]
            if (!/^\d+$/.test(malId)) {
                throw failure("unavailable", `${providerName} invalid anime identifier`)
            }
            const base = siteBase(context)
            const html = await site.text({
                url: `${base}/anime/${encodeURIComponent(malId)}`,
                headers: { Accept: "text/html,application/xhtml+xml" },
            })
            const card = extractCard(html)
            if (!card) {
                throw failure("unavailable", `${providerName} anime data was not found`)
            }
            const season = selectSeason(card, malId)
            const sourceEpisodes = Array.isArray(season?.episodes) ? season.episodes : []
            const installments: SourceInstallment[] = []
            for (const item of sourceEpisodes) {
                if (!item || item.has_stream === false || item.stream_ep == null) continue
                const num = parseEpisodeNumber(item.ep)
                const streamEp = parseEpisodeNumber(item.stream_ep)
                if (num === undefined || streamEp === undefined) continue
                installments.push({
                    number: num,
                    ...(item.title ? { name: String(item.title).trim().slice(0, 500) } : {}),
                    ref: videoRef(providerId, `${malId}:${streamEp}`),
                })
            }
            installments.sort((a, b) => a.number - b.number)
            return {
                installments,
                choices: {
                    audio: [{ id: "sub", label: "Sub" }],
                    server: [{ id: "uqload", label: "UQLoad" }],
                    quality: [{ id: "auto", label: "Auto" }],
                },
            }
        },

        async find(context: Context, ref: Ref): Promise<SourcePage> {
            const { malId, streamEp } = parseEpisodeRef(ref.nativeId)
            const embedUrl = await resolveEmbedUrl(malId, streamEp)
            if (!embedUrl) {
                return { items: [], state: "complete" }
            }
            return {
                items: [
                    {
                        id: "sub:uqload",
                        origin: "hls",
                        capabilities: ["video"],
                        expiresAt: futureDeadline(context?.deadline),
                        tracks: [
                            {
                                id: "main",
                                kind: "video",
                                language: "ja",
                                label: "Sub · UQLoad",
                            },
                        ],
                        ranges: [],
                        choices: {
                            audio: "sub",
                            server: "uqload",
                            quality: "auto",
                        },
                    },
                ],
                state: "complete",
            }
        },

        async resolve(_context: Context, input: SourceResolveInput): Promise<Source> {
            const { malId, streamEp } = parseEpisodeRef(input.ref.nativeId)
            const embedUrl = await resolveEmbedUrl(malId, streamEp)
            if (!embedUrl) {
                throw failure("unavailable", `${providerName} embed URL is unavailable`)
            }
            const html = await site.text({
                url: embedUrl,
                headers: {
                    Accept: "text/html,application/xhtml+xml",
                    Referer: `${embedBase}/`,
                },
            })
            const doc = caye.html.parse(html)
            let playlistUrl = ""
            let subtitles: Source["subtitles"]
            doc.find("script").each((_i, el) => {
                if (playlistUrl) return
                const unpacked = unpackAll(el.text())
                const match = /https?:\/\/[^"'\s<>]+?\.m3u8(?:\?[^"'\s<>]*)?/i.exec(unpacked)
                if (match) {
                    playlistUrl = caye.html.unescape(match[0])
                    subtitles = extractSubtitlesFromScript(unpacked, embedUrl)
                }
            })
            if (!playlistUrl) {
                throw failure("unavailable", `${providerName} playlist was not found`)
            }
            const headers = {
                Referer: embedUrl,
                Origin: originOf(embedUrl),
            }
            const handle = await site.handle({ url: playlistUrl, headers: headers })
            return {
                id: input.sourceId,
                origin: streamOriginOf(playlistUrl, "hls"),
                capabilities: ["video"],
                expiresAt: handle.expiresAt,
                handle,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: "ja",
                        label: "Sub · UQLoad",
                    },
                ],
                ranges: [],
                subtitles,
                choices: {
                    audio: "sub",
                    server: "uqload",
                    quality: "auto",
                },
            }
        },
    },
})
