(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __pow = Math.pow;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __objRest = (source, exclude) => {
    var target = {};
    for (var prop in source)
      if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
        target[prop] = source[prop];
    if (source != null && __getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(source)) {
        if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
          target[prop] = source[prop];
      }
    return target;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve2, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve2(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../../../packages/plugin-std/src/magnet.ts
  var BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  function decodeBase32(input) {
    const cleaned = input.trim().toUpperCase().replace(/=+$/, "");
    if (!cleaned || !/^[A-Z2-7]+$/.test(cleaned)) {
      throw new TypeError("Invalid base32 string");
    }
    const bytes = [];
    let buffer = 0;
    let bitsLeft = 0;
    for (let i = 0; i < cleaned.length; i++) {
      const val = BASE32_ALPHABET.indexOf(cleaned[i]);
      buffer = buffer << 5 | val;
      bitsLeft += 5;
      if (bitsLeft >= 8) {
        bitsLeft -= 8;
        bytes.push(buffer >>> bitsLeft & 255);
      }
    }
    return new Uint8Array(bytes);
  }
  function bytesToHex(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i++) {
      out += bytes[i].toString(16).padStart(2, "0");
    }
    return out;
  }
  function normalizeInfoHash(raw) {
    const trimmed = raw.trim();
    if (/^[0-9a-fA-F]{40}$/.test(trimmed)) {
      return trimmed.toLowerCase();
    }
    if (/^[A-Za-z2-7]{32}=*$/.test(trimmed)) {
      const decoded = decodeBase32(trimmed);
      if (decoded.length === 20) {
        return bytesToHex(decoded);
      }
    }
    throw new TypeError(`Invalid infoHash: ${raw}`);
  }
  function parseMagnet(uri) {
    var _a;
    const trimmed = uri.trim();
    if (!/^magnet:\?/i.test(trimmed)) {
      throw new TypeError("Invalid magnet URI");
    }
    const query = trimmed.slice(trimmed.indexOf("?") + 1);
    const params = new URLSearchParams(query);
    let infoHash = "";
    for (const xt of params.getAll("xt")) {
      const match = xt.match(/^urn:btih:([0-9a-fA-F]{40}|[A-Za-z2-7]{32}=*)$/i);
      if (match) {
        infoHash = normalizeInfoHash(match[1]);
        break;
      }
    }
    if (!infoHash) {
      throw new TypeError("Magnet URI missing valid btih infoHash");
    }
    const name = (_a = params.get("dn")) != null ? _a : "";
    const seen = /* @__PURE__ */ new Set();
    const trackers = [];
    for (const tr of params.getAll("tr")) {
      const t = tr.trim();
      if (t && !seen.has(t)) {
        seen.add(t);
        trackers.push(t);
      }
    }
    const xlRaw = params.get("xl");
    let size = 0;
    if (xlRaw && /^\d+$/.test(xlRaw.trim())) {
      size = Number.parseInt(xlRaw.trim(), 10);
    }
    return { infoHash, name, trackers, size };
  }
  function buildMagnet(options) {
    const infoHash = normalizeInfoHash(options.infoHash);
    const parts = [`magnet:?xt=urn:btih:${infoHash}`];
    if (options.name) {
      parts.push(`dn=${encodeURIComponent(options.name)}`);
    }
    if (options.trackers) {
      const seen = /* @__PURE__ */ new Set();
      for (const tr of options.trackers) {
        const trimmed = tr.trim();
        if (trimmed && !seen.has(trimmed)) {
          seen.add(trimmed);
          parts.push(`tr=${encodeURIComponent(trimmed)}`);
        }
      }
    }
    return parts.join("&");
  }
  function parseTorrent(api, bytes) {
    const infoHash = api.crypto.digest("sha1", api.bencode.raw(bytes, "info"), { output: "hex" }).toLowerCase();
    const trackers = [];
    let name = "";
    try {
      const decoded = api.bencode.decode(bytes);
      const add = (value) => {
        if (typeof value === "string" && value.trim() && !trackers.includes(value.trim())) {
          trackers.push(value.trim());
        }
      };
      add(decoded.announce);
      if (Array.isArray(decoded["announce-list"])) {
        for (const tier of decoded["announce-list"]) {
          if (Array.isArray(tier)) tier.forEach(add);
          else add(tier);
        }
      }
      const info = decoded.info;
      if (typeof (info == null ? void 0 : info.name) === "string") name = info.name.trim();
    } catch (e) {
    }
    return { infoHash, name, trackers };
  }

  // ../../../packages/plugin-std/src/size.ts
  var UNIT_EXPONENTS = {
    B: 0,
    K: 1,
    M: 2,
    G: 3,
    T: 4,
    P: 5
  };
  function parseSize(input) {
    const match = input.trim().match(/^([\d,]+(?:\.\d+)?|\.\d+)\s*([KMGTPE]?i?B)$/i);
    if (!match) {
      const inner = input.match(/([\d,]+(?:\.\d+)?)\s*([KMGT]?i?B)/i);
      if (!inner) return 0;
      return computeBytes(inner[1], inner[2]);
    }
    return computeBytes(match[1], match[2]);
  }
  function computeBytes(numStr, rawUnit) {
    const value = Number.parseFloat(numStr.replace(/,/g, ""));
    if (!Number.isFinite(value) || value < 0) return 0;
    const unit = rawUnit.toUpperCase();
    const base = unit.endsWith("IB") ? 1024 : 1e3;
    const prefix = unit === "B" ? "B" : unit[0];
    const exp = UNIT_EXPONENTS[prefix];
    if (exp === void 0) return 0;
    return Math.round(value * __pow(base, exp));
  }

  // ../../../packages/plugin-std/src/titles.ts
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../torrent-common/src/option.ts
  var DEFAULT_TRACKERS = [
    "http://nyaa.tracker.wf:7777/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce"
  ];
  var MAX_RETRIEVAL_URI_LENGTH = 2e3;
  function numberValue(value) {
    return { kind: "number", number: value };
  }
  function makeFact(producerId, id, field, value, at = (/* @__PURE__ */ new Date()).toISOString()) {
    return {
      id,
      producerId,
      field,
      value: numberValue(value),
      locale: "",
      region: "",
      status: "complete",
      at
    };
  }
  function buildCountsFacts(producerId, key, counts) {
    const at = (/* @__PURE__ */ new Date()).toISOString();
    const facts = [];
    if (counts.size !== void 0 && Number.isFinite(counts.size) && counts.size > 0) {
      facts.push(makeFact(producerId, `size-${key}`, "size", counts.size, at));
    }
    if (counts.seeders !== void 0 && Number.isFinite(counts.seeders) && counts.seeders >= 0) {
      facts.push(makeFact(producerId, `seeders-${key}`, "seeders", counts.seeders, at));
    }
    if (counts.leechers !== void 0 && Number.isFinite(counts.leechers) && counts.leechers >= 0) {
      facts.push(makeFact(producerId, `leechers-${key}`, "leechers", counts.leechers, at));
    }
    if (counts.downloads !== void 0 && Number.isFinite(counts.downloads) && counts.downloads > 0) {
      facts.push(makeFact(producerId, `downloads-${key}`, "downloads", counts.downloads, at));
    }
    return facts;
  }
  function parseIsoDate(caye2, raw, layouts) {
    var _a;
    const trimmed = raw == null ? void 0 : raw.trim();
    if (!trimmed) return void 0;
    if (typeof ((_a = caye2.time) == null ? void 0 : _a.parse) === "function") {
      try {
        const ms = caye2.time.parse(trimmed, layouts ? { layouts } : void 0);
        if (Number.isFinite(ms)) {
          return new Date(ms).toISOString();
        }
      } catch (e) {
      }
    }
    const parsed = Date.parse(trimmed);
    if (Number.isFinite(parsed)) {
      return new Date(parsed).toISOString();
    }
    return void 0;
  }
  function pickUri(magnet, torrentUrl) {
    if (magnet && Array.from(magnet).length <= MAX_RETRIEVAL_URI_LENGTH) {
      return magnet;
    }
    return torrentUrl || magnet || "";
  }
  function createTorrentOption(caye2, input) {
    var _a, _b, _c, _d;
    const uri = pickUri(input.magnet, input.torrentUrl);
    const facts = buildCountsFacts(input.providerId, input.key, {
      size: input.size,
      seeders: input.seeders,
      leechers: input.leechers,
      downloads: input.downloads
    });
    let resolution = ((_a = input.resolution) == null ? void 0 : _a.trim()) || "";
    let group = ((_b = input.group) == null ? void 0 : _b.trim()) || "";
    if ((!resolution || !group) && typeof ((_c = caye2.release) == null ? void 0 : _c.parse) === "function") {
      try {
        const parsed = caye2.release.parse(input.name);
        if (!resolution && parsed.resolution) resolution = parsed.resolution;
        if (!group && parsed.group) group = parsed.group;
      } catch (e) {
      }
    }
    const option = {
      id: input.id,
      name: input.name,
      kind: "torrent",
      uri,
      files: [],
      facts,
      availability: "available",
      eligible: true,
      reasons: [],
      confirmed: Boolean(input.confirmed)
    };
    if (input.seeders !== void 0 && Number.isFinite(input.seeders) && input.seeders >= 0) {
      option.seeders = Math.trunc(input.seeders);
    }
    if (input.size !== void 0 && Number.isFinite(input.size) && input.size > 0) {
      option.size = Math.round(input.size);
    }
    if (input.publishedAt) option.publishedAt = input.publishedAt;
    if (input.pageUrl && /^https?:\/\//i.test(input.pageUrl)) {
      option.pageUrl = input.pageUrl;
    }
    if ((_d = input.magnet) == null ? void 0 : _d.startsWith("magnet:")) {
      option.magnet = input.magnet;
    }
    if (resolution) option.resolution = resolution;
    if (group) option.group = group;
    if (input.best) option.best = true;
    return option;
  }
  var missingMessage = (service) => `${service} no longer lists this torrent.`;
  function fetchText(caye2, service, url, options) {
    return __async(this, null, function* () {
      var _b, _c;
      const _a = options != null ? options : {}, { missingOn404 } = _a, input = __objRest(_a, ["missingOn404"]);
      const response = yield httpClient(caye2, service).send(
        __spreadProps(__spreadValues({}, input), { url }),
        missingOn404 ? { missing: missingMessage(service) } : void 0
      );
      return {
        status: response.status,
        headers: (_b = response.headers) != null ? _b : {},
        body: (_c = response.body) != null ? _c : "",
        url: response.url
      };
    });
  }
  function torrentUrlToMagnet(caye2, service, torrentUrl, options) {
    return __async(this, null, function* () {
      var _a;
      const body = yield httpClient(caye2, service).base64(
        { url: torrentUrl, headers: options == null ? void 0 : options.headers },
        (options == null ? void 0 : options.missingOn404) ? { missing: missingMessage(service) } : void 0
      );
      let torrent;
      try {
        torrent = parseTorrent(caye2, caye2.encoding.base64.decode(body));
      } catch (e) {
        throw failure("unavailable", `${service} returned an invalid torrent file.`);
      }
      const trackers = [...torrent.trackers, ...(_a = options == null ? void 0 : options.extraTrackers) != null ? _a : []];
      return {
        infoHash: torrent.infoHash,
        magnet: buildMagnet({
          infoHash: torrent.infoHash,
          name: (options == null ? void 0 : options.fallbackName) || torrent.name || void 0,
          trackers: trackers.length > 0 ? trackers : DEFAULT_TRACKERS
        })
      };
    });
  }

  // ../../../packages/plugin-std/src/cache.ts
  function getCachedJson(api, key) {
    return __async(this, null, function* () {
      try {
        const value = yield api.cache.get({ key });
        if ((value == null ? void 0 : value.kind) === "text") return JSON.parse(value.text);
      } catch (e) {
      }
      return void 0;
    });
  }
  function setCachedJson(api, key, value, ttlSeconds) {
    return __async(this, null, function* () {
      try {
        yield api.cache.set({
          key,
          value: { kind: "text", text: JSON.stringify(value) },
          ttlSeconds
        });
      } catch (e) {
      }
    });
  }

  // ../torrent-common/src/smart.ts
  var OPTION_CACHE_TTL_SECONDS = 7 * 24 * 60 * 60;
  function clampLimit(limit, fallback = 50, max = 100) {
    return Math.min(Math.max(limit || fallback, 1), max);
  }
  function cacheOptions(_0, _1, _2) {
    return __async(this, arguments, function* (caye2, prefix, options, ttlSeconds = OPTION_CACHE_TTL_SECONDS) {
      for (const option of options) {
        yield setCachedJson(caye2, `${prefix}:option:${option.id}`, option, ttlSeconds);
      }
    });
  }
  function validateHttpUrl(raw) {
    const trimmed = (raw == null ? void 0 : raw.trim()) || "";
    if (!trimmed) return void 0;
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol === "http:" || parsed.protocol === "https:") {
        return parsed.toString();
      }
    } catch (e) {
    }
    return void 0;
  }
  function resolveFromRetrievalInput(caye2, providerId, prefix, input, notFoundMessage, defaultGroup) {
    var _a, _b, _c, _d;
    const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
    const rawMagnet = ((_b = input.magnet) == null ? void 0 : _b.trim()) || "";
    const rawInfoHash = ((_c = input.infoHash) == null ? void 0 : _c.trim()) || "";
    const rawTorrentUrl = ((_d = input.torrentUrl) == null ? void 0 : _d.trim()) || "";
    const hasRetrieval = Boolean(rawMagnet || rawInfoHash || rawTorrentUrl);
    if (!hasRetrieval) return void 0;
    if (optionId && !optionId.startsWith(`${prefix}-`)) {
      throw failure("missing", notFoundMessage);
    }
    const validTorrentUrl = rawTorrentUrl ? validateHttpUrl(rawTorrentUrl) : void 0;
    if (rawTorrentUrl && !validTorrentUrl) {
      throw failure("missing", "Invalid torrent retrieval URL.");
    }
    if (rawMagnet) {
      let parsed;
      try {
        parsed = parseMagnet(rawMagnet);
      } catch (e) {
        throw failure("missing", "Invalid magnet retrieval URI.");
      }
      const id = optionId || `${prefix}-${parsed.infoHash}`;
      return createTorrentOption(caye2, {
        id,
        key: parsed.infoHash,
        providerId,
        name: parsed.name || `${prefix} ${parsed.infoHash}`,
        magnet: rawMagnet,
        torrentUrl: validTorrentUrl,
        size: parsed.size > 0 ? parsed.size : void 0,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (rawInfoHash) {
      let infoHash = "";
      try {
        infoHash = normalizeInfoHash(rawInfoHash);
      } catch (e) {
        throw failure("missing", "Invalid torrent info hash.");
      }
      const id = optionId || `${prefix}-${infoHash}`;
      const magnet = buildMagnet({ infoHash, trackers: DEFAULT_TRACKERS });
      return createTorrentOption(caye2, {
        id,
        key: infoHash,
        providerId,
        name: `${prefix} ${infoHash}`,
        magnet,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (validTorrentUrl) {
      const id = optionId || `${prefix}-torrent`;
      const key = id.startsWith(`${prefix}-`) ? id.slice(prefix.length + 1) : id;
      return createTorrentOption(caye2, {
        id,
        key,
        providerId,
        name: `${prefix} ${key}`,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    return void 0;
  }
  function requireSearchText(query, message = "Enter a title to search.") {
    var _a;
    const text = ((_a = query.text) == null ? void 0 : _a.trim()) || "";
    if (!text) {
      throw failure("unsupported", message);
    }
    return text;
  }

  // src/backend.ts
  var PROVIDER_ID = "backreef.acg-rip:search";
  var BASE_URL = "https://acg.rip";
  function absoluteUrl(pathOrUrl) {
    const raw = (pathOrUrl == null ? void 0 : pathOrUrl.trim()) || "";
    if (!raw) return "";
    if (/^https?:\/\//i.test(raw)) return raw;
    return `${BASE_URL}${raw.startsWith("/") ? "" : "/"}${raw}`;
  }
  function parseTimestamp(raw) {
    const trimmed = (raw == null ? void 0 : raw.trim()) || "";
    if (!trimmed) return void 0;
    if (/^\d+$/.test(trimmed)) {
      const ms = Number.parseInt(trimmed, 10) * 1e3;
      if (Number.isFinite(ms) && ms > 0) return new Date(ms).toISOString();
    }
    return parseIsoDate(caye, trimmed);
  }
  function parseRows(html) {
    const doc = caye.html.parse(html);
    const out = [];
    doc.find("table.post-index tr").each((_, row) => {
      const titleEl = row.find("td.title span.title a").first();
      const rawTitle = titleEl.text().trim();
      if (!rawTitle) return true;
      const href = titleEl.attr("href") || "";
      const downloadHref = row.find("td.action a").first().attr("href") || "";
      const pageUrl = absoluteUrl(href);
      const torrentUrl = absoluteUrl(downloadHref);
      const idMatch = /\/t\/(\d+)/.exec(href || downloadHref);
      const idKey = idMatch ? idMatch[1] : `${out.length + 1}`;
      if (!torrentUrl) return true;
      let group = row.find("td.title span.label-team a").first().text().trim();
      let name = rawTitle;
      if (!group) {
        try {
          group = caye.release.parse(rawTitle).group;
        } catch (e) {
        }
      }
      const size = parseSize(row.find("td.size").first().text().trim());
      const publishedAt = parseTimestamp(row.find("td.date time").first().attr("datetime"));
      out.push(
        createTorrentOption(caye, {
          id: `acg-rip-${idKey}`,
          key: idKey,
          providerId: PROVIDER_ID,
          name,
          torrentUrl,
          pageUrl: pageUrl || void 0,
          size: size > 0 ? size : void 0,
          publishedAt,
          group: group || void 0,
          confirmed: false
        })
      );
      return true;
    });
    return out;
  }
  function find(_context, query) {
    return __async(this, null, function* () {
      const text = requireSearchText(query);
      const res = yield fetchText(caye, "ACG.RIP", `${BASE_URL}/?term=${encodeURIComponent(text)}`, {
        headers: { Accept: "text/html" }
      });
      const limit = clampLimit(query.limit, 50, 100);
      const items = parseRows(res.body).slice(0, limit);
      yield cacheOptions(caye, "acg-rip", items);
      return { items, state: "complete" };
    });
  }
  function resolve(_context, input) {
    return __async(this, null, function* () {
      var _a, _b;
      const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
      const match = /^acg-rip-([1-9][0-9]*)$/.exec(optionId);
      if (!match) {
        throw failure("missing", "Unknown ACG.RIP option.");
      }
      const id = match[1];
      const cached = yield getCachedJson(caye, `acg-rip:option:${optionId}`);
      if (cached && cached.magnet) {
        return cached;
      }
      const torrentUrl = ((_b = cached == null ? void 0 : cached.uri) == null ? void 0 : _b.endsWith(".torrent")) ? cached.uri : `${BASE_URL}/t/${id}.torrent`;
      let magnet = "";
      try {
        const result = yield torrentUrlToMagnet(caye, "ACG.RIP", torrentUrl, {
          fallbackName: cached == null ? void 0 : cached.name,
          missingOn404: true
        });
        magnet = result.magnet;
      } catch (err) {
        const fallback = resolveFromRetrievalInput(
          caye,
          PROVIDER_ID,
          "acg-rip",
          input,
          "Unknown ACG.RIP option."
        );
        if (fallback) return fallback;
        throw err;
      }
      const resolved = cached ? __spreadProps(__spreadValues({}, cached), {
        magnet,
        uri: magnet.length <= 2e3 ? magnet : torrentUrl
      }) : createTorrentOption(caye, {
        id: optionId,
        key: id,
        providerId: PROVIDER_ID,
        name: `ACG.RIP ${id}`,
        magnet,
        torrentUrl,
        pageUrl: `${BASE_URL}/t/${id}`,
        confirmed: false
      });
      yield setCachedJson(caye, `acg-rip:option:${optionId}`, resolved, OPTION_CACHE_TTL_SECONDS);
      return resolved;
    });
  }
  caye.register(PROVIDER_ID, { acquisition: { find, resolve } });
})();
//# sourceMappingURL=backend.js.map
