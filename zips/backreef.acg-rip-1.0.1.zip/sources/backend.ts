import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DownloadOption,
} from "../../../../packages/plugin-sdk/src/index"
import {
    cacheOptions,
    clampLimit,
    createTorrentOption,
    fetchText,
    OPTION_CACHE_TTL_SECONDS,
    parseIsoDate,
    parseSize,
    requireSearchText,
    resolveFromRetrievalInput,
    torrentUrlToMagnet,
} from "../../torrent-common/src/index.ts"
import { getCachedJson, setCachedJson } from "../../../../packages/plugin-std/src/cache.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const PROVIDER_ID = "backreef.acg-rip:search"
const BASE_URL = "https://acg.rip"

function absoluteUrl(pathOrUrl: string | undefined): string {
    const raw = pathOrUrl?.trim() || ""
    if (!raw) return ""
    if (/^https?:\/\//i.test(raw)) return raw
    return `${BASE_URL}${raw.startsWith("/") ? "" : "/"}${raw}`
}

function parseTimestamp(raw: string | undefined): string | undefined {
    const trimmed = raw?.trim() || ""
    if (!trimmed) return undefined
    if (/^\d+$/.test(trimmed)) {
        const ms = Number.parseInt(trimmed, 10) * 1000
        if (Number.isFinite(ms) && ms > 0) return new Date(ms).toISOString()
    }
    return parseIsoDate(caye, trimmed)
}

function parseRows(html: string): DownloadOption[] {
    const doc = caye.html.parse(html)
    const out: DownloadOption[] = []
    doc.find("table.post-index tr").each((_, row) => {
        const titleEl = row.find("td.title span.title a").first()
        const rawTitle = titleEl.text().trim()
        if (!rawTitle) return true
        const href = titleEl.attr("href") || ""
        const downloadHref = row.find("td.action a").first().attr("href") || ""
        const pageUrl = absoluteUrl(href)
        const torrentUrl = absoluteUrl(downloadHref)
        const idMatch = /\/t\/(\d+)/.exec(href || downloadHref)
        const idKey = idMatch ? idMatch[1] : `${out.length + 1}`
        if (!torrentUrl) return true

        let group = row.find("td.title span.label-team a").first().text().trim()
        let name = rawTitle
        if (!group) {
            try {
                group = caye.release.parse(rawTitle).group
            } catch {}
        }
        const size = parseSize(row.find("td.size").first().text().trim())
        const publishedAt = parseTimestamp(row.find("td.date time").first().attr("datetime"))

        out.push(
            createTorrentOption(caye, {
                id: `acg-rip-${idKey}`,
                key: idKey,
                providerId: PROVIDER_ID,
                name,
                torrentUrl,
                pageUrl: pageUrl || undefined,
                size: size > 0 ? size : undefined,
                publishedAt,
                group: group || undefined,
                confirmed: false,
            }),
        )
        return true
    })
    return out
}

async function find(_context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const text = requireSearchText(query)
    const res = await fetchText(caye, "ACG.RIP", `${BASE_URL}/?term=${encodeURIComponent(text)}`, {
        headers: { Accept: "text/html" },
    })
    const limit = clampLimit(query.limit, 50, 100)
    const items = parseRows(res.body).slice(0, limit)
    await cacheOptions(caye, "acg-rip", items)
    return { items, state: "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    const optionId = input.optionId?.trim() || ""
    const match = /^acg-rip-([1-9][0-9]*)$/.exec(optionId)
    if (!match) {
        throw failure("missing", "Unknown ACG.RIP option.")
    }
    const id = match[1]
    const cached = await getCachedJson<DownloadOption>(caye, `acg-rip:option:${optionId}`)
    if (cached && cached.magnet) {
        return cached
    }
    const torrentUrl = cached?.uri?.endsWith(".torrent")
        ? cached.uri
        : `${BASE_URL}/t/${id}.torrent`
    let magnet = ""
    try {
        const result = await torrentUrlToMagnet(caye, "ACG.RIP", torrentUrl, {
            fallbackName: cached?.name,
            missingOn404: true,
        })
        magnet = result.magnet
    } catch (err) {
        const fallback = resolveFromRetrievalInput(
            caye,
            PROVIDER_ID,
            "acg-rip",
            input,
            "Unknown ACG.RIP option.",
        )
        if (fallback) return fallback
        throw err
    }
    const resolved: DownloadOption = cached
        ? {
              ...cached,
              magnet,
              uri: magnet.length <= 2000 ? magnet : torrentUrl,
          }
        : createTorrentOption(caye, {
              id: optionId,
              key: id,
              providerId: PROVIDER_ID,
              name: `ACG.RIP ${id}`,
              magnet,
              torrentUrl,
              pageUrl: `${BASE_URL}/t/${id}`,
              confirmed: false,
          })
    await setCachedJson(caye, `acg-rip:option:${optionId}`, resolved, OPTION_CACHE_TTL_SECONDS)
    return resolved
}

caye.register(PROVIDER_ID, { acquisition: { find, resolve } })
