import type { API, Ref, SourceRecord } from "../../../../packages/plugin-sdk/src/index.ts"
import {
    buildChapterList,
    createMangaSource,
    fetchText,
    makeDirectPageResolver,
    parseChapterNumber,
    type ParsedChapterInput,
    type RawPageInput,
} from "../../manga-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"
import { resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.komiku:source"
const providerName = "Komiku"
const siteUrl = "https://komiku.org"
const searchUrl = "https://api.komiku.org"

function extractTitle(html: string): string {
    const doc = caye.html.parse(html)
    const itemprop = doc.find('#Judul h1 span[itemprop="name"]').first().text().trim()
    if (itemprop) return itemprop
    const judul = doc
        .find("#Judul h1")
        .first()
        .text()
        .trim()
        .replace(/^Komik\s+/i, "")
        .trim()
    if (judul) return judul
    return doc
        .find("h1")
        .first()
        .text()
        .trim()
        .replace(/^Komik\s+/i, "")
        .trim()
}

async function findPages(_context: unknown, ref: Ref): Promise<RawPageInput[]> {
    const pageUrl = `${siteUrl}/${ref.nativeId.replace(/^\/+/, "")}`
    const { text: html } = await fetchText(providerName, pageUrl, {
        headers: { Referer: `${siteUrl}/` },
    })
    const doc = caye.html.parse(html)

    const pages: RawPageInput[] = []
    doc.find("img.klazy.ww").each((_, el) => {
        const src = el.attr("src") || el.attr("data-src") || ""
        const resolved = resolveUrl(src, pageUrl)
        if (resolved) pages.push({ url: resolved })
    })
    return pages
}

const komikuSource = createMangaSource({
    providerId,
    providerName,

    async search(_context, text) {
        const url = new URL("/", searchUrl)
        url.searchParams.set("post_type", "manga")
        url.searchParams.set("s", text)
        const { text: html } = await fetchText(providerName, url.toString())
        const doc = caye.html.parse(html)

        const records: SourceRecord[] = []
        const seen = new Set<string>()
        doc.find("div.bge").each((_, el) => {
            const href = el.find("div.kan a").first().attr("href") || ""
            if (!href.includes("/manga/")) return
            const nativeId = href.split("/manga/")[1]?.replace(/^\/+|\/+$/g, "") ?? ""
            const title = el.find("div.kan h3").first().text().trim()
            if (!nativeId || !title || seen.has(nativeId)) return
            seen.add(nativeId)
            records.push({
                ref: { providerId, type: "manga", nativeId },
                name: title,
            })
        })
        return records
    },

    async read(_context, ref) {
        const url = `${siteUrl}/manga/${ref.nativeId.replace(/^\/+|\/+$/g, "")}`
        const { text: html } = await fetchText(providerName, url, {
            headers: { Referer: `${siteUrl}/` },
        })
        const name = extractTitle(html)
        if (!name) {
            throw failure("unavailable", `${providerName} title not found.`)
        }
        return { name }
    },

    async list(_context, ref) {
        const url = `${siteUrl}/manga/${ref.nativeId.replace(/^\/+|\/+$/g, "")}`
        const { text: html } = await fetchText(providerName, url, {
            headers: { Referer: `${siteUrl}/` },
        })
        const doc = caye.html.parse(html)

        const entries: ParsedChapterInput[] = []
        doc.find("td.judulseries a").each((_, el) => {
            const href = el.attr("href") || ""
            const title = el.find("span").first().text().trim() || el.text().trim()
            const nativeId = href.replace(/^\/+|\/+$/g, "")
            if (!nativeId || !title) return
            entries.push({
                nativeId,
                name: title,
                number: parseChapterNumber(title),
                language: "id",
            })
        })

        if (entries.length === 0 && !extractTitle(html)) {
            throw failure("unavailable", `${providerName} chapters page unavailable.`)
        }
        return buildChapterList(providerId, entries, { reverse: true, sortByNumber: true })
    },

    findPages,

    resolveTarget: makeDirectPageResolver(
        (ref) => ({ Referer: `${siteUrl}/${ref.nativeId.replace(/^\/+/, "")}` }),
        findPages,
    ),
})

caye.register(providerId, { source: komikuSource })
