(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../manga-common/src/http.ts
  function fetchText(_0, _1) {
    return __async(this, arguments, function* (providerName2, url, options = {}) {
      var _a, _b, _c;
      const response = yield httpClient(caye, providerName2).send(__spreadProps(__spreadValues({}, options), { url, mode: "text" }));
      return {
        text: (_a = response.body) != null ? _a : "",
        url: (_b = response.url) != null ? _b : url,
        redirected: Boolean(response.redirected),
        headers: (_c = response.headers) != null ? _c : {}
      };
    });
  }
  function fetchHandle(_0, _1) {
    return __async(this, arguments, function* (providerName2, url, headers = {}) {
      const handle = yield httpClient(caye, providerName2).handle({ url, headers });
      if (handle.mediaType.toLowerCase().startsWith("text/html")) {
        throw failure("unavailable", `${providerName2} returned HTML instead of image.`);
      }
      return handle;
    });
  }

  // ../../../packages/plugin-std/src/titles.ts
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];
  function extractChapter(title) {
    for (const re of CHAPTER_PATTERNS) {
      const match = title.match(re);
      if (match) {
        const val = Number.parseFloat(match[1].replace(/[,-]/, "."));
        if (Number.isFinite(val)) return val;
      }
    }
    return -1;
  }

  // ../manga-common/src/manga.ts
  function parseChapterNumber(value) {
    if (typeof value === "number") return Number.isFinite(value) && value >= 0 ? value : void 0;
    if (typeof value !== "string" || !value.trim()) return void 0;
    const chapter = extractChapter(value);
    if (chapter >= 0) return chapter;
    const fallback = value.replace(/\bvol(?:ume)?\.?\s*\d+(?:[.,-]\d+)?/gi, " ").match(/\b(\d+(?:[.,]\d+)?)\b/);
    return fallback ? Number.parseFloat(fallback[1].replace(",", ".")) : void 0;
  }
  function boundedDeadline(deadline) {
    const now = Date.now();
    const parsed = deadline ? Date.parse(deadline) : Number.NaN;
    if (Number.isFinite(parsed) && parsed > now + 1e3 && parsed <= now + 23 * 3600 * 1e3) {
      return new Date(parsed).toISOString();
    }
    return new Date(now + 3600 * 1e3).toISOString();
  }
  function paginateSearch(records, query) {
    const limit = Math.max(1, Math.min(200, query.limit || 25));
    const parsedOffset = query.cursor ? Number.parseInt(query.cursor, 10) : 0;
    const offset = Number.isFinite(parsedOffset) && parsedOffset > 0 ? parsedOffset : 0;
    const items = records.slice(offset, offset + limit);
    const nextCursor = offset + limit < records.length ? String(offset + limit) : "";
    return {
      items,
      nextCursor,
      state: "complete"
    };
  }
  function sanitizeScopePart(value) {
    return value.trim().toLowerCase().replace(/\s+/g, "-").slice(0, 80);
  }
  function addDistinctOption(seen, raw) {
    const trimmed = raw == null ? void 0 : raw.trim();
    if (!trimmed) return void 0;
    const id = sanitizeScopePart(trimmed);
    if (!id) return void 0;
    if (!seen.has(id)) {
      seen.set(id, trimmed.slice(0, 200));
    }
    return id;
  }
  function sortChaptersForReading(entries, options) {
    const list = options.reverse ? entries.slice().reverse() : entries.slice();
    if (!options.sortByNumber) {
      return list;
    }
    let lastAnchor = -1;
    let unnumberedOffset = 0;
    const keyed = list.map((item, idx) => {
      if (item.number !== void 0) {
        lastAnchor = item.number;
        unnumberedOffset = 0;
        return { item, key: item.number, sub: 0, idx };
      }
      unnumberedOffset += 1;
      return {
        item,
        key: lastAnchor >= 0 ? lastAnchor : Number.MAX_SAFE_INTEGER,
        sub: unnumberedOffset,
        idx
      };
    });
    keyed.sort((a, b) => {
      if (a.key !== b.key) return a.key - b.key;
      if (a.sub !== b.sub) return a.sub - b.sub;
      return a.idx - b.idx;
    });
    return keyed.map((entry) => entry.item);
  }
  function buildChapterList(providerId2, entries, options = {}) {
    var _a;
    const ordered = sortChaptersForReading(entries, options);
    const numberCounts = /* @__PURE__ */ new Map();
    const languages = /* @__PURE__ */ new Map();
    const scanlators = /* @__PURE__ */ new Map();
    for (const entry of ordered) {
      if (entry.number !== void 0) {
        numberCounts.set(entry.number, ((_a = numberCounts.get(entry.number)) != null ? _a : 0) + 1);
      }
      addDistinctOption(languages, entry.language);
      addDistinctOption(scanlators, entry.scanlator);
    }
    const hasDuplicates = Array.from(numberCounts.values()).some((count) => count > 1);
    const multiLanguage = languages.size > 1;
    const multiScanlator = scanlators.size > 1;
    const needsScope = hasDuplicates && (multiLanguage || multiScanlator);
    const groups = [];
    if (needsScope && multiLanguage) {
      groups.push({
        id: "language",
        label: "Language",
        options: Array.from(languages.entries()).slice(0, 200).map(([id, label]) => ({ id, label }))
      });
    }
    if (needsScope && multiScanlator) {
      groups.push({
        id: "scanlator",
        label: "Scanlator",
        options: Array.from(scanlators.entries()).slice(0, 200).map(([id, label]) => ({ id, label }))
      });
    }
    const choices = groups.length > 0 ? { groups: groups.slice(0, 8) } : {};
    const seenKeys = /* @__PURE__ */ new Set();
    const installments = [];
    for (const entry of ordered) {
      const nativeId = entry.nativeId.trim();
      if (!nativeId) continue;
      if (nativeId.length > 200) {
        throw failure("unavailable", "Chapter ID is too long.");
      }
      const langId = entry.language ? sanitizeScopePart(entry.language) : "";
      const scanId = entry.scanlator ? sanitizeScopePart(entry.scanlator) : "";
      let scope;
      if (needsScope) {
        const parts = [];
        if (multiLanguage && langId) parts.push(langId);
        if (multiScanlator && scanId) parts.push(scanId);
        if (parts.length > 0) scope = parts.join(":").slice(0, 200);
      }
      const dedupeKey = `${nativeId}\0${scope != null ? scope : ""}`;
      if (seenKeys.has(dedupeKey)) continue;
      seenKeys.add(dedupeKey);
      const installment = __spreadValues(__spreadValues(__spreadValues({
        ref: __spreadValues({
          providerId: providerId2,
          type: "chapter",
          nativeId
        }, scope ? { scope } : {}),
        number: entry.number
      }, entry.name ? { name: entry.name.trim().slice(0, 500) } : {}), entry.language ? { language: entry.language.trim().slice(0, 35) } : {}), entry.scanlator ? { scanlator: entry.scanlator.trim().slice(0, 200) } : {});
      if (entry.number === void 0) {
        delete installment.number;
      }
      installments.push(installment);
    }
    return { installments, choices };
  }
  function buildSourcePage(context, rawPages) {
    const seenIds = /* @__PURE__ */ new Set();
    const pages = rawPages.slice(0, 5e3).map((page, index) => {
      var _a;
      const candidateId = !page.forceIndexId && page.url.length > 0 && page.url.length <= 200 ? page.url : String(index + 1);
      const id = !seenIds.has(candidateId) ? candidateId : String(index + 1);
      seenIds.add(id);
      const name = (((_a = page.name) == null ? void 0 : _a.trim()) || `Page ${index + 1}`).slice(0, 200);
      return __spreadValues(__spreadValues({
        id,
        name
      }, typeof page.width === "number" && Number.isInteger(page.width) && page.width > 0 ? { width: page.width } : {}), typeof page.height === "number" && Number.isInteger(page.height) && page.height > 0 ? { height: page.height } : {});
    });
    return {
      items: [
        {
          id: "pages",
          capabilities: ["pages"],
          origin: "pages",
          expiresAt: boundedDeadline(context.deadline),
          tracks: [],
          ranges: [],
          pages
        }
      ],
      state: "complete"
    };
  }
  function resolvePageSource(providerName2, input, target) {
    return __async(this, null, function* () {
      if (!target) {
        throw failure("unavailable", `${providerName2} page not found.`);
      }
      const handle = "resolveHandle" in target ? yield target.resolveHandle() : yield fetchHandle(providerName2, target.url, target.headers);
      return {
        id: input.sourceId,
        capabilities: ["pages"],
        origin: "pages",
        expiresAt: handle.expiresAt,
        tracks: [],
        ranges: [],
        handle
      };
    });
  }
  function createMangaSource(adapter) {
    return {
      search(context, query) {
        return __async(this, null, function* () {
          var _a2;
          const text = ((_a2 = query.q) != null ? _a2 : "").trim();
          if (!text) {
            return { items: [], nextCursor: "", state: "complete" };
          }
          const records = yield adapter.search(context, text, query);
          return paginateSearch(records, query);
        });
      },
      read(context, ref) {
        return __async(this, null, function* () {
          var _a2, _b;
          if (!((_a2 = ref == null ? void 0 : ref.nativeId) == null ? void 0 : _a2.trim())) {
            throw failure("unavailable", `${adapter.providerName} record ID is required.`);
          }
          const info = yield adapter.read(context, ref);
          if (!((_b = info.name) == null ? void 0 : _b.trim())) {
            throw failure("unavailable", `${adapter.providerName} record title is missing.`);
          }
          return __spreadValues({
            ref,
            name: info.name.trim()
          }, info.year !== void 0 ? { year: info.year } : {});
        });
      },
      list(context, ref) {
        return __async(this, null, function* () {
          var _a2;
          if (!((_a2 = ref == null ? void 0 : ref.nativeId) == null ? void 0 : _a2.trim())) {
            throw failure("unavailable", `${adapter.providerName} record ID is required.`);
          }
          return adapter.list(context, ref);
        });
      },
      find(context, ref) {
        return __async(this, null, function* () {
          var _a2;
          if (!((_a2 = ref == null ? void 0 : ref.nativeId) == null ? void 0 : _a2.trim())) {
            throw failure("unavailable", `${adapter.providerName} chapter ID is required.`);
          }
          const pages = yield adapter.findPages(context, ref);
          if (pages.length === 0) {
            throw failure("unavailable", `${adapter.providerName} returned no chapter pages.`);
          }
          return buildSourcePage(context, pages);
        });
      },
      resolve(context, input) {
        return __async(this, null, function* () {
          var _a2, _b;
          if (!((_b = (_a2 = input == null ? void 0 : input.ref) == null ? void 0 : _a2.nativeId) == null ? void 0 : _b.trim())) {
            throw failure("unavailable", `${adapter.providerName} chapter ID is required.`);
          }
          const target = yield adapter.resolveTarget(context, input);
          return resolvePageSource(adapter.providerName, input, target);
        });
      }
    };
  }
  function pickPageFromList(pages, pageId) {
    if (!pages.length) return void 0;
    if (!pageId) return pages[0];
    const byUrl = pages.find((p) => p.url === pageId);
    if (byUrl) return byUrl;
    if (/^\d+$/.test(pageId)) {
      const index = Number.parseInt(pageId, 10) - 1;
      return pages[index];
    }
    return void 0;
  }
  function makeDirectPageResolver(headersFor, findPages2) {
    return (context, input) => __async(null, null, function* () {
      var _a;
      if (input.pageId && /^https?:\/\//i.test(input.pageId)) {
        return {
          url: input.pageId,
          headers: headersFor(input.ref)
        };
      }
      const pages = yield findPages2(context, input.ref);
      const target = pickPageFromList(pages, input.pageId);
      if (!target) return void 0;
      return {
        url: target.url,
        headers: (_a = target.headers) != null ? _a : headersFor(input.ref)
      };
    });
  }

  // ../../../packages/plugin-std/src/url.ts
  function resolveUrl(raw, base) {
    const trimmed = raw.trim();
    if (!trimmed) return "";
    try {
      const url = new URL(trimmed.startsWith("//") ? `https:${trimmed}` : trimmed, base);
      return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : "";
    } catch (e) {
      return "";
    }
  }

  // src/backend.ts
  var providerId = "backreef.komiku:source";
  var providerName = "Komiku";
  var siteUrl = "https://komiku.org";
  var searchUrl = "https://api.komiku.org";
  function extractTitle(html) {
    const doc = caye.html.parse(html);
    const itemprop = doc.find('#Judul h1 span[itemprop="name"]').first().text().trim();
    if (itemprop) return itemprop;
    const judul = doc.find("#Judul h1").first().text().trim().replace(/^Komik\s+/i, "").trim();
    if (judul) return judul;
    return doc.find("h1").first().text().trim().replace(/^Komik\s+/i, "").trim();
  }
  function findPages(_context, ref) {
    return __async(this, null, function* () {
      const pageUrl = `${siteUrl}/${ref.nativeId.replace(/^\/+/, "")}`;
      const { text: html } = yield fetchText(providerName, pageUrl, {
        headers: { Referer: `${siteUrl}/` }
      });
      const doc = caye.html.parse(html);
      const pages = [];
      doc.find("img.klazy.ww").each((_, el) => {
        const src = el.attr("src") || el.attr("data-src") || "";
        const resolved = resolveUrl(src, pageUrl);
        if (resolved) pages.push({ url: resolved });
      });
      return pages;
    });
  }
  var komikuSource = createMangaSource({
    providerId,
    providerName,
    search(_context, text) {
      return __async(this, null, function* () {
        const url = new URL("/", searchUrl);
        url.searchParams.set("post_type", "manga");
        url.searchParams.set("s", text);
        const { text: html } = yield fetchText(providerName, url.toString());
        const doc = caye.html.parse(html);
        const records = [];
        const seen = /* @__PURE__ */ new Set();
        doc.find("div.bge").each((_, el) => {
          var _a, _b;
          const href = el.find("div.kan a").first().attr("href") || "";
          if (!href.includes("/manga/")) return;
          const nativeId = (_b = (_a = href.split("/manga/")[1]) == null ? void 0 : _a.replace(/^\/+|\/+$/g, "")) != null ? _b : "";
          const title = el.find("div.kan h3").first().text().trim();
          if (!nativeId || !title || seen.has(nativeId)) return;
          seen.add(nativeId);
          records.push({
            ref: { providerId, type: "manga", nativeId },
            name: title
          });
        });
        return records;
      });
    },
    read(_context, ref) {
      return __async(this, null, function* () {
        const url = `${siteUrl}/manga/${ref.nativeId.replace(/^\/+|\/+$/g, "")}`;
        const { text: html } = yield fetchText(providerName, url, {
          headers: { Referer: `${siteUrl}/` }
        });
        const name = extractTitle(html);
        if (!name) {
          throw failure("unavailable", `${providerName} title not found.`);
        }
        return { name };
      });
    },
    list(_context, ref) {
      return __async(this, null, function* () {
        const url = `${siteUrl}/manga/${ref.nativeId.replace(/^\/+|\/+$/g, "")}`;
        const { text: html } = yield fetchText(providerName, url, {
          headers: { Referer: `${siteUrl}/` }
        });
        const doc = caye.html.parse(html);
        const entries = [];
        doc.find("td.judulseries a").each((_, el) => {
          const href = el.attr("href") || "";
          const title = el.find("span").first().text().trim() || el.text().trim();
          const nativeId = href.replace(/^\/+|\/+$/g, "");
          if (!nativeId || !title) return;
          entries.push({
            nativeId,
            name: title,
            number: parseChapterNumber(title),
            language: "id"
          });
        });
        if (entries.length === 0 && !extractTitle(html)) {
          throw failure("unavailable", `${providerName} chapters page unavailable.`);
        }
        return buildChapterList(providerId, entries, { reverse: true, sortByNumber: true });
      });
    },
    findPages,
    resolveTarget: makeDirectPageResolver(
      (ref) => ({ Referer: `${siteUrl}/${ref.nativeId.replace(/^\/+/, "")}` }),
      findPages
    )
  });
  caye.register(providerId, { source: komikuSource });
})();
//# sourceMappingURL=backend.js.map
