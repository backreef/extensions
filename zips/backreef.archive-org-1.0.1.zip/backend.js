(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __objRest = (source, exclude) => {
    var target = {};
    for (var prop in source)
      if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
        target[prop] = source[prop];
    if (source != null && __getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(source)) {
        if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
          target[prop] = source[prop];
      }
    return target;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve2, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve2(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../../../packages/plugin-std/src/magnet.ts
  var BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  function decodeBase32(input) {
    const cleaned = input.trim().toUpperCase().replace(/=+$/, "");
    if (!cleaned || !/^[A-Z2-7]+$/.test(cleaned)) {
      throw new TypeError("Invalid base32 string");
    }
    const bytes = [];
    let buffer = 0;
    let bitsLeft = 0;
    for (let i = 0; i < cleaned.length; i++) {
      const val = BASE32_ALPHABET.indexOf(cleaned[i]);
      buffer = buffer << 5 | val;
      bitsLeft += 5;
      if (bitsLeft >= 8) {
        bitsLeft -= 8;
        bytes.push(buffer >>> bitsLeft & 255);
      }
    }
    return new Uint8Array(bytes);
  }
  function bytesToHex(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i++) {
      out += bytes[i].toString(16).padStart(2, "0");
    }
    return out;
  }
  function normalizeInfoHash(raw) {
    const trimmed = raw.trim();
    if (/^[0-9a-fA-F]{40}$/.test(trimmed)) {
      return trimmed.toLowerCase();
    }
    if (/^[A-Za-z2-7]{32}=*$/.test(trimmed)) {
      const decoded = decodeBase32(trimmed);
      if (decoded.length === 20) {
        return bytesToHex(decoded);
      }
    }
    throw new TypeError(`Invalid infoHash: ${raw}`);
  }
  function parseMagnet(uri) {
    var _a;
    const trimmed = uri.trim();
    if (!/^magnet:\?/i.test(trimmed)) {
      throw new TypeError("Invalid magnet URI");
    }
    const query = trimmed.slice(trimmed.indexOf("?") + 1);
    const params = new URLSearchParams(query);
    let infoHash = "";
    for (const xt of params.getAll("xt")) {
      const match = xt.match(/^urn:btih:([0-9a-fA-F]{40}|[A-Za-z2-7]{32}=*)$/i);
      if (match) {
        infoHash = normalizeInfoHash(match[1]);
        break;
      }
    }
    if (!infoHash) {
      throw new TypeError("Magnet URI missing valid btih infoHash");
    }
    const name = (_a = params.get("dn")) != null ? _a : "";
    const seen = /* @__PURE__ */ new Set();
    const trackers = [];
    for (const tr of params.getAll("tr")) {
      const t = tr.trim();
      if (t && !seen.has(t)) {
        seen.add(t);
        trackers.push(t);
      }
    }
    const xlRaw = params.get("xl");
    let size = 0;
    if (xlRaw && /^\d+$/.test(xlRaw.trim())) {
      size = Number.parseInt(xlRaw.trim(), 10);
    }
    return { infoHash, name, trackers, size };
  }
  function buildMagnet(options) {
    const infoHash = normalizeInfoHash(options.infoHash);
    const parts = [`magnet:?xt=urn:btih:${infoHash}`];
    if (options.name) {
      parts.push(`dn=${encodeURIComponent(options.name)}`);
    }
    if (options.trackers) {
      const seen = /* @__PURE__ */ new Set();
      for (const tr of options.trackers) {
        const trimmed = tr.trim();
        if (trimmed && !seen.has(trimmed)) {
          seen.add(trimmed);
          parts.push(`tr=${encodeURIComponent(trimmed)}`);
        }
      }
    }
    return parts.join("&");
  }

  // ../../../packages/plugin-std/src/titles.ts
  var ORDINAL_TO_NUMBER = {
    first: 1,
    "1st": 1,
    second: 2,
    "2nd": 2,
    third: 3,
    "3rd": 3,
    fourth: 4,
    "4th": 4,
    fifth: 5,
    "5th": 5,
    sixth: 6,
    "6th": 6,
    seventh: 7,
    "7th": 7,
    eighth: 8,
    "8th": 8,
    ninth: 9,
    "9th": 9,
    tenth: 10,
    "10th": 10
  };
  var ROMAN_SEASON_MAP = {
    ii: 2,
    iii: 3,
    iv: 4,
    v: 5,
    vi: 6,
    vii: 7,
    viii: 8,
    ix: 9,
    xi: 11,
    xii: 12,
    xiii: 13
  };
  function extractSeason(title) {
    const val = title.toLowerCase();
    const explicit = val.match(/season\s*(\d+)/);
    if (explicit) return Number.parseInt(explicit[1], 10);
    const sFmt = val.match(/\bs0?(\d{1,2})(?:e\d|$|\s|\.)/);
    if (sFmt) {
      const num = Number.parseInt(sFmt[1], 10);
      if (num > 0 && num < 20) return num;
    }
    const ordinal = val.match(/(\d+)(?:st|nd|rd|th)\s+season/);
    if (ordinal) return Number.parseInt(ordinal[1], 10);
    const romanCleaned = val.replace(
      /\b((?:act|arc|chapter|saga|hen|part|cour))[\s._:-]+(i{1,3}|iv|vi?i?i?|ix|x)\b/g,
      "$1"
    );
    const romanPatterns = [
      /[\s.](i{1,3}|iv|vi?i?i?|ix|x)(?:\s|$|[:,.]|[''])/,
      /[\s.](i{1,3}|iv|vi?i?i?|ix|x)[.\s]*(?:s\d|e\d|part)/
    ];
    for (const re of romanPatterns) {
      const m = romanCleaned.match(re);
      if (m && ROMAN_SEASON_MAP[m[1]] !== void 0) {
        return ROMAN_SEASON_MAP[m[1]];
      }
    }
    const trailing = val.match(/(?:^|\s)(\d{1,2})\s*$/);
    if (trailing && !/(?:part|cour|specials?|sp|movie|ova|ona|oad)\s*\d{1,2}\s*$/.test(val)) {
      const num = Number.parseInt(trailing[1], 10);
      if (num >= 2 && num <= 10) return num;
    }
    const jp = val.match(/(?:第)?(\d+)\s*期/);
    if (jp) return Number.parseInt(jp[1], 10);
    const wordOrd = val.match(
      /\b(first|second|third|fourth|fifth|sixth|seventh|eighth|ninth|tenth)\s+season\b/
    );
    if (wordOrd && ORDINAL_TO_NUMBER[wordOrd[1]] !== void 0) {
      return ORDINAL_TO_NUMBER[wordOrd[1]];
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../torrent-common/src/option.ts
  var DEFAULT_TRACKERS = [
    "http://nyaa.tracker.wf:7777/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce"
  ];
  var MAX_RETRIEVAL_URI_LENGTH = 2e3;
  function numberValue(value) {
    return { kind: "number", number: value };
  }
  function makeFact(producerId, id, field, value, at = (/* @__PURE__ */ new Date()).toISOString()) {
    return {
      id,
      producerId,
      field,
      value: numberValue(value),
      locale: "",
      region: "",
      status: "complete",
      at
    };
  }
  function buildCountsFacts(producerId, key, counts) {
    const at = (/* @__PURE__ */ new Date()).toISOString();
    const facts = [];
    if (counts.size !== void 0 && Number.isFinite(counts.size) && counts.size > 0) {
      facts.push(makeFact(producerId, `size-${key}`, "size", counts.size, at));
    }
    if (counts.seeders !== void 0 && Number.isFinite(counts.seeders) && counts.seeders >= 0) {
      facts.push(makeFact(producerId, `seeders-${key}`, "seeders", counts.seeders, at));
    }
    if (counts.leechers !== void 0 && Number.isFinite(counts.leechers) && counts.leechers >= 0) {
      facts.push(makeFact(producerId, `leechers-${key}`, "leechers", counts.leechers, at));
    }
    if (counts.downloads !== void 0 && Number.isFinite(counts.downloads) && counts.downloads > 0) {
      facts.push(makeFact(producerId, `downloads-${key}`, "downloads", counts.downloads, at));
    }
    return facts;
  }
  function parseIsoDate(caye2, raw, layouts) {
    var _a;
    const trimmed = raw == null ? void 0 : raw.trim();
    if (!trimmed) return void 0;
    if (typeof ((_a = caye2.time) == null ? void 0 : _a.parse) === "function") {
      try {
        const ms = caye2.time.parse(trimmed, layouts ? { layouts } : void 0);
        if (Number.isFinite(ms)) {
          return new Date(ms).toISOString();
        }
      } catch (e) {
      }
    }
    const parsed = Date.parse(trimmed);
    if (Number.isFinite(parsed)) {
      return new Date(parsed).toISOString();
    }
    return void 0;
  }
  function pickUri(magnet, torrentUrl) {
    if (magnet && Array.from(magnet).length <= MAX_RETRIEVAL_URI_LENGTH) {
      return magnet;
    }
    return torrentUrl || magnet || "";
  }
  function createTorrentOption(caye2, input) {
    var _a, _b, _c, _d;
    const uri = pickUri(input.magnet, input.torrentUrl);
    const facts = buildCountsFacts(input.providerId, input.key, {
      size: input.size,
      seeders: input.seeders,
      leechers: input.leechers,
      downloads: input.downloads
    });
    let resolution = ((_a = input.resolution) == null ? void 0 : _a.trim()) || "";
    let group = ((_b = input.group) == null ? void 0 : _b.trim()) || "";
    if ((!resolution || !group) && typeof ((_c = caye2.release) == null ? void 0 : _c.parse) === "function") {
      try {
        const parsed = caye2.release.parse(input.name);
        if (!resolution && parsed.resolution) resolution = parsed.resolution;
        if (!group && parsed.group) group = parsed.group;
      } catch (e) {
      }
    }
    const option = {
      id: input.id,
      name: input.name,
      kind: "torrent",
      uri,
      files: [],
      facts,
      availability: "available",
      eligible: true,
      reasons: [],
      confirmed: Boolean(input.confirmed)
    };
    if (input.seeders !== void 0 && Number.isFinite(input.seeders) && input.seeders >= 0) {
      option.seeders = Math.trunc(input.seeders);
    }
    if (input.size !== void 0 && Number.isFinite(input.size) && input.size > 0) {
      option.size = Math.round(input.size);
    }
    if (input.publishedAt) option.publishedAt = input.publishedAt;
    if (input.pageUrl && /^https?:\/\//i.test(input.pageUrl)) {
      option.pageUrl = input.pageUrl;
    }
    if ((_d = input.magnet) == null ? void 0 : _d.startsWith("magnet:")) {
      option.magnet = input.magnet;
    }
    if (resolution) option.resolution = resolution;
    if (group) option.group = group;
    if (input.best) option.best = true;
    return option;
  }
  var missingMessage = (service) => `${service} no longer lists this torrent.`;
  function fetchText(caye2, service, url, options) {
    return __async(this, null, function* () {
      var _b, _c;
      const _a = options != null ? options : {}, { missingOn404 } = _a, input = __objRest(_a, ["missingOn404"]);
      const response = yield httpClient(caye2, service).send(
        __spreadProps(__spreadValues({}, input), { url }),
        missingOn404 ? { missing: missingMessage(service) } : void 0
      );
      return {
        status: response.status,
        headers: (_b = response.headers) != null ? _b : {},
        body: (_c = response.body) != null ? _c : "",
        url: response.url
      };
    });
  }
  function fetchJson(caye2, service, url, options) {
    return __async(this, null, function* () {
      const res = yield fetchText(caye2, service, url, options);
      if (!res.body) {
        throw failure("unavailable", `${service} returned an empty response.`);
      }
      try {
        return JSON.parse(res.body);
      } catch (e) {
        throw failure("unavailable", `${service} returned malformed JSON.`);
      }
    });
  }

  // ../../../packages/plugin-std/src/cache.ts
  function getCachedJson(api, key) {
    return __async(this, null, function* () {
      try {
        const value = yield api.cache.get({ key });
        if ((value == null ? void 0 : value.kind) === "text") return JSON.parse(value.text);
      } catch (e) {
      }
      return void 0;
    });
  }
  function setCachedJson(api, key, value, ttlSeconds) {
    return __async(this, null, function* () {
      try {
        yield api.cache.set({
          key,
          value: { kind: "text", text: JSON.stringify(value) },
          ttlSeconds
        });
      } catch (e) {
      }
    });
  }

  // ../torrent-common/src/smart.ts
  var OPTION_CACHE_TTL_SECONDS = 7 * 24 * 60 * 60;
  function parseResolutionNumber(raw) {
    if (!raw) return 0;
    const lower = raw.trim().toLowerCase();
    if (lower === "4k" || lower === "uhd") return 2160;
    if (lower === "8k") return 4320;
    const match = /(\d{3,4})/.exec(lower);
    return match ? Number.parseInt(match[1], 10) : 0;
  }
  function normalizeResolutionLabel(raw) {
    const n = parseResolutionNumber(raw);
    if (n >= 360 && n <= 4320) return `${n}p`;
    return "";
  }
  function extractResolution(caye2, title) {
    try {
      const parsed = caye2.release.parse(title);
      if (parsed.resolution) {
        const normalized = normalizeResolutionLabel(parsed.resolution);
        if (normalized) return normalized;
      }
    } catch (e) {
    }
    if (/\b(?:4k|2160p?|uhd)\b/i.test(title)) return "2160p";
    const match = /\b(\d{3,4})\s*p\b/i.exec(title);
    if (match) {
      const normalized = normalizeResolutionLabel(match[1]);
      if (normalized) return normalized;
    }
    return "";
  }
  function clampLimit(limit, fallback = 50, max = 100) {
    return Math.min(Math.max(limit || fallback, 1), max);
  }
  function cacheOptions(_0, _1, _2) {
    return __async(this, arguments, function* (caye2, prefix, options, ttlSeconds = OPTION_CACHE_TTL_SECONDS) {
      for (const option of options) {
        yield setCachedJson(caye2, `${prefix}:option:${option.id}`, option, ttlSeconds);
      }
    });
  }
  function validateHttpUrl(raw) {
    const trimmed = (raw == null ? void 0 : raw.trim()) || "";
    if (!trimmed) return void 0;
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol === "http:" || parsed.protocol === "https:") {
        return parsed.toString();
      }
    } catch (e) {
    }
    return void 0;
  }
  function resolveFromRetrievalInput(caye2, providerId, prefix, input, notFoundMessage, defaultGroup) {
    var _a, _b, _c, _d;
    const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
    const rawMagnet = ((_b = input.magnet) == null ? void 0 : _b.trim()) || "";
    const rawInfoHash = ((_c = input.infoHash) == null ? void 0 : _c.trim()) || "";
    const rawTorrentUrl = ((_d = input.torrentUrl) == null ? void 0 : _d.trim()) || "";
    const hasRetrieval = Boolean(rawMagnet || rawInfoHash || rawTorrentUrl);
    if (!hasRetrieval) return void 0;
    if (optionId && !optionId.startsWith(`${prefix}-`)) {
      throw failure("missing", notFoundMessage);
    }
    const validTorrentUrl = rawTorrentUrl ? validateHttpUrl(rawTorrentUrl) : void 0;
    if (rawTorrentUrl && !validTorrentUrl) {
      throw failure("missing", "Invalid torrent retrieval URL.");
    }
    if (rawMagnet) {
      let parsed;
      try {
        parsed = parseMagnet(rawMagnet);
      } catch (e) {
        throw failure("missing", "Invalid magnet retrieval URI.");
      }
      const id = optionId || `${prefix}-${parsed.infoHash}`;
      return createTorrentOption(caye2, {
        id,
        key: parsed.infoHash,
        providerId,
        name: parsed.name || `${prefix} ${parsed.infoHash}`,
        magnet: rawMagnet,
        torrentUrl: validTorrentUrl,
        size: parsed.size > 0 ? parsed.size : void 0,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (rawInfoHash) {
      let infoHash = "";
      try {
        infoHash = normalizeInfoHash(rawInfoHash);
      } catch (e) {
        throw failure("missing", "Invalid torrent info hash.");
      }
      const id = optionId || `${prefix}-${infoHash}`;
      const magnet = buildMagnet({ infoHash, trackers: DEFAULT_TRACKERS });
      return createTorrentOption(caye2, {
        id,
        key: infoHash,
        providerId,
        name: `${prefix} ${infoHash}`,
        magnet,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (validTorrentUrl) {
      const id = optionId || `${prefix}-torrent`;
      const key = id.startsWith(`${prefix}-`) ? id.slice(prefix.length + 1) : id;
      return createTorrentOption(caye2, {
        id,
        key,
        providerId,
        name: `${prefix} ${key}`,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    return void 0;
  }
  function resolveCachedOrFallback(caye2, prefix, input, notFoundMessage, fetchFallback, options) {
    return __async(this, null, function* () {
      var _a;
      const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
      if (!optionId && !input.magnet && !input.torrentUrl && !input.infoHash) {
        throw failure("missing", notFoundMessage);
      }
      if (optionId && !optionId.startsWith(`${prefix}-`)) {
        throw failure("missing", notFoundMessage);
      }
      if (optionId) {
        const cached = yield getCachedJson(caye2, `${prefix}:option:${optionId}`);
        if (cached && cached.id === optionId) {
          return cached;
        }
      }
      if (fetchFallback && optionId) {
        try {
          return yield fetchFallback(optionId);
        } catch (err) {
          const code = err == null ? void 0 : err.code;
          if (code !== "missing" && code !== "unavailable" && code !== "rate-limited") throw err;
          const fallback2 = resolveFromRetrievalInput(
            caye2,
            (options == null ? void 0 : options.providerId) || `backreef.${prefix}:search`,
            prefix,
            input,
            notFoundMessage,
            options == null ? void 0 : options.group
          );
          if (fallback2) return fallback2;
          throw err;
        }
      }
      const fallback = resolveFromRetrievalInput(
        caye2,
        (options == null ? void 0 : options.providerId) || `backreef.${prefix}:search`,
        prefix,
        input,
        notFoundMessage,
        options == null ? void 0 : options.group
      );
      if (fallback) return fallback;
      throw failure("missing", notFoundMessage);
    });
  }
  function normalizeLatinText(s) {
    let out = (s || "").toLowerCase().replace(/×/g, "x");
    try {
      out = out.normalize("NFKD").replace(/[\u0300-\u036f]/g, "");
    } catch (e) {
    }
    return out.replace(/[^a-z0-9]+/g, " ").trim();
  }
  function inferSeasonFromTitle(title) {
    return Math.max(1, extractSeason(title || ""));
  }
  function stripTitleSeason(title) {
    return (title || "").replace(/\(?\b\d+(?:st|nd|rd|th)\s+season\b\)?/gi, "").replace(/\b(?:season|part|cour)\s*\d+\b/gi, "").replace(/\s+(?:ii|iii|iv|v|vi|vii|viii|\d{1,2})\s*$/i, "").replace(/[\s:\-–]+$/, "").trim();
  }

  // ../torrent-common/src/media.ts
  function asRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return void 0;
    return value;
  }
  function positiveIntString(value) {
    if (typeof value === "number") {
      return Number.isInteger(value) && value > 0 ? String(value) : void 0;
    }
    if (typeof value === "string") {
      const trimmed = value.trim();
      return /^[1-9][0-9]*$/.test(trimmed) ? trimmed : void 0;
    }
    return void 0;
  }
  function addUniqueTitle(target, raw) {
    if (typeof raw !== "string") return;
    const trimmed = raw.trim();
    if (trimmed && !target.includes(trimmed)) {
      target.push(trimmed);
    }
  }
  function extractEntriesIds(entriesValue, preferredNative) {
    if (!Array.isArray(entriesValue)) return {};
    let anilistId;
    let anidbId;
    let malId;
    let bgmId;
    const inspect = (requireMatch) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      for (const rawEntry of entriesValue) {
        const entry = asRecord(rawEntry);
        if (!entry) continue;
        const ref = asRecord(entry.ref);
        if (requireMatch && preferredNative) {
          if ((ref == null ? void 0 : ref.providerId) !== preferredNative.entry.providerId || (ref == null ? void 0 : ref.nativeId) !== preferredNative.entry.nativeId) {
            continue;
          }
        }
        const ids = asRecord(entry.ids);
        if (ids) {
          anilistId != null ? anilistId : anilistId = positiveIntString((_b = (_a = ids.anilistid) != null ? _a : ids.anilistId) != null ? _b : ids.anilist);
          anidbId != null ? anidbId : anidbId = positiveIntString((_d = (_c = ids.anidbid) != null ? _c : ids.anidbId) != null ? _d : ids.anidb);
          malId != null ? malId : malId = positiveIntString((_f = (_e = ids.malid) != null ? _e : ids.malId) != null ? _f : ids.mal);
          bgmId != null ? bgmId : bgmId = positiveIntString((_i = (_h = (_g = ids.bgmid) != null ? _g : ids.bgmId) != null ? _h : ids.bgm) != null ? _i : ids.bangumi);
        }
        if ((ref == null ? void 0 : ref.providerId) === "caye.anilist:catalog" || (ref == null ? void 0 : ref.providerId) === "anilist" || typeof (ref == null ? void 0 : ref.providerId) === "string" && ref.providerId.includes("anilist")) {
          anilistId != null ? anilistId : anilistId = positiveIntString(ref.nativeId);
        }
      }
    };
    if (preferredNative) inspect(true);
    inspect(false);
    return { anilistId, anidbId, malId, bgmId };
  }
  function extractFieldMap(fieldsValue) {
    const out = {};
    if (!Array.isArray(fieldsValue)) return out;
    for (const rawField of fieldsValue) {
      const entry = asRecord(rawField);
      if (!entry || typeof entry.field !== "string") continue;
      const val = asRecord(entry.value);
      if (val) out[entry.field] = val;
    }
    return out;
  }
  function parseDateParts(raw) {
    if (typeof raw !== "string") return void 0;
    const m = /^(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?/.exec(raw.trim());
    if (!m) return void 0;
    const year = Number.parseInt(m[1], 10);
    if (year < 1900 || year > 2100) return void 0;
    return {
      year,
      month: m[2] ? Number.parseInt(m[2], 10) : void 0,
      day: m[3] ? Number.parseInt(m[3], 10) : void 0
    };
  }
  function safeGetItem(caye2, itemId) {
    return __async(this, null, function* () {
      if (!itemId || typeof caye2.request !== "function") return void 0;
      try {
        const raw = yield caye2.request("getItem", { path: { itemId } });
        return asRecord(raw);
      } catch (e) {
        return void 0;
      }
    });
  }
  function pickPreferredNative(query) {
    var _a;
    const refs = (_a = query.native) != null ? _a : [];
    if (refs.length === 0) return void 0;
    const exact = refs.find((r) => r.itemId === query.itemId);
    if (exact) return exact;
    return refs[0];
  }
  function resolveMediaContext(caye2, query) {
    return __async(this, null, function* () {
      var _a, _b;
      const titles = [];
      let romajiTitle = "";
      let englishTitle = "";
      let originalTitle = "";
      const synonyms = [];
      let anilistId;
      let anidbId;
      let malId;
      let bgmId;
      let isMovie = false;
      let isAnime = false;
      let adult = false;
      let year;
      let startDate;
      let episodeCount;
      let releaseStatus;
      const preferredNative = pickPreferredNative(query);
      const item = yield safeGetItem(caye2, query.itemId || (preferredNative == null ? void 0 : preferredNative.itemId));
      const parentId = typeof (item == null ? void 0 : item.parentId) === "string" ? item.parentId : void 0;
      const parentItem = parentId ? yield safeGetItem(caye2, parentId) : void 0;
      const consumeTitlesObj = (rawTitles) => {
        const t = asRecord(rawTitles);
        if (!t) return;
        if (!romajiTitle && typeof t.romaji === "string") romajiTitle = t.romaji.trim();
        if (!englishTitle && typeof t.english === "string") englishTitle = t.english.trim();
        if (!originalTitle && typeof t.original === "string") originalTitle = t.original.trim();
        addUniqueTitle(titles, t.romaji);
        addUniqueTitle(titles, t.english);
        addUniqueTitle(titles, t.original);
      };
      const inspectRecord = (record) => {
        var _a2, _b2, _c, _d, _e, _f, _g, _h, _i, _j, _k;
        if (!record) return;
        if (record.adult === true) adult = true;
        const kindId = typeof record.kindId === "string" ? record.kindId : "";
        const kindLeaf = (kindId.includes(":") ? kindId.split(":")[1] : kindId).toLowerCase();
        if (kindLeaf === "movie") isMovie = true;
        if (kindLeaf === "anime" || kindId.toLowerCase().includes(":anime")) isAnime = true;
        const ids = extractEntriesIds(record.entries, preferredNative);
        anilistId != null ? anilistId : anilistId = ids.anilistId;
        anidbId != null ? anidbId : anidbId = ids.anidbId;
        malId != null ? malId : malId = ids.malId;
        bgmId != null ? bgmId : bgmId = ids.bgmId;
        if (anilistId || anidbId) isAnime = true;
        const parentSummary = asRecord(record.parent);
        if (parentSummary) {
          consumeTitlesObj(parentSummary.titles);
          addUniqueTitle(titles, parentSummary.name);
        }
        consumeTitlesObj(record.titles);
        addUniqueTitle(titles, record.name);
        const totalChildren = typeof record.totalChildren === "number" ? record.totalChildren : typeof record.childCount === "number" ? record.childCount : void 0;
        if (totalChildren !== void 0 && totalChildren > 0 && episodeCount === void 0) {
          episodeCount = totalChildren;
        }
        const fields = extractFieldMap(record.fields);
        if (((_a2 = fields["caye:adult"]) == null ? void 0 : _a2.boolean) === true) adult = true;
        const formatVal = typeof ((_b2 = fields["caye:format"]) == null ? void 0 : _b2.text) === "string" ? fields["caye:format"].text.trim() : "";
        if (/^movie$/i.test(formatVal)) isMovie = true;
        if (/^(?:tv|tv_short|ova|ona|special|anime)$/i.test(formatVal) && isAnime) isMovie = false;
        const romajiField = typeof ((_c = fields["caye:romaji"]) == null ? void 0 : _c.text) === "string" ? fields["caye:romaji"].text.trim() : "";
        const englishField = typeof ((_d = fields["caye:english"]) == null ? void 0 : _d.text) === "string" ? fields["caye:english"].text.trim() : "";
        const originalField = typeof ((_e = fields["caye:original"]) == null ? void 0 : _e.text) === "string" ? fields["caye:original"].text.trim() : "";
        if (!romajiTitle && romajiField) romajiTitle = romajiField;
        if (!englishTitle && englishField) englishTitle = englishField;
        if (!originalTitle && originalField) originalTitle = originalField;
        addUniqueTitle(titles, romajiField);
        addUniqueTitle(titles, englishField);
        addUniqueTitle(titles, originalField);
        if (!releaseStatus) {
          const statusVal = (_h = (_f = fields["caye:status"]) == null ? void 0 : _f.text) != null ? _h : (_g = fields["caye:releaseStatus"]) == null ? void 0 : _g.text;
          if (typeof statusVal === "string" && statusVal.trim()) releaseStatus = statusVal.trim();
        }
        if (!startDate) {
          const releaseAt = (_i = fields["caye:releaseAt"]) == null ? void 0 : _i.text;
          startDate = parseDateParts(releaseAt);
        }
        if (year === void 0) {
          const yNum = (_j = fields["caye:year"]) == null ? void 0 : _j.number;
          if (typeof yNum === "number" && yNum >= 1900 && yNum <= 2100) {
            year = Math.trunc(yNum);
          } else if (startDate) {
            year = startDate.year;
          }
        }
        for (const key of ["caye:titles", "caye:synonyms", "caye:alternativeTitles"]) {
          const list = (_k = fields[key]) == null ? void 0 : _k.list;
          if (Array.isArray(list)) {
            for (const v of list) {
              const obj = asRecord(v);
              if (typeof (obj == null ? void 0 : obj.text) === "string" && obj.text.trim()) {
                addUniqueTitle(synonyms, obj.text);
                addUniqueTitle(titles, obj.text);
              }
            }
          }
        }
      };
      inspectRecord(parentItem);
      inspectRecord(item);
      const text = ((_a = query.text) == null ? void 0 : _a.trim()) || "";
      if (text) {
        addUniqueTitle(titles, text);
      }
      if (!anilistId) {
        for (const ref of (_b = query.native) != null ? _b : []) {
          if (ref.entry.providerId === "caye.anilist:catalog" || ref.entry.providerId === "anilist" || ref.entry.providerId.includes("anilist")) {
            anilistId = positiveIntString(ref.entry.nativeId);
            if (anilistId) break;
          }
        }
      }
      const season = typeof query.season === "number" && query.season > 0 ? query.season : typeof (item == null ? void 0 : item.season) === "number" && item.season > 0 ? item.season : void 0;
      const number = typeof query.number === "number" && query.number > 0 ? query.number : typeof (item == null ? void 0 : item.number) === "number" && item.number > 0 ? item.number : void 0;
      const absolute = typeof query.absolute === "number" && query.absolute > 0 ? query.absolute : void 0;
      const absoluteSeasonOffset = absolute !== void 0 && number !== void 0 && absolute > number ? absolute - number : 0;
      return {
        text,
        titles,
        romajiTitle: romajiTitle || titles[0] || "",
        englishTitle: englishTitle || "",
        originalTitle,
        synonyms,
        anilistId,
        anidbId,
        malId,
        bgmId,
        season,
        number,
        absolute,
        isMovie,
        isAnime,
        adult,
        year,
        startDate: startDate != null ? startDate : year ? { year } : void 0,
        episodeCount,
        releaseStatus,
        absoluteSeasonOffset
      };
    });
  }

  // src/backend.ts
  var PROVIDER_ID = "backreef.archive-org:search";
  var IA = "https://archive.org";
  var VIDEO_FORMATS = /* @__PURE__ */ new Set([
    "matroska",
    "mpeg4",
    "h.264",
    "h.264 ia",
    "512kb mpeg4",
    "avi",
    "divx",
    "webm",
    "ogg video",
    "mpeg2",
    "mpeg1",
    "quicktime",
    "windows media",
    "hevc"
  ]);
  var JUNK_COLLECTIONS = [
    "mirrortube",
    "social-media-video",
    "tiktoks",
    "bilibili_videos",
    "youtubegraveyard",
    "podcasts-video",
    "twitchstreams",
    "movie_trailers",
    "movie_trailers_unsorted",
    "vhsopenings",
    "speedpaintingvids",
    "ytpmv-mad",
    "deemphasize",
    "vhsvault",
    "commercials",
    "vipernation-tv"
  ];
  var JUNK_WORDS = /\b(?:amv|amvs|mad|mmd|fandub|fan ?dub|fan ?made|fanmade|cosplay|reaction|reactions|review|reviews|trailer|trailers|promo|teaser|teasers|asmr|unboxing|explained|shorts|podcast|vod|livestream|gameplay|walkthrough|lets play|ost|soundtrack|music video|full album|manga|webtoon|manhwa|manhua|light novel|audiobook|audio book|3ds|cia|iso|dvdiso|bdiso|bdmv|video ts|umd|tiktok|parody|abridged|meme|memes|tier list|top \d+|analysis|theory|funny moments|edit|edits|opening|openings|ending|endings|op ed|vtuber|minecraft|roblox|fortnite|gacha|drawing|speedpaint|redraw|tutorial|figure|figures|haul|interview|panel|concert|live stage|stage play|musical|live action|tv drama|j drama|kdrama|commentary|watchalong|rewatch|mv|pv|cm|videoclip|videoclips|clip|clips|op \d+|ed \d+|ncop|nced|creditless)\b/;
  var ADULT_WORDS = /\b(?:hentai|nsfw|xxx|porn|porno|sex|nude|nudes|onlyfans|jav|r18|erotic|lewd)\b/;
  var YEAR_RE = /\b(19[5-9]\d|20[0-4]\d)\b/g;
  var FOREIGN_SCRIPT = /[Ѐ-ӿ֐-ۿ฀-๿぀-ヿ㐀-鿿가-힯]+/g;
  var SITE_PREFIX = /^\s*(?:\[[^\]]*\]|\([^)]*\)|【[^】]*】|[\w-]+\.(?:com|net|org|plus|fun|tv|to|cc|me|io|site|xyz|in|club|info|ru|top)\b)\s*/i;
  var ALLOWED_AFTER = /^(?:\d+|s\d+|e\d+|s\d+e\d+|complete|completo|completa|series|serie|season|seasons|temporada|temporadas|staffel|saison|sezon|ep|eps|episode|episodes|episodio|episodios|capitulo|capitulos|cap|folge|folgen|part|vol|volume|dub|dubbed|dublado|dublaj|doblaje|sub|subs|subbed|subtitles|subtitled|legendado|legendada|eng|english|jap|japanese|jpn|dual|audio|multi|latino|castellano|espanol|hindi|german|deutsch|ger|french|vostfr|vf|ita|rus|russian|turkce|pt|br|bd|bdrip|bluray|blu|ray|dvd|dvdrip|web|webrip|webdl|dl|hd|sd|fhd|hevc|x264|x265|h264|h265|av1|10bit|aac|flac|raw|raws|uncensored|tv|batch|collection|box|set|remastered|uncut|und|and|with|mit|by|anime|\d+p|4k|uhd|bolum|bolumler|yayini|cr|nf|amzn|ia|mp4|mkv|avi|version|edition|e|en|jp|v2)$/;
  var CONNECTORS = /^(?:the|full|all)$/;
  var BASE_FILTER = `mediatype:movies AND format:"Archive BitTorrent" AND -collection:(${JUNK_COLLECTIONS.join(" OR ")})`;
  function normItem(s) {
    return normalizeLatinText((s || "").replace(FOREIGN_SCRIPT, " zzforeign "));
  }
  function firstStr(v) {
    return Array.isArray(v) ? v[0] || "" : v || "";
  }
  function asList(v) {
    return Array.isArray(v) ? v : v ? [v] : [];
  }
  function seasonsIn(text) {
    let t = normalizeLatinText(text);
    if (/\b(?:complete series|all seasons|complete collection|integrale|serie completa|komplette serie)\b/.test(
      t
    )) {
      return [0];
    }
    const out = [];
    const add = (a, b) => {
      if (!(a > 0 && b >= a && b - a < 30)) return;
      for (let i = a; i <= b; i++) if (!out.includes(i)) out.push(i);
    };
    const patterns = [
      [
        /\b(?:seasons?|temporadas?|staffeln?|saisons?)\s*0*(\d{1,2})\s+(?:(?:to|and|a|bis|und|y)\s+)?0*(\d{1,2})\b/g,
        true
      ],
      [/\bs\s*0*(\d{1,2})\s+(?:(?:to|and|a|bis)\s+)?s?\s*0*(\d{1,2})\b(?!\s*e\s*\d)/g, true],
      [/\b0*(\d{1,2})(?:st|nd|rd|th)?\s*(?:season|sezon|temporada|staffel)\b/g, false],
      [/\b(?:season|temporada|staffel|saison|stagione)\s*0*(\d{1,2})\b/g, false],
      [/\bs\s*0*(\d{1,2})\b/g, false]
    ];
    for (const [re, isRange] of patterns) {
      let m;
      const used = [];
      while (m = re.exec(t)) {
        const a = Number.parseInt(m[1], 10);
        const b = isRange ? Number.parseInt(m[2], 10) : a;
        if (a > 0 && b >= a && b - a < 30) {
          add(a, b);
          used.push(m[0]);
        }
      }
      for (const u of used) t = t.replace(u, " ");
    }
    return out;
  }
  function parseEpisodeFromRest(rest) {
    const r = " " + rest.replace(YEAR_RE, " ").replace(/\b\d{3,4}\s*p\b/g, " ").replace(/\b\d{3,4}\s*x\s*\d{3,4}\b/g, " ").replace(/\b(?:x|h)\s*26[45]\b/g, " ").replace(/\b(?:10|8)\s*bit\b/g, " ").replace(/\b(?:5|2|7)\s+1\b/g, " ").replace(/\b\d{1,2}(?:st|nd|rd|th)?\s*(?:season|sezon|temporada|staffel)\b/g, " ").replace(/\b(?:seasons?|temporadas?|staffel|saison)\s*\d{1,2}\b/g, " ").replace(/\bs\s*\d{1,2}\b(?!\s*e\s*\d)/g, " ") + " ";
    let m = /\b(?:episodes?|eps?|episodios?|capitulos?|caps?|folgen?)\s*(\d{1,4})\s+(?:(?:to|a|al|bis|and|y|e|ve)\s+)?(\d{1,4})\b/.exec(
      r
    ) || /^\s*(\d{1,4})\s+(?:(?:to|a|al|bis|and|y|e|ve)\s+)?(\d{1,4})\b/.exec(r);
    if (m && Number.parseInt(m[2], 10) > Number.parseInt(m[1], 10)) {
      return { episode: -1, explicit: false };
    }
    m = /\bs\s*\d{1,2}\s*e\s*(\d{1,4})\b/.exec(r) || /\b(?:episode|episodio|episodi|ep|e|folge|capitulo|cap|chapter|bolum|odcinek)\s*(\d{1,4})\b/.exec(
      r
    ) || /\b(\d{1,4})\s*(?:bolum\w*|serie|seria|odcinek|wa|hua)\b/.exec(r);
    if (m) return { episode: Number.parseInt(m[1], 10), explicit: true };
    m = /^\s*(\d{1,4})\b/.exec(r);
    if (m) return { episode: Number.parseInt(m[1], 10), explicit: false };
    return { episode: -1, explicit: false };
  }
  function isJunk(doc, allowAdult) {
    const title = firstStr(doc.title);
    const t = normalizeLatinText(title);
    if (!doc.btih || !title || !doc.identifier) return true;
    if (/^(?:youtube|tiktok|bilibili|twitch|instagram|twitter|vimeo)[-_]/i.test(doc.identifier))
      return true;
    if (asList(doc.collection).some((c) => JUNK_COLLECTIONS.includes(c))) return true;
    if ((doc.item_size || 0) < 20 * 1024 * 1024) return true;
    const formats = asList(doc.format).map((f) => f.toLowerCase());
    if (formats.length > 0 && !formats.some((f) => VIDEO_FORMATS.has(f))) return true;
    if (JUNK_WORDS.test(t)) return true;
    if (!allowAdult && ADULT_WORDS.test(t)) return true;
    return false;
  }
  function quotePhrase(s) {
    return `"${s.replace(/["\\:;!?()[\]{}~^*]/g, " ").replace(/\s+/g, " ").trim()}"`;
  }
  function docToOption(doc, confirmed) {
    var _a;
    const id = ((_a = doc.identifier) == null ? void 0 : _a.trim()) || "";
    const title = firstStr(doc.title).trim();
    if (!id || !title || !doc.btih) return void 0;
    let infoHash = "";
    try {
      infoHash = normalizeInfoHash(doc.btih);
    } catch (e) {
      return void 0;
    }
    const torrentUrl = `${IA}/download/${encodeURIComponent(id)}/${encodeURIComponent(id)}_archive.torrent`;
    const baseMagnet = buildMagnet({
      infoHash,
      name: id,
      trackers: ["http://bt1.archive.org:6969/announce", "http://bt2.archive.org:6969/announce"]
    });
    const magnet = `${baseMagnet}&ws=${encodeURIComponent(`${IA}/download/`)}&xs=${encodeURIComponent(torrentUrl)}`;
    const size = typeof doc.item_size === "number" && doc.item_size > 0 ? doc.item_size : void 0;
    const downloads = typeof doc.downloads === "number" && doc.downloads > 0 ? doc.downloads : void 0;
    return createTorrentOption(caye, {
      id: `archive-org-${id}`,
      key: id,
      providerId: PROVIDER_ID,
      name: title,
      magnet,
      torrentUrl,
      pageUrl: `${IA}/details/${encodeURIComponent(id)}`,
      size,
      seeders: 1,
      leechers: 0,
      downloads,
      publishedAt: parseIsoDate(caye, doc.publicdate),
      resolution: extractResolution(caye, title) || void 0,
      confirmed
    });
  }
  function getCachedMediaInfo(media) {
    return __async(this, null, function* () {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i, _j;
      const addLatin = (target, t) => {
        if (t && /[a-z]/i.test(t) && !FOREIGN_SCRIPT.test(t) && !target.includes(t)) {
          target.push(t);
        }
      };
      const baseTitles = [];
      for (const t of [media.romajiTitle, media.englishTitle, ...media.synonyms, ...media.titles]) {
        addLatin(baseTitles, t);
      }
      if (!media.anilistId) {
        return { titles: baseTitles, seasons: [], related: null };
      }
      const cacheKey = `archive-org:media:${media.anilistId}`;
      const cached = yield getCachedJson(caye, cacheKey);
      if (cached && Array.isArray(cached.titles)) {
        const mergedTitles2 = [...baseTitles];
        for (const t of cached.titles) addLatin(mergedTitles2, t);
        return {
          titles: mergedTitles2,
          seasons: cached.seasons || [],
          related: (_a = cached.related) != null ? _a : null
        };
      }
      const seasons = [];
      const extraTitles = [];
      let related = null;
      try {
        const zip = yield fetchJson(caye, "ani.zip", `https://api.ani.zip/mappings?anilist_id=${media.anilistId}`, {
          headers: { Accept: "application/json" },
          timeoutMs: 5e3
        });
        for (const val of Object.values((_b = zip.titles) != null ? _b : {})) addLatin(extraTitles, val);
        for (const [k, ep] of Object.entries((_c = zip.episodes) != null ? _c : {})) {
          if (/^\d+$/.test(k) && typeof ep.seasonNumber === "number" && ep.seasonNumber > 0) {
            if (!seasons.includes(ep.seasonNumber)) seasons.push(ep.seasonNumber);
          }
        }
      } catch (e) {
      }
      try {
        const gql = "query($id:Int){Media(id:$id){relations{edges{node{type title{romaji english} synonyms}}}}}";
        const res = yield fetchJson(caye, "AniList", "https://graphql.anilist.co", {
          method: "POST",
          headers: { "Content-Type": "application/json", Accept: "application/json" },
          body: JSON.stringify({ query: gql, variables: { id: Number(media.anilistId) } }),
          timeoutMs: 5e3
        });
        const out = [];
        for (const edge of (_g = (_f = (_e = (_d = res.data) == null ? void 0 : _d.Media) == null ? void 0 : _e.relations) == null ? void 0 : _f.edges) != null ? _g : []) {
          const node = edge.node;
          if (!node || node.type !== "ANIME") continue;
          for (const t of [(_h = node.title) == null ? void 0 : _h.romaji, (_i = node.title) == null ? void 0 : _i.english, ...(_j = node.synonyms) != null ? _j : []]) {
            const x = normalizeLatinText(t || "");
            if (x && !out.includes(x)) out.push(x);
          }
        }
        related = out;
      } catch (e) {
      }
      if (related || seasons.length > 0 || extraTitles.length > 0) {
        yield setCachedJson(
          caye,
          cacheKey,
          { titles: extraTitles, seasons, related },
          OPTION_CACHE_TTL_SECONDS
        );
      }
      const mergedTitles = [...baseTitles];
      for (const t of extraTitles) addLatin(mergedTitles, t);
      return { titles: mergedTitles, seasons, related };
    });
  }
  function iaSearch(q, rows, sort) {
    return __async(this, null, function* () {
      var _a;
      const fl = [
        "identifier",
        "title",
        "item_size",
        "downloads",
        "publicdate",
        "btih",
        "format",
        "collection"
      ].map((f) => `fl[]=${f}`).join("&");
      const url = `${IA}/advancedsearch.php?q=${encodeURIComponent(q)}&${fl}&rows=${rows}&page=1&output=json${sort ? `&sort[]=${encodeURIComponent(sort)}` : ""}`;
      let lastError;
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const data = yield fetchJson(
            caye,
            "Archive.org",
            url,
            {
              headers: { Accept: "application/json" }
            }
          );
          if (Array.isArray((_a = data.response) == null ? void 0 : _a.docs)) return data.response.docs;
          throw failure("unavailable", "Archive.org returned an invalid search response.");
        } catch (err) {
          const code = err == null ? void 0 : err.code;
          if (code === "rate-limited") throw err;
          lastError = err;
        }
      }
      throw lastError instanceof Error ? lastError : failure("unavailable", "Archive.org is unavailable.");
    });
  }
  function find(_context, query) {
    return __async(this, null, function* () {
      var _a, _b;
      const media = yield resolveMediaContext(caye, query);
      const isSmart = Boolean(query.batch || query.number && query.number > 0 || query.itemId);
      const limit = clampLimit(query.limit, 50, 100);
      if (!isSmart) {
        const words = normalizeLatinText(query.text || "").split(" ").filter(Boolean);
        if (words.length === 0) {
          throw failure("unsupported", "Enter a title to search.");
        }
        const docs2 = yield iaSearch(
          `title:(${words.join(" AND ")}) AND ${BASE_FILTER}`,
          Math.max(limit, 50),
          "downloads desc"
        );
        const items2 = docs2.filter((d) => !isJunk(d, media.adult)).map((d) => docToOption(d, false)).filter((o) => Boolean(o)).slice(0, limit);
        yield cacheOptions(caye, "archive-org", items2);
        return { items: items2, state: "complete" };
      }
      const info = yield getCachedMediaInfo(media);
      const customQuery = ((_a = query.text) == null ? void 0 : _a.trim()) || "";
      const fullTitles = customQuery ? [customQuery, ...info.titles.filter((t) => t !== customQuery)] : info.titles;
      const usable = (n) => n.length >= 4 || n.includes(" ");
      const full = fullTitles.map(normalizeLatinText).filter(usable);
      const bases = [];
      const prefixes = [];
      const names = [];
      for (const t of fullTitles) {
        const b = normalizeLatinText(stripTitleSeason(t));
        if (usable(b) && !bases.includes(b)) bases.push(b);
      }
      for (const t of fullTitles) {
        const b = normalizeLatinText(stripTitleSeason(t));
        const p = normalizeLatinText(stripTitleSeason(t.split(/:\s| - /)[0]));
        if (usable(b) && !names.includes(b)) names.push(b);
        if (usable(p) && !bases.includes(p) && !prefixes.includes(p)) {
          prefixes.push(p);
          names.push(p);
        }
      }
      if (names.length === 0) {
        const fallbackWords = normalizeLatinText(customQuery || media.romajiTitle || "").split(" ").filter(Boolean);
        if (fallbackWords.length === 0) throw failure("unsupported", "Enter a title to search.");
        names.push(fallbackWords.join(" "));
      }
      const own = [media.romajiTitle, media.englishTitle].map(
        (x) => normalizeLatinText(stripTitleSeason(x || ""))
      );
      const ambiguous = (n) => !own.includes(n) && (prefixes.includes(n) && (!info.related || info.related.includes(n)) || Boolean(info.related && info.related.includes(n)));
      const mediaSeasons = info.seasons.length > 0 ? info.seasons : [
        query.season && query.season > 0 ? query.season : inferSeasonFromTitle(media.romajiTitle || media.englishTitle || "")
      ];
      const startYear = ((_b = media.startDate) == null ? void 0 : _b.year) || media.year || 0;
      const yearSpan = media.releaseStatus === "releasing" || !media.episodeCount ? 50 : Math.max(1, Math.ceil(media.episodeCount / 45));
      const yearFits = (y) => y >= startYear - 1 && y <= startYear + yearSpan + 3;
      const phrases = names.slice(0, 10).map(quotePhrase).join(" OR ");
      const docs = yield iaSearch(`title:(${phrases}) AND ${BASE_FILTER}`, 200, "downloads desc");
      const singles = [];
      const batches = [];
      const seen = /* @__PURE__ */ new Set();
      const wantedEpisode = query.number && query.number > 0 ? Math.trunc(query.number) : 0;
      const wantedAbsolute = query.absolute && query.absolute > 0 ? Math.trunc(query.absolute) : -1;
      for (const doc of docs) {
        if (isJunk(doc, media.adult)) continue;
        const btih = (doc.btih || "").toLowerCase();
        if (seen.has(btih)) continue;
        const title = firstStr(doc.title);
        let stripped = title;
        while (SITE_PREFIX.test(stripped)) stripped = stripped.replace(SITE_PREFIX, "");
        const t = ` ${normItem(stripped)} `;
        const opens = (n) => t.startsWith(` ${n} `);
        const fullHit = full.filter(opens).sort((a, b) => b.length - a.length)[0];
        const nameHit = names.filter(opens).sort((a, b) => b.length - a.length)[0];
        const hit = fullHit && (!nameHit || fullHit.length >= nameHit.length) ? fullHit : nameHit;
        if (!hit) continue;
        const namesItself = Boolean(fullHit && hit === fullHit && !bases.includes(fullHit));
        const rest = t.slice(hit.length + 2).trim();
        const restWords = rest ? rest.split(" ") : [];
        const itemSeasons = seasonsIn(`${title.slice(0, title.length - stripped.length)} ${rest}`);
        const years = (title.match(YEAR_RE) || []).map((y) => Number.parseInt(y, 10));
        if (startYear > 0 && years.length > 0 && !years.some(yearFits)) continue;
        if (!namesItself && ambiguous(hit)) {
          const seasonProof = itemSeasons.length > 0 && itemSeasons.some((s) => mediaSeasons.includes(s));
          if (!seasonProof && !(startYear > 0 && years.some(yearFits))) continue;
        }
        if (media.isMovie) {
          if (itemSeasons.length > 0 && itemSeasons[0] !== 0) continue;
          if (!namesItself) {
            const subtitle = normalizeLatinText(fullTitles[0] || "").split(" ").filter(
              (w) => w.length > 2 && !hit.split(" ").includes(w) && !/^(?:the|movie|film|gekijouban)$/.test(w)
            );
            const pool = ` ${normalizeLatinText(title)} `;
            if (subtitle.length > 0 && subtitle.filter((w) => pool.includes(` ${w} `)).length / subtitle.length < 0.5) {
              continue;
            }
          }
        } else {
          let k = 0;
          while (k < restWords.length && CONNECTORS.test(restWords[k])) k++;
          if (k > 0 && k === restWords.length) continue;
          let foreign = false;
          for (let i = k; i < Math.min(k + 2, restWords.length) && !/\d/.test(restWords[i]); i++) {
            if (!ALLOWED_AFTER.test(restWords[i])) foreign = true;
          }
          if (foreign) continue;
          if (/\b(?:movie|film|gekijouban|pelicula|final season)\b/.test(rest)) continue;
          if (itemSeasons[0] !== 0) {
            if (itemSeasons.length > 0) {
              if (!itemSeasons.some((s) => mediaSeasons.includes(s))) continue;
            } else if (!namesItself && !mediaSeasons.includes(1)) {
              continue;
            }
          }
        }
        const ep = parseEpisodeFromRest(rest);
        let episode = ep.episode;
        if (episode > 0 && !ep.explicit && (doc.item_size || 0) > 3.5 * 1024 * 1024 * 1024 && !media.isMovie) {
          episode = -1;
        }
        const isBatch = !media.isMovie && episode < 0;
        seen.add(btih);
        if (media.isMovie) {
          const opt = docToOption(doc, false);
          if (opt) singles.push(opt);
          continue;
        }
        if (isBatch) {
          const opt = docToOption(doc, false);
          if (opt) batches.push(opt);
          continue;
        }
        if (wantedEpisode > 0) {
          if (episode === wantedEpisode || wantedAbsolute > 0 && episode === wantedAbsolute) {
            const opt = docToOption(doc, true);
            if (opt) singles.push(opt);
          }
        } else if (!query.batch) {
          const opt = docToOption(doc, false);
          if (opt) singles.push(opt);
        }
      }
      let items;
      if (query.batch) {
        items = media.isMovie ? singles : batches;
      } else if (wantedEpisode > 0 && singles.length > 0) {
        items = singles;
      } else {
        items = singles.concat(batches);
      }
      const chosen = items.slice(0, limit);
      yield cacheOptions(caye, "archive-org", chosen);
      return { items: chosen, state: "complete" };
    });
  }
  function resolve(_context, input) {
    return __async(this, null, function* () {
      return yield resolveCachedOrFallback(
        caye,
        "archive-org",
        input,
        "Unknown Archive.org option.",
        (optionId) => __async(null, null, function* () {
          var _a, _b, _c;
          const id = optionId.slice("archive-org-".length);
          if (!id) throw failure("missing", "Unknown Archive.org option.");
          const meta = yield fetchJson(caye, "Archive.org", `${IA}/metadata/${encodeURIComponent(id)}`, {
            headers: { Accept: "application/json" },
            missingOn404: true
          });
          const btih = ((_b = (_a = meta.files) == null ? void 0 : _a.find((f) => f.btih)) == null ? void 0 : _b.btih) || "";
          if (!((_c = meta.metadata) == null ? void 0 : _c.identifier) || !btih) {
            throw failure("missing", "Archive.org no longer lists this torrent.");
          }
          const opt = docToOption(
            {
              identifier: meta.metadata.identifier,
              title: meta.metadata.title || meta.metadata.identifier,
              publicdate: meta.metadata.publicdate,
              item_size: meta.item_size,
              btih
            },
            false
          );
          if (!opt) throw failure("unavailable", "Archive.org returned invalid torrent metadata.");
          yield setCachedJson(
            caye,
            `archive-org:option:${optionId}`,
            opt,
            OPTION_CACHE_TTL_SECONDS
          );
          return opt;
        }),
        { providerId: PROVIDER_ID }
      );
    });
  }
  caye.register(PROVIDER_ID, { acquisition: { find, resolve } });
})();
//# sourceMappingURL=backend.js.map
