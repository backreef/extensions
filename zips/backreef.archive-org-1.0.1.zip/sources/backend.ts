import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DownloadOption,
} from "../../../../packages/plugin-sdk/src/index"
import {
    buildMagnet,
    cacheOptions,
    clampLimit,
    createTorrentOption,
    extractResolution,
    fetchJson,
    inferSeasonFromTitle,
    normalizeInfoHash,
    normalizeLatinText,
    OPTION_CACHE_TTL_SECONDS,
    parseIsoDate,
    resolveCachedOrFallback,
    resolveMediaContext,
    stripTitleSeason,
    type MediaContext,
} from "../../torrent-common/src/index.ts"
import { getCachedJson, setCachedJson } from "../../../../packages/plugin-std/src/cache.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const PROVIDER_ID = "backreef.archive-org:search"
const IA = "https://archive.org"

type IaDoc = {
    identifier?: string
    title?: string | string[]
    item_size?: number
    downloads?: number
    publicdate?: string
    btih?: string
    format?: string[]
    collection?: string | string[]
}

type CachedMediaInfo = {
    titles: string[]
    seasons: number[]
    related: string[] | null
}

const VIDEO_FORMATS = new Set([
    "matroska",
    "mpeg4",
    "h.264",
    "h.264 ia",
    "512kb mpeg4",
    "avi",
    "divx",
    "webm",
    "ogg video",
    "mpeg2",
    "mpeg1",
    "quicktime",
    "windows media",
    "hevc",
])

const JUNK_COLLECTIONS = [
    "mirrortube",
    "social-media-video",
    "tiktoks",
    "bilibili_videos",
    "youtubegraveyard",
    "podcasts-video",
    "twitchstreams",
    "movie_trailers",
    "movie_trailers_unsorted",
    "vhsopenings",
    "speedpaintingvids",
    "ytpmv-mad",
    "deemphasize",
    "vhsvault",
    "commercials",
    "vipernation-tv",
]

const JUNK_WORDS =
    /\b(?:amv|amvs|mad|mmd|fandub|fan ?dub|fan ?made|fanmade|cosplay|reaction|reactions|review|reviews|trailer|trailers|promo|teaser|teasers|asmr|unboxing|explained|shorts|podcast|vod|livestream|gameplay|walkthrough|lets play|ost|soundtrack|music video|full album|manga|webtoon|manhwa|manhua|light novel|audiobook|audio book|3ds|cia|iso|dvdiso|bdiso|bdmv|video ts|umd|tiktok|parody|abridged|meme|memes|tier list|top \d+|analysis|theory|funny moments|edit|edits|opening|openings|ending|endings|op ed|vtuber|minecraft|roblox|fortnite|gacha|drawing|speedpaint|redraw|tutorial|figure|figures|haul|interview|panel|concert|live stage|stage play|musical|live action|tv drama|j drama|kdrama|commentary|watchalong|rewatch|mv|pv|cm|videoclip|videoclips|clip|clips|op \d+|ed \d+|ncop|nced|creditless)\b/
const ADULT_WORDS = /\b(?:hentai|nsfw|xxx|porn|porno|sex|nude|nudes|onlyfans|jav|r18|erotic|lewd)\b/
const YEAR_RE = /\b(19[5-9]\d|20[0-4]\d)\b/g
const FOREIGN_SCRIPT = /[Ѐ-ӿ֐-ۿ฀-๿぀-ヿ㐀-鿿가-힯]+/g
const SITE_PREFIX =
    /^\s*(?:\[[^\]]*\]|\([^)]*\)|【[^】]*】|[\w-]+\.(?:com|net|org|plus|fun|tv|to|cc|me|io|site|xyz|in|club|info|ru|top)\b)\s*/i
const ALLOWED_AFTER =
    /^(?:\d+|s\d+|e\d+|s\d+e\d+|complete|completo|completa|series|serie|season|seasons|temporada|temporadas|staffel|saison|sezon|ep|eps|episode|episodes|episodio|episodios|capitulo|capitulos|cap|folge|folgen|part|vol|volume|dub|dubbed|dublado|dublaj|doblaje|sub|subs|subbed|subtitles|subtitled|legendado|legendada|eng|english|jap|japanese|jpn|dual|audio|multi|latino|castellano|espanol|hindi|german|deutsch|ger|french|vostfr|vf|ita|rus|russian|turkce|pt|br|bd|bdrip|bluray|blu|ray|dvd|dvdrip|web|webrip|webdl|dl|hd|sd|fhd|hevc|x264|x265|h264|h265|av1|10bit|aac|flac|raw|raws|uncensored|tv|batch|collection|box|set|remastered|uncut|und|and|with|mit|by|anime|\d+p|4k|uhd|bolum|bolumler|yayini|cr|nf|amzn|ia|mp4|mkv|avi|version|edition|e|en|jp|v2)$/
const CONNECTORS = /^(?:the|full|all)$/
const BASE_FILTER = `mediatype:movies AND format:"Archive BitTorrent" AND -collection:(${JUNK_COLLECTIONS.join(" OR ")})`

function normItem(s: string): string {
    return normalizeLatinText((s || "").replace(FOREIGN_SCRIPT, " zzforeign "))
}

function firstStr(v: string | string[] | undefined): string {
    return Array.isArray(v) ? v[0] || "" : v || ""
}

function asList(v: string | string[] | undefined): string[] {
    return Array.isArray(v) ? v : v ? [v] : []
}

function seasonsIn(text: string): number[] {
    let t = normalizeLatinText(text)
    if (
        /\b(?:complete series|all seasons|complete collection|integrale|serie completa|komplette serie)\b/.test(
            t,
        )
    ) {
        return [0]
    }
    const out: number[] = []
    const add = (a: number, b: number) => {
        if (!(a > 0 && b >= a && b - a < 30)) return
        for (let i = a; i <= b; i++) if (!out.includes(i)) out.push(i)
    }
    const patterns: [RegExp, boolean][] = [
        [
            /\b(?:seasons?|temporadas?|staffeln?|saisons?)\s*0*(\d{1,2})\s+(?:(?:to|and|a|bis|und|y)\s+)?0*(\d{1,2})\b/g,
            true,
        ],
        [/\bs\s*0*(\d{1,2})\s+(?:(?:to|and|a|bis)\s+)?s?\s*0*(\d{1,2})\b(?!\s*e\s*\d)/g, true],
        [/\b0*(\d{1,2})(?:st|nd|rd|th)?\s*(?:season|sezon|temporada|staffel)\b/g, false],
        [/\b(?:season|temporada|staffel|saison|stagione)\s*0*(\d{1,2})\b/g, false],
        [/\bs\s*0*(\d{1,2})\b/g, false],
    ]
    for (const [re, isRange] of patterns) {
        let m: RegExpExecArray | null
        const used: string[] = []
        while ((m = re.exec(t))) {
            const a = Number.parseInt(m[1], 10)
            const b = isRange ? Number.parseInt(m[2], 10) : a
            if (a > 0 && b >= a && b - a < 30) {
                add(a, b)
                used.push(m[0])
            }
        }
        for (const u of used) t = t.replace(u, " ")
    }
    return out
}

function parseEpisodeFromRest(rest: string): { episode: number; explicit: boolean } {
    const r =
        " " +
        rest
            .replace(YEAR_RE, " ")
            .replace(/\b\d{3,4}\s*p\b/g, " ")
            .replace(/\b\d{3,4}\s*x\s*\d{3,4}\b/g, " ")
            .replace(/\b(?:x|h)\s*26[45]\b/g, " ")
            .replace(/\b(?:10|8)\s*bit\b/g, " ")
            .replace(/\b(?:5|2|7)\s+1\b/g, " ")
            .replace(/\b\d{1,2}(?:st|nd|rd|th)?\s*(?:season|sezon|temporada|staffel)\b/g, " ")
            .replace(/\b(?:seasons?|temporadas?|staffel|saison)\s*\d{1,2}\b/g, " ")
            .replace(/\bs\s*\d{1,2}\b(?!\s*e\s*\d)/g, " ") +
        " "

    let m =
        /\b(?:episodes?|eps?|episodios?|capitulos?|caps?|folgen?)\s*(\d{1,4})\s+(?:(?:to|a|al|bis|and|y|e|ve)\s+)?(\d{1,4})\b/.exec(
            r,
        ) || /^\s*(\d{1,4})\s+(?:(?:to|a|al|bis|and|y|e|ve)\s+)?(\d{1,4})\b/.exec(r)
    if (m && Number.parseInt(m[2], 10) > Number.parseInt(m[1], 10)) {
        return { episode: -1, explicit: false }
    }
    m =
        /\bs\s*\d{1,2}\s*e\s*(\d{1,4})\b/.exec(r) ||
        /\b(?:episode|episodio|episodi|ep|e|folge|capitulo|cap|chapter|bolum|odcinek)\s*(\d{1,4})\b/.exec(
            r,
        ) ||
        /\b(\d{1,4})\s*(?:bolum\w*|serie|seria|odcinek|wa|hua)\b/.exec(r)
    if (m) return { episode: Number.parseInt(m[1], 10), explicit: true }
    m = /^\s*(\d{1,4})\b/.exec(r)
    if (m) return { episode: Number.parseInt(m[1], 10), explicit: false }
    return { episode: -1, explicit: false }
}

function isJunk(doc: IaDoc, allowAdult: boolean): boolean {
    const title = firstStr(doc.title)
    const t = normalizeLatinText(title)
    if (!doc.btih || !title || !doc.identifier) return true
    if (/^(?:youtube|tiktok|bilibili|twitch|instagram|twitter|vimeo)[-_]/i.test(doc.identifier))
        return true
    if (asList(doc.collection).some((c) => JUNK_COLLECTIONS.includes(c))) return true
    if ((doc.item_size || 0) < 20 * 1024 * 1024) return true
    const formats = asList(doc.format).map((f) => f.toLowerCase())
    if (formats.length > 0 && !formats.some((f) => VIDEO_FORMATS.has(f))) return true
    if (JUNK_WORDS.test(t)) return true
    if (!allowAdult && ADULT_WORDS.test(t)) return true
    return false
}

function quotePhrase(s: string): string {
    return `"${s
        .replace(/["\\:;!?()[\]{}~^*]/g, " ")
        .replace(/\s+/g, " ")
        .trim()}"`
}

function docToOption(doc: IaDoc, confirmed: boolean): DownloadOption | undefined {
    const id = doc.identifier?.trim() || ""
    const title = firstStr(doc.title).trim()
    if (!id || !title || !doc.btih) return undefined
    let infoHash = ""
    try {
        infoHash = normalizeInfoHash(doc.btih)
    } catch {
        return undefined
    }
    const torrentUrl = `${IA}/download/${encodeURIComponent(id)}/${encodeURIComponent(id)}_archive.torrent`
    const baseMagnet = buildMagnet({
        infoHash,
        name: id,
        trackers: ["http://bt1.archive.org:6969/announce", "http://bt2.archive.org:6969/announce"],
    })
    const magnet = `${baseMagnet}&ws=${encodeURIComponent(`${IA}/download/`)}&xs=${encodeURIComponent(torrentUrl)}`
    const size = typeof doc.item_size === "number" && doc.item_size > 0 ? doc.item_size : undefined
    const downloads =
        typeof doc.downloads === "number" && doc.downloads > 0 ? doc.downloads : undefined
    return createTorrentOption(caye, {
        id: `archive-org-${id}`,
        key: id,
        providerId: PROVIDER_ID,
        name: title,
        magnet,
        torrentUrl,
        pageUrl: `${IA}/details/${encodeURIComponent(id)}`,
        size,
        seeders: 1,
        leechers: 0,
        downloads,
        publishedAt: parseIsoDate(caye, doc.publicdate),
        resolution: extractResolution(caye, title) || undefined,
        confirmed,
    })
}

async function getCachedMediaInfo(media: MediaContext): Promise<CachedMediaInfo> {
    const addLatin = (target: string[], t: string | undefined) => {
        if (t && /[a-z]/i.test(t) && !FOREIGN_SCRIPT.test(t) && !target.includes(t)) {
            target.push(t)
        }
    }
    const baseTitles: string[] = []
    for (const t of [media.romajiTitle, media.englishTitle, ...media.synonyms, ...media.titles]) {
        addLatin(baseTitles, t)
    }
    if (!media.anilistId) {
        return { titles: baseTitles, seasons: [], related: null }
    }

    const cacheKey = `archive-org:media:${media.anilistId}`
    const cached = await getCachedJson<CachedMediaInfo>(caye, cacheKey)
    if (cached && Array.isArray(cached.titles)) {
        const mergedTitles = [...baseTitles]
        for (const t of cached.titles) addLatin(mergedTitles, t)
        return {
            titles: mergedTitles,
            seasons: cached.seasons || [],
            related: cached.related ?? null,
        }
    }

    const seasons: number[] = []
    const extraTitles: string[] = []
    let related: string[] | null = null

    try {
        const zip = await fetchJson<{
            titles?: Record<string, string>
            episodes?: Record<string, { seasonNumber?: number }>
        }>(caye, "ani.zip", `https://api.ani.zip/mappings?anilist_id=${media.anilistId}`, {
            headers: { Accept: "application/json" },
            timeoutMs: 5000,
        })
        for (const val of Object.values(zip.titles ?? {})) addLatin(extraTitles, val)
        for (const [k, ep] of Object.entries(zip.episodes ?? {})) {
            if (/^\d+$/.test(k) && typeof ep.seasonNumber === "number" && ep.seasonNumber > 0) {
                if (!seasons.includes(ep.seasonNumber)) seasons.push(ep.seasonNumber)
            }
        }
    } catch {}

    try {
        const gql =
            "query($id:Int){Media(id:$id){relations{edges{node{type title{romaji english} synonyms}}}}}"
        const res = await fetchJson<{
            data?: {
                Media?: {
                    relations?: {
                        edges?: {
                            node?: {
                                type?: string
                                title?: { romaji?: string; english?: string }
                                synonyms?: string[]
                            }
                        }[]
                    }
                }
            }
        }>(caye, "AniList", "https://graphql.anilist.co", {
            method: "POST",
            headers: { "Content-Type": "application/json", Accept: "application/json" },
            body: JSON.stringify({ query: gql, variables: { id: Number(media.anilistId) } }),
            timeoutMs: 5000,
        })
        const out: string[] = []
        for (const edge of res.data?.Media?.relations?.edges ?? []) {
            const node = edge.node
            if (!node || node.type !== "ANIME") continue
            for (const t of [node.title?.romaji, node.title?.english, ...(node.synonyms ?? [])]) {
                const x = normalizeLatinText(t || "")
                if (x && !out.includes(x)) out.push(x)
            }
        }
        related = out
    } catch {}

    if (related || seasons.length > 0 || extraTitles.length > 0) {
        await setCachedJson(
            caye,
            cacheKey,
            { titles: extraTitles, seasons, related },
            OPTION_CACHE_TTL_SECONDS,
        )
    }
    const mergedTitles = [...baseTitles]
    for (const t of extraTitles) addLatin(mergedTitles, t)
    return { titles: mergedTitles, seasons, related }
}

async function iaSearch(q: string, rows: number, sort: string): Promise<IaDoc[]> {
    const fl = [
        "identifier",
        "title",
        "item_size",
        "downloads",
        "publicdate",
        "btih",
        "format",
        "collection",
    ]
        .map((f) => `fl[]=${f}`)
        .join("&")
    const url = `${IA}/advancedsearch.php?q=${encodeURIComponent(q)}&${fl}&rows=${rows}&page=1&output=json${sort ? `&sort[]=${encodeURIComponent(sort)}` : ""}`
    let lastError: unknown
    for (let attempt = 0; attempt < 2; attempt++) {
        try {
            const data = await fetchJson<{ response?: { docs?: IaDoc[] } }>(
                caye,
                "Archive.org",
                url,
                {
                    headers: { Accept: "application/json" },
                },
            )
            if (Array.isArray(data.response?.docs)) return data.response.docs
            throw failure("unavailable", "Archive.org returned an invalid search response.")
        } catch (err) {
            const code = (err as { code?: string })?.code
            if (code === "rate-limited") throw err
            lastError = err
        }
    }
    throw lastError instanceof Error
        ? lastError
        : failure("unavailable", "Archive.org is unavailable.")
}

async function find(_context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const media = await resolveMediaContext(caye, query)
    const isSmart = Boolean(query.batch || (query.number && query.number > 0) || query.itemId)
    const limit = clampLimit(query.limit, 50, 100)

    if (!isSmart) {
        const words = normalizeLatinText(query.text || "")
            .split(" ")
            .filter(Boolean)
        if (words.length === 0) {
            throw failure("unsupported", "Enter a title to search.")
        }
        const docs = await iaSearch(
            `title:(${words.join(" AND ")}) AND ${BASE_FILTER}`,
            Math.max(limit, 50),
            "downloads desc",
        )
        const items = docs
            .filter((d) => !isJunk(d, media.adult))
            .map((d) => docToOption(d, false))
            .filter((o): o is DownloadOption => Boolean(o))
            .slice(0, limit)
        await cacheOptions(caye, "archive-org", items)
        return { items, state: "complete" }
    }

    const info = await getCachedMediaInfo(media)
    const customQuery = query.text?.trim() || ""
    const fullTitles = customQuery
        ? [customQuery, ...info.titles.filter((t) => t !== customQuery)]
        : info.titles
    const usable = (n: string) => n.length >= 4 || n.includes(" ")
    const full = fullTitles.map(normalizeLatinText).filter(usable)
    const bases: string[] = []
    const prefixes: string[] = []
    const names: string[] = []
    for (const t of fullTitles) {
        const b = normalizeLatinText(stripTitleSeason(t))
        if (usable(b) && !bases.includes(b)) bases.push(b)
    }
    for (const t of fullTitles) {
        const b = normalizeLatinText(stripTitleSeason(t))
        const p = normalizeLatinText(stripTitleSeason(t.split(/:\s| - /)[0]))
        if (usable(b) && !names.includes(b)) names.push(b)
        if (usable(p) && !bases.includes(p) && !prefixes.includes(p)) {
            prefixes.push(p)
            names.push(p)
        }
    }
    if (names.length === 0) {
        const fallbackWords = normalizeLatinText(customQuery || media.romajiTitle || "")
            .split(" ")
            .filter(Boolean)
        if (fallbackWords.length === 0) throw failure("unsupported", "Enter a title to search.")
        names.push(fallbackWords.join(" "))
    }

    const own = [media.romajiTitle, media.englishTitle].map((x) =>
        normalizeLatinText(stripTitleSeason(x || "")),
    )
    const ambiguous = (n: string) =>
        !own.includes(n) &&
        ((prefixes.includes(n) && (!info.related || info.related.includes(n))) ||
            Boolean(info.related && info.related.includes(n)))

    const mediaSeasons =
        info.seasons.length > 0
            ? info.seasons
            : [
                  query.season && query.season > 0
                      ? query.season
                      : inferSeasonFromTitle(media.romajiTitle || media.englishTitle || ""),
              ]
    const startYear = media.startDate?.year || media.year || 0
    const yearSpan =
        media.releaseStatus === "releasing" || !media.episodeCount
            ? 50
            : Math.max(1, Math.ceil(media.episodeCount / 45))
    const yearFits = (y: number) => y >= startYear - 1 && y <= startYear + yearSpan + 3

    const phrases = names.slice(0, 10).map(quotePhrase).join(" OR ")
    const docs = await iaSearch(`title:(${phrases}) AND ${BASE_FILTER}`, 200, "downloads desc")

    const singles: DownloadOption[] = []
    const batches: DownloadOption[] = []
    const seen = new Set<string>()
    const wantedEpisode = query.number && query.number > 0 ? Math.trunc(query.number) : 0
    const wantedAbsolute = query.absolute && query.absolute > 0 ? Math.trunc(query.absolute) : -1

    for (const doc of docs) {
        if (isJunk(doc, media.adult)) continue
        const btih = (doc.btih || "").toLowerCase()
        if (seen.has(btih)) continue
        const title = firstStr(doc.title)
        let stripped = title
        while (SITE_PREFIX.test(stripped)) stripped = stripped.replace(SITE_PREFIX, "")
        const t = ` ${normItem(stripped)} `
        const opens = (n: string) => t.startsWith(` ${n} `)
        const fullHit = full.filter(opens).sort((a, b) => b.length - a.length)[0]
        const nameHit = names.filter(opens).sort((a, b) => b.length - a.length)[0]
        const hit = fullHit && (!nameHit || fullHit.length >= nameHit.length) ? fullHit : nameHit
        if (!hit) continue

        const namesItself = Boolean(fullHit && hit === fullHit && !bases.includes(fullHit))
        const rest = t.slice(hit.length + 2).trim()
        const restWords = rest ? rest.split(" ") : []
        const itemSeasons = seasonsIn(`${title.slice(0, title.length - stripped.length)} ${rest}`)
        const years = (title.match(YEAR_RE) || []).map((y) => Number.parseInt(y, 10))
        if (startYear > 0 && years.length > 0 && !years.some(yearFits)) continue

        if (!namesItself && ambiguous(hit)) {
            const seasonProof =
                itemSeasons.length > 0 && itemSeasons.some((s) => mediaSeasons.includes(s))
            if (!seasonProof && !(startYear > 0 && years.some(yearFits))) continue
        }

        if (media.isMovie) {
            if (itemSeasons.length > 0 && itemSeasons[0] !== 0) continue
            if (!namesItself) {
                const subtitle = normalizeLatinText(fullTitles[0] || "")
                    .split(" ")
                    .filter(
                        (w) =>
                            w.length > 2 &&
                            !hit.split(" ").includes(w) &&
                            !/^(?:the|movie|film|gekijouban)$/.test(w),
                    )
                const pool = ` ${normalizeLatinText(title)} `
                if (
                    subtitle.length > 0 &&
                    subtitle.filter((w) => pool.includes(` ${w} `)).length / subtitle.length < 0.5
                ) {
                    continue
                }
            }
        } else {
            let k = 0
            while (k < restWords.length && CONNECTORS.test(restWords[k])) k++
            if (k > 0 && k === restWords.length) continue
            let foreign = false
            for (
                let i = k;
                i < Math.min(k + 2, restWords.length) && !/\d/.test(restWords[i]);
                i++
            ) {
                if (!ALLOWED_AFTER.test(restWords[i])) foreign = true
            }
            if (foreign) continue
            if (/\b(?:movie|film|gekijouban|pelicula|final season)\b/.test(rest)) continue
            if (itemSeasons[0] !== 0) {
                if (itemSeasons.length > 0) {
                    if (!itemSeasons.some((s) => mediaSeasons.includes(s))) continue
                } else if (!namesItself && !mediaSeasons.includes(1)) {
                    continue
                }
            }
        }

        const ep = parseEpisodeFromRest(rest)
        let episode = ep.episode
        if (
            episode > 0 &&
            !ep.explicit &&
            (doc.item_size || 0) > 3.5 * 1024 * 1024 * 1024 &&
            !media.isMovie
        ) {
            episode = -1
        }
        const isBatch = !media.isMovie && episode < 0
        seen.add(btih)

        if (media.isMovie) {
            const opt = docToOption(doc, false)
            if (opt) singles.push(opt)
            continue
        }
        if (isBatch) {
            const opt = docToOption(doc, false)
            if (opt) batches.push(opt)
            continue
        }
        if (wantedEpisode > 0) {
            if (episode === wantedEpisode || (wantedAbsolute > 0 && episode === wantedAbsolute)) {
                const opt = docToOption(doc, true)
                if (opt) singles.push(opt)
            }
        } else if (!query.batch) {
            const opt = docToOption(doc, false)
            if (opt) singles.push(opt)
        }
    }

    let items: DownloadOption[]
    if (query.batch) {
        items = media.isMovie ? singles : batches
    } else if (wantedEpisode > 0 && singles.length > 0) {
        items = singles
    } else {
        items = singles.concat(batches)
    }

    const chosen = items.slice(0, limit)
    await cacheOptions(caye, "archive-org", chosen)
    return { items: chosen, state: "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    return await resolveCachedOrFallback(
        caye,
        "archive-org",
        input,
        "Unknown Archive.org option.",
        async (optionId) => {
            const id = optionId.slice("archive-org-".length)
            if (!id) throw failure("missing", "Unknown Archive.org option.")
            const meta = await fetchJson<{
                metadata?: { identifier?: string; title?: string | string[]; publicdate?: string }
                item_size?: number
                files?: { btih?: string; format?: string }[]
            }>(caye, "Archive.org", `${IA}/metadata/${encodeURIComponent(id)}`, {
                headers: { Accept: "application/json" },
                missingOn404: true,
            })
            const btih = meta.files?.find((f) => f.btih)?.btih || ""
            if (!meta.metadata?.identifier || !btih) {
                throw failure("missing", "Archive.org no longer lists this torrent.")
            }
            const opt = docToOption(
                {
                    identifier: meta.metadata.identifier,
                    title: meta.metadata.title || meta.metadata.identifier,
                    publicdate: meta.metadata.publicdate,
                    item_size: meta.item_size,
                    btih,
                },
                false,
            )
            if (!opt) throw failure("unavailable", "Archive.org returned invalid torrent metadata.")
            await setCachedJson(
                caye,
                `archive-org:option:${optionId}`,
                opt,
                OPTION_CACHE_TTL_SECONDS,
            )
            return opt
        },
        { providerId: PROVIDER_ID },
    )
}

caye.register(PROVIDER_ID, { acquisition: { find, resolve } })
