import type { API, HTTPOutput, Ref } from "../../../../packages/plugin-sdk/src/index.ts"
import { CHROME_DESKTOP } from "../../../../packages/plugin-std/src/user-agents.ts"
import {
    buildChapterList,
    createMangaSource,
    fetchJson,
    fetchText,
    makeDirectPageResolver,
    parseChapterNumber,
    type ParsedChapterInput,
    type RawPageInput,
} from "../../manga-common/src/index.ts"
import { checkResponse, failure, isChallenge } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const providerId = "backreef.mangataro:source"
const providerName = "MangaTaro"
const siteUrl = "https://mangataro.org"
const chaptersLimit = 500
const placeholders = new Set(["N/A", "—"])

type TaroSearchResponse = {
    results?: {
        id?: number | string
        slug?: string
        title?: string
        type?: string
    }[]
}

type TaroChapterEntry = {
    chapter?: string | number
    title?: string | null
    language?: string | null
    group_name?: string | null
    url?: string
}

type TaroChaptersResponse = {
    chapters?: TaroChapterEntry[]
    has_more?: boolean
}

type TaroContentResponse = {
    images?: string[]
}

function cleanText(value: string | null | undefined): string | undefined {
    const trimmed = value?.trim()
    if (!trimmed || placeholders.has(trimmed.toUpperCase())) return undefined
    return caye.html.unescape(trimmed)
}

function chapterIdFromUrl(rawUrl: string): string | undefined {
    try {
        const parsed = new URL(rawUrl, siteUrl)
        const cleaned = parsed.pathname.replace(/\/+$/, "")
        const match = cleaned.match(/([^/-]+)$/)
        return match?.[1] || undefined
    } catch {
        return undefined
    }
}

function splitNativeId(nativeId: string): { id: string; slug: string } {
    const idx = nativeId.indexOf("|")
    if (idx === -1) return { id: nativeId.trim(), slug: "" }
    return {
        id: nativeId.slice(0, idx).trim(),
        slug: nativeId.slice(idx + 1).trim(),
    }
}

function buildChapterListUrl(mangaId: string, offset: number, offsetMs: number): string {
    const now = Date.now() + offsetMs
    const epochSecond = Math.floor(now / 1000)
    const iso = new Date(now).toISOString()
    const hour = iso.slice(0, 4) + iso.slice(5, 7) + iso.slice(8, 10) + iso.slice(11, 13)
    const token = caye.crypto
        .digest("md5", `${epochSecond}mng_ch_${hour}`, { output: "hex" })
        .slice(0, 16)
    const url = new URL("/auth/manga-chapters", siteUrl)
    url.searchParams.set("manga_id", mangaId)
    url.searchParams.set("offset", String(offset))
    url.searchParams.set("limit", String(chaptersLimit))
    url.searchParams.set("order", "DESC")
    url.searchParams.set("_t", token)
    url.searchParams.set("_ts", String(epochSecond))
    return url.toString()
}

async function fetchChapterPage(
    mangaId: string,
    offset: number,
    clockSkew: { offsetMs: number },
): Promise<TaroChaptersResponse> {
    const requestPage = async (offsetMs: number): Promise<HTTPOutput> => {
        try {
            return await caye.http({
                url: buildChapterListUrl(mangaId, offset, offsetMs),
                headers: {
                    "User-Agent": CHROME_DESKTOP,
                    Accept: "application/json",
                    Referer: `${siteUrl}/`,
                },
            })
        } catch {
            throw failure("unavailable", `${providerName} is unavailable.`)
        }
    }

    let response = await requestPage(clockSkew.offsetMs)
    if (response.status === 403 && !isChallenge(response)) {
        const serverDate = Date.parse(response.headers?.["date"] ?? "")
        if (Number.isFinite(serverDate)) {
            clockSkew.offsetMs = serverDate - Date.now()
            response = await requestPage(clockSkew.offsetMs)
        }
    }

    checkResponse(providerName, response)
    let data: unknown
    try {
        data = JSON.parse(response.body ?? "")
    } catch {
        throw failure("unavailable", `${providerName} returned invalid JSON.`)
    }
    if (!data || typeof data !== "object") {
        throw failure("unavailable", `${providerName} returned unexpected chapters payload.`)
    }
    return data as TaroChaptersResponse
}

async function findPages(_context: unknown, ref: Ref): Promise<RawPageInput[]> {
    const url = new URL("/auth/chapter-content", siteUrl)
    url.searchParams.set("chapter_id", ref.nativeId)
    const { data } = await fetchJson<TaroContentResponse>(providerName, url.toString(), {
        headers: { Referer: `${siteUrl}/` },
    })
    if (!Array.isArray(data.images)) {
        throw failure("unavailable", `${providerName} returned unexpected images payload.`)
    }
    return data.images.flatMap((img) =>
        typeof img === "string" && img.trim() ? [{ url: img.trim() }] : [],
    )
}

const mangataroSource = createMangaSource({
    providerId,
    providerName,

    async search(_context, text) {
        const { data } = await fetchJson<TaroSearchResponse>(
            providerName,
            `${siteUrl}/auth/search`,
            {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Referer: `${siteUrl}/`,
                },
                body: JSON.stringify({ query: text, limit: 25 }),
            },
        )
        if (!Array.isArray(data.results)) {
            throw failure("unavailable", `${providerName} returned unexpected search payload.`)
        }
        return data.results
            .filter(
                (manga) => manga.type !== "Novel" && manga.id !== undefined && manga.title?.trim(),
            )
            .map((manga) => {
                const idPart = String(manga.id)
                const slugPart = manga.slug?.trim() ?? ""
                const nativeId =
                    slugPart && `${idPart}|${slugPart}`.length <= 200
                        ? `${idPart}|${slugPart}`
                        : idPart
                return {
                    ref: { providerId, type: "manga", nativeId },
                    name: caye.html.unescape(manga.title!.trim()),
                }
            })
    },

    async read(_context, ref) {
        const { slug } = splitNativeId(ref.nativeId)
        if (!slug) {
            throw failure("unavailable", `${providerName} slug missing for title read.`)
        }
        const { text: html } = await fetchText(
            providerName,
            `${siteUrl}/manga/${encodeURIComponent(slug)}`,
            {
                headers: { Referer: `${siteUrl}/` },
            },
        )
        const doc = caye.html.parse(html)
        const name = doc.find("h1").first().text().trim()
        if (!name) {
            throw failure("unavailable", `${providerName} title not found.`)
        }
        return { name }
    },

    async list(_context, ref) {
        const { id } = splitNativeId(ref.nativeId)
        const clockSkew = { offsetMs: 0 }
        const rawEntries: TaroChapterEntry[] = []

        let page = await fetchChapterPage(id, 0, clockSkew)
        while (page) {
            if (!Array.isArray(page.chapters)) {
                throw failure(
                    "unavailable",
                    `${providerName} returned unexpected chapters payload.`,
                )
            }
            rawEntries.push(...page.chapters)
            if (!page.has_more || page.chapters.length === 0) break
            page = await fetchChapterPage(id, rawEntries.length, clockSkew)
        }

        const parsed: ParsedChapterInput[] = []
        for (const entry of rawEntries) {
            if (!entry.url) continue
            const chapterId = chapterIdFromUrl(entry.url)
            if (!chapterId) continue
            const number = parseChapterNumber(entry.chapter)
            const title = cleanText(entry.title)
            const labelNum = entry.chapter !== undefined ? String(entry.chapter).trim() : ""
            const name = title
                ? labelNum
                    ? `Chapter ${labelNum}: ${title}`
                    : title
                : labelNum
                  ? `Chapter ${labelNum}`
                  : undefined
            const language = entry.language?.trim() || undefined
            const scanlator = cleanText(entry.group_name)
            parsed.push({
                nativeId: chapterId,
                name,
                number,
                language,
                scanlator,
            })
        }

        return buildChapterList(providerId, parsed, { reverse: true, sortByNumber: true })
    },

    findPages,

    resolveTarget: makeDirectPageResolver(() => ({ Referer: `${siteUrl}/` }), findPages),
})

caye.register(providerId, { source: mangataroSource })
