import type { API, Ref } from "../../../../packages/plugin-sdk/src/index.ts"
import { CHROME_MOBILE } from "../../../../packages/plugin-std/src/user-agents.ts"
import {
    buildChapterList,
    createMangaSource,
    fetchJson,
    fetchText,
    makeDirectPageResolver,
    parseChapterNumber,
    parseYear,
    type RawPageInput,
} from "../../manga-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"
import { resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.mangabuddy:source"
const providerName = "MangaBuddy"
const siteUrl = "https://mangak.io"
const apiBase = "https://api.mangak.io"

const apiHeaders = {
    "User-Agent": CHROME_MOBILE,
    Accept: "application/json",
    "X-Requested-With": "XMLHttpRequest",
    Referer: `${siteUrl}/`,
}

const htmlHeaders = {
    "User-Agent": CHROME_MOBILE,
    Accept: "text/html",
    Referer: `${siteUrl}/`,
}

type SearchApiResponse = {
    success?: boolean
    data?: {
        items?: {
            id?: string
            cv?: string | number
            name?: string
            release_date?: string
            year?: string | number
        }[]
    }
}

type DetailApiResponse = {
    success?: boolean
    data?: {
        title?: {
            id?: string
            name?: string
            release_date?: string
            year?: string | number
        }
    }
}

type ChaptersApiResponse = {
    success?: boolean
    data?: {
        chapters?: {
            url?: string
            name?: string
        }[]
    }
}

type NextDataPayload = {
    props?: {
        pageProps?: {
            initialChapter?: {
                images?: string[]
            }
        }
    }
}

function splitMangaId(nativeId: string): { hashId: string; cv: string } {
    const idx = nativeId.indexOf(":::")
    if (idx === -1) return { hashId: nativeId, cv: "" }
    return {
        hashId: nativeId.slice(0, idx),
        cv: nativeId.slice(idx + 3),
    }
}

async function findPages(_context: unknown, ref: Ref): Promise<RawPageInput[]> {
    const pageUrl = resolveUrl(ref.nativeId.replace(/^\/+/, ""), `${siteUrl}/`)
    const { text: html } = await fetchText(providerName, pageUrl, { headers: htmlHeaders })
    const doc = caye.html.parse(html)

    const rawImages: string[] = []
    const nextScript = doc.find("#__NEXT_DATA__").first().text().trim()
    if (nextScript) {
        try {
            const nextData = JSON.parse(nextScript) as NextDataPayload
            const images = nextData.props?.pageProps?.initialChapter?.images
            if (Array.isArray(images)) {
                for (const src of images) {
                    if (typeof src === "string" && src.trim()) {
                        rawImages.push(src.trim())
                    }
                }
            }
        } catch {}
    }

    if (rawImages.length === 0) {
        doc.find("img.w-full.h-full.object-cover").each((_, el) => {
            const src = el.attr("src") || el.attr("data-src") || ""
            const normalized = resolveUrl(src, pageUrl)
            if (normalized) rawImages.push(normalized)
        })
    }

    const seen = new Set<string>()
    const pages: RawPageInput[] = []
    for (const src of rawImages) {
        const resolved = resolveUrl(src, pageUrl)
        if (!resolved || seen.has(resolved)) continue
        seen.add(resolved)
        pages.push({ url: resolved })
    }
    return pages
}

const mangabuddySource = createMangaSource({
    providerId,
    providerName,

    async search(_context, text) {
        const url = new URL("/titles/search", apiBase)
        url.searchParams.set("page", "1")
        url.searchParams.set("limit", "25")
        url.searchParams.set("q", text)
        const { data } = await fetchJson<SearchApiResponse>(providerName, url.toString(), {
            headers: apiHeaders,
        })
        if (!data.success || !Array.isArray(data.data?.items)) {
            throw failure("unavailable", `${providerName} returned unexpected search payload`)
        }
        return data.data.items.flatMap((item) => {
            if (!item.id || !item.name?.trim()) return []
            const nativeId =
                item.cv !== undefined && item.cv !== ""
                    ? `${item.id}:::${item.cv}`
                    : String(item.id)
            const year = parseYear(item.release_date ?? item.year)
            return [
                {
                    ref: { providerId, type: "manga", nativeId },
                    name: item.name.trim(),
                    ...(year !== undefined ? { year } : {}),
                },
            ]
        })
    },

    async read(_context, ref) {
        const { hashId } = splitMangaId(ref.nativeId)
        const url = new URL(`/titles/${encodeURIComponent(hashId)}`, apiBase)
        const { data } = await fetchJson<DetailApiResponse>(providerName, url.toString(), {
            headers: apiHeaders,
        })
        const title = data.data?.title
        if (!data.success || !title?.name?.trim()) {
            throw failure("unavailable", `${providerName} title not found`)
        }
        return {
            name: title.name.trim(),
            year: parseYear(title.release_date ?? title.year),
        }
    },

    async list(_context, ref) {
        const { hashId, cv } = splitMangaId(ref.nativeId)
        const url = new URL(`/titles/${encodeURIComponent(hashId)}/chapters`, apiBase)
        if (cv) url.searchParams.set("cv", cv)
        const { data } = await fetchJson<ChaptersApiResponse>(providerName, url.toString(), {
            headers: apiHeaders,
        })
        if (!data.success || !Array.isArray(data.data?.chapters)) {
            throw failure("unavailable", `${providerName} returned unexpected chapters payload`)
        }
        const entries = data.data.chapters.flatMap((ch) => {
            const path = ch.url?.replace(/^\/+/, "").trim() ?? ""
            if (!path) return []
            const number = parseChapterNumber(ch.name) ?? parseChapterNumber(path)
            return [
                {
                    nativeId: path,
                    name: ch.name?.trim() || undefined,
                    number,
                },
            ]
        })
        return buildChapterList(providerId, entries, { reverse: true, sortByNumber: true })
    },

    findPages,

    resolveTarget: makeDirectPageResolver(
        () => ({ "User-Agent": CHROME_MOBILE, Referer: `${siteUrl}/` }),
        findPages,
    ),
})

caye.register(providerId, { source: mangabuddySource })
