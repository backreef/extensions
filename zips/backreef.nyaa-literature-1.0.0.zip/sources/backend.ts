import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DecisionObservation,
    DownloadOption,
    Value,
} from "../../../../packages/plugin-sdk/src/index"
import { failure } from "../../../../packages/provider-source/src/errors"
import {
    fact,
    magnetURI,
    parseRSS,
    type RawTorrent,
    unescapeHTML,
} from "../../nyaa/src/nyaa"

declare const caye: API

const provider = "backreef.nyaa-literature:search"
const rssEndpoint = "https://nyaa.si/"
const cacheSeconds = 7 * 24 * 60 * 60

function text(value: string): Value {
    return { kind: "text", text: value }
}

type SmartQuery = { query: string; sortBy: string }

function buildSmartQueries(query: AcquisitionQuery): SmartQuery[] {
    const textStr = query.text?.trim() || ""
    if (!textStr) return []
    const queries: SmartQuery[] = []

    if (query.number !== undefined && query.number > 0) {
        const pad = String(query.number).padStart(2, "0")
        const num = String(query.number)
        queries.push({
            query: `${textStr} (c${pad}|ch${pad}|v${pad}|vol${pad}|${pad}|${num})`,
            sortBy: "seeders",
        })
        queries.push({
            query: `${textStr} ${pad}`,
            sortBy: "seeders",
        })
    } else {
        queries.push({
            query: textStr,
            sortBy: query.batch ? "size" : "seeders",
        })
    }

    const seen = new Set<string>()
    const unique: SmartQuery[] = []
    for (const q of queries) {
        const key = `${q.query}|${q.sortBy}`
        if (!seen.has(key)) {
            seen.add(key)
            unique.push(q)
        }
        if (unique.length >= 5) break
    }
    return unique
}

function toOption(item: RawTorrent, confirmed: boolean): DownloadOption {
    const magnet = item.infoHash ? magnetURI(item.infoHash, item.name) : undefined
    const uri = magnet || item.downloadUrl || item.link
    const facts: DecisionObservation[] = []
    if (item.size > 0) {
        facts.push(fact(provider, `size-${item.id}`, "size", item.size))
    }
    if (item.seeders >= 0) {
        facts.push(fact(provider, `seeders-${item.id}`, "seeders", item.seeders))
    }
    if (item.leechers >= 0) {
        facts.push(fact(provider, `leechers-${item.id}`, "leechers", item.leechers))
    }
    if (item.downloads > 0) {
        facts.push(fact(provider, `downloads-${item.id}`, "downloads", item.downloads))
    }

    let publishedAt: string | undefined
    if (item.pubDate) {
        try {
            const d = new Date(item.pubDate)
            if (!isNaN(d.getTime())) publishedAt = d.toISOString()
        } catch {}
    }

    const opt: DownloadOption = {
        id: `nyaa-literature-${item.id}`,
        name: item.name,
        kind: "torrent",
        uri,
        files: [],
        facts,
        availability: "available",
        eligible: true,
        reasons: [],
        confirmed,
        seeders: item.seeders,
        size: item.size > 0 ? item.size : undefined,
    }
    if (publishedAt) opt.publishedAt = publishedAt
    if (item.link.startsWith("https://")) opt.pageUrl = item.link
    if (magnet) opt.magnet = magnet
    return opt
}

async function search(q: string, sortBy: string): Promise<RawTorrent[]> {
    const params = [
        "page=rss",
        `q=${encodeURIComponent(q)}`,
        "c=3_1",
        "f=0",
        `s=${encodeURIComponent(sortBy)}`,
        "o=desc",
    ].join("&")
    const response = await caye.http({
        url: `${rssEndpoint}?${params}`,
        method: "GET",
        headers: { Accept: "application/rss+xml, application/xml, text/xml" },
    })
    if (response.status !== 200 || !response.body) {
        throw failure("unavailable", `Nyaa answered ${response.status}.`)
    }
    return parseRSS(response.body)
}

async function find(_context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const textStr = query.text?.trim()
    if (!textStr) {
        throw failure("unsupported", "Enter a title to search.")
    }
    const smartQueries = buildSmartQueries(query)
    const seen = new Set<number>()
    const items: DownloadOption[] = []
    const limit = Math.min(Math.max(query.limit || 50, 1), 100)

    for (const sq of smartQueries) {
        const results = await search(sq.query, sq.sortBy)
        for (const raw of results) {
            if (seen.has(raw.id)) continue
            seen.add(raw.id)
            const opt = toOption(raw, !query.batch && query.number !== undefined)
            items.push(opt)
            await caye.cache.set({
                key: `nyaa-literature:option:${raw.id}`,
                value: text(JSON.stringify(opt)),
                ttlSeconds: cacheSeconds,
            })
            if (items.length >= limit) break
        }
        if (items.length >= limit) break
    }

    return { items, state: "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    const match = /^nyaa-literature-([1-9][0-9]*)$/.exec(input.optionId ?? "")
    if (!match) throw failure("missing", "Unknown Nyaa literature option.")
    const id = match[1]
    const cached = await caye.cache.get({
        key: `nyaa-literature:option:${id}`,
    })
    if (cached?.kind === "text") {
        try {
            return JSON.parse(cached.text) as DownloadOption
        } catch {}
    }

    const response = await caye.http({
        url: `https://nyaa.si/view/${id}`,
        method: "GET",
        headers: { Accept: "text/html" },
    })
    if (response.status === 404) {
        throw failure("missing", "Nyaa no longer lists this torrent.")
    }
    if (response.status !== 200 || !response.body) {
        throw failure("unavailable", `Nyaa answered ${response.status}.`)
    }
    const html = response.body
    const titleMatch = html.match(/<h3 class="panel-title">\s*([\s\S]*?)\s*<\/h3>/)
    const title = titleMatch ? unescapeHTML(titleMatch[1].trim()) : ""
    const magnetMatch = html.match(/href="(magnet:\?[^"]+)"/)
    const magnet = magnetMatch ? unescapeHTML(magnetMatch[1]) : undefined
    const infoHashMatch = html.match(/<kbd[^>]*>([a-fA-F0-9]{40})<\/kbd>/)
    const infoHash = infoHashMatch ? infoHashMatch[1].toLowerCase() : undefined
    const uri =
        magnet ||
        (infoHash && title ? magnetURI(infoHash, title) : `https://nyaa.si/download/${id}.torrent`)
    if (!title || !uri) {
        throw failure("unavailable", "Nyaa returned an invalid torrent page.")
    }
    const opt: DownloadOption = {
        id: `nyaa-literature-${id}`,
        name: title,
        kind: "torrent",
        uri,
        files: [],
        facts: [],
        availability: "available",
        eligible: true,
        reasons: [],
        confirmed: false,
    }
    if (magnet) opt.magnet = magnet
    opt.pageUrl = `https://nyaa.si/view/${id}`
    return opt
}

caye.register(provider, { acquisition: { find, resolve } })
