import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DownloadOption,
    OptionFile,
} from "../../../../packages/plugin-sdk/src/index"
import {
    buildMagnet,
    cacheOptions,
    clampLimit,
    connectionStringConfig,
    createTorrentOption,
    DEFAULT_TRACKERS,
    fetchJson,
    fetchText,
    mapLimit,
    normalizeInfoHash,
    OPTION_CACHE_TTL_SECONDS,
    parseIsoDate,
    parseSize,
    resolveFromRetrievalInput,
    resolveMediaContext,
} from "../../torrent-common/src/index.ts"
import { getCachedJson, setCachedJson } from "../../../../packages/plugin-std/src/cache.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const PROVIDER_ID = "backreef.seadex:search"
const DEFAULT_API_URL = "https://releases.moe/api/collections/entries/records"

type TrFile = {
    length?: number
    name?: string
    path?: string
}

type TrRecord = {
    id?: string
    created?: string
    url?: string
    infoHash?: string
    releaseGroup?: string
    tracker?: string
    files?: TrFile[]
    dualAudio?: boolean
    isBest?: boolean
}

type EntryRecord = {
    id?: string
    alID?: number
    title?: string
    expand?: {
        trs?: TrRecord[]
    }
}

type RecordsResponse = {
    items?: EntryRecord[]
}

function parseNyaaDetails(
    pageUrl: string,
    html: string,
): {
    title?: string
    magnet?: string
    torrentUrl?: string
    seeders?: number
    leechers?: number
    downloads?: number
    size?: number
} {
    const doc = caye.html.parse(html)
    const title = doc.find("h3.panel-title").first().text().trim() || undefined
    let magnet: string | undefined
    doc.find('a.card-footer-item, a[href^="magnet:"]').each((_, el) => {
        const href = el.attr("href") || ""
        if (href.startsWith("magnet:")) {
            magnet = href
            return false
        }
        return true
    })
    let torrentUrl =
        doc.find("a.card-footer-item[href*='/download/']").first().attr("href") || undefined
    if (torrentUrl && !/^https?:\/\//i.test(torrentUrl)) {
        const parsed = new URL(pageUrl)
        torrentUrl = `${parsed.protocol}//${parsed.host}${torrentUrl.startsWith("/") ? "" : "/"}${torrentUrl}`
    }
    let seeders: number | undefined
    let leechers: number | undefined
    let downloads: number | undefined
    let size: number | undefined

    doc.find(".panel-body .row div.col-md-1").each((_, el) => {
        const label = el.text().trim()
        const value = el.next().text().trim()
        if (!value) return
        if (label === "Seeders:") {
            const n = Number.parseInt(value, 10)
            if (Number.isFinite(n) && n >= 0) seeders = n
        } else if (label === "Leechers:") {
            const n = Number.parseInt(value, 10)
            if (Number.isFinite(n) && n >= 0) leechers = n
        } else if (label === "Downloads:") {
            const n = Number.parseInt(value, 10)
            if (Number.isFinite(n) && n >= 0) downloads = n
        } else if (label === "File size:") {
            const parsedSize = parseSize(value)
            if (parsedSize > 0) size = parsedSize
        }
    })
    return { title, magnet, torrentUrl, seeders, leechers, downloads, size }
}

function buildFiles(trId: string, files: TrFile[] | undefined): OptionFile[] {
    if (!Array.isArray(files)) return []
    const out: OptionFile[] = []
    for (let i = 0; i < files.length; i++) {
        const f = files[i]
        const path = (f.path || f.name || "").trim()
        if (!path) continue
        const slash = path.lastIndexOf("/")
        const name = slash >= 0 ? path.slice(slash + 1) : path
        const entry: OptionFile = {
            id: `${trId}-${i}`,
            name,
            path,
            itemIds: [],
        }
        if (typeof f.length === "number" && Number.isFinite(f.length) && f.length >= 0) {
            entry.size = Math.round(f.length)
        }
        out.push(entry)
    }
    return out
}

async function enrichTorrent(
    tr: TrRecord,
    fallbackTitle: string,
): Promise<DownloadOption | undefined> {
    if (!tr.infoHash || tr.infoHash === "<redacted>") return undefined
    if (tr.tracker !== "Nyaa" || !tr.url || !tr.url.includes("nyaa.si")) return undefined

    let infoHash = ""
    try {
        infoHash = normalizeInfoHash(tr.infoHash)
    } catch {
        return undefined
    }

    const dualAudioTag = tr.dualAudio ? " [Dual-Audio]" : ""
    const groupPrefix = tr.releaseGroup ? `[${tr.releaseGroup}] ` : ""
    let name = `${groupPrefix}${fallbackTitle}${dualAudioTag}`.trim()
    let size = Array.isArray(tr.files)
        ? tr.files.reduce(
              (sum, f) => sum + (typeof f.length === "number" && f.length > 0 ? f.length : 0),
              0,
          )
        : 0
    let seeders: number | undefined
    let leechers: number | undefined
    let downloads: number | undefined
    let torrentUrl: string | undefined
    let scrapedMagnet: string | undefined

    try {
        const res = await fetchText(caye, "Nyaa", tr.url, {
            headers: { Accept: "text/html" },
            timeoutMs: 5000,
        })
        const details = parseNyaaDetails(tr.url, res.body)
        if (details.title) name = details.title
        if (details.seeders !== undefined) seeders = details.seeders
        if (details.leechers !== undefined) leechers = details.leechers
        if (details.downloads !== undefined) downloads = details.downloads
        if (details.size && details.size > 0) size = details.size
        if (details.torrentUrl) torrentUrl = details.torrentUrl
        if (details.magnet) scrapedMagnet = details.magnet
    } catch {}

    const magnet = scrapedMagnet || buildMagnet({ infoHash, name, trackers: DEFAULT_TRACKERS })
    const key = tr.id?.trim() || infoHash
    const opt = createTorrentOption(caye, {
        id: `seadex-${key}`,
        key,
        providerId: PROVIDER_ID,
        name,
        magnet,
        torrentUrl,
        pageUrl: tr.url,
        size: size > 0 ? size : undefined,
        seeders,
        leechers,
        downloads,
        publishedAt: parseIsoDate(caye, tr.created),
        group: tr.releaseGroup?.trim() || undefined,
        best: tr.isBest !== false,
        confirmed: true,
    })
    opt.files = buildFiles(key, tr.files)
    return opt
}

async function find(context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const media = await resolveMediaContext(caye, query)
    if (!media.anilistId) {
        throw failure("unsupported", "SeaDex requires an AniList-linked anime item.")
    }
    const baseUrl = connectionStringConfig(context, "apiUrl", DEFAULT_API_URL).replace(/\/+$/, "")
    const filter = encodeURIComponent(`alID="${media.anilistId}"`)
    const url = `${baseUrl}?page=1&perPage=1&filter=${filter}&skipTotal=1&expand=trs`
    const data = await fetchJson<RecordsResponse>(caye, "SeaDex", url, {
        headers: { Accept: "application/json" },
    })

    const record = data.items?.[0]
    const trs = record?.expand?.trs ?? []
    if (trs.length === 0) {
        return { items: [], state: "complete" }
    }

    const fallbackTitle = media.romajiTitle || media.englishTitle || record?.title || "Release"
    const limit = clampLimit(query.limit, 50, 100)
    const enriched = await mapLimit(trs, 4, (tr) => enrichTorrent(tr, fallbackTitle))
    const items = enriched.filter((item): item is DownloadOption => Boolean(item)).slice(0, limit)
    await cacheOptions(caye, "seadex", items)
    return { items, state: "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    const optionId = input.optionId?.trim() || ""
    if (optionId && !/^seadex-.+$/.test(optionId)) {
        throw failure("missing", "Unknown SeaDex option.")
    }
    if (optionId) {
        const cached = await getCachedJson<DownloadOption>(caye, `seadex:option:${optionId}`)
        if (cached && cached.id === optionId) {
            if (cached.pageUrl && (!cached.magnet || !cached.magnet.includes("&tr="))) {
                try {
                    const res = await fetchText(caye, "Nyaa", cached.pageUrl, {
                        headers: { Accept: "text/html" },
                        missingOn404: true,
                    })
                    const details = parseNyaaDetails(cached.pageUrl, res.body)
                    if (details.magnet) {
                        const updated: DownloadOption = {
                            ...cached,
                            magnet: details.magnet,
                            uri:
                                details.magnet.length <= 2000
                                    ? details.magnet
                                    : details.torrentUrl || details.magnet,
                        }
                        await setCachedJson(
                            caye,
                            `seadex:option:${optionId}`,
                            updated,
                            OPTION_CACHE_TTL_SECONDS,
                        )
                        return updated
                    }
                } catch (err) {
                    const code = (err as { code?: string })?.code
                    if (code === "missing" || code === "rate-limited") throw err
                }
            }
            return cached
        }
    }
    const fallback = resolveFromRetrievalInput(
        caye,
        PROVIDER_ID,
        "seadex",
        input,
        "SeaDex option is no longer cached; search again.",
    )
    if (fallback) {
        fallback.best = true
        return fallback
    }
    throw failure("missing", "SeaDex option is no longer cached; search again.")
}

caye.register(PROVIDER_ID, { acquisition: { find, resolve } })
