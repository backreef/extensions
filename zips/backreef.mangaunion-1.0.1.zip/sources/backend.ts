import type { API, Handle, Ref } from "../../../../packages/plugin-sdk/src/index.ts"
import {
    buildChapterList,
    createMangaSource,
    fetchBase64,
    fetchJson,
    parseYear,
    type ParsedChapterInput,
    type RawPageInput,
} from "../../manga-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const providerId = "backreef.mangaunion:source"
const providerName = "MangaUnion"
const baseUrl = "https://mangaunion.com"
const apiUrl = "https://api.mangaunion.com/api/v1"

type UnionList<T> = {
    data?: T[]
    meta?: { page: number; limit: number; total: number; totalPages: number }
}

type UnionManga = {
    slug?: string
    title?: string
    year?: number | null
}

type UnionChapter = {
    number: number | string
    title?: string | null
}

type UnionReaderResponse = {
    chapter?: {
        pageCount?: number
        pages?: { url: string; n?: string; w?: number; h?: number }[]
        enc?: { alg: string; key: string } | null
    }
}

type ReaderPayload = {
    readerUrl: string
    enc: { alg: string; key: string } | null
    pages: { url: string; n?: string; w?: number; h?: number }[]
}

function mangaSlug(id: string): string {
    const slug = id
        .trim()
        .replace(/^https:\/\/mangaunion\.com\/manga\//, "")
        .replace(/\/$/, "")
    if (!/^[a-z0-9_-]+$/.test(slug)) {
        throw failure("unavailable", `${providerName} invalid manga ID.`)
    }
    return slug
}

function chapterNumberText(value: string | number): string {
    const raw = String(value)
    if (!/^\d+(?:\.\d+)?$/.test(raw) || !Number.isFinite(Number(raw))) {
        throw failure("unavailable", `${providerName} invalid chapter number.`)
    }
    return String(Number(raw))
}

function assertSafeImageUrl(url: string): string {
    if (!/^https:\/\/(?:cdn\.budgethosting\.online|api\.mangaunion\.com)\//i.test(url)) {
        throw failure("unavailable", `${providerName} unexpected image host.`)
    }
    return url
}

function chacha20Xor(bytes: Uint8Array, key: Uint8Array, nonce: Uint8Array): Uint8Array {
    if (key.length !== 32 || nonce.length !== 12) {
        throw failure("unavailable", `${providerName} invalid ChaCha20 parameters.`)
    }
    const word = (arr: Uint8Array, i: number) =>
        arr[i] | (arr[i + 1] << 8) | (arr[i + 2] << 16) | (arr[i + 3] << 24)
    const state = new Uint32Array(16)
    state.set([0x61707865, 0x3320646e, 0x79622d32, 0x6b206574])
    for (let i = 0; i < 8; i++) state[4 + i] = word(key, i * 4)
    for (let i = 0; i < 3; i++) state[13 + i] = word(nonce, i * 4)
    const output = new Uint8Array(Math.ceil(bytes.length / 4) * 4)
    output.set(bytes)
    const words = new Uint32Array(output.buffer)

    const [s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, , s13, s14, s15] = state
    let counter = 0
    for (let offset = 0; offset < bytes.length; offset += 64) {
        let x0 = s0,
            x1 = s1,
            x2 = s2,
            x3 = s3
        let x4 = s4,
            x5 = s5,
            x6 = s6,
            x7 = s7
        let x8 = s8,
            x9 = s9,
            x10 = s10,
            x11 = s11
        let x12 = counter,
            x13 = s13,
            x14 = s14,
            x15 = s15
        for (let round = 0; round < 10; round++) {
            x0 = x0 + x4
            x12 ^= x0
            x12 = (x12 << 16) | (x12 >>> 16)
            x8 = x8 + x12
            x4 ^= x8
            x4 = (x4 << 12) | (x4 >>> 20)
            x0 = x0 + x4
            x12 ^= x0
            x12 = (x12 << 8) | (x12 >>> 24)
            x8 = x8 + x12
            x4 ^= x8
            x4 = (x4 << 7) | (x4 >>> 25)
            x1 = x1 + x5
            x13 ^= x1
            x13 = (x13 << 16) | (x13 >>> 16)
            x9 = x9 + x13
            x5 ^= x9
            x5 = (x5 << 12) | (x5 >>> 20)
            x1 = x1 + x5
            x13 ^= x1
            x13 = (x13 << 8) | (x13 >>> 24)
            x9 = x9 + x13
            x5 ^= x9
            x5 = (x5 << 7) | (x5 >>> 25)
            x2 = x2 + x6
            x14 ^= x2
            x14 = (x14 << 16) | (x14 >>> 16)
            x10 = x10 + x14
            x6 ^= x10
            x6 = (x6 << 12) | (x6 >>> 20)
            x2 = x2 + x6
            x14 ^= x2
            x14 = (x14 << 8) | (x14 >>> 24)
            x10 = x10 + x14
            x6 ^= x10
            x6 = (x6 << 7) | (x6 >>> 25)
            x3 = x3 + x7
            x15 ^= x3
            x15 = (x15 << 16) | (x15 >>> 16)
            x11 = x11 + x15
            x7 ^= x11
            x7 = (x7 << 12) | (x7 >>> 20)
            x3 = x3 + x7
            x15 ^= x3
            x15 = (x15 << 8) | (x15 >>> 24)
            x11 = x11 + x15
            x7 ^= x11
            x7 = (x7 << 7) | (x7 >>> 25)
            x0 = x0 + x5
            x15 ^= x0
            x15 = (x15 << 16) | (x15 >>> 16)
            x10 = x10 + x15
            x5 ^= x10
            x5 = (x5 << 12) | (x5 >>> 20)
            x0 = x0 + x5
            x15 ^= x0
            x15 = (x15 << 8) | (x15 >>> 24)
            x10 = x10 + x15
            x5 ^= x10
            x5 = (x5 << 7) | (x5 >>> 25)
            x1 = x1 + x6
            x12 ^= x1
            x12 = (x12 << 16) | (x12 >>> 16)
            x11 = x11 + x12
            x6 ^= x11
            x6 = (x6 << 12) | (x6 >>> 20)
            x1 = x1 + x6
            x12 ^= x1
            x12 = (x12 << 8) | (x12 >>> 24)
            x11 = x11 + x12
            x6 ^= x11
            x6 = (x6 << 7) | (x6 >>> 25)
            x2 = x2 + x7
            x13 ^= x2
            x13 = (x13 << 16) | (x13 >>> 16)
            x8 = x8 + x13
            x7 ^= x8
            x7 = (x7 << 12) | (x7 >>> 20)
            x2 = x2 + x7
            x13 ^= x2
            x13 = (x13 << 8) | (x13 >>> 24)
            x8 = x8 + x13
            x7 ^= x8
            x7 = (x7 << 7) | (x7 >>> 25)
            x3 = x3 + x4
            x14 ^= x3
            x14 = (x14 << 16) | (x14 >>> 16)
            x9 = x9 + x14
            x4 ^= x9
            x4 = (x4 << 12) | (x4 >>> 20)
            x3 = x3 + x4
            x14 ^= x3
            x14 = (x14 << 8) | (x14 >>> 24)
            x9 = x9 + x14
            x4 ^= x9
            x4 = (x4 << 7) | (x4 >>> 25)
        }
        const block = offset >>> 2
        words[block + 0] ^= x0 + s0
        words[block + 1] ^= x1 + s1
        words[block + 2] ^= x2 + s2
        words[block + 3] ^= x3 + s3
        words[block + 4] ^= x4 + s4
        words[block + 5] ^= x5 + s5
        words[block + 6] ^= x6 + s6
        words[block + 7] ^= x7 + s7
        words[block + 8] ^= x8 + s8
        words[block + 9] ^= x9 + s9
        words[block + 10] ^= x10 + s10
        words[block + 11] ^= x11 + s11
        words[block + 12] ^= x12 + counter
        words[block + 13] ^= x13 + s13
        words[block + 14] ^= x14 + s14
        words[block + 15] ^= x15 + s15
        counter++
    }
    return output.subarray(0, bytes.length)
}

function detectImageMediaType(bytes: Uint8Array): string {
    const inspected = caye.image.inspect(bytes)
    if (
        inspected.format === "jpeg" ||
        inspected.format === "png" ||
        inspected.format === "webp" ||
        inspected.format === "gif"
    ) {
        return `image/${inspected.format}`
    }
    const sniffed = caye.mime.sniff(bytes)
    if (sniffed.startsWith("image/")) return sniffed
    throw failure("unavailable", `${providerName} decrypted page is not a valid image.`)
}

async function fetchReader(ref: Ref): Promise<ReaderPayload> {
    const parts = ref.nativeId.split("|")
    if (parts.length !== 2) {
        throw failure("unavailable", `${providerName} invalid chapter ID.`)
    }
    const slug = mangaSlug(parts[0])
    const num = chapterNumberText(parts[1])
    const readerUrl = `${baseUrl}/manga/${slug}/${num}`
    const { data } = await fetchJson<UnionReaderResponse>(
        providerName,
        `${apiUrl}/manga/${encodeURIComponent(slug)}/chapters/${num}`,
        { headers: { Referer: readerUrl, Origin: baseUrl } },
    )
    const chapter = data.chapter
    if (!chapter || !Array.isArray(chapter.pages) || chapter.pages.length === 0) {
        throw failure("unavailable", `${providerName} chapter has no pages.`)
    }
    if (chapter.pageCount !== undefined && chapter.pageCount !== chapter.pages.length) {
        throw failure("unavailable", `${providerName} chapter pages incomplete.`)
    }
    if (chapter.enc) {
        if (chapter.enc.alg !== "chacha20" || !chapter.enc.key || chapter.pages.some((p) => !p.n)) {
            throw failure("unavailable", `${providerName} unsupported encryption format.`)
        }
    }
    return {
        readerUrl,
        enc: chapter.enc ?? null,
        pages: chapter.pages,
    }
}

async function decryptPageHandle(reader: ReaderPayload, pageIndex: number): Promise<Handle> {
    const page = reader.pages[pageIndex]
    if (!page || !reader.enc || !page.n) {
        throw failure("unavailable", `${providerName} encrypted page not found.`)
    }
    const key = caye.encoding.base64.decode(reader.enc.key)
    const nonce = caye.encoding.base64.decode(page.n)
    const encoded = await fetchBase64(providerName, assertSafeImageUrl(page.url), {
        headers: { Referer: reader.readerUrl, Origin: baseUrl },
    })
    const encrypted = caye.encoding.base64.decode(encoded)
    const decrypted = chacha20Xor(encrypted, key, nonce)
    const mediaType = detectImageMediaType(decrypted)
    const staged = await caye.stage({
        data: caye.encoding.base64.encode(decrypted),
        mediaType,
        final: true,
    })
    if (!staged.handle) {
        throw failure("unavailable", `${providerName} failed to stage decrypted page.`)
    }
    return staged.handle
}

async function findPages(_context: unknown, ref: Ref): Promise<RawPageInput[]> {
    const reader = await fetchReader(ref)
    return reader.pages.map((page) => {
        if (!reader.enc && (!/^https:\/\//i.test(page.url) || /\.bin(?:\?|$)/i.test(page.url))) {
            throw failure("unavailable", `${providerName} invalid unencrypted page.`)
        }
        return {
            url: page.url,
            width: page.w,
            height: page.h,
            forceIndexId: true,
        }
    })
}

const mangaunionSource = createMangaSource({
    providerId,
    providerName,

    async search(_context, text) {
        const url = new URL(`${apiUrl}/manga`)
        url.searchParams.set("q", text)
        url.searchParams.set("limit", "25")
        url.searchParams.set("page", "1")
        const { data } = await fetchJson<UnionList<UnionManga>>(providerName, url.toString(), {
            headers: { Referer: `${baseUrl}/manga`, Origin: baseUrl },
        })
        if (!Array.isArray(data.data)) {
            throw failure("unavailable", `${providerName} returned unexpected search payload.`)
        }
        const seen = new Set<string>()
        return data.data.flatMap((item) => {
            if (!item.slug || !item.title?.trim() || seen.has(item.slug)) return []
            seen.add(item.slug)
            const year = parseYear(item.year)
            return [
                {
                    ref: { providerId, type: "manga", nativeId: item.slug },
                    name: item.title.trim(),
                    ...(year !== undefined ? { year } : {}),
                },
            ]
        })
    },

    async read(_context, ref) {
        const slug = mangaSlug(ref.nativeId)
        const { data } = await fetchJson<UnionManga>(
            providerName,
            `${apiUrl}/manga/${encodeURIComponent(slug)}`,
            { headers: { Referer: `${baseUrl}/manga/${slug}`, Origin: baseUrl } },
        )
        if (!data.title?.trim()) {
            throw failure("unavailable", `${providerName} title not found.`)
        }
        return {
            name: data.title.trim(),
            year: parseYear(data.year),
        }
    },

    async list(_context, ref) {
        const slug = mangaSlug(ref.nativeId)
        const mangaUrl = `${baseUrl}/manga/${slug}`
        const entries: ParsedChapterInput[] = []
        const seen = new Set<string>()

        for (let page = 1; ; page++) {
            if (page > 1000) {
                throw failure("unavailable", `${providerName} exceeded maximum chapter pages.`)
            }
            const url = new URL(`${apiUrl}/manga/${encodeURIComponent(slug)}/chapters`)
            url.searchParams.set("limit", "100")
            url.searchParams.set("page", String(page))
            url.searchParams.set("order", "asc")
            const { data } = await fetchJson<UnionList<UnionChapter>>(
                providerName,
                url.toString(),
                {
                    headers: { Referer: mangaUrl, Origin: baseUrl },
                },
            )
            if (!Array.isArray(data.data)) {
                throw failure(
                    "unavailable",
                    `${providerName} returned unexpected chapters payload.`,
                )
            }
            let added = 0
            for (const item of data.data) {
                const numStr = chapterNumberText(item.number)
                const chapterId = `${slug}|${numStr}`
                if (seen.has(chapterId)) continue
                seen.add(chapterId)
                added++
                entries.push({
                    nativeId: chapterId,
                    name: `Capitolo ${numStr}${item.title?.trim() ? ` - ${item.title.trim()}` : ""}`,
                    number: Number(numStr),
                    language: "it",
                })
            }
            const totalPages = data.meta?.totalPages
            if (!Number.isInteger(totalPages) || totalPages! < 0) {
                throw failure("unavailable", `${providerName} missing pagination metadata.`)
            }
            if (page >= totalPages!) break
            if (!added) {
                throw failure("unavailable", `${providerName} pagination stalled.`)
            }
        }

        return buildChapterList(providerId, entries, { sortByNumber: true })
    },

    findPages,

    async resolveTarget(_context, input) {
        const reader = await fetchReader(input.ref)
        const idx = input.pageId ? Number.parseInt(input.pageId, 10) - 1 : 0
        const page = reader.pages[idx]
        if (!page) return undefined
        if (reader.enc) {
            return {
                resolveHandle: () => decryptPageHandle(reader, idx),
            }
        }
        return {
            url: page.url,
            headers: { Referer: reader.readerUrl, Origin: baseUrl },
        }
    },
})

caye.register(providerId, { source: mangaunionSource })
