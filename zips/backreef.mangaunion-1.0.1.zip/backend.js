(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../manga-common/src/http.ts
  function fetchText(_0, _1) {
    return __async(this, arguments, function* (providerName2, url, options = {}) {
      var _a, _b, _c;
      const response = yield httpClient(caye, providerName2).send(__spreadProps(__spreadValues({}, options), { url, mode: "text" }));
      return {
        text: (_a = response.body) != null ? _a : "",
        url: (_b = response.url) != null ? _b : url,
        redirected: Boolean(response.redirected),
        headers: (_c = response.headers) != null ? _c : {}
      };
    });
  }
  function fetchJson(_0, _1) {
    return __async(this, arguments, function* (providerName2, url, options = {}) {
      var _a;
      const response = yield fetchText(providerName2, url, __spreadProps(__spreadValues({}, options), {
        headers: __spreadValues({ Accept: "application/json" }, (_a = options.headers) != null ? _a : {})
      }));
      let data;
      try {
        data = JSON.parse(response.text);
      } catch (e) {
        throw failure("unavailable", `${providerName2} returned invalid JSON.`);
      }
      if (!data || typeof data !== "object") {
        throw failure("unavailable", `${providerName2} returned unexpected JSON.`);
      }
      return { data, url: response.url, headers: response.headers };
    });
  }
  function fetchBase64(_0, _1) {
    return __async(this, arguments, function* (providerName2, url, options = {}) {
      return httpClient(caye, providerName2).base64(__spreadProps(__spreadValues({}, options), { url }));
    });
  }
  function fetchHandle(_0, _1) {
    return __async(this, arguments, function* (providerName2, url, headers = {}) {
      const handle = yield httpClient(caye, providerName2).handle({ url, headers });
      if (handle.mediaType.toLowerCase().startsWith("text/html")) {
        throw failure("unavailable", `${providerName2} returned HTML instead of image.`);
      }
      return handle;
    });
  }

  // ../../../packages/plugin-std/src/titles.ts
  var YEAR_PAREN_RE = /\((\d{4})\)/;
  var YEAR_STANDALONE_RE = /\b(19\d{2}|20\d{2})\b/;
  function extractYear(title) {
    const paren = title.match(YEAR_PAREN_RE);
    if (paren) {
      const year = Number.parseInt(paren[1], 10);
      if (year >= 1900 && year <= 2100) return year;
    }
    const standalone = title.match(YEAR_STANDALONE_RE);
    if (standalone) {
      return Number.parseInt(standalone[1], 10);
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../manga-common/src/manga.ts
  function parseYear(value) {
    if (typeof value === "number") {
      const year2 = Math.trunc(value);
      return Number.isInteger(year2) && year2 >= 1e3 && year2 <= 9999 ? year2 : void 0;
    }
    if (typeof value !== "string") return void 0;
    const trimmed = value.trim();
    if (!trimmed) return void 0;
    const year = extractYear(trimmed);
    return year >= 1e3 && year <= 9999 ? year : void 0;
  }
  function boundedDeadline(deadline) {
    const now = Date.now();
    const parsed = deadline ? Date.parse(deadline) : Number.NaN;
    if (Number.isFinite(parsed) && parsed > now + 1e3 && parsed <= now + 23 * 3600 * 1e3) {
      return new Date(parsed).toISOString();
    }
    return new Date(now + 3600 * 1e3).toISOString();
  }
  function paginateSearch(records, query) {
    const limit = Math.max(1, Math.min(200, query.limit || 25));
    const parsedOffset = query.cursor ? Number.parseInt(query.cursor, 10) : 0;
    const offset = Number.isFinite(parsedOffset) && parsedOffset > 0 ? parsedOffset : 0;
    const items = records.slice(offset, offset + limit);
    const nextCursor = offset + limit < records.length ? String(offset + limit) : "";
    return {
      items,
      nextCursor,
      state: "complete"
    };
  }
  function sanitizeScopePart(value) {
    return value.trim().toLowerCase().replace(/\s+/g, "-").slice(0, 80);
  }
  function addDistinctOption(seen, raw) {
    const trimmed = raw == null ? void 0 : raw.trim();
    if (!trimmed) return void 0;
    const id = sanitizeScopePart(trimmed);
    if (!id) return void 0;
    if (!seen.has(id)) {
      seen.set(id, trimmed.slice(0, 200));
    }
    return id;
  }
  function sortChaptersForReading(entries, options) {
    const list = options.reverse ? entries.slice().reverse() : entries.slice();
    if (!options.sortByNumber) {
      return list;
    }
    let lastAnchor = -1;
    let unnumberedOffset = 0;
    const keyed = list.map((item, idx) => {
      if (item.number !== void 0) {
        lastAnchor = item.number;
        unnumberedOffset = 0;
        return { item, key: item.number, sub: 0, idx };
      }
      unnumberedOffset += 1;
      return {
        item,
        key: lastAnchor >= 0 ? lastAnchor : Number.MAX_SAFE_INTEGER,
        sub: unnumberedOffset,
        idx
      };
    });
    keyed.sort((a, b) => {
      if (a.key !== b.key) return a.key - b.key;
      if (a.sub !== b.sub) return a.sub - b.sub;
      return a.idx - b.idx;
    });
    return keyed.map((entry) => entry.item);
  }
  function buildChapterList(providerId2, entries, options = {}) {
    var _a;
    const ordered = sortChaptersForReading(entries, options);
    const numberCounts = /* @__PURE__ */ new Map();
    const languages = /* @__PURE__ */ new Map();
    const scanlators = /* @__PURE__ */ new Map();
    for (const entry of ordered) {
      if (entry.number !== void 0) {
        numberCounts.set(entry.number, ((_a = numberCounts.get(entry.number)) != null ? _a : 0) + 1);
      }
      addDistinctOption(languages, entry.language);
      addDistinctOption(scanlators, entry.scanlator);
    }
    const hasDuplicates = Array.from(numberCounts.values()).some((count) => count > 1);
    const multiLanguage = languages.size > 1;
    const multiScanlator = scanlators.size > 1;
    const needsScope = hasDuplicates && (multiLanguage || multiScanlator);
    const groups = [];
    if (needsScope && multiLanguage) {
      groups.push({
        id: "language",
        label: "Language",
        options: Array.from(languages.entries()).slice(0, 200).map(([id, label]) => ({ id, label }))
      });
    }
    if (needsScope && multiScanlator) {
      groups.push({
        id: "scanlator",
        label: "Scanlator",
        options: Array.from(scanlators.entries()).slice(0, 200).map(([id, label]) => ({ id, label }))
      });
    }
    const choices = groups.length > 0 ? { groups: groups.slice(0, 8) } : {};
    const seenKeys = /* @__PURE__ */ new Set();
    const installments = [];
    for (const entry of ordered) {
      const nativeId = entry.nativeId.trim();
      if (!nativeId) continue;
      if (nativeId.length > 200) {
        throw failure("unavailable", "Chapter ID is too long.");
      }
      const langId = entry.language ? sanitizeScopePart(entry.language) : "";
      const scanId = entry.scanlator ? sanitizeScopePart(entry.scanlator) : "";
      let scope;
      if (needsScope) {
        const parts = [];
        if (multiLanguage && langId) parts.push(langId);
        if (multiScanlator && scanId) parts.push(scanId);
        if (parts.length > 0) scope = parts.join(":").slice(0, 200);
      }
      const dedupeKey = `${nativeId}\0${scope != null ? scope : ""}`;
      if (seenKeys.has(dedupeKey)) continue;
      seenKeys.add(dedupeKey);
      const installment = __spreadValues(__spreadValues(__spreadValues({
        ref: __spreadValues({
          providerId: providerId2,
          type: "chapter",
          nativeId
        }, scope ? { scope } : {}),
        number: entry.number
      }, entry.name ? { name: entry.name.trim().slice(0, 500) } : {}), entry.language ? { language: entry.language.trim().slice(0, 35) } : {}), entry.scanlator ? { scanlator: entry.scanlator.trim().slice(0, 200) } : {});
      if (entry.number === void 0) {
        delete installment.number;
      }
      installments.push(installment);
    }
    return { installments, choices };
  }
  function buildSourcePage(context, rawPages) {
    const seenIds = /* @__PURE__ */ new Set();
    const pages = rawPages.slice(0, 5e3).map((page, index) => {
      var _a;
      const candidateId = !page.forceIndexId && page.url.length > 0 && page.url.length <= 200 ? page.url : String(index + 1);
      const id = !seenIds.has(candidateId) ? candidateId : String(index + 1);
      seenIds.add(id);
      const name = (((_a = page.name) == null ? void 0 : _a.trim()) || `Page ${index + 1}`).slice(0, 200);
      return __spreadValues(__spreadValues({
        id,
        name
      }, typeof page.width === "number" && Number.isInteger(page.width) && page.width > 0 ? { width: page.width } : {}), typeof page.height === "number" && Number.isInteger(page.height) && page.height > 0 ? { height: page.height } : {});
    });
    return {
      items: [
        {
          id: "pages",
          capabilities: ["pages"],
          origin: "pages",
          expiresAt: boundedDeadline(context.deadline),
          tracks: [],
          ranges: [],
          pages
        }
      ],
      state: "complete"
    };
  }
  function resolvePageSource(providerName2, input, target) {
    return __async(this, null, function* () {
      if (!target) {
        throw failure("unavailable", `${providerName2} page not found.`);
      }
      const handle = "resolveHandle" in target ? yield target.resolveHandle() : yield fetchHandle(providerName2, target.url, target.headers);
      return {
        id: input.sourceId,
        capabilities: ["pages"],
        origin: "pages",
        expiresAt: handle.expiresAt,
        tracks: [],
        ranges: [],
        handle
      };
    });
  }
  function createMangaSource(adapter) {
    return {
      search(context, query) {
        return __async(this, null, function* () {
          var _a2;
          const text = ((_a2 = query.q) != null ? _a2 : "").trim();
          if (!text) {
            return { items: [], nextCursor: "", state: "complete" };
          }
          const records = yield adapter.search(context, text, query);
          return paginateSearch(records, query);
        });
      },
      read(context, ref) {
        return __async(this, null, function* () {
          var _a2, _b;
          if (!((_a2 = ref == null ? void 0 : ref.nativeId) == null ? void 0 : _a2.trim())) {
            throw failure("unavailable", `${adapter.providerName} record ID is required.`);
          }
          const info = yield adapter.read(context, ref);
          if (!((_b = info.name) == null ? void 0 : _b.trim())) {
            throw failure("unavailable", `${adapter.providerName} record title is missing.`);
          }
          return __spreadValues({
            ref,
            name: info.name.trim()
          }, info.year !== void 0 ? { year: info.year } : {});
        });
      },
      list(context, ref) {
        return __async(this, null, function* () {
          var _a2;
          if (!((_a2 = ref == null ? void 0 : ref.nativeId) == null ? void 0 : _a2.trim())) {
            throw failure("unavailable", `${adapter.providerName} record ID is required.`);
          }
          return adapter.list(context, ref);
        });
      },
      find(context, ref) {
        return __async(this, null, function* () {
          var _a2;
          if (!((_a2 = ref == null ? void 0 : ref.nativeId) == null ? void 0 : _a2.trim())) {
            throw failure("unavailable", `${adapter.providerName} chapter ID is required.`);
          }
          const pages = yield adapter.findPages(context, ref);
          if (pages.length === 0) {
            throw failure("unavailable", `${adapter.providerName} returned no chapter pages.`);
          }
          return buildSourcePage(context, pages);
        });
      },
      resolve(context, input) {
        return __async(this, null, function* () {
          var _a2, _b;
          if (!((_b = (_a2 = input == null ? void 0 : input.ref) == null ? void 0 : _a2.nativeId) == null ? void 0 : _b.trim())) {
            throw failure("unavailable", `${adapter.providerName} chapter ID is required.`);
          }
          const target = yield adapter.resolveTarget(context, input);
          return resolvePageSource(adapter.providerName, input, target);
        });
      }
    };
  }

  // src/backend.ts
  var providerId = "backreef.mangaunion:source";
  var providerName = "MangaUnion";
  var baseUrl = "https://mangaunion.com";
  var apiUrl = "https://api.mangaunion.com/api/v1";
  function mangaSlug(id) {
    const slug = id.trim().replace(/^https:\/\/mangaunion\.com\/manga\//, "").replace(/\/$/, "");
    if (!/^[a-z0-9_-]+$/.test(slug)) {
      throw failure("unavailable", `${providerName} invalid manga ID.`);
    }
    return slug;
  }
  function chapterNumberText(value) {
    const raw = String(value);
    if (!/^\d+(?:\.\d+)?$/.test(raw) || !Number.isFinite(Number(raw))) {
      throw failure("unavailable", `${providerName} invalid chapter number.`);
    }
    return String(Number(raw));
  }
  function assertSafeImageUrl(url) {
    if (!/^https:\/\/(?:cdn\.budgethosting\.online|api\.mangaunion\.com)\//i.test(url)) {
      throw failure("unavailable", `${providerName} unexpected image host.`);
    }
    return url;
  }
  function chacha20Xor(bytes, key, nonce) {
    if (key.length !== 32 || nonce.length !== 12) {
      throw failure("unavailable", `${providerName} invalid ChaCha20 parameters.`);
    }
    const word = (arr, i) => arr[i] | arr[i + 1] << 8 | arr[i + 2] << 16 | arr[i + 3] << 24;
    const state = new Uint32Array(16);
    state.set([1634760805, 857760878, 2036477234, 1797285236]);
    for (let i = 0; i < 8; i++) state[4 + i] = word(key, i * 4);
    for (let i = 0; i < 3; i++) state[13 + i] = word(nonce, i * 4);
    const output = new Uint8Array(Math.ceil(bytes.length / 4) * 4);
    output.set(bytes);
    const words = new Uint32Array(output.buffer);
    const [s0, s1, s2, s3, s4, s5, s6, s7, s8, s9, s10, s11, , s13, s14, s15] = state;
    let counter = 0;
    for (let offset = 0; offset < bytes.length; offset += 64) {
      let x0 = s0, x1 = s1, x2 = s2, x3 = s3;
      let x4 = s4, x5 = s5, x6 = s6, x7 = s7;
      let x8 = s8, x9 = s9, x10 = s10, x11 = s11;
      let x12 = counter, x13 = s13, x14 = s14, x15 = s15;
      for (let round = 0; round < 10; round++) {
        x0 = x0 + x4;
        x12 ^= x0;
        x12 = x12 << 16 | x12 >>> 16;
        x8 = x8 + x12;
        x4 ^= x8;
        x4 = x4 << 12 | x4 >>> 20;
        x0 = x0 + x4;
        x12 ^= x0;
        x12 = x12 << 8 | x12 >>> 24;
        x8 = x8 + x12;
        x4 ^= x8;
        x4 = x4 << 7 | x4 >>> 25;
        x1 = x1 + x5;
        x13 ^= x1;
        x13 = x13 << 16 | x13 >>> 16;
        x9 = x9 + x13;
        x5 ^= x9;
        x5 = x5 << 12 | x5 >>> 20;
        x1 = x1 + x5;
        x13 ^= x1;
        x13 = x13 << 8 | x13 >>> 24;
        x9 = x9 + x13;
        x5 ^= x9;
        x5 = x5 << 7 | x5 >>> 25;
        x2 = x2 + x6;
        x14 ^= x2;
        x14 = x14 << 16 | x14 >>> 16;
        x10 = x10 + x14;
        x6 ^= x10;
        x6 = x6 << 12 | x6 >>> 20;
        x2 = x2 + x6;
        x14 ^= x2;
        x14 = x14 << 8 | x14 >>> 24;
        x10 = x10 + x14;
        x6 ^= x10;
        x6 = x6 << 7 | x6 >>> 25;
        x3 = x3 + x7;
        x15 ^= x3;
        x15 = x15 << 16 | x15 >>> 16;
        x11 = x11 + x15;
        x7 ^= x11;
        x7 = x7 << 12 | x7 >>> 20;
        x3 = x3 + x7;
        x15 ^= x3;
        x15 = x15 << 8 | x15 >>> 24;
        x11 = x11 + x15;
        x7 ^= x11;
        x7 = x7 << 7 | x7 >>> 25;
        x0 = x0 + x5;
        x15 ^= x0;
        x15 = x15 << 16 | x15 >>> 16;
        x10 = x10 + x15;
        x5 ^= x10;
        x5 = x5 << 12 | x5 >>> 20;
        x0 = x0 + x5;
        x15 ^= x0;
        x15 = x15 << 8 | x15 >>> 24;
        x10 = x10 + x15;
        x5 ^= x10;
        x5 = x5 << 7 | x5 >>> 25;
        x1 = x1 + x6;
        x12 ^= x1;
        x12 = x12 << 16 | x12 >>> 16;
        x11 = x11 + x12;
        x6 ^= x11;
        x6 = x6 << 12 | x6 >>> 20;
        x1 = x1 + x6;
        x12 ^= x1;
        x12 = x12 << 8 | x12 >>> 24;
        x11 = x11 + x12;
        x6 ^= x11;
        x6 = x6 << 7 | x6 >>> 25;
        x2 = x2 + x7;
        x13 ^= x2;
        x13 = x13 << 16 | x13 >>> 16;
        x8 = x8 + x13;
        x7 ^= x8;
        x7 = x7 << 12 | x7 >>> 20;
        x2 = x2 + x7;
        x13 ^= x2;
        x13 = x13 << 8 | x13 >>> 24;
        x8 = x8 + x13;
        x7 ^= x8;
        x7 = x7 << 7 | x7 >>> 25;
        x3 = x3 + x4;
        x14 ^= x3;
        x14 = x14 << 16 | x14 >>> 16;
        x9 = x9 + x14;
        x4 ^= x9;
        x4 = x4 << 12 | x4 >>> 20;
        x3 = x3 + x4;
        x14 ^= x3;
        x14 = x14 << 8 | x14 >>> 24;
        x9 = x9 + x14;
        x4 ^= x9;
        x4 = x4 << 7 | x4 >>> 25;
      }
      const block = offset >>> 2;
      words[block + 0] ^= x0 + s0;
      words[block + 1] ^= x1 + s1;
      words[block + 2] ^= x2 + s2;
      words[block + 3] ^= x3 + s3;
      words[block + 4] ^= x4 + s4;
      words[block + 5] ^= x5 + s5;
      words[block + 6] ^= x6 + s6;
      words[block + 7] ^= x7 + s7;
      words[block + 8] ^= x8 + s8;
      words[block + 9] ^= x9 + s9;
      words[block + 10] ^= x10 + s10;
      words[block + 11] ^= x11 + s11;
      words[block + 12] ^= x12 + counter;
      words[block + 13] ^= x13 + s13;
      words[block + 14] ^= x14 + s14;
      words[block + 15] ^= x15 + s15;
      counter++;
    }
    return output.subarray(0, bytes.length);
  }
  function detectImageMediaType(bytes) {
    const inspected = caye.image.inspect(bytes);
    if (inspected.format === "jpeg" || inspected.format === "png" || inspected.format === "webp" || inspected.format === "gif") {
      return `image/${inspected.format}`;
    }
    const sniffed = caye.mime.sniff(bytes);
    if (sniffed.startsWith("image/")) return sniffed;
    throw failure("unavailable", `${providerName} decrypted page is not a valid image.`);
  }
  function fetchReader(ref) {
    return __async(this, null, function* () {
      var _a;
      const parts = ref.nativeId.split("|");
      if (parts.length !== 2) {
        throw failure("unavailable", `${providerName} invalid chapter ID.`);
      }
      const slug = mangaSlug(parts[0]);
      const num = chapterNumberText(parts[1]);
      const readerUrl = `${baseUrl}/manga/${slug}/${num}`;
      const { data } = yield fetchJson(
        providerName,
        `${apiUrl}/manga/${encodeURIComponent(slug)}/chapters/${num}`,
        { headers: { Referer: readerUrl, Origin: baseUrl } }
      );
      const chapter = data.chapter;
      if (!chapter || !Array.isArray(chapter.pages) || chapter.pages.length === 0) {
        throw failure("unavailable", `${providerName} chapter has no pages.`);
      }
      if (chapter.pageCount !== void 0 && chapter.pageCount !== chapter.pages.length) {
        throw failure("unavailable", `${providerName} chapter pages incomplete.`);
      }
      if (chapter.enc) {
        if (chapter.enc.alg !== "chacha20" || !chapter.enc.key || chapter.pages.some((p) => !p.n)) {
          throw failure("unavailable", `${providerName} unsupported encryption format.`);
        }
      }
      return {
        readerUrl,
        enc: (_a = chapter.enc) != null ? _a : null,
        pages: chapter.pages
      };
    });
  }
  function decryptPageHandle(reader, pageIndex) {
    return __async(this, null, function* () {
      const page = reader.pages[pageIndex];
      if (!page || !reader.enc || !page.n) {
        throw failure("unavailable", `${providerName} encrypted page not found.`);
      }
      const key = caye.encoding.base64.decode(reader.enc.key);
      const nonce = caye.encoding.base64.decode(page.n);
      const encoded = yield fetchBase64(providerName, assertSafeImageUrl(page.url), {
        headers: { Referer: reader.readerUrl, Origin: baseUrl }
      });
      const encrypted = caye.encoding.base64.decode(encoded);
      const decrypted = chacha20Xor(encrypted, key, nonce);
      const mediaType = detectImageMediaType(decrypted);
      const staged = yield caye.stage({
        data: caye.encoding.base64.encode(decrypted),
        mediaType,
        final: true
      });
      if (!staged.handle) {
        throw failure("unavailable", `${providerName} failed to stage decrypted page.`);
      }
      return staged.handle;
    });
  }
  function findPages(_context, ref) {
    return __async(this, null, function* () {
      const reader = yield fetchReader(ref);
      return reader.pages.map((page) => {
        if (!reader.enc && (!/^https:\/\//i.test(page.url) || /\.bin(?:\?|$)/i.test(page.url))) {
          throw failure("unavailable", `${providerName} invalid unencrypted page.`);
        }
        return {
          url: page.url,
          width: page.w,
          height: page.h,
          forceIndexId: true
        };
      });
    });
  }
  var mangaunionSource = createMangaSource({
    providerId,
    providerName,
    search(_context, text) {
      return __async(this, null, function* () {
        const url = new URL(`${apiUrl}/manga`);
        url.searchParams.set("q", text);
        url.searchParams.set("limit", "25");
        url.searchParams.set("page", "1");
        const { data } = yield fetchJson(providerName, url.toString(), {
          headers: { Referer: `${baseUrl}/manga`, Origin: baseUrl }
        });
        if (!Array.isArray(data.data)) {
          throw failure("unavailable", `${providerName} returned unexpected search payload.`);
        }
        const seen = /* @__PURE__ */ new Set();
        return data.data.flatMap((item) => {
          var _a;
          if (!item.slug || !((_a = item.title) == null ? void 0 : _a.trim()) || seen.has(item.slug)) return [];
          seen.add(item.slug);
          const year = parseYear(item.year);
          return [
            __spreadValues({
              ref: { providerId, type: "manga", nativeId: item.slug },
              name: item.title.trim()
            }, year !== void 0 ? { year } : {})
          ];
        });
      });
    },
    read(_context, ref) {
      return __async(this, null, function* () {
        var _a;
        const slug = mangaSlug(ref.nativeId);
        const { data } = yield fetchJson(
          providerName,
          `${apiUrl}/manga/${encodeURIComponent(slug)}`,
          { headers: { Referer: `${baseUrl}/manga/${slug}`, Origin: baseUrl } }
        );
        if (!((_a = data.title) == null ? void 0 : _a.trim())) {
          throw failure("unavailable", `${providerName} title not found.`);
        }
        return {
          name: data.title.trim(),
          year: parseYear(data.year)
        };
      });
    },
    list(_context, ref) {
      return __async(this, null, function* () {
        var _a, _b;
        const slug = mangaSlug(ref.nativeId);
        const mangaUrl = `${baseUrl}/manga/${slug}`;
        const entries = [];
        const seen = /* @__PURE__ */ new Set();
        for (let page = 1; ; page++) {
          if (page > 1e3) {
            throw failure("unavailable", `${providerName} exceeded maximum chapter pages.`);
          }
          const url = new URL(`${apiUrl}/manga/${encodeURIComponent(slug)}/chapters`);
          url.searchParams.set("limit", "100");
          url.searchParams.set("page", String(page));
          url.searchParams.set("order", "asc");
          const { data } = yield fetchJson(
            providerName,
            url.toString(),
            {
              headers: { Referer: mangaUrl, Origin: baseUrl }
            }
          );
          if (!Array.isArray(data.data)) {
            throw failure(
              "unavailable",
              `${providerName} returned unexpected chapters payload.`
            );
          }
          let added = 0;
          for (const item of data.data) {
            const numStr = chapterNumberText(item.number);
            const chapterId = `${slug}|${numStr}`;
            if (seen.has(chapterId)) continue;
            seen.add(chapterId);
            added++;
            entries.push({
              nativeId: chapterId,
              name: `Capitolo ${numStr}${((_a = item.title) == null ? void 0 : _a.trim()) ? ` - ${item.title.trim()}` : ""}`,
              number: Number(numStr),
              language: "it"
            });
          }
          const totalPages = (_b = data.meta) == null ? void 0 : _b.totalPages;
          if (!Number.isInteger(totalPages) || totalPages < 0) {
            throw failure("unavailable", `${providerName} missing pagination metadata.`);
          }
          if (page >= totalPages) break;
          if (!added) {
            throw failure("unavailable", `${providerName} pagination stalled.`);
          }
        }
        return buildChapterList(providerId, entries, { sortByNumber: true });
      });
    },
    findPages,
    resolveTarget(_context, input) {
      return __async(this, null, function* () {
        const reader = yield fetchReader(input.ref);
        const idx = input.pageId ? Number.parseInt(input.pageId, 10) - 1 : 0;
        const page = reader.pages[idx];
        if (!page) return void 0;
        if (reader.enc) {
          return {
            resolveHandle: () => decryptPageHandle(reader, idx)
          };
        }
        return {
          url: page.url,
          headers: { Referer: reader.readerUrl, Origin: baseUrl }
        };
      });
    }
  });
  caye.register(providerId, { source: mangaunionSource });
})();
//# sourceMappingURL=backend.js.map
