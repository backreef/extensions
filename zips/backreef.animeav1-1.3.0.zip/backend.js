(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/titles.ts
  var YEAR_PAREN_RE = /\((\d{4})\)/;
  var YEAR_STANDALONE_RE = /\b(19\d{2}|20\d{2})\b/;
  function extractYear(title) {
    const paren = title.match(YEAR_PAREN_RE);
    if (paren) {
      const year = Number.parseInt(paren[1], 10);
      if (year >= 1900 && year <= 2100) return year;
    }
    const standalone = title.match(YEAR_STANDALONE_RE);
    if (standalone) {
      return Number.parseInt(standalone[1], 10);
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../../../packages/plugin-std/src/url.ts
  function resolveUrl(raw, base) {
    const trimmed = raw.trim();
    if (!trimmed) return "";
    try {
      const url = new URL(trimmed.startsWith("//") ? `https:${trimmed}` : trimmed, base);
      return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : "";
    } catch (e) {
      return "";
    }
  }
  function cleanBaseUrl(raw, fallback) {
    const resolved = resolveUrl(raw != null ? raw : "");
    if (!resolved) return fallback;
    const url = new URL(resolved);
    return url.origin + url.pathname.replace(/\/+$/, "");
  }

  // ../stream-common/src/common.ts
  function streamOriginOf(url, hint) {
    const lowerUrl = url.toLowerCase();
    const lowerHint = (hint != null ? hint : "").toLowerCase();
    if (lowerHint === "hls" || lowerHint === "m3u8" || /\.m3u8(\?|$|#)/.test(lowerUrl)) {
      return "hls";
    }
    return "http";
  }
  function choiceId(label, fallback = "default") {
    const slug = label.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64);
    return slug || fallback;
  }
  function videoRef(providerId2, nativeId) {
    return {
      providerId: providerId2,
      type: "video",
      nativeId
    };
  }
  function sameRef(ref) {
    return ref.scope ? {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId,
      scope: ref.scope
    } : {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId
    };
  }
  function limitItems(items, limit) {
    if (typeof limit === "number" && Number.isFinite(limit) && limit > 0) {
      return items.slice(0, limit);
    }
    return items;
  }
  function futureDeadline(contextDeadline, minutes = 10) {
    const now = Date.now();
    if (contextDeadline) {
      const parsed = Date.parse(contextDeadline);
      if (Number.isFinite(parsed) && parsed > now + 5e3 && parsed <= now + 24 * 3600 * 1e3) {
        return contextDeadline;
      }
    }
    return new Date(now + minutes * 60 * 1e3).toISOString();
  }
  function parseEpisodeNumber(raw) {
    if (typeof raw === "number") {
      return Number.isFinite(raw) && raw >= 0 ? raw : void 0;
    }
    if (typeof raw !== "string") return void 0;
    const cleaned = raw.trim().replace(",", ".");
    if (!cleaned) return void 0;
    const match = /\d+(?:\.\d+)?/.exec(cleaned);
    if (!match) return void 0;
    const num = Number(match[0]);
    return Number.isFinite(num) && num >= 0 ? num : void 0;
  }
  function extractFirstYear(text) {
    const year = extractYear(text != null ? text : "");
    return year > 0 ? year : void 0;
  }

  // ../../../packages/plugin-std/src/unpack.ts
  var PACKER_RE = /eval\(function\(p,a,c,k,e,[dr]\)\{[\s\S]*?\}\s*\(\s*(['"])((?:\\.|(?!\1)[\s\S])*)\1\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(['"])((?:\\.|(?!\5)[\s\S])*)\5\.split\((['"])\|\7\)(?:\s*,\s*\d+\s*,\s*\{\s*\})?\s*\)\)/;
  function unescapeJsString(raw) {
    let out = "";
    for (let i = 0; i < raw.length; i++) {
      const ch = raw[i];
      if (ch !== "\\" || i + 1 >= raw.length) {
        out += ch;
        continue;
      }
      const next = raw[i + 1];
      if (next === "x" && i + 3 < raw.length) {
        const hex = raw.slice(i + 2, i + 4);
        if (/^[0-9a-fA-F]{2}$/.test(hex)) {
          out += String.fromCharCode(Number.parseInt(hex, 16));
          i += 3;
          continue;
        }
      }
      if (next === "u" && i + 5 < raw.length) {
        const hex = raw.slice(i + 2, i + 6);
        if (/^[0-9a-fA-F]{4}$/.test(hex)) {
          out += String.fromCharCode(Number.parseInt(hex, 16));
          i += 5;
          continue;
        }
      }
      switch (next) {
        case "n":
          out += "\n";
          break;
        case "r":
          out += "\r";
          break;
        case "t":
          out += "	";
          break;
        case "\\":
          out += "\\";
          break;
        case "'":
          out += "'";
          break;
        case '"':
          out += '"';
          break;
        default:
          out += next;
          break;
      }
      i += 1;
    }
    return out;
  }
  function encodeBase(value, base) {
    const prefix = value < base ? "" : encodeBase(Math.floor(value / base), base);
    const rem = value % base;
    if (rem > 35) {
      return prefix + String.fromCharCode(rem + 29);
    }
    return prefix + rem.toString(36);
  }
  function isPacked(code) {
    return PACKER_RE.test(code);
  }
  function unpack(code) {
    const match = code.match(PACKER_RE);
    if (!match) return code;
    const payload = unescapeJsString(match[2]);
    const base = Number.parseInt(match[3], 10);
    const count = Number.parseInt(match[4], 10);
    const symtab = unescapeJsString(match[6]).split("|");
    if (!Number.isFinite(base) || base < 2 || base > 62 || symtab.length === 0) {
      return code;
    }
    const dict = /* @__PURE__ */ new Map();
    const limit = Math.min(count, symtab.length);
    for (let i = 0; i < limit; i++) {
      const key = encodeBase(i, base);
      const replacement = symtab[i];
      dict.set(key, replacement || key);
    }
    const unpacked = payload.replace(/\b[0-9A-Za-z]+\b/g, (word) => {
      var _a;
      return (_a = dict.get(word)) != null ? _a : word;
    });
    return code.slice(0, match.index) + unpacked + code.slice(match.index + match[0].length);
  }
  function unpackAll(code) {
    let current = code;
    for (let i = 0; i < 32; i++) {
      if (!isPacked(current)) break;
      const next = unpack(current);
      if (next === current) break;
      current = next;
    }
    return current;
  }

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../stream-common/src/extractors.ts
  var VOE_MARKERS = ["@$", "^^", "~@", "%?", "*~", "!!", "#&"];
  function unpackVoe(api, packed) {
    let text = packed.replace(/[a-zA-Z]/g, (c) => {
      const base = c <= "Z" ? 65 : 97;
      return String.fromCharCode((c.charCodeAt(0) - base + 13) % 26 + base);
    });
    for (const marker of VOE_MARKERS) {
      text = text.split(marker).join("");
    }
    const shifted = api.encoding.latin1.decode(api.encoding.base64.decode(text));
    let reversed = "";
    for (let i = shifted.length - 1; i >= 0; i--) {
      reversed += String.fromCharCode(shifted.charCodeAt(i) - 3);
    }
    return api.encoding.utf8.decode(api.encoding.base64.decode(reversed));
  }
  function voeStreamsFromHtml(api, html) {
    const doc = api.html.parse(html);
    const blob = doc.find('script[type="application/json"]').first().text().trim();
    if (!blob) return [];
    try {
      const packed = JSON.parse(blob);
      const first = Array.isArray(packed) ? packed[0] : packed;
      if (typeof first !== "string") return [];
      const info = JSON.parse(unpackVoe(api, first));
      if (info.source) return [{ url: info.source, hint: "hls" }];
      if (info.direct_access_url) return [{ url: info.direct_access_url, hint: "mp4" }];
    } catch (e) {
    }
    return [];
  }
  function extractVoe(api, embedUrl, providerName2) {
    return __async(this, null, function* () {
      const site2 = httpClient(api, providerName2);
      let html = yield site2.text(embedUrl);
      const hasJsonScript = api.html.parse(html).find('script[type="application/json"]').length > 0;
      if (!hasJsonScript) {
        const hop = /window\.location\.href\s*=\s*['"](https?:\/\/[^'"]+)['"]/.exec(html);
        if (hop) {
          html = yield site2.text(hop[1]);
        }
      }
      return voeStreamsFromHtml(api, html);
    });
  }
  function extractMp4Upload(api, embedUrl, referer, providerName2) {
    return __async(this, null, function* () {
      const html = yield httpClient(api, providerName2).text({
        url: embedUrl,
        headers: { Referer: referer }
      });
      const doc = api.html.parse(html);
      let foundUrl = "";
      const matchIn = (body) => {
        var _a;
        const m = (_a = /src:\s*"([^"]+\.mp4[^"]*)"/i.exec(body)) != null ? _a : /"src"\s*:\s*"([^"]+\.mp4[^"]*)"/i.exec(body);
        return m ? m[1].replace(/\\\//g, "/") : "";
      };
      doc.find("script").each((_i, el) => {
        if (foundUrl) return;
        foundUrl = matchIn(unpackAll(el.text()));
      });
      if (!foundUrl) foundUrl = matchIn(html);
      const resolved = foundUrl ? resolveUrl(foundUrl, embedUrl) : "";
      return resolved ? [{ url: resolved, headers: { Referer: "https://www.mp4upload.com/" }, hint: "mp4" }] : [];
    });
  }

  // src/backend.ts
  var providerId = "backreef.animeav1:source";
  var providerName = "AnimeAV1";
  var site = httpClient(caye, providerName);
  var defaultBaseUrl = "https://animeav1.com";
  var UPNSHARE_KEY = "kiemtienmua911ca";
  var UPNSHARE_IV = "1234567890oiuytr";
  var BYSE_FALLBACK_EDGE = "https://edge1-frankfurt-sprintcdn.owphbf24.com";
  function siteBase(context) {
    var _a;
    return cleanBaseUrl((_a = context == null ? void 0 : context.config) == null ? void 0 : _a.url, defaultBaseUrl);
  }
  function siteHeaders(base) {
    return {
      Accept: "*/*",
      "Accept-Language": "es-ES,es;q=0.9",
      Referer: `${base}/`,
      "Sec-Fetch-Site": "same-origin",
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Dest": "empty"
    };
  }
  function resolveCatalogResults(payload, base) {
    var _a, _b;
    const out = [];
    for (const node of (_a = payload.nodes) != null ? _a : []) {
      if (!((_b = node == null ? void 0 : node.uses) == null ? void 0 : _b.search_params) || !Array.isArray(node.data) || node.data.length === 0)
        continue;
      const data = node.data;
      const root = data[0];
      if (!root || typeof root.results !== "number") continue;
      const ptrs = data[root.results];
      if (!Array.isArray(ptrs)) continue;
      for (const ptr of ptrs) {
        if (typeof ptr !== "number") continue;
        const raw = data[ptr];
        if (!raw) continue;
        const title = typeof raw.title === "number" ? data[raw.title] : void 0;
        const slug = typeof raw.slug === "number" ? data[raw.slug] : void 0;
        if (typeof title !== "string" || typeof slug !== "string") continue;
        const dateVal = typeof raw.startDate === "number" ? data[raw.startDate] : void 0;
        const year = extractFirstYear(typeof dateVal === "string" ? dateVal : void 0);
        out.push(__spreadValues({ slug, title }, year !== void 0 ? { year } : {}));
      }
      return out;
    }
    return out;
  }
  function findMediaNode(payload, slug) {
    var _a;
    for (const node of (_a = payload.nodes) != null ? _a : []) {
      if (!Array.isArray(node == null ? void 0 : node.data)) continue;
      for (const obj of node.data) {
        if (!obj || typeof obj !== "object") continue;
        const rec = obj;
        if ("slug" in rec && "episodes" in rec && typeof rec.slug === "number" && node.data[rec.slug] === slug) {
          return { data: node.data, descriptor: rec };
        }
      }
    }
    return void 0;
  }
  function findEmbedsNode(payload) {
    var _a;
    for (const node of (_a = payload.nodes) != null ? _a : []) {
      if (!Array.isArray(node == null ? void 0 : node.data)) continue;
      const root = node.data.find(
        (item) => Boolean(item) && typeof item === "object" && "embeds" in item
      );
      if (root && typeof root.embeds === "number") {
        const embeds = node.data[root.embeds];
        if (embeds && typeof embeds === "object") {
          return { data: node.data, embeds };
        }
      }
    }
    return void 0;
  }
  function concatBytes(chunks) {
    let total = 0;
    for (const chunk of chunks) total += chunk.length;
    const out = new Uint8Array(total);
    let offset = 0;
    for (const chunk of chunks) {
      out.set(chunk, offset);
      offset += chunk.length;
    }
    return out;
  }
  function byseKeyParts(parts, version) {
    const vStr = String(version != null ? version : "").trim();
    const first = /^\d+$/.test(vStr) ? Number.parseInt(vStr, 10) : 0;
    const second = 31 - first;
    if (first < 1 || first > 20 || first > parts.length || second > parts.length) {
      return parts;
    }
    return [parts[first - 1], parts[second - 1]];
  }
  function extractUpnShare(embedUrl) {
    return __async(this, null, function* () {
      const parsed = new URL(embedUrl);
      const id = parsed.hash.replace(/^#/, "");
      if (!id) return [];
      const referer = `${parsed.origin}/`;
      const apiUrl = new URL("/api/v1/video", parsed.origin);
      apiUrl.searchParams.set("id", id);
      const hexCipher = (yield site.text({ url: apiUrl.toString(), headers: { Referer: referer } })).trim();
      const plainBytes = caye.crypto.decrypt({
        algorithm: "aes-cbc",
        key: UPNSHARE_KEY,
        iv: UPNSHARE_IV,
        data: caye.encoding.hex.decode(hexCipher),
        padding: "pkcs7"
      });
      const info = JSON.parse(caye.encoding.utf8.decode(plainBytes));
      if (!info.cfNative) return [];
      return [{ url: info.cfNative, headers: { Referer: referer }, hint: "hls" }];
    });
  }
  function extractByse(embedUrl) {
    return __async(this, null, function* () {
      var _a, _b, _c;
      const match = /^(https?:\/\/[^/]+)\/[a-z]\/([A-Za-z0-9]+)/.exec(embedUrl);
      if (!match) return [];
      const json = yield site.json({ url: `${match[1]}/api/videos/${match[2]}` });
      const playback = json == null ? void 0 : json.playback;
      if (!((_a = playback == null ? void 0 : playback.key_parts) == null ? void 0 : _a.length) || !playback.iv || !playback.payload) return [];
      const key = concatBytes(
        byseKeyParts(playback.key_parts, playback.version).map(
          (part) => caye.encoding.base64.decode(part)
        )
      );
      const nonce = caye.encoding.base64.decode(playback.iv);
      const data = caye.encoding.base64.decode(playback.payload);
      const plain = caye.crypto.decrypt({
        algorithm: "aes-gcm",
        key,
        nonce,
        data
      });
      const decoded = JSON.parse(caye.encoding.utf8.decode(plain));
      const out = [];
      for (const s of (_b = decoded.sources) != null ? _b : []) {
        if (!(s == null ? void 0 : s.url)) continue;
        const hint = String((_c = s.mime_type) != null ? _c : "").includes("mpegurl") ? "hls" : "mp4";
        out.push({ url: s.url, hint });
        try {
          const parsed = new URL(s.url);
          if (parsed.origin !== BYSE_FALLBACK_EDGE) {
            out.push({ url: `${BYSE_FALLBACK_EDGE}${parsed.pathname}${parsed.search}`, hint });
          }
        } catch (e) {
        }
      }
      return out;
    });
  }
  function parseEpisodeNativeId(nativeId) {
    const sep = nativeId.lastIndexOf("|");
    if (sep <= 0 || sep >= nativeId.length - 1) {
      throw failure("unavailable", `${providerName} invalid episode reference`);
    }
    return { slug: nativeId.slice(0, sep), epNum: nativeId.slice(sep + 1) };
  }
  function collectEpisodeServers(payload) {
    var _a, _b;
    const found = findEmbedsNode(payload);
    if (!found) return [];
    const { data, embeds } = found;
    const out = [];
    for (const category of ["SUB", "DUB"]) {
      const listIdx = embeds[category];
      if (typeof listIdx !== "number") continue;
      const ptrs = data[listIdx];
      if (!Array.isArray(ptrs)) continue;
      const audio = category === "DUB" ? "dub" : "sub";
      for (const ptr of ptrs) {
        if (typeof ptr !== "number") continue;
        const entry = data[ptr];
        if (!entry || typeof entry.server !== "number" || typeof entry.url !== "number")
          continue;
        const serverName = String((_a = data[entry.server]) != null ? _a : "").trim();
        const embedUrl = String((_b = data[entry.url]) != null ? _b : "").trim();
        if (!serverName || !embedUrl) continue;
        out.push({
          audio,
          serverId: choiceId(serverName),
          serverName,
          embedUrl
        });
      }
    }
    return out;
  }
  caye.register(providerId, {
    source: {
      search(context, query) {
        return __async(this, null, function* () {
          var _a;
          const base = siteBase(context);
          const q = ((_a = query == null ? void 0 : query.q) != null ? _a : "").trim();
          if (!q) return { items: [], nextCursor: "", state: "complete" };
          const url = new URL("/catalogo/__data.json", base);
          url.searchParams.set("page", "1");
          url.searchParams.set("search", q);
          const payload = yield site.json({
            url: url.toString(),
            headers: siteHeaders(base)
          });
          const items = resolveCatalogResults(payload, base).map((item) => __spreadValues({
            ref: videoRef(providerId, item.slug),
            name: item.title
          }, item.year !== void 0 ? { year: item.year } : {}));
          return {
            items: limitItems(items, query == null ? void 0 : query.limit),
            nextCursor: "",
            state: "complete"
          };
        });
      },
      read(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const slug = ref.nativeId.split("|")[0];
          const payload = yield site.json({
            url: `${base}/media/${encodeURIComponent(slug)}/__data.json`,
            headers: siteHeaders(base)
          });
          const found = findMediaNode(payload, slug);
          if (!found) {
            throw failure("unavailable", `${providerName} title was not found`);
          }
          const { data, descriptor } = found;
          const title = typeof descriptor.title === "number" ? data[descriptor.title] : void 0;
          const startDate = typeof descriptor.startDate === "number" ? data[descriptor.startDate] : void 0;
          const name = typeof title === "string" ? title.trim() : slug;
          const year = extractFirstYear(typeof startDate === "string" ? startDate : void 0);
          return __spreadValues({
            ref: sameRef(ref),
            name
          }, year !== void 0 ? { year } : {});
        });
      },
      list(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const slug = ref.nativeId.split("|")[0];
          const payload = yield site.json({
            url: `${base}/media/${encodeURIComponent(slug)}/__data.json`,
            headers: siteHeaders(base)
          });
          const found = findMediaNode(payload, slug);
          if (!found) {
            throw failure("unavailable", `${providerName} episodes were not found`);
          }
          const { data, descriptor } = found;
          const epPtrs = typeof descriptor.episodes === "number" ? data[descriptor.episodes] : void 0;
          const installments = [];
          if (Array.isArray(epPtrs)) {
            for (let i = 0; i < epPtrs.length; i++) {
              const ep = typeof epPtrs[i] === "number" ? data[epPtrs[i]] : void 0;
              if (!ep) continue;
              const rawNum = typeof ep.number === "number" ? data[ep.number] : i + 1;
              const num = parseEpisodeNumber(
                typeof rawNum === "number" || typeof rawNum === "string" ? rawNum : i + 1
              );
              if (num === void 0 || num <= 0) continue;
              const rawTitle = typeof ep.title === "number" ? data[ep.title] : ep.title;
              const epTitle = typeof rawTitle === "string" ? rawTitle.trim() : "";
              installments.push(__spreadProps(__spreadValues({
                number: num
              }, epTitle ? { name: epTitle.slice(0, 500) } : {}), {
                ref: videoRef(providerId, `${slug}|${num}`)
              }));
            }
          }
          installments.sort((a, b) => a.number - b.number);
          return {
            installments,
            choices: {
              audio: [
                { id: "sub", label: "Sub" },
                { id: "dub", label: "Dub" }
              ],
              server: [
                { id: "hls", label: "HLS" },
                { id: "upnshare", label: "UPNShare" },
                { id: "byse", label: "Byse" },
                { id: "voe", label: "Voe" },
                { id: "mp4upload", label: "MP4Upload" }
              ],
              quality: [{ id: "auto", label: "Auto" }]
            }
          };
        });
      },
      find(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const { slug, epNum } = parseEpisodeNativeId(ref.nativeId);
          const payload = yield site.json({
            url: `${base}/media/${encodeURIComponent(slug)}/${encodeURIComponent(epNum)}/__data.json`,
            headers: siteHeaders(base)
          });
          const servers = collectEpisodeServers(payload);
          const deadline = futureDeadline(context == null ? void 0 : context.deadline);
          const items = servers.map((srv) => ({
            id: `${srv.audio}:${srv.serverId}`,
            origin: srv.serverId === "mp4upload" ? "http" : "hls",
            capabilities: ["video"],
            expiresAt: deadline,
            tracks: [
              {
                id: "main",
                kind: "video",
                language: "es",
                label: `${srv.audio === "dub" ? "Dub" : "Sub"} \xB7 ${srv.serverName}`
              }
            ],
            ranges: [],
            choices: {
              audio: srv.audio,
              server: srv.serverId,
              quality: "auto"
            }
          }));
          return { items, state: "complete" };
        });
      },
      resolve(context, input) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const { slug, epNum } = parseEpisodeNativeId(input.ref.nativeId);
          const [wantAudio, wantServer] = input.sourceId.split(":");
          const payload = yield site.json({
            url: `${base}/media/${encodeURIComponent(slug)}/${encodeURIComponent(epNum)}/__data.json`,
            headers: siteHeaders(base)
          });
          const servers = collectEpisodeServers(payload);
          const match = servers.find((s) => s.audio === wantAudio && s.serverId === wantServer);
          if (!match) {
            throw failure("unavailable", `${providerName} server is unavailable`);
          }
          const embedUrl = resolveUrl(match.embedUrl, base);
          if (!embedUrl) {
            throw failure("unavailable", `${providerName} invalid embed URL`);
          }
          let candidates = [];
          if (wantServer === "hls") {
            candidates = [
              {
                url: embedUrl.replace("/play/", "/m3u8/"),
                headers: {
                  Referer: "https://player.zilla-networks.com/",
                  "Sec-Fetch-Site": "same-origin",
                  "Sec-Fetch-Mode": "cors",
                  "Sec-Fetch-Dest": "empty"
                },
                hint: "hls"
              }
            ];
          } else if (wantServer === "upnshare") {
            candidates = yield extractUpnShare(embedUrl);
          } else if (wantServer === "byse") {
            candidates = yield extractByse(embedUrl);
          } else if (wantServer === "voe") {
            candidates = yield extractVoe(caye, embedUrl, providerName);
          } else if (wantServer === "mp4upload") {
            candidates = yield extractMp4Upload(
              caye,
              embedUrl,
              "https://www.mp4upload.com/",
              providerName
            );
          }
          if (candidates.length === 0) {
            throw failure("unavailable", `${providerName} stream extraction failed`);
          }
          let lastErr;
          for (const candidate of candidates) {
            try {
              const handle = yield site.handle({
                url: candidate.url,
                headers: candidate.headers
              });
              return {
                id: input.sourceId,
                origin: streamOriginOf(candidate.url, candidate.hint),
                capabilities: ["video"],
                expiresAt: handle.expiresAt,
                handle,
                tracks: [
                  {
                    id: "main",
                    kind: "video",
                    language: "es",
                    label: `${match.audio === "dub" ? "Dub" : "Sub"} \xB7 ${match.serverName}`
                  }
                ],
                ranges: [],
                choices: {
                  audio: match.audio,
                  server: match.serverId,
                  quality: "auto"
                }
              };
            } catch (err) {
              lastErr = err;
            }
          }
          throw lastErr != null ? lastErr : failure("unavailable", `${providerName} stream is unavailable`);
        });
      }
    }
  });
})();
//# sourceMappingURL=backend.js.map
