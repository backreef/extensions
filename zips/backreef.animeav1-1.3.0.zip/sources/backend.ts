import type {
    API,
    Context,
    Query,
    Ref,
    Source,
    SourceInstallment,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
    SourceResolveInput,
} from "../../../../packages/plugin-sdk/src/index"
import {
    choiceId,
    extractFirstYear,
    futureDeadline,
    limitItems,
    parseEpisodeNumber,
    sameRef,
    streamOriginOf,
    videoRef,
} from "../../stream-common/src/common"
import {
    extractMp4Upload,
    extractVoe,
    type ExtractedStream,
} from "../../stream-common/src/extractors"
import { failure, httpClient } from "../../../../packages/plugin-std/src/http.ts"
import { type SvelteKitPayload } from "../../../../packages/plugin-std/src/page-data.ts"
import { cleanBaseUrl, resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.animeav1:source"
const providerName = "AnimeAV1"
const site = httpClient(caye, providerName)
const defaultBaseUrl = "https://animeav1.com"

const UPNSHARE_KEY = "kiemtienmua911ca"
const UPNSHARE_IV = "1234567890oiuytr"
const BYSE_FALLBACK_EDGE = "https://edge1-frankfurt-sprintcdn.owphbf24.com"

function siteBase(context: Context): string {
    return cleanBaseUrl(context?.config?.url, defaultBaseUrl)
}

function siteHeaders(base: string): Record<string, string> {
    return {
        Accept: "*/*",
        "Accept-Language": "es-ES,es;q=0.9",
        Referer: `${base}/`,
        "Sec-Fetch-Site": "same-origin",
        "Sec-Fetch-Mode": "cors",
        "Sec-Fetch-Dest": "empty",
    }
}

function resolveCatalogResults(
    payload: SvelteKitPayload,
    base: string,
): Array<{ slug: string; title: string; year?: number }> {
    const out: Array<{ slug: string; title: string; year?: number }> = []
    for (const node of payload.nodes ?? []) {
        if (!node?.uses?.search_params || !Array.isArray(node.data) || node.data.length === 0)
            continue
        const data = node.data
        const root = data[0] as Record<string, unknown> | undefined
        if (!root || typeof root.results !== "number") continue
        const ptrs = data[root.results]
        if (!Array.isArray(ptrs)) continue
        for (const ptr of ptrs) {
            if (typeof ptr !== "number") continue
            const raw = data[ptr] as Record<string, unknown> | undefined
            if (!raw) continue
            const title = typeof raw.title === "number" ? data[raw.title] : undefined
            const slug = typeof raw.slug === "number" ? data[raw.slug] : undefined
            if (typeof title !== "string" || typeof slug !== "string") continue
            const dateVal = typeof raw.startDate === "number" ? data[raw.startDate] : undefined
            const year = extractFirstYear(typeof dateVal === "string" ? dateVal : undefined)
            out.push({ slug, title, ...(year !== undefined ? { year } : {}) })
        }
        return out
    }
    return out
}

function findMediaNode(
    payload: SvelteKitPayload,
    slug: string,
): { data: unknown[]; descriptor: Record<string, unknown> } | undefined {
    for (const node of payload.nodes ?? []) {
        if (!Array.isArray(node?.data)) continue
        for (const obj of node.data) {
            if (!obj || typeof obj !== "object") continue
            const rec = obj as Record<string, unknown>
            if (
                "slug" in rec &&
                "episodes" in rec &&
                typeof rec.slug === "number" &&
                node.data[rec.slug] === slug
            ) {
                return { data: node.data, descriptor: rec }
            }
        }
    }
    return undefined
}

function findEmbedsNode(
    payload: SvelteKitPayload,
): { data: unknown[]; embeds: Record<string, unknown> } | undefined {
    for (const node of payload.nodes ?? []) {
        if (!Array.isArray(node?.data)) continue
        const root = node.data.find(
            (item): item is Record<string, unknown> =>
                Boolean(item) && typeof item === "object" && "embeds" in (item as object),
        )
        if (root && typeof root.embeds === "number") {
            const embeds = node.data[root.embeds]
            if (embeds && typeof embeds === "object") {
                return { data: node.data, embeds: embeds as Record<string, unknown> }
            }
        }
    }
    return undefined
}

function concatBytes(chunks: Uint8Array[]): Uint8Array {
    let total = 0
    for (const chunk of chunks) total += chunk.length
    const out = new Uint8Array(total)
    let offset = 0
    for (const chunk of chunks) {
        out.set(chunk, offset)
        offset += chunk.length
    }
    return out
}

function byseKeyParts(parts: string[], version: unknown): string[] {
    const vStr = String(version ?? "").trim()
    const first = /^\d+$/.test(vStr) ? Number.parseInt(vStr, 10) : 0
    const second = 31 - first
    if (first < 1 || first > 20 || first > parts.length || second > parts.length) {
        return parts
    }
    return [parts[first - 1], parts[second - 1]]
}

async function extractUpnShare(embedUrl: string): Promise<ExtractedStream[]> {
    const parsed = new URL(embedUrl)
    const id = parsed.hash.replace(/^#/, "")
    if (!id) return []
    const referer = `${parsed.origin}/`
    const apiUrl = new URL("/api/v1/video", parsed.origin)
    apiUrl.searchParams.set("id", id)
    const hexCipher = (
        await site.text({ url: apiUrl.toString(), headers: { Referer: referer } })
    ).trim()
    const plainBytes = caye.crypto.decrypt({
        algorithm: "aes-cbc",
        key: UPNSHARE_KEY,
        iv: UPNSHARE_IV,
        data: caye.encoding.hex.decode(hexCipher),
        padding: "pkcs7",
    })
    const info = JSON.parse(caye.encoding.utf8.decode(plainBytes)) as { cfNative?: string }
    if (!info.cfNative) return []
    return [{ url: info.cfNative, headers: { Referer: referer }, hint: "hls" }]
}

async function extractByse(embedUrl: string): Promise<ExtractedStream[]> {
    const match = /^(https?:\/\/[^/]+)\/[a-z]\/([A-Za-z0-9]+)/.exec(embedUrl)
    if (!match) return []
    const json = await site.json<{
        playback?: {
            key_parts?: string[]
            version?: string
            iv?: string
            payload?: string
        }
    }>({ url: `${match[1]}/api/videos/${match[2]}` })
    const playback = json?.playback
    if (!playback?.key_parts?.length || !playback.iv || !playback.payload) return []
    const key = concatBytes(
        byseKeyParts(playback.key_parts, playback.version).map((part) =>
            caye.encoding.base64.decode(part),
        ),
    )
    const nonce = caye.encoding.base64.decode(playback.iv)
    const data = caye.encoding.base64.decode(playback.payload)
    const plain = caye.crypto.decrypt({
        algorithm: "aes-gcm",
        key,
        nonce,
        data,
    })
    const decoded = JSON.parse(caye.encoding.utf8.decode(plain)) as {
        sources?: Array<{ url?: string; mime_type?: string }>
    }
    const out: ExtractedStream[] = []
    for (const s of decoded.sources ?? []) {
        if (!s?.url) continue
        const hint = String(s.mime_type ?? "").includes("mpegurl") ? "hls" : "mp4"
        out.push({ url: s.url, hint })
        try {
            const parsed = new URL(s.url)
            if (parsed.origin !== BYSE_FALLBACK_EDGE) {
                out.push({ url: `${BYSE_FALLBACK_EDGE}${parsed.pathname}${parsed.search}`, hint })
            }
        } catch {}
    }
    return out
}

function parseEpisodeNativeId(nativeId: string): { slug: string; epNum: string } {
    const sep = nativeId.lastIndexOf("|")
    if (sep <= 0 || sep >= nativeId.length - 1) {
        throw failure("unavailable", `${providerName} invalid episode reference`)
    }
    return { slug: nativeId.slice(0, sep), epNum: nativeId.slice(sep + 1) }
}

function collectEpisodeServers(
    payload: SvelteKitPayload,
): Array<{ audio: "sub" | "dub"; serverId: string; serverName: string; embedUrl: string }> {
    const found = findEmbedsNode(payload)
    if (!found) return []
    const { data, embeds } = found
    const out: Array<{
        audio: "sub" | "dub"
        serverId: string
        serverName: string
        embedUrl: string
    }> = []
    for (const category of ["SUB", "DUB"] as const) {
        const listIdx = embeds[category]
        if (typeof listIdx !== "number") continue
        const ptrs = data[listIdx]
        if (!Array.isArray(ptrs)) continue
        const audio = category === "DUB" ? "dub" : "sub"
        for (const ptr of ptrs) {
            if (typeof ptr !== "number") continue
            const entry = data[ptr] as Record<string, unknown> | undefined
            if (!entry || typeof entry.server !== "number" || typeof entry.url !== "number")
                continue
            const serverName = String(data[entry.server] ?? "").trim()
            const embedUrl = String(data[entry.url] ?? "").trim()
            if (!serverName || !embedUrl) continue
            out.push({
                audio,
                serverId: choiceId(serverName),
                serverName,
                embedUrl,
            })
        }
    }
    return out
}

caye.register(providerId, {
    source: {
        async search(context: Context, query: Query): Promise<SourceRecords> {
            const base = siteBase(context)
            const q = (query?.q ?? "").trim()
            if (!q) return { items: [], nextCursor: "", state: "complete" }
            const url = new URL("/catalogo/__data.json", base)
            url.searchParams.set("page", "1")
            url.searchParams.set("search", q)
            const payload = await site.json<SvelteKitPayload>({
                url: url.toString(),
                headers: siteHeaders(base),
            })
            const items: SourceRecord[] = resolveCatalogResults(payload, base).map((item) => ({
                ref: videoRef(providerId, item.slug),
                name: item.title,
                ...(item.year !== undefined ? { year: item.year } : {}),
            }))
            return {
                items: limitItems(items, query?.limit),
                nextCursor: "",
                state: "complete",
            }
        },

        async read(context: Context, ref: Ref): Promise<SourceRecord> {
            const base = siteBase(context)
            const slug = ref.nativeId.split("|")[0]
            const payload = await site.json<SvelteKitPayload>({
                url: `${base}/media/${encodeURIComponent(slug)}/__data.json`,
                headers: siteHeaders(base),
            })
            const found = findMediaNode(payload, slug)
            if (!found) {
                throw failure("unavailable", `${providerName} title was not found`)
            }
            const { data, descriptor } = found
            const title = typeof descriptor.title === "number" ? data[descriptor.title] : undefined
            const startDate =
                typeof descriptor.startDate === "number" ? data[descriptor.startDate] : undefined
            const name = typeof title === "string" ? title.trim() : slug
            const year = extractFirstYear(typeof startDate === "string" ? startDate : undefined)
            return {
                ref: sameRef(ref),
                name,
                ...(year !== undefined ? { year } : {}),
            }
        },

        async list(context: Context, ref: Ref): Promise<SourceListResult> {
            const base = siteBase(context)
            const slug = ref.nativeId.split("|")[0]
            const payload = await site.json<SvelteKitPayload>({
                url: `${base}/media/${encodeURIComponent(slug)}/__data.json`,
                headers: siteHeaders(base),
            })
            const found = findMediaNode(payload, slug)
            if (!found) {
                throw failure("unavailable", `${providerName} episodes were not found`)
            }
            const { data, descriptor } = found
            const epPtrs =
                typeof descriptor.episodes === "number" ? data[descriptor.episodes] : undefined
            const installments: SourceInstallment[] = []
            if (Array.isArray(epPtrs)) {
                for (let i = 0; i < epPtrs.length; i++) {
                    const ep =
                        typeof epPtrs[i] === "number"
                            ? (data[epPtrs[i]] as Record<string, unknown>)
                            : undefined
                    if (!ep) continue
                    const rawNum = typeof ep.number === "number" ? data[ep.number] : i + 1
                    const num = parseEpisodeNumber(
                        typeof rawNum === "number" || typeof rawNum === "string" ? rawNum : i + 1,
                    )
                    if (num === undefined || num <= 0) continue
                    const rawTitle = typeof ep.title === "number" ? data[ep.title] : ep.title
                    const epTitle = typeof rawTitle === "string" ? rawTitle.trim() : ""
                    installments.push({
                        number: num,
                        ...(epTitle ? { name: epTitle.slice(0, 500) } : {}),
                        ref: videoRef(providerId, `${slug}|${num}`),
                    })
                }
            }
            installments.sort((a, b) => a.number - b.number)
            return {
                installments,
                choices: {
                    audio: [
                        { id: "sub", label: "Sub" },
                        { id: "dub", label: "Dub" },
                    ],
                    server: [
                        { id: "hls", label: "HLS" },
                        { id: "upnshare", label: "UPNShare" },
                        { id: "byse", label: "Byse" },
                        { id: "voe", label: "Voe" },
                        { id: "mp4upload", label: "MP4Upload" },
                    ],
                    quality: [{ id: "auto", label: "Auto" }],
                },
            }
        },

        async find(context: Context, ref: Ref): Promise<SourcePage> {
            const base = siteBase(context)
            const { slug, epNum } = parseEpisodeNativeId(ref.nativeId)
            const payload = await site.json<SvelteKitPayload>({
                url: `${base}/media/${encodeURIComponent(slug)}/${encodeURIComponent(epNum)}/__data.json`,
                headers: siteHeaders(base),
            })
            const servers = collectEpisodeServers(payload)
            const deadline = futureDeadline(context?.deadline)
            const items: Source[] = servers.map((srv) => ({
                id: `${srv.audio}:${srv.serverId}`,
                origin: srv.serverId === "mp4upload" ? "http" : "hls",
                capabilities: ["video"],
                expiresAt: deadline,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: "es",
                        label: `${srv.audio === "dub" ? "Dub" : "Sub"} · ${srv.serverName}`,
                    },
                ],
                ranges: [],
                choices: {
                    audio: srv.audio,
                    server: srv.serverId,
                    quality: "auto",
                },
            }))
            return { items, state: "complete" }
        },

        async resolve(context: Context, input: SourceResolveInput): Promise<Source> {
            const base = siteBase(context)
            const { slug, epNum } = parseEpisodeNativeId(input.ref.nativeId)
            const [wantAudio, wantServer] = input.sourceId.split(":")
            const payload = await site.json<SvelteKitPayload>({
                url: `${base}/media/${encodeURIComponent(slug)}/${encodeURIComponent(epNum)}/__data.json`,
                headers: siteHeaders(base),
            })
            const servers = collectEpisodeServers(payload)
            const match = servers.find((s) => s.audio === wantAudio && s.serverId === wantServer)
            if (!match) {
                throw failure("unavailable", `${providerName} server is unavailable`)
            }
            const embedUrl = resolveUrl(match.embedUrl, base)
            if (!embedUrl) {
                throw failure("unavailable", `${providerName} invalid embed URL`)
            }

            let candidates: ExtractedStream[] = []
            if (wantServer === "hls") {
                candidates = [
                    {
                        url: embedUrl.replace("/play/", "/m3u8/"),
                        headers: {
                            Referer: "https://player.zilla-networks.com/",
                            "Sec-Fetch-Site": "same-origin",
                            "Sec-Fetch-Mode": "cors",
                            "Sec-Fetch-Dest": "empty",
                        },
                        hint: "hls",
                    },
                ]
            } else if (wantServer === "upnshare") {
                candidates = await extractUpnShare(embedUrl)
            } else if (wantServer === "byse") {
                candidates = await extractByse(embedUrl)
            } else if (wantServer === "voe") {
                candidates = await extractVoe(caye, embedUrl, providerName)
            } else if (wantServer === "mp4upload") {
                candidates = await extractMp4Upload(
                    caye,
                    embedUrl,
                    "https://www.mp4upload.com/",
                    providerName,
                )
            }
            if (candidates.length === 0) {
                throw failure("unavailable", `${providerName} stream extraction failed`)
            }

            let lastErr: unknown
            for (const candidate of candidates) {
                try {
                    const handle = await site.handle({
                        url: candidate.url,
                        headers: candidate.headers,
                    })
                    return {
                        id: input.sourceId,
                        origin: streamOriginOf(candidate.url, candidate.hint),
                        capabilities: ["video"],
                        expiresAt: handle.expiresAt,
                        handle,
                        tracks: [
                            {
                                id: "main",
                                kind: "video",
                                language: "es",
                                label: `${match.audio === "dub" ? "Dub" : "Sub"} · ${match.serverName}`,
                            },
                        ],
                        ranges: [],
                        choices: {
                            audio: match.audio,
                            server: match.serverId,
                            quality: "auto",
                        },
                    }
                } catch (err) {
                    lastErr = err
                }
            }
            throw lastErr ?? failure("unavailable", `${providerName} stream is unavailable`)
        },
    },
})
