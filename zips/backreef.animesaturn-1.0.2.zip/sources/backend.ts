import type {
    API,
    Context,
    Query,
    Ref,
    Source,
    SourceInstallment,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
    SourceResolveInput,
} from "../../../../packages/plugin-sdk/src/index"
import {
    extractFirstYear,
    firstText,
    futureDeadline,
    limitItems,
    parseEpisodeNumber,
    sameRef,
    streamOriginOf,
    videoRef,
} from "../../stream-common/src/common"
import { failure, httpClient } from "../../../../packages/plugin-std/src/http.ts"
import { cleanBaseUrl, resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.animesaturn:source"
const providerName = "AnimeSaturn"
const site = httpClient(caye, providerName)
const defaultBaseUrl = "https://animesaturn.ro"
const mobileUserAgent =
    "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Mobile Safari/537.36"

function siteBase(context: Context): string {
    return cleanBaseUrl(context?.config?.url, defaultBaseUrl)
}

function pathOf(rawUrl: string, base: string): string {
    const resolved = resolveUrl(rawUrl, base)
    if (!resolved) return ""
    try {
        return new URL(resolved).pathname.replace(/^\/+|\/+$/g, "")
    } catch {
        return ""
    }
}

function extractStreamUrl(html: string): string {
    const patterns = [/\bprimary\s*=\s*(["'])([^\r\n]*?)\1/i, /\bfile\s*:\s*(["'])([^\r\n]*?)\1/i]
    for (const pattern of patterns) {
        const match = pattern.exec(html)
        if (!match) continue
        const raw = match[2]
            .replace(/\\u0026/gi, "&")
            .replace(/\\x26/gi, "&")
            .replace(/\\\//g, "/")
        const unescaped = caye.html.unescape(raw).trim()
        if (unescaped) return unescaped
    }
    return ""
}

function streamHintOf(url: string): string {
    try {
        const parsed = new URL(url)
        const target = parsed.searchParams.get("src") || parsed.pathname
        if (/\.m3u8(?:$|[?#])/i.test(target)) return "hls"
        if (/\.mp4(?:$|[?#])/i.test(target)) return "mp4"
    } catch {}
    return ""
}

function audioOfContext(text: string): "dub" | "sub" {
    return /\bdub\b/i.test(text) || (/\bita\b/i.test(text) && !/\bsub\s+ita\b/i.test(text))
        ? "dub"
        : "sub"
}

async function resolveEpisodeStream(
    base: string,
    epPath: string,
): Promise<{ streamUrl: string; referer: string }> {
    const episodeUrl = `${base}/${epPath}/`
    const episodeHtml = await site.text({ url: episodeUrl, headers: { Referer: `${base}/` } })
    const doc = caye.html.parse(episodeHtml)
    const playerSrc = (doc.find("#pembed iframe").first().attr("src") ?? "").trim()
    const playerUrl = resolveUrl(caye.html.unescape(playerSrc), episodeUrl)
    if (!playerUrl) {
        throw failure("unavailable", `${providerName} player iframe was not found`)
    }
    const playerHtml = await site.text({ url: playerUrl, headers: { Referer: episodeUrl } })
    let streamUrl = extractStreamUrl(playerHtml)
    let streamPageUrl = playerUrl
    if (!streamUrl) {
        const nestedSrc = (
            caye.html.parse(playerHtml).find("iframe").first().attr("src") ?? ""
        ).trim()
        const nestedUrl = resolveUrl(caye.html.unescape(nestedSrc), playerUrl)
        if (!nestedUrl) {
            throw failure("unavailable", `${providerName} nested player iframe was not found`)
        }
        const nestedHtml = await site.text({ url: nestedUrl, headers: { Referer: playerUrl } })
        streamUrl = extractStreamUrl(nestedHtml)
        streamPageUrl = nestedUrl
    }
    const resolvedStream = resolveUrl(streamUrl, streamPageUrl)
    if (!resolvedStream) {
        throw failure("unavailable", `${providerName} stream URL was not found`)
    }
    return { streamUrl: resolvedStream, referer: streamPageUrl }
}

caye.register(providerId, {
    source: {
        async search(context: Context, query: Query): Promise<SourceRecords> {
            const base = siteBase(context)
            const q = (query?.q ?? "").trim()
            if (!q) return { items: [], nextCursor: "", state: "complete" }
            const url = new URL("/", base)
            url.searchParams.set("s", q)
            const html = await site.text({ url: url.toString(), headers: { Referer: `${base}/` } })
            const doc = caye.html.parse(html)
            const items: SourceRecord[] = []
            const seen = new Set<string>()
            doc.find("article.bs").each((_i, el) => {
                const anchor = el.find("a").first()
                const href = (anchor.attr("href") ?? "").trim()
                const nativeId = pathOf(href, base)
                const rawTitle = (anchor.attr("title") || el.find(".tt").first().text()).trim()
                if (!nativeId || !rawTitle || nativeId.length > 200 || seen.has(nativeId)) return
                seen.add(nativeId)
                const badge = el.find(".sb").first().text().trim().toLowerCase()
                const suffix = badge === "dub" && !/\bdub\b/i.test(rawTitle) ? " (Dub)" : ""
                const year = extractFirstYear(rawTitle)
                items.push({
                    ref: videoRef(providerId, nativeId),
                    name: `${rawTitle}${suffix}`,
                    ...(year !== undefined ? { year } : {}),
                })
            })
            return {
                items: limitItems(items, query?.limit),
                nextCursor: "",
                state: "complete",
            }
        },

        async read(context: Context, ref: Ref): Promise<SourceRecord> {
            const base = siteBase(context)
            const html = await site.text({
                url: `${base}/${ref.nativeId}/`,
                headers: { Referer: `${base}/` },
            })
            const doc = caye.html.parse(html)
            const name = firstText(doc, ["h1.entry-title", "h1", "title"])
                .replace(/\s*[-|]\s*AnimeSaturn.*$/i, "")
                .trim()
            if (!name) {
                throw failure("unavailable", `${providerName} title was not found`)
            }
            const year = extractFirstYear(name)
            return {
                ref: sameRef(ref),
                name,
                ...(year !== undefined ? { year } : {}),
            }
        },

        async list(context: Context, ref: Ref): Promise<SourceListResult> {
            const base = siteBase(context)
            const html = await site.text({
                url: `${base}/${ref.nativeId}/`,
                headers: { Referer: `${base}/` },
            })
            const doc = caye.html.parse(html)
            const title = firstText(doc, ["h1.entry-title", "h1", "title"])
            const audio = audioOfContext(`${ref.nativeId} ${title}`)
            const installments: SourceInstallment[] = []
            const seen = new Set<string>()
            doc.find(".eplister ul li a").each((_i, el) => {
                const href = (el.attr("href") ?? "").trim()
                const epPath = pathOf(href, base)
                const num = parseEpisodeNumber(el.find(".epl-num").first().text())
                if (!epPath || num === undefined || epPath.length > 200 || seen.has(epPath)) return
                seen.add(epPath)
                const epTitle = el.find(".epl-title").first().text().trim()
                installments.push({
                    number: num,
                    name: epTitle ? epTitle.slice(0, 500) : `Episode ${num}`,
                    ref: videoRef(providerId, epPath),
                })
            })
            installments.sort((a, b) => a.number - b.number)
            return {
                installments,
                choices: {
                    audio: [{ id: audio, label: audio === "dub" ? "Dub" : "Sub" }],
                    server: [{ id: "server-1", label: "Server 1" }],
                    quality: [{ id: "auto", label: "Auto" }],
                },
            }
        },

        async find(context: Context, ref: Ref): Promise<SourcePage> {
            const base = siteBase(context)
            const resolved = await resolveEpisodeStream(base, ref.nativeId)
            const audio = audioOfContext(ref.nativeId)
            const origin = streamOriginOf(resolved.streamUrl, streamHintOf(resolved.streamUrl))
            return {
                items: [
                    {
                        id: `${audio}:server-1`,
                        origin,
                        capabilities: ["video"],
                        expiresAt: futureDeadline(context?.deadline),
                        tracks: [
                            {
                                id: "main",
                                kind: "video",
                                language: "it",
                                label: `${audio === "dub" ? "Dub" : "Sub"} · Server 1`,
                            },
                        ],
                        ranges: [],
                        choices: {
                            audio,
                            server: "server-1",
                            quality: "auto",
                        },
                    },
                ],
                state: "complete",
            }
        },

        async resolve(context: Context, input: SourceResolveInput): Promise<Source> {
            const base = siteBase(context)
            const { streamUrl, referer } = await resolveEpisodeStream(base, input.ref.nativeId)
            const audio = input.sourceId.startsWith("dub:") ? "dub" : "sub"
            const handle = await site.handle({
                url: streamUrl,
                headers: {
                    Referer: referer,
                    "User-Agent": mobileUserAgent,
                    Accept: "*/*",
                    "Cache-Control": "no-cache",
                    Pragma: "no-cache",
                },
            })
            return {
                id: input.sourceId,
                origin: streamOriginOf(streamUrl, streamHintOf(streamUrl)),
                capabilities: ["video"],
                expiresAt: handle.expiresAt,
                handle,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: "it",
                        label: `${audio === "dub" ? "Dub" : "Sub"} · Server 1`,
                    },
                ],
                ranges: [],
                choices: {
                    audio,
                    server: "server-1",
                    quality: "auto",
                },
            }
        },
    },
})
