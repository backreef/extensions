import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DownloadOption,
} from "../../../../packages/plugin-sdk/src/index"
import {
    buildMagnet,
    cacheOptions,
    clampLimit,
    createTorrentOption,
    fetchJson,
    mapLimit,
    normalizeInfoHash,
    normalizeResolutionLabel,
    parseIsoDate,
    requireSearchText,
    resolveCachedOrFallback,
} from "../../torrent-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const PROVIDER_ID = "backreef.aniliberty:search"
const API_BASE = "https://aniliberty.top/api/v1"
const HEADERS = {
    Accept: "application/json",
    "X-CSRF-TOKEN": "seanime",
}
const TORRENT_FIELDS = [
    "id",
    "hash",
    "size",
    "label",
    "magnet",
    "seeders",
    "leechers",
    "completed_times",
    "created_at",
    "description",
    "is_hardsub",
    "quality",
    "codec",
    "type",
].join(",")

type ReleaseEntry = {
    id?: number
    name?: {
        english?: string
        main?: string
    }
}

type TorrentEntry = {
    id?: number
    hash?: string
    size?: number
    label?: string
    magnet?: string
    seeders?: number
    leechers?: number
    completed_times?: number
    created_at?: string
    description?: string
    quality?: { description?: string; value?: string }
    codec?: { value?: string }
}

function toOption(torrent: TorrentEntry, release?: ReleaseEntry): DownloadOption | undefined {
    const titleBase = release?.name?.english || release?.name?.main || torrent.label || ""
    if (!titleBase) return undefined
    const res = normalizeResolutionLabel(
        torrent.quality?.description || torrent.quality?.value || "",
    )
    const desc = torrent.description?.trim() || ""
    const nameParts = [titleBase]
    if (desc && !titleBase.includes(desc)) nameParts.push(`[${desc}]`)
    if (res) nameParts.push(`[${res}]`)
    const name = nameParts.join(" ")

    let magnet = torrent.magnet?.trim() || ""
    let infoHash = ""
    if (torrent.hash) {
        try {
            infoHash = normalizeInfoHash(torrent.hash)
        } catch {}
    }
    if (!magnet && infoHash) {
        magnet = buildMagnet({ infoHash, name })
    }
    if (!magnet) return undefined

    const key = torrent.id !== undefined ? String(torrent.id) : infoHash
    if (!key) return undefined

    const best =
        res === "1080p" &&
        typeof torrent.seeders === "number" &&
        torrent.seeders > 50 &&
        torrent.codec?.value !== "xvid"

    return createTorrentOption(caye, {
        id: `aniliberty-${key}`,
        key,
        providerId: PROVIDER_ID,
        name,
        magnet,
        size: typeof torrent.size === "number" && torrent.size > 0 ? torrent.size : undefined,
        seeders: typeof torrent.seeders === "number" ? torrent.seeders : undefined,
        leechers: typeof torrent.leechers === "number" ? torrent.leechers : undefined,
        downloads:
            typeof torrent.completed_times === "number" ? torrent.completed_times : undefined,
        publishedAt: parseIsoDate(caye, torrent.created_at),
        resolution: res || undefined,
        group: "AniLiberty",
        best,
        confirmed: true,
    })
}

async function find(_context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const text = requireSearchText(query)
    const searchUrl = `${API_BASE}/app/search/releases?query=${encodeURIComponent(text)}&include=id,name`
    const releases = await fetchJson<ReleaseEntry[]>(caye, "AniLiberty", searchUrl, {
        headers: HEADERS,
    })
    if (!Array.isArray(releases)) {
        throw failure("unavailable", "AniLiberty returned an invalid search response.")
    }
    const limit = clampLimit(query.limit, 50, 100)
    const perRelease = await mapLimit(releases.slice(0, 10), 3, async (release) => {
        if (!release?.id) return [] as DownloadOption[]
        const url = `${API_BASE}/anime/torrents/release/${release.id}?include=${TORRENT_FIELDS}`
        const rows = await fetchJson<TorrentEntry[]>(caye, "AniLiberty", url, { headers: HEADERS })
        if (!Array.isArray(rows)) return [] as DownloadOption[]
        return rows
            .map((t) => toOption(t, release))
            .filter((opt): opt is DownloadOption => Boolean(opt))
    })
    const items: DownloadOption[] = []
    const seen = new Set<string>()
    for (const group of perRelease) {
        for (const opt of group) {
            if (seen.has(opt.id)) continue
            seen.add(opt.id)
            items.push(opt)
            if (items.length >= limit) break
        }
        if (items.length >= limit) break
    }
    await cacheOptions(caye, "aniliberty", items)
    return { items, state: "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    return await resolveCachedOrFallback(
        caye,
        "aniliberty",
        input,
        "Unknown or uncached AniLiberty option.",
        async (optionId) => {
            const match = /^aniliberty-([1-9][0-9]*)$/.exec(optionId)
            if (!match) throw failure("missing", "Unknown AniLiberty option.")
            const row = await fetchJson<TorrentEntry>(
                caye,
                "AniLiberty",
                `${API_BASE}/anime/torrents/${match[1]}?include=${TORRENT_FIELDS}`,
                { headers: HEADERS, missingOn404: true },
            )
            const opt = toOption(row)
            if (!opt) throw failure("unavailable", "AniLiberty returned an invalid torrent.")
            return opt
        },
        { providerId: PROVIDER_ID, group: "AniLiberty" },
    )
}

caye.register(PROVIDER_ID, { acquisition: { find, resolve } })
