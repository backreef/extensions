(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/titles.ts
  var YEAR_PAREN_RE = /\((\d{4})\)/;
  var YEAR_STANDALONE_RE = /\b(19\d{2}|20\d{2})\b/;
  function extractYear(title) {
    const paren = title.match(YEAR_PAREN_RE);
    if (paren) {
      const year = Number.parseInt(paren[1], 10);
      if (year >= 1900 && year <= 2100) return year;
    }
    const standalone = title.match(YEAR_STANDALONE_RE);
    if (standalone) {
      return Number.parseInt(standalone[1], 10);
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../../../packages/plugin-std/src/url.ts
  function resolveUrl(raw, base) {
    const trimmed = raw.trim();
    if (!trimmed) return "";
    try {
      const url = new URL(trimmed.startsWith("//") ? `https:${trimmed}` : trimmed, base);
      return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : "";
    } catch (e) {
      return "";
    }
  }
  function cleanBaseUrl(raw, fallback) {
    const resolved = resolveUrl(raw != null ? raw : "");
    if (!resolved) return fallback;
    const url = new URL(resolved);
    return url.origin + url.pathname.replace(/\/+$/, "");
  }

  // ../stream-common/src/common.ts
  function streamOriginOf(url, hint) {
    const lowerUrl = url.toLowerCase();
    const lowerHint = (hint != null ? hint : "").toLowerCase();
    if (lowerHint === "hls" || lowerHint === "m3u8" || /\.m3u8(\?|$|#)/.test(lowerUrl)) {
      return "hls";
    }
    return "http";
  }
  function firstText(doc, selectors) {
    for (const selector of selectors) {
      const text = doc.find(selector).first().text().trim();
      if (text) return text;
    }
    return "";
  }
  function videoRef(providerId2, nativeId) {
    return {
      providerId: providerId2,
      type: "video",
      nativeId
    };
  }
  function sameRef(ref) {
    return ref.scope ? {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId,
      scope: ref.scope
    } : {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId
    };
  }
  function limitItems(items, limit) {
    if (typeof limit === "number" && Number.isFinite(limit) && limit > 0) {
      return items.slice(0, limit);
    }
    return items;
  }
  function futureDeadline(contextDeadline, minutes = 10) {
    const now = Date.now();
    if (contextDeadline) {
      const parsed = Date.parse(contextDeadline);
      if (Number.isFinite(parsed) && parsed > now + 5e3 && parsed <= now + 24 * 3600 * 1e3) {
        return contextDeadline;
      }
    }
    return new Date(now + minutes * 60 * 1e3).toISOString();
  }
  function parseEpisodeNumber(raw) {
    if (typeof raw === "number") {
      return Number.isFinite(raw) && raw >= 0 ? raw : void 0;
    }
    if (typeof raw !== "string") return void 0;
    const cleaned = raw.trim().replace(",", ".");
    if (!cleaned) return void 0;
    const match = /\d+(?:\.\d+)?/.exec(cleaned);
    if (!match) return void 0;
    const num = Number(match[0]);
    return Number.isFinite(num) && num >= 0 ? num : void 0;
  }
  function extractFirstYear(text) {
    const year = extractYear(text != null ? text : "");
    return year > 0 ? year : void 0;
  }

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // src/backend.ts
  var providerId = "backreef.animeheaven:source";
  var providerName = "AnimeHeaven";
  var site = httpClient(caye, providerName);
  var defaultBaseUrl = "https://animeheaven.me";
  function siteBase(context) {
    var _a;
    return cleanBaseUrl((_a = context == null ? void 0 : context.config) == null ? void 0 : _a.url, defaultBaseUrl);
  }
  function extractVideoUrls(base, html) {
    const doc = caye.html.parse(html);
    const urls = [];
    const seen = /* @__PURE__ */ new Set();
    doc.find("video#vid source").each((_i, el) => {
      var _a;
      const src = ((_a = el.attr("src")) != null ? _a : "").trim();
      if (!src) return;
      const resolved = resolveUrl(caye.html.unescape(src), base);
      if (!resolved || seen.has(resolved)) return;
      if (!/\.mp4(?:[?#]|$)|\.m3u8(?:[?#]|$)/i.test(resolved)) return;
      seen.add(resolved);
      urls.push(resolved);
    });
    if (urls.length === 0) {
      const tokenMatch = /video\.mp4\?([a-f0-9]+)&([a-f0-9]+)/i.exec(html);
      if (tokenMatch) {
        urls.push(`https://ax.animeheaven.me/video.mp4?${tokenMatch[1]}&${tokenMatch[2]}`);
      }
    }
    return urls;
  }
  function fetchGateHtml(base, gateKey) {
    return __async(this, null, function* () {
      return site.text({
        url: `${base}/gate.php`,
        headers: {
          Cookie: `key=${gateKey}`,
          Referer: `${base}/anime.php`
        }
      });
    });
  }
  caye.register(providerId, {
    source: {
      search(context, query) {
        return __async(this, null, function* () {
          var _a;
          const base = siteBase(context);
          const q = ((_a = query == null ? void 0 : query.q) != null ? _a : "").trim();
          if (!q) return { items: [], nextCursor: "", state: "complete" };
          const url = new URL("/search.php", base);
          url.searchParams.set("s", q);
          const html = yield site.text({ url: url.toString() });
          const doc = caye.html.parse(html);
          const items = [];
          const seen = /* @__PURE__ */ new Set();
          doc.find(".similarimg a").each((_i, anchor) => {
            var _a2;
            const href = ((_a2 = anchor.attr("href")) != null ? _a2 : "").trim();
            if (!href.includes("anime.php?")) return;
            const full = resolveUrl(href, base);
            if (!full) return;
            const parsed = new URL(full);
            const nativeId = parsed.search.replace(/^\?/, "");
            if (!nativeId || seen.has(nativeId)) return;
            seen.add(nativeId);
            const title = (anchor.find("img").first().attr("alt") || anchor.attr("title") || anchor.text()).trim();
            if (!title) return;
            const year = extractFirstYear(anchor.text());
            items.push(__spreadValues({
              ref: videoRef(providerId, nativeId),
              name: title
            }, year !== void 0 ? { year } : {}));
          });
          return {
            items: limitItems(items, query == null ? void 0 : query.limit),
            nextCursor: "",
            state: "complete"
          };
        });
      },
      read(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const html = yield site.text({ url: `${base}/anime.php?${ref.nativeId}` });
          const doc = caye.html.parse(html);
          const rawTitle = firstText(doc, ["div.infotitle", "h1", "title"]).replace(/\s*\|\s*AnimeHeaven.*$/i, "").trim();
          if (!rawTitle) {
            throw failure("unavailable", `${providerName} anime title was not found`);
          }
          const year = extractFirstYear(doc.find("div.infoyear, div.infodesc").text());
          return __spreadValues({
            ref: sameRef(ref),
            name: rawTitle
          }, year !== void 0 ? { year } : {});
        });
      },
      list(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const html = yield site.text({ url: `${base}/anime.php?${ref.nativeId}` });
          const doc = caye.html.parse(html);
          const installments = [];
          const seen = /* @__PURE__ */ new Set();
          doc.find("a[id]").each((_i, anchor) => {
            var _a;
            const gateKey = ((_a = anchor.attr("id")) != null ? _a : "").trim();
            const epText = anchor.find(".watch2").first().text();
            const num = parseEpisodeNumber(epText);
            if (!gateKey || num === void 0 || seen.has(gateKey)) return;
            seen.add(gateKey);
            installments.push({
              number: num,
              name: `Episode ${num}`,
              ref: videoRef(providerId, gateKey)
            });
          });
          installments.sort((a, b) => a.number - b.number);
          return {
            installments,
            choices: {
              audio: [{ id: "sub", label: "Sub" }],
              server: [{ id: "server-1", label: "Server 1" }],
              quality: [{ id: "auto", label: "Auto" }]
            }
          };
        });
      },
      find(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const html = yield fetchGateHtml(base, ref.nativeId);
          const urls = extractVideoUrls(base, html);
          if (urls.length === 0) {
            return { items: [], state: "complete" };
          }
          const deadline = futureDeadline(context == null ? void 0 : context.deadline);
          const items = urls.map((url, index) => ({
            id: index === 0 ? "server-1" : `server-1:${index + 1}`,
            origin: streamOriginOf(url),
            capabilities: ["video"],
            expiresAt: deadline,
            tracks: [
              {
                id: "main",
                kind: "video",
                language: "ja",
                label: "Sub \xB7 Server 1"
              }
            ],
            ranges: [],
            choices: {
              audio: "sub",
              server: "server-1",
              quality: "auto"
            }
          }));
          return { items, state: "complete" };
        });
      },
      resolve(context, input) {
        return __async(this, null, function* () {
          var _a;
          const base = siteBase(context);
          const html = yield fetchGateHtml(base, input.ref.nativeId);
          const urls = extractVideoUrls(base, html);
          const parts = input.sourceId.split(":");
          const index = parts[1] ? Math.max(0, Number.parseInt(parts[1], 10) - 1) : 0;
          const selected = (_a = urls[index]) != null ? _a : urls[0];
          if (!selected) {
            throw failure("unavailable", `${providerName} video URL was not found`);
          }
          const handle = yield site.handle({
            url: selected,
            headers: {
              Referer: `${base}/`,
              Origin: base
            }
          });
          return {
            id: input.sourceId,
            origin: streamOriginOf(selected),
            capabilities: ["video"],
            expiresAt: handle.expiresAt,
            handle,
            tracks: [
              {
                id: "main",
                kind: "video",
                language: "ja",
                label: "Sub \xB7 Server 1"
              }
            ],
            ranges: [],
            choices: {
              audio: "sub",
              server: "server-1",
              quality: "auto"
            }
          };
        });
      }
    }
  });
})();
//# sourceMappingURL=backend.js.map
