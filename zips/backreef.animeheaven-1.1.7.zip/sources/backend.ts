import type {
    API,
    Context,
    Query,
    Ref,
    Source,
    SourceInstallment,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
    SourceResolveInput,
} from "../../../../packages/plugin-sdk/src/index"
import {
    extractFirstYear,
    firstText,
    futureDeadline,
    limitItems,
    parseEpisodeNumber,
    sameRef,
    streamOriginOf,
    videoRef,
} from "../../stream-common/src/common"
import { failure, httpClient } from "../../../../packages/plugin-std/src/http.ts"
import { cleanBaseUrl, resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.animeheaven:source"
const providerName = "AnimeHeaven"
const site = httpClient(caye, providerName)
const defaultBaseUrl = "https://animeheaven.me"

function siteBase(context: Context): string {
    return cleanBaseUrl(context?.config?.url, defaultBaseUrl)
}

function extractVideoUrls(base: string, html: string): string[] {
    const doc = caye.html.parse(html)
    const urls: string[] = []
    const seen = new Set<string>()
    doc.find("video#vid source").each((_i, el) => {
        const src = (el.attr("src") ?? "").trim()
        if (!src) return
        const resolved = resolveUrl(caye.html.unescape(src), base)
        if (!resolved || seen.has(resolved)) return
        if (!/\.mp4(?:[?#]|$)|\.m3u8(?:[?#]|$)/i.test(resolved)) return
        seen.add(resolved)
        urls.push(resolved)
    })
    if (urls.length === 0) {
        const tokenMatch = /video\.mp4\?([a-f0-9]+)&([a-f0-9]+)/i.exec(html)
        if (tokenMatch) {
            urls.push(`https://ax.animeheaven.me/video.mp4?${tokenMatch[1]}&${tokenMatch[2]}`)
        }
    }
    return urls
}

async function fetchGateHtml(base: string, gateKey: string): Promise<string> {
    return site.text({
        url: `${base}/gate.php`,
        headers: {
            Cookie: `key=${gateKey}`,
            Referer: `${base}/anime.php`,
        },
    })
}

caye.register(providerId, {
    source: {
        async search(context: Context, query: Query): Promise<SourceRecords> {
            const base = siteBase(context)
            const q = (query?.q ?? "").trim()
            if (!q) return { items: [], nextCursor: "", state: "complete" }
            const url = new URL("/search.php", base)
            url.searchParams.set("s", q)
            const html = await site.text({ url: url.toString() })
            const doc = caye.html.parse(html)
            const items: SourceRecord[] = []
            const seen = new Set<string>()
            doc.find(".similarimg a").each((_i, anchor) => {
                const href = (anchor.attr("href") ?? "").trim()
                if (!href.includes("anime.php?")) return
                const full = resolveUrl(href, base)
                if (!full) return
                const parsed = new URL(full)
                const nativeId = parsed.search.replace(/^\?/, "")
                if (!nativeId || seen.has(nativeId)) return
                seen.add(nativeId)
                const title = (
                    anchor.find("img").first().attr("alt") ||
                    anchor.attr("title") ||
                    anchor.text()
                ).trim()
                if (!title) return
                const year = extractFirstYear(anchor.text())
                items.push({
                    ref: videoRef(providerId, nativeId),
                    name: title,
                    ...(year !== undefined ? { year } : {}),
                })
            })
            return {
                items: limitItems(items, query?.limit),
                nextCursor: "",
                state: "complete",
            }
        },

        async read(context: Context, ref: Ref): Promise<SourceRecord> {
            const base = siteBase(context)
            const html = await site.text({ url: `${base}/anime.php?${ref.nativeId}` })
            const doc = caye.html.parse(html)
            const rawTitle = firstText(doc, ["div.infotitle", "h1", "title"])
                .replace(/\s*\|\s*AnimeHeaven.*$/i, "")
                .trim()
            if (!rawTitle) {
                throw failure("unavailable", `${providerName} anime title was not found`)
            }
            const year = extractFirstYear(doc.find("div.infoyear, div.infodesc").text())
            return {
                ref: sameRef(ref),
                name: rawTitle,
                ...(year !== undefined ? { year } : {}),
            }
        },

        async list(context: Context, ref: Ref): Promise<SourceListResult> {
            const base = siteBase(context)
            const html = await site.text({ url: `${base}/anime.php?${ref.nativeId}` })
            const doc = caye.html.parse(html)
            const installments: SourceInstallment[] = []
            const seen = new Set<string>()
            doc.find("a[id]").each((_i, anchor) => {
                const gateKey = (anchor.attr("id") ?? "").trim()
                const epText = anchor.find(".watch2").first().text()
                const num = parseEpisodeNumber(epText)
                if (!gateKey || num === undefined || seen.has(gateKey)) return
                seen.add(gateKey)
                installments.push({
                    number: num,
                    name: `Episode ${num}`,
                    ref: videoRef(providerId, gateKey),
                })
            })
            installments.sort((a, b) => a.number - b.number)
            return {
                installments,
                choices: {
                    audio: [{ id: "sub", label: "Sub" }],
                    server: [{ id: "server-1", label: "Server 1" }],
                    quality: [{ id: "auto", label: "Auto" }],
                },
            }
        },

        async find(context: Context, ref: Ref): Promise<SourcePage> {
            const base = siteBase(context)
            const html = await fetchGateHtml(base, ref.nativeId)
            const urls = extractVideoUrls(base, html)
            if (urls.length === 0) {
                return { items: [], state: "complete" }
            }
            const deadline = futureDeadline(context?.deadline)
            const items: Source[] = urls.map((url, index) => ({
                id: index === 0 ? "server-1" : `server-1:${index + 1}`,
                origin: streamOriginOf(url),
                capabilities: ["video"],
                expiresAt: deadline,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: "ja",
                        label: "Sub · Server 1",
                    },
                ],
                ranges: [],
                choices: {
                    audio: "sub",
                    server: "server-1",
                    quality: "auto",
                },
            }))
            return { items, state: "complete" }
        },

        async resolve(context: Context, input: SourceResolveInput): Promise<Source> {
            const base = siteBase(context)
            const html = await fetchGateHtml(base, input.ref.nativeId)
            const urls = extractVideoUrls(base, html)
            const parts = input.sourceId.split(":")
            const index = parts[1] ? Math.max(0, Number.parseInt(parts[1], 10) - 1) : 0
            const selected = urls[index] ?? urls[0]
            if (!selected) {
                throw failure("unavailable", `${providerName} video URL was not found`)
            }
            const handle = await site.handle({
                url: selected,
                headers: {
                    Referer: `${base}/`,
                    Origin: base,
                },
            })
            return {
                id: input.sourceId,
                origin: streamOriginOf(selected),
                capabilities: ["video"],
                expiresAt: handle.expiresAt,
                handle,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: "ja",
                        label: "Sub · Server 1",
                    },
                ],
                ranges: [],
                choices: {
                    audio: "sub",
                    server: "server-1",
                    quality: "auto",
                },
            }
        },
    },
})
