import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DecisionObservation,
    DownloadOption,
    Value,
} from "../../../../packages/plugin-sdk/src/index"
import { failure } from "../../../../packages/provider-source/src/errors"
import {
    fact,
    magnetURI,
    parseRSS,
    type RawTorrent,
    unescapeHTML,
} from "./nyaa"

declare const caye: API

const provider = "backreef.nyaa:search"
const rssEndpoint = "https://nyaa.si/"
const cacheSeconds = 7 * 24 * 60 * 60

function text(value: string): Value {
    return { kind: "text", text: value }
}

function titleVariants(raw: string): string[] {
    const clean = raw
        .replace(/[()[\]{}|"'~?\\^!]/g, "")
        .replace(/\s+/g, " ")
        .trim()
    if (!clean) return []
    const variants: string[] = [clean]
    const colonIdx = clean.indexOf(":")
    if (colonIdx > 4) {
        variants.push(clean.substring(0, colonIdx).trim())
    }
    const dashIdx = clean.indexOf(" - ")
    if (dashIdx > 4) {
        variants.push(clean.substring(0, dashIdx).trim())
    }
    const stripped = clean
        .replace(/\s+(?:The\s+)?Final(?:\s+Season)?$/i, "")
        .replace(/\s+Final$/i, "")
        .replace(/\s+Season\s+\d+$/i, "")
        .replace(/\s+\d+(?:st|nd|rd|th)\s+Season$/i, "")
        .replace(/\s+Part\s+\d+$/i, "")
        .replace(/\s+(?:II|III|IV|V|VI|VII|VIII|IX|X)$/i, "")
        .trim()
    if (stripped && stripped !== clean && stripped.length >= 4) {
        variants.push(stripped)
    }
    return Array.from(new Set(variants))
}

function episodeGroup(ep: number, season?: number): string {
    const padded = String(ep).padStart(2, "0")
    const terms = [padded, `E${padded}`, `EP${padded}`, `EP${ep}`]
    if (season && season > 0) {
        const sPadded = String(season).padStart(2, "0")
        terms.push(`S${sPadded}E${padded}`)
    }
    return `(${Array.from(new Set(terms)).join("|")})`
}

type SmartQuery = { query: string; sortBy: string }

function buildSmartQueries(query: AcquisitionQuery): SmartQuery[] {
    const text = query.text?.trim() || ""
    const variants = titleVariants(text)
    if (variants.length === 0) return []
    const resStr = query.resolution ? ` ${query.resolution}` : ""
    const queries: SmartQuery[] = []

    if (query.batch) {
        for (const title of variants) {
            queries.push({
                query: `${title} (Batch|Complete)${resStr}`,
                sortBy: "size",
            })
            if (query.season && query.season > 1) {
                queries.push({
                    query: `${title} Season ${query.season} (Batch|Complete)${resStr}`,
                    sortBy: "size",
                })
            }
            queries.push({ query: `${title}${resStr}`, sortBy: "size" })
        }
    } else if (query.number !== undefined && query.number > 0) {
        const epGroup = episodeGroup(query.number, query.season)
        for (const title of variants) {
            queries.push({
                query: `${title} ${epGroup}${resStr}`,
                sortBy: "seeders",
            })
            if (query.season && query.season > 1) {
                queries.push({
                    query: `${title} Season ${query.season} ${epGroup}${resStr}`,
                    sortBy: "seeders",
                })
            }
        }
        if (query.absolute !== undefined && query.absolute > 0 && query.absolute !== query.number) {
            const absGroup = episodeGroup(query.absolute)
            for (const title of variants) {
                queries.push({
                    query: `${title} ${absGroup}${resStr}`,
                    sortBy: "seeders",
                })
            }
        }
    } else {
        for (const title of variants) {
            queries.push({ query: `${title}${resStr}`, sortBy: "seeders" })
        }
    }

    const seen = new Set<string>()
    const unique: SmartQuery[] = []
    for (const q of queries) {
        const key = `${q.query}|${q.sortBy}`
        if (!seen.has(key)) {
            seen.add(key)
            unique.push(q)
        }
        if (unique.length >= 5) break
    }
    return unique
}

function toOption(item: RawTorrent, confirmed: boolean): DownloadOption {
    const magnet = item.infoHash ? magnetURI(item.infoHash, item.name) : undefined
    const uri = magnet || item.downloadUrl || item.link
    const facts: DecisionObservation[] = []
    if (item.size > 0) {
        facts.push(fact(provider, `size-${item.id}`, "size", item.size))
    }
    if (item.seeders >= 0) {
        facts.push(fact(provider, `seeders-${item.id}`, "seeders", item.seeders))
    }
    if (item.leechers >= 0) {
        facts.push(fact(provider, `leechers-${item.id}`, "leechers", item.leechers))
    }
    if (item.downloads > 0) {
        facts.push(fact(provider, `downloads-${item.id}`, "downloads", item.downloads))
    }

    let publishedAt: string | undefined
    if (item.pubDate) {
        try {
            const d = new Date(item.pubDate)
            if (!isNaN(d.getTime())) publishedAt = d.toISOString()
        } catch {}
    }

    const opt: DownloadOption = {
        id: `nyaa-${item.id}`,
        name: item.name,
        kind: "torrent",
        uri,
        files: [],
        facts,
        availability: "available",
        eligible: true,
        reasons: [],
        confirmed,
        seeders: item.seeders,
        size: item.size > 0 ? item.size : undefined,
    }
    if (publishedAt) opt.publishedAt = publishedAt
    if (item.link.startsWith("https://")) opt.pageUrl = item.link
    if (magnet) opt.magnet = magnet
    return opt
}

async function search(q: string, sortBy: string): Promise<RawTorrent[]> {
    const params = [
        "page=rss",
        `q=${encodeURIComponent(q)}`,
        "c=1_2",
        "f=0",
        `s=${encodeURIComponent(sortBy)}`,
        "o=desc",
    ].join("&")
    const response = await caye.http({
        url: `${rssEndpoint}?${params}`,
        method: "GET",
        headers: { Accept: "application/rss+xml, application/xml, text/xml" },
    })
    if (response.status !== 200 || !response.body) {
        throw failure("unavailable", `Nyaa answered ${response.status}.`)
    }
    return parseRSS(response.body)
}

async function find(_context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    const textStr = query.text?.trim()
    if (!textStr) {
        throw failure("unsupported", "Enter a title to search.")
    }
    const smartQueries = buildSmartQueries(query)
    const seen = new Set<number>()
    const items: DownloadOption[] = []
    const limit = Math.min(Math.max(query.limit || 50, 1), 100)

    for (const sq of smartQueries) {
        const results = await search(sq.query, sq.sortBy)
        for (const raw of results) {
            if (seen.has(raw.id)) continue
            seen.add(raw.id)
            const opt = toOption(raw, !query.batch && query.number !== undefined)
            items.push(opt)
            await caye.cache.set({
                key: `nyaa:option:${raw.id}`,
                value: text(JSON.stringify(opt)),
                ttlSeconds: cacheSeconds,
            })
            if (items.length >= limit) break
        }
        if (items.length >= limit) break
    }

    return { items, state: "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    const match = /^nyaa-([1-9][0-9]*)$/.exec(input.optionId ?? "")
    if (!match) throw failure("missing", "Unknown Nyaa option.")
    const id = match[1]
    const cached = await caye.cache.get({ key: `nyaa:option:${id}` })
    if (cached?.kind === "text") {
        try {
            return JSON.parse(cached.text) as DownloadOption
        } catch {}
    }

    const response = await caye.http({
        url: `https://nyaa.si/view/${id}`,
        method: "GET",
        headers: { Accept: "text/html" },
    })
    if (response.status === 404) {
        throw failure("missing", "Nyaa no longer lists this torrent.")
    }
    if (response.status !== 200 || !response.body) {
        throw failure("unavailable", `Nyaa answered ${response.status}.`)
    }
    const html = response.body
    const titleMatch = html.match(/<h3 class="panel-title">\s*([\s\S]*?)\s*<\/h3>/)
    const title = titleMatch ? unescapeHTML(titleMatch[1].trim()) : ""
    const magnetMatch = html.match(/href="(magnet:\?[^"]+)"/)
    const magnet = magnetMatch ? unescapeHTML(magnetMatch[1]) : undefined
    const infoHashMatch = html.match(/<kbd[^>]*>([a-fA-F0-9]{40})<\/kbd>/)
    const infoHash = infoHashMatch ? infoHashMatch[1].toLowerCase() : undefined
    const uri =
        magnet ||
        (infoHash && title ? magnetURI(infoHash, title) : `https://nyaa.si/download/${id}.torrent`)
    if (!title || !uri) {
        throw failure("unavailable", "Nyaa returned an invalid torrent page.")
    }
    const opt: DownloadOption = {
        id: `nyaa-${id}`,
        name: title,
        kind: "torrent",
        uri,
        files: [],
        facts: [],
        availability: "available",
        eligible: true,
        reasons: [],
        confirmed: false,
    }
    if (magnet) opt.magnet = magnet
    opt.pageUrl = `https://nyaa.si/view/${id}`
    return opt
}

caye.register(provider, { acquisition: { find, resolve } })
