import type { DecisionObservation } from "../../../../packages/plugin-sdk/src/index"

const trackers = [
    "http://nyaa.tracker.wf:7777/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce",
]

export type RawTorrent = {
    id: number
    name: string
    link: string
    downloadUrl: string
    pubDate: string
    seeders: number
    leechers: number
    downloads: number
    infoHash: string
    size: number
}

export function unescapeHTML(str: string): string {
    return str
        .replace(/&amp;/g, "&")
        .replace(/&lt;/g, "<")
        .replace(/&gt;/g, ">")
        .replace(/&quot;/g, '"')
        .replace(/&#39;/g, "'")
        .replace(/&#34;/g, '"')
        .replace(/&#x27;/g, "'")
        .replace(/&#x2F;/g, "/")
        .replace(/&nbsp;/g, " ")
}

function getTag(xml: string, tag: string): string {
    const match = xml.match(new RegExp(`<${tag}[^>]*>([^<]*)</${tag}>`))
    return match ? match[1].trim() : ""
}

function getNyaaTag(xml: string, tag: string): string {
    const match = xml.match(new RegExp(`<nyaa:${tag}[^>]*>([^<]*)</nyaa:${tag}>`))
    return match ? match[1].trim() : ""
}

function parseSize(sizeStr: string): number {
    const match = sizeStr.match(/([\d.]+)\s*([KMGT]?i?B)/i)
    if (!match) return 0
    const size = parseFloat(match[1])
    const unit = match[2].toUpperCase()
    if (unit.endsWith("IB")) {
        if (unit.startsWith("M")) return Math.round(size * 1024 ** 2)
        if (unit.startsWith("G")) return Math.round(size * 1024 ** 3)
        if (unit.startsWith("T")) return Math.round(size * 1024 ** 4)
        return Math.round(size * 1024)
    }
    if (unit.startsWith("M")) return Math.round(size * 1000 ** 2)
    if (unit.startsWith("G")) return Math.round(size * 1000 ** 3)
    if (unit.startsWith("T")) return Math.round(size * 1000 ** 4)
    return Math.round(size * 1000)
}

export function magnetURI(infoHash: string, name: string): string {
    const list = trackers.map((tracker) => `&tr=${encodeURIComponent(tracker)}`).join("")
    return `magnet:?xt=urn:btih:${infoHash}&dn=${encodeURIComponent(name)}${list}`
}

export function parseRSS(rssText: string): RawTorrent[] {
    const items: RawTorrent[] = []
    const itemRegex = /<item>([\s\S]*?)<\/item>/g
    for (const match of rssText.matchAll(itemRegex)) {
        const itemXml = match[1]
        const name = unescapeHTML(getTag(itemXml, "title"))
        if (!name) continue
        const guid = getTag(itemXml, "guid")
        const idMatch = guid.match(/\/view\/(\d+)/)
        const id = idMatch ? parseInt(idMatch[1], 10) : 0
        if (!id) continue
        items.push({
            id,
            name,
            link: guid,
            downloadUrl: getTag(itemXml, "link"),
            pubDate: getTag(itemXml, "pubDate"),
            seeders: parseInt(getNyaaTag(itemXml, "seeders"), 10) || 0,
            leechers: parseInt(getNyaaTag(itemXml, "leechers"), 10) || 0,
            downloads: parseInt(getNyaaTag(itemXml, "downloads"), 10) || 0,
            infoHash: getNyaaTag(itemXml, "infoHash"),
            size: parseSize(getNyaaTag(itemXml, "size")),
        })
    }
    return items
}

export function fact(
    providerId: string,
    id: string,
    field: string,
    value: number,
): DecisionObservation {
    return {
        id,
        producerId: providerId,
        field,
        value: { kind: "number", number: value },
        locale: "",
        region: "",
        status: "complete",
        at: new Date().toISOString(),
    }
}
