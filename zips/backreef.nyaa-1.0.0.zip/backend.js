(() => {
  var __pow = Math.pow;
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve2, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve2(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/provider-source/src/errors.ts
  function failure(code, message) {
    const error = new Error(message);
    error.code = code;
    return error;
  }

  // src/nyaa.ts
  var trackers = [
    "http://nyaa.tracker.wf:7777/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce"
  ];
  function unescapeHTML(str) {
    return str.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#34;/g, '"').replace(/&#x27;/g, "'").replace(/&#x2F;/g, "/").replace(/&nbsp;/g, " ");
  }
  function getTag(xml, tag) {
    const match = xml.match(new RegExp(`<${tag}[^>]*>([^<]*)</${tag}>`));
    return match ? match[1].trim() : "";
  }
  function getNyaaTag(xml, tag) {
    const match = xml.match(new RegExp(`<nyaa:${tag}[^>]*>([^<]*)</nyaa:${tag}>`));
    return match ? match[1].trim() : "";
  }
  function parseSize(sizeStr) {
    const match = sizeStr.match(/([\d.]+)\s*([KMGT]?i?B)/i);
    if (!match) return 0;
    const size = parseFloat(match[1]);
    const unit = match[2].toUpperCase();
    if (unit.endsWith("IB")) {
      if (unit.startsWith("M")) return Math.round(size * __pow(1024, 2));
      if (unit.startsWith("G")) return Math.round(size * __pow(1024, 3));
      if (unit.startsWith("T")) return Math.round(size * __pow(1024, 4));
      return Math.round(size * 1024);
    }
    if (unit.startsWith("M")) return Math.round(size * __pow(1e3, 2));
    if (unit.startsWith("G")) return Math.round(size * __pow(1e3, 3));
    if (unit.startsWith("T")) return Math.round(size * __pow(1e3, 4));
    return Math.round(size * 1e3);
  }
  function magnetURI(infoHash, name) {
    const list = trackers.map((tracker) => `&tr=${encodeURIComponent(tracker)}`).join("");
    return `magnet:?xt=urn:btih:${infoHash}&dn=${encodeURIComponent(name)}${list}`;
  }
  function parseRSS(rssText) {
    const items = [];
    const itemRegex = /<item>([\s\S]*?)<\/item>/g;
    for (const match of rssText.matchAll(itemRegex)) {
      const itemXml = match[1];
      const name = unescapeHTML(getTag(itemXml, "title"));
      if (!name) continue;
      const guid = getTag(itemXml, "guid");
      const idMatch = guid.match(/\/view\/(\d+)/);
      const id = idMatch ? parseInt(idMatch[1], 10) : 0;
      if (!id) continue;
      items.push({
        id,
        name,
        link: guid,
        downloadUrl: getTag(itemXml, "link"),
        pubDate: getTag(itemXml, "pubDate"),
        seeders: parseInt(getNyaaTag(itemXml, "seeders"), 10) || 0,
        leechers: parseInt(getNyaaTag(itemXml, "leechers"), 10) || 0,
        downloads: parseInt(getNyaaTag(itemXml, "downloads"), 10) || 0,
        infoHash: getNyaaTag(itemXml, "infoHash"),
        size: parseSize(getNyaaTag(itemXml, "size"))
      });
    }
    return items;
  }
  function fact(providerId, id, field, value) {
    return {
      id,
      producerId: providerId,
      field,
      value: { kind: "number", number: value },
      locale: "",
      region: "",
      status: "complete",
      at: (/* @__PURE__ */ new Date()).toISOString()
    };
  }

  // src/backend.ts
  var provider = "backreef.nyaa:search";
  var rssEndpoint = "https://nyaa.si/";
  var cacheSeconds = 7 * 24 * 60 * 60;
  function text(value) {
    return { kind: "text", text: value };
  }
  function titleVariants(raw) {
    const clean = raw.replace(/[()[\]{}|"'~?\\^!]/g, "").replace(/\s+/g, " ").trim();
    if (!clean) return [];
    const variants = [clean];
    const colonIdx = clean.indexOf(":");
    if (colonIdx > 4) {
      variants.push(clean.substring(0, colonIdx).trim());
    }
    const dashIdx = clean.indexOf(" - ");
    if (dashIdx > 4) {
      variants.push(clean.substring(0, dashIdx).trim());
    }
    const stripped = clean.replace(/\s+(?:The\s+)?Final(?:\s+Season)?$/i, "").replace(/\s+Final$/i, "").replace(/\s+Season\s+\d+$/i, "").replace(/\s+\d+(?:st|nd|rd|th)\s+Season$/i, "").replace(/\s+Part\s+\d+$/i, "").replace(/\s+(?:II|III|IV|V|VI|VII|VIII|IX|X)$/i, "").trim();
    if (stripped && stripped !== clean && stripped.length >= 4) {
      variants.push(stripped);
    }
    return Array.from(new Set(variants));
  }
  function episodeGroup(ep, season) {
    const padded = String(ep).padStart(2, "0");
    const terms = [padded, `E${padded}`, `EP${padded}`, `EP${ep}`];
    if (season && season > 0) {
      const sPadded = String(season).padStart(2, "0");
      terms.push(`S${sPadded}E${padded}`);
    }
    return `(${Array.from(new Set(terms)).join("|")})`;
  }
  function buildSmartQueries(query) {
    var _a;
    const text2 = ((_a = query.text) == null ? void 0 : _a.trim()) || "";
    const variants = titleVariants(text2);
    if (variants.length === 0) return [];
    const resStr = query.resolution ? ` ${query.resolution}` : "";
    const queries = [];
    if (query.batch) {
      for (const title of variants) {
        queries.push({
          query: `${title} (Batch|Complete)${resStr}`,
          sortBy: "size"
        });
        if (query.season && query.season > 1) {
          queries.push({
            query: `${title} Season ${query.season} (Batch|Complete)${resStr}`,
            sortBy: "size"
          });
        }
        queries.push({ query: `${title}${resStr}`, sortBy: "size" });
      }
    } else if (query.number !== void 0 && query.number > 0) {
      const epGroup = episodeGroup(query.number, query.season);
      for (const title of variants) {
        queries.push({
          query: `${title} ${epGroup}${resStr}`,
          sortBy: "seeders"
        });
        if (query.season && query.season > 1) {
          queries.push({
            query: `${title} Season ${query.season} ${epGroup}${resStr}`,
            sortBy: "seeders"
          });
        }
      }
      if (query.absolute !== void 0 && query.absolute > 0 && query.absolute !== query.number) {
        const absGroup = episodeGroup(query.absolute);
        for (const title of variants) {
          queries.push({
            query: `${title} ${absGroup}${resStr}`,
            sortBy: "seeders"
          });
        }
      }
    } else {
      for (const title of variants) {
        queries.push({ query: `${title}${resStr}`, sortBy: "seeders" });
      }
    }
    const seen = /* @__PURE__ */ new Set();
    const unique = [];
    for (const q of queries) {
      const key = `${q.query}|${q.sortBy}`;
      if (!seen.has(key)) {
        seen.add(key);
        unique.push(q);
      }
      if (unique.length >= 5) break;
    }
    return unique;
  }
  function toOption(item, confirmed) {
    const magnet = item.infoHash ? magnetURI(item.infoHash, item.name) : void 0;
    const uri = magnet || item.downloadUrl || item.link;
    const facts = [];
    if (item.size > 0) {
      facts.push(fact(provider, `size-${item.id}`, "size", item.size));
    }
    if (item.seeders >= 0) {
      facts.push(fact(provider, `seeders-${item.id}`, "seeders", item.seeders));
    }
    if (item.leechers >= 0) {
      facts.push(fact(provider, `leechers-${item.id}`, "leechers", item.leechers));
    }
    if (item.downloads > 0) {
      facts.push(fact(provider, `downloads-${item.id}`, "downloads", item.downloads));
    }
    let publishedAt;
    if (item.pubDate) {
      try {
        const d = new Date(item.pubDate);
        if (!isNaN(d.getTime())) publishedAt = d.toISOString();
      } catch (e) {
      }
    }
    const opt = {
      id: `nyaa-${item.id}`,
      name: item.name,
      kind: "torrent",
      uri,
      files: [],
      facts,
      availability: "available",
      eligible: true,
      reasons: [],
      confirmed,
      seeders: item.seeders,
      size: item.size > 0 ? item.size : void 0
    };
    if (publishedAt) opt.publishedAt = publishedAt;
    if (item.link.startsWith("https://")) opt.pageUrl = item.link;
    if (magnet) opt.magnet = magnet;
    return opt;
  }
  function search(q, sortBy) {
    return __async(this, null, function* () {
      const params = [
        "page=rss",
        `q=${encodeURIComponent(q)}`,
        "c=1_2",
        "f=0",
        `s=${encodeURIComponent(sortBy)}`,
        "o=desc"
      ].join("&");
      const response = yield caye.http({
        url: `${rssEndpoint}?${params}`,
        method: "GET",
        headers: { Accept: "application/rss+xml, application/xml, text/xml" }
      });
      if (response.status !== 200 || !response.body) {
        throw failure("unavailable", `Nyaa answered ${response.status}.`);
      }
      return parseRSS(response.body);
    });
  }
  function find(_context, query) {
    return __async(this, null, function* () {
      var _a;
      const textStr = (_a = query.text) == null ? void 0 : _a.trim();
      if (!textStr) {
        throw failure("unsupported", "Enter a title to search.");
      }
      const smartQueries = buildSmartQueries(query);
      const seen = /* @__PURE__ */ new Set();
      const items = [];
      const limit = Math.min(Math.max(query.limit || 50, 1), 100);
      for (const sq of smartQueries) {
        const results = yield search(sq.query, sq.sortBy);
        for (const raw of results) {
          if (seen.has(raw.id)) continue;
          seen.add(raw.id);
          const opt = toOption(raw, !query.batch && query.number !== void 0);
          items.push(opt);
          yield caye.cache.set({
            key: `nyaa:option:${raw.id}`,
            value: text(JSON.stringify(opt)),
            ttlSeconds: cacheSeconds
          });
          if (items.length >= limit) break;
        }
        if (items.length >= limit) break;
      }
      return { items, state: "complete" };
    });
  }
  function resolve(_context, input) {
    return __async(this, null, function* () {
      var _a;
      const match = /^nyaa-([1-9][0-9]*)$/.exec((_a = input.optionId) != null ? _a : "");
      if (!match) throw failure("missing", "Unknown Nyaa option.");
      const id = match[1];
      const cached = yield caye.cache.get({ key: `nyaa:option:${id}` });
      if ((cached == null ? void 0 : cached.kind) === "text") {
        try {
          return JSON.parse(cached.text);
        } catch (e) {
        }
      }
      const response = yield caye.http({
        url: `https://nyaa.si/view/${id}`,
        method: "GET",
        headers: { Accept: "text/html" }
      });
      if (response.status === 404) {
        throw failure("missing", "Nyaa no longer lists this torrent.");
      }
      if (response.status !== 200 || !response.body) {
        throw failure("unavailable", `Nyaa answered ${response.status}.`);
      }
      const html = response.body;
      const titleMatch = html.match(/<h3 class="panel-title">\s*([\s\S]*?)\s*<\/h3>/);
      const title = titleMatch ? unescapeHTML(titleMatch[1].trim()) : "";
      const magnetMatch = html.match(/href="(magnet:\?[^"]+)"/);
      const magnet = magnetMatch ? unescapeHTML(magnetMatch[1]) : void 0;
      const infoHashMatch = html.match(/<kbd[^>]*>([a-fA-F0-9]{40})<\/kbd>/);
      const infoHash = infoHashMatch ? infoHashMatch[1].toLowerCase() : void 0;
      const uri = magnet || (infoHash && title ? magnetURI(infoHash, title) : `https://nyaa.si/download/${id}.torrent`);
      if (!title || !uri) {
        throw failure("unavailable", "Nyaa returned an invalid torrent page.");
      }
      const opt = {
        id: `nyaa-${id}`,
        name: title,
        kind: "torrent",
        uri,
        files: [],
        facts: [],
        availability: "available",
        eligible: true,
        reasons: [],
        confirmed: false
      };
      if (magnet) opt.magnet = magnet;
      opt.pageUrl = `https://nyaa.si/view/${id}`;
      return opt;
    });
  }
  caye.register(provider, { acquisition: { find, resolve } });
})();
//# sourceMappingURL=backend.js.map
