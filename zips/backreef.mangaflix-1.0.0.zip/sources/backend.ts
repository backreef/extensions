import type { API, Ref, SourceRecord } from "../../../../packages/plugin-sdk/src/index.ts"
import {
    buildChapterList,
    createMangaSource,
    fetchJson,
    makeDirectPageResolver,
    parseChapterNumber,
    parseYear,
    type ParsedChapterInput,
    type RawPageInput,
} from "../../manga-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const providerId = "backreef.mangaflix:source"
const providerName = "MangaFlix"
const baseUrl = "https://mangaflix.net"
const apiUrl = "https://api.mangaflix.net/v1"
const chapterLanguage = "pt-BR"

type FlixMangaItem = {
    _id?: string
    name?: string
    year?: number | string
    release_year?: number | string
    createdAt?: string
}

type FlixSearchResponse = {
    data?: {
        works?: FlixMangaItem[]
    }
}

type FlixLatestResponse = {
    data?: FlixMangaItem[]
}

type FlixDetailResponse = {
    data?: FlixMangaItem & {
        chapters?: {
            _id?: string
            name?: string
            number?: string | number
            owners?: { name?: string }[]
        }[]
    }
}

type FlixChapterResponse = {
    data?: {
        images?: {
            default_url?: string
        }[]
    }
}

function toRecord(item: FlixMangaItem): SourceRecord | undefined {
    const id = item._id?.trim() ?? ""
    const name = item.name?.trim() ?? ""
    if (!id || !name) return undefined
    const year = parseYear(item.year ?? item.release_year ?? item.createdAt)
    return {
        ref: { providerId, type: "manga", nativeId: id },
        name,
        ...(year !== undefined ? { year } : {}),
    }
}

async function findPages(_context: unknown, ref: Ref): Promise<RawPageInput[]> {
    const url = new URL(`${apiUrl}/chapters/${encodeURIComponent(ref.nativeId)}`)
    url.searchParams.set("selected_language", "pt-br")
    const { data } = await fetchJson<FlixChapterResponse>(providerName, url.toString())
    const images = data.data?.images
    if (!Array.isArray(images)) {
        throw failure("unavailable", `${providerName} returned unexpected chapter images payload.`)
    }
    return images.flatMap((img) => {
        const imageUrl = img.default_url?.trim() ?? ""
        return imageUrl ? [{ url: imageUrl }] : []
    })
}

const mangaflixSource = createMangaSource({
    providerId,
    providerName,

    async search(_context, text) {
        const url = new URL(`${apiUrl}/search/mangas`)
        url.searchParams.set("query", text)
        url.searchParams.set("selected_language", "pt-br")
        const { data } = await fetchJson<FlixSearchResponse>(providerName, url.toString())
        if (!Array.isArray(data.data?.works)) {
            throw failure("unavailable", `${providerName} returned unexpected search payload.`)
        }

        let items = data.data.works
        if (items.length === 0) {
            const latestUrl = new URL(`${apiUrl}/latest-releases`)
            latestUrl.searchParams.set("selected_language", "pt-br")
            const latest = await fetchJson<FlixLatestResponse>(providerName, latestUrl.toString())
            if (Array.isArray(latest.data.data)) {
                const needle = text.toLowerCase()
                items = latest.data.data.filter((item) =>
                    (item.name ?? "").toLowerCase().includes(needle),
                )
            }
        }

        const seen = new Set<string>()
        const records: SourceRecord[] = []
        for (const item of items) {
            const rec = toRecord(item)
            if (!rec || seen.has(rec.ref.nativeId)) continue
            seen.add(rec.ref.nativeId)
            records.push(rec)
        }
        return records
    },

    async read(_context, ref) {
        const { data } = await fetchJson<FlixDetailResponse>(
            providerName,
            `${apiUrl}/mangas/${encodeURIComponent(ref.nativeId)}`,
        )
        const work = data.data
        if (!work?.name?.trim()) {
            throw failure("unavailable", `${providerName} title not found.`)
        }
        return {
            name: work.name.trim(),
            year: parseYear(work.year ?? work.release_year ?? work.createdAt),
        }
    },

    async list(_context, ref) {
        const { data } = await fetchJson<FlixDetailResponse>(
            providerName,
            `${apiUrl}/mangas/${encodeURIComponent(ref.nativeId)}`,
        )
        const chapters = data.data?.chapters
        if (!Array.isArray(chapters)) {
            throw failure("unavailable", `${providerName} returned unexpected chapters payload.`)
        }
        const entries: ParsedChapterInput[] = chapters.flatMap((ch) => {
            const chapterId = ch._id?.trim() ?? ""
            if (!chapterId) return []
            const number = parseChapterNumber(ch.number ?? ch.name)
            const explicitName = ch.name?.trim() ?? ""
            const name = explicitName || (number !== undefined ? `Capítulo ${number}` : undefined)
            const owners = Array.isArray(ch.owners)
                ? Array.from(new Set(ch.owners.map((o) => o?.name?.trim() ?? "").filter(Boolean)))
                : []
            return [
                {
                    nativeId: chapterId,
                    name,
                    number,
                    language: chapterLanguage,
                    ...(owners.length > 0 ? { scanlator: owners.join(", ") } : {}),
                },
            ]
        })
        return buildChapterList(providerId, entries, { reverse: true, sortByNumber: true })
    },

    findPages,

    resolveTarget: makeDirectPageResolver(() => ({ Referer: `${baseUrl}/` }), findPages),
})

caye.register(providerId, { source: mangaflixSource })
