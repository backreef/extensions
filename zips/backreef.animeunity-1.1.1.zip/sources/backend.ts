import type {
    API,
    Context,
    Query,
    Ref,
    Source,
    SourceInstallment,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
    SourceResolveInput,
} from "../../../../packages/plugin-sdk/src/index"
import {
    extractFirstYear,
    firstText,
    futureDeadline,
    limitItems,
    parseEpisodeNumber,
    sameRef,
    streamOriginOf,
    videoRef,
} from "../../stream-common/src/common"
import { failure, httpClient } from "../../../../packages/plugin-std/src/http.ts"
import { cleanBaseUrl, resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.animeunity:source"
const providerName = "AnimeUnity"
const site = httpClient(caye, providerName)
const defaultBaseUrl = "https://animeunity.ch"

function siteBase(context: Context): string {
    return cleanBaseUrl(context?.config?.url, defaultBaseUrl)
}

function pathOf(rawUrl: string, base: string): string {
    const resolved = resolveUrl(rawUrl, base)
    if (!resolved) return ""
    try {
        return new URL(resolved).pathname.replace(/^\/+|\/+$/g, "")
    } catch {
        return ""
    }
}

async function resolveEpisodeStream(base: string, epPath: string): Promise<string> {
    const epUrl = `${base}/${epPath}/`
    const html = await site.text({ url: epUrl, headers: { Referer: `${base}/` } })
    const doc = caye.html.parse(html)
    let embedSrc = ""
    doc.find("iframe[src]").each((_i, el) => {
        if (embedSrc) return
        const src = (el.attr("src") ?? "").trim()
        if (src.includes("anixo.net/embed.html") || src.includes("embed.html?data=")) {
            embedSrc = resolveUrl(caye.html.unescape(src), epUrl)
        }
    })
    if (!embedSrc) {
        throw failure("unavailable", `${providerName} video embed was not found`)
    }
    const encodedData = new URL(embedSrc).searchParams.get("data") ?? ""
    if (!encodedData) {
        throw failure("unavailable", `${providerName} embed data parameter was missing`)
    }
    let decodedUrl = ""
    try {
        decodedUrl = caye.encoding.utf8.decode(caye.encoding.base64.decode(encodedData)).trim()
    } catch {
        throw failure("unavailable", `${providerName} stream payload could not be decoded`)
    }
    const streamUrl = resolveUrl(decodedUrl, embedSrc)
    if (!streamUrl) {
        throw failure("unavailable", `${providerName} decoded stream URL is invalid`)
    }
    return streamUrl
}

caye.register(providerId, {
    source: {
        async search(context: Context, query: Query): Promise<SourceRecords> {
            const base = siteBase(context)
            const q = (query?.q ?? "").trim()
            if (!q) return { items: [], nextCursor: "", state: "complete" }
            const url = new URL("/", base)
            url.searchParams.set("s", q)
            const html = await site.text({ url: url.toString() })
            const doc = caye.html.parse(html)
            const items: SourceRecord[] = []
            const seen = new Set<string>()
            doc.find("article.bs").each((_i, el) => {
                const anchor = el.find("a").first()
                const href = (anchor.attr("href") ?? "").trim()
                const slugMatch = /\/anime\/([^/?#]+)\/?/.exec(href)
                const slug = slugMatch?.[1] ?? ""
                const title = (anchor.attr("title") || el.find(".tt").first().text()).trim()
                if (!slug || !title || slug.length > 200 || seen.has(slug)) return
                seen.add(slug)
                const year = extractFirstYear(title)
                items.push({
                    ref: videoRef(providerId, slug),
                    name: title,
                    ...(year !== undefined ? { year } : {}),
                })
            })
            return {
                items: limitItems(items, query?.limit),
                nextCursor: "",
                state: "complete",
            }
        },

        async read(context: Context, ref: Ref): Promise<SourceRecord> {
            const base = siteBase(context)
            const slug = ref.nativeId.split("/").pop() ?? ref.nativeId
            const html = await site.text({ url: `${base}/anime/${encodeURIComponent(slug)}/` })
            const doc = caye.html.parse(html)
            const name = firstText(doc, ["h1.entry-title", "h1", "title"])
                .replace(/\s*[-|]\s*AnimeUnity.*$/i, "")
                .trim()
            if (!name) {
                throw failure("unavailable", `${providerName} title was not found`)
            }
            const year = extractFirstYear(name)
            return {
                ref: sameRef(ref),
                name,
                ...(year !== undefined ? { year } : {}),
            }
        },

        async list(context: Context, ref: Ref): Promise<SourceListResult> {
            const base = siteBase(context)
            const slug = ref.nativeId.split("/").pop() ?? ref.nativeId
            const html = await site.text({ url: `${base}/anime/${encodeURIComponent(slug)}/` })
            const doc = caye.html.parse(html)
            const installments: SourceInstallment[] = []
            const seen = new Set<string>()
            doc.find("li[data-index]").each((_i, el) => {
                const anchor = el.find("a").first()
                const href = (anchor.attr("href") ?? "").trim()
                const epPath = pathOf(href, base)
                const num = parseEpisodeNumber(el.find(".epl-num").first().text())
                if (!epPath || num === undefined || epPath.length > 200 || seen.has(epPath)) return
                seen.add(epPath)
                const epTitle = el.find(".epl-title").first().text().trim()
                installments.push({
                    number: num,
                    name: epTitle ? epTitle.slice(0, 500) : `Episode ${num}`,
                    ref: videoRef(providerId, epPath),
                })
            })
            installments.sort((a, b) => a.number - b.number)
            return {
                installments,
                choices: {
                    audio: [{ id: "sub", label: "Sub" }],
                    server: [{ id: "animeunity", label: "AnimeUnity" }],
                    quality: [{ id: "auto", label: "Auto" }],
                },
            }
        },

        async find(context: Context, ref: Ref): Promise<SourcePage> {
            const base = siteBase(context)
            const streamUrl = await resolveEpisodeStream(base, ref.nativeId)
            return {
                items: [
                    {
                        id: "sub:animeunity",
                        origin: streamOriginOf(streamUrl),
                        capabilities: ["video"],
                        expiresAt: futureDeadline(context?.deadline),
                        tracks: [
                            {
                                id: "main",
                                kind: "video",
                                language: "it",
                                label: "Sub · AnimeUnity",
                            },
                        ],
                        ranges: [],
                        choices: {
                            audio: "sub",
                            server: "animeunity",
                            quality: "auto",
                        },
                    },
                ],
                state: "complete",
            }
        },

        async resolve(context: Context, input: SourceResolveInput): Promise<Source> {
            const base = siteBase(context)
            const streamUrl = await resolveEpisodeStream(base, input.ref.nativeId)
            const handle = await site.handle(streamUrl)
            return {
                id: input.sourceId,
                origin: streamOriginOf(streamUrl),
                capabilities: ["video"],
                expiresAt: handle.expiresAt,
                handle,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: "it",
                        label: "Sub · AnimeUnity",
                    },
                ],
                ranges: [],
                choices: {
                    audio: "sub",
                    server: "animeunity",
                    quality: "auto",
                },
            }
        },
    },
})
