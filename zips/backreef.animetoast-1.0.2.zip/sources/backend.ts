import type {
    API,
    Context,
    Query,
    Ref,
    Source,
    SourceChoiceDef,
    SourceInstallment,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
    SourceResolveInput,
} from "../../../../packages/plugin-sdk/src/index"
import { pooled } from "../../../../packages/provider-source/src/concurrency"
import {
    choiceId,
    extractFirstYear,
    firstText,
    futureDeadline,
    limitItems,
    parseEpisodeNumber,
    sameRef,
    streamOriginOf,
    uniqueChoices,
    videoRef,
} from "../../stream-common/src/common"
import {
    extractMp4Upload,
    extractVoe,
    type ExtractedStream,
} from "../../stream-common/src/extractors"
import { failure, httpClient } from "../../../../packages/plugin-std/src/http.ts"
import { cleanBaseUrl, resolveUrl } from "../../../../packages/plugin-std/src/url.ts"

declare const caye: API

const providerId = "backreef.animetoast:source"
const providerName = "AnimeToast"
const site = httpClient(caye, providerName)
const defaultBaseUrl = "https://www.animetoast.cc"

type IframeLoaderConfig = {
    ajaxUrl: string
    nonce: string
    title: string
    servers: string[]
}

function siteBase(context: Context): string {
    return cleanBaseUrl(context?.config?.url, defaultBaseUrl)
}

function slugFromHref(href: string, base: string): string {
    const resolved = resolveUrl(href, base)
    if (!resolved) return ""
    try {
        return new URL(resolved).pathname.replace(/^\/+|\/+$/g, "")
    } catch {
        return ""
    }
}

function parseIframeLoader(html: string, base: string): IframeLoaderConfig | undefined {
    const doc = caye.html.parse(html)
    const player = doc.find(".simple-iframe-player").first()
    if (player.length === 0) return undefined
    const title = (player.attr("data-title") ?? "").trim()
    const cfgMatch = /iframe_loader\s*=\s*(\{[^}]+\})/.exec(html)
    if (!title || !cfgMatch) return undefined
    let ajaxUrl = ""
    let nonce = ""
    try {
        const parsed = JSON.parse(cfgMatch[1]) as { ajax_url?: string; nonce?: string }
        ajaxUrl = resolveUrl(parsed.ajax_url ?? "", base)
        nonce = (parsed.nonce ?? "").trim()
    } catch {
        return undefined
    }
    if (!ajaxUrl || !nonce) return undefined
    const servers: string[] = []
    player.find(".server-select option").each((_i, el) => {
        const val = (el.attr("value") ?? el.text()).trim()
        if (val) servers.push(val)
    })
    return { ajaxUrl, nonce, title, servers: servers.length > 0 ? servers : ["1"] }
}

async function fetchIframeEpisodes(
    cfg: IframeLoaderConfig,
    server: string,
    referer: string,
): Promise<Array<{ number: number; title?: string }>> {
    const body = new URLSearchParams({
        action: "get_episode_data",
        title: cfg.title,
        server,
        nonce: cfg.nonce,
    }).toString()
    const payload = await site.json<{
        success?: boolean
        data?: { episodes?: Array<{ number?: number | string; title?: string }> }
    }>({
        url: cfg.ajaxUrl,
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Referer: referer,
        },
        body,
    })
    const out: Array<{ number: number; title?: string }> = []
    for (const ep of payload?.data?.episodes ?? []) {
        const num = parseEpisodeNumber(ep?.number)
        if (num === undefined) continue
        out.push({ number: num, title: ep.title?.trim() || undefined })
    }
    return out.sort((a, b) => a.number - b.number)
}

async function fetchIframeEpisodeUrl(
    cfg: IframeLoaderConfig,
    server: string,
    episode: number,
    referer: string,
): Promise<string> {
    const body = new URLSearchParams({
        action: "get_episode_data",
        title: cfg.title,
        server,
        episode: String(episode),
        nonce: cfg.nonce,
    }).toString()
    const payload = await site.json<{
        success?: boolean
        data?: { url?: string }
    }>({
        url: cfg.ajaxUrl,
        method: "POST",
        headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
            Referer: referer,
        },
        body,
    })
    if (!payload?.success || !payload.data?.url) return ""
    return resolveUrl(payload.data.url, referer)
}

function parseServerTabs(html: string): Array<{ tabId: string; serverId: string; label: string }> {
    const doc = caye.html.parse(html)
    const out: Array<{ tabId: string; serverId: string; label: string }> = []
    doc.find('a[data-toggle="tab"]').each((_i, el) => {
        const href = (el.attr("href") ?? "").trim()
        const label = el.text().trim()
        const match = /^#multi_link_tab(\d+)$/.exec(href)
        if (!match || !label) return
        const lower = label.toLowerCase()
        if (!lower.includes("mp4upload") && !lower.includes("voe")) return
        out.push({
            tabId: match[1],
            serverId: lower.includes("mp4upload") ? "mp4upload" : "voe",
            label,
        })
    })
    return out
}

function extractTabLinks(
    html: string,
    tabId: string,
    base: string,
): Array<{ epNum: number; linkParam: string }> {
    const doc = caye.html.parse(html)
    const container = doc.find(`#multi_link_tab${tabId}`).first()
    const links: Array<{ epNum: number; linkParam: string }> = []
    const seen = new Set<number>()
    container.find('a[href*="?link="]').each((index, el) => {
        const href = (el.attr("href") ?? "").trim()
        const resolved = resolveUrl(href, base)
        if (!resolved) return
        const linkParam = new URL(resolved).searchParams.get("link") ?? ""
        if (!linkParam) return
        const text = el.text().trim()
        const epMatch = /Ep\.?\s*(\d+(?:\.\d+)?)/i.exec(text)
        const epNum = epMatch ? parseEpisodeNumber(epMatch[1]) : index + 1
        if (epNum === undefined || seen.has(epNum)) return
        seen.add(epNum)
        links.push({ epNum, linkParam })
    })
    return links.sort((a, b) => a.epNum - b.epNum)
}

function parseEpisodeNativeId(nativeId: string): { slug: string; epNum: number } {
    const sep = nativeId.lastIndexOf("|")
    if (sep <= 0 || sep >= nativeId.length - 1) {
        throw failure("unavailable", `${providerName} invalid episode reference`)
    }
    const epNum = parseEpisodeNumber(nativeId.slice(sep + 1))
    if (epNum === undefined) {
        throw failure("unavailable", `${providerName} invalid episode number`)
    }
    return { slug: nativeId.slice(0, sep), epNum }
}

function audioOfTitle(text: string): "dub" | "sub" {
    return /\bdub\b/i.test(text) ? "dub" : "sub"
}

async function extractFromEmbed(embedUrl: string, siteReferer: string): Promise<ExtractedStream[]> {
    if (/\.m3u8(?:[?#]|$)/i.test(embedUrl)) return [{ url: embedUrl, hint: "hls" }]
    if (/\.mp4(?:[?#]|$)/i.test(embedUrl)) return [{ url: embedUrl, hint: "mp4" }]
    if (embedUrl.toLowerCase().includes("mp4upload")) {
        return extractMp4Upload(caye, embedUrl, siteReferer, providerName)
    }
    const voe = await extractVoe(caye, embedUrl, providerName)
    if (voe.length > 0) return voe
    return extractMp4Upload(caye, embedUrl, siteReferer, providerName)
}

caye.register(providerId, {
    source: {
        async search(context: Context, query: Query): Promise<SourceRecords> {
            const base = siteBase(context)
            const q = (query?.q ?? "").trim()
            if (!q) return { items: [], nextCursor: "", state: "complete" }
            const url = new URL("/", base)
            url.searchParams.set("s", q)
            const html = await site.text({ url: url.toString() })
            const doc = caye.html.parse(html)
            const items: SourceRecord[] = []
            const seen = new Set<string>()
            doc.find('div[id^="post-"] h3 a').each((_i, el) => {
                const href = (el.attr("href") ?? "").trim()
                const rawTitle = el.text().trim()
                const slug = slugFromHref(href, base)
                if (!slug || !rawTitle || slug.length > 200 || seen.has(slug)) return
                seen.add(slug)
                const year = extractFirstYear(rawTitle)
                items.push({
                    ref: videoRef(providerId, slug),
                    name: rawTitle,
                    ...(year !== undefined ? { year } : {}),
                })
            })
            return {
                items: limitItems(items, query?.limit),
                nextCursor: "",
                state: "complete",
            }
        },

        async read(context: Context, ref: Ref): Promise<SourceRecord> {
            const base = siteBase(context)
            const slug = ref.nativeId.split("|")[0]
            const html = await site.text({ url: `${base}/${encodeURIComponent(slug)}/` })
            const doc = caye.html.parse(html)
            const rawTitle = firstText(doc, ["h1.entry-title", "h1", "title"])
                .replace(/\s*[-|]\s*AnimeToast.*$/i, "")
                .trim()
            if (!rawTitle) {
                throw failure("unavailable", `${providerName} title was not found`)
            }
            const year = extractFirstYear(rawTitle)
            return {
                ref: sameRef(ref),
                name: rawTitle,
                ...(year !== undefined ? { year } : {}),
            }
        },

        async list(context: Context, ref: Ref): Promise<SourceListResult> {
            const base = siteBase(context)
            const slug = ref.nativeId.split("|")[0]
            const pageUrl = `${base}/${encodeURIComponent(slug)}/`
            const html = await site.text({ url: pageUrl })
            const doc = caye.html.parse(html)
            const title = firstText(doc, ["h1.entry-title", "h1", "title"])
            const audio = audioOfTitle(`${slug} ${title}`)
            const audioChoice =
                audio === "dub" ? { id: "dub", label: "Ger Dub" } : { id: "sub", label: "Ger Sub" }

            const tabs = parseServerTabs(html)
            const tabInstallments = new Map<number, SourceInstallment>()
            const serverChoices: SourceChoiceDef[] = []
            for (const tab of tabs) {
                const links = extractTabLinks(html, tab.tabId, base)
                if (links.length === 0) continue
                serverChoices.push({ id: tab.serverId, label: tab.label })
                for (const link of links) {
                    if (!tabInstallments.has(link.epNum)) {
                        tabInstallments.set(link.epNum, {
                            number: link.epNum,
                            name: `Episode ${link.epNum}`,
                            ref: videoRef(providerId, `${slug}|${link.epNum}`),
                        })
                    }
                }
            }
            if (tabInstallments.size > 0) {
                return {
                    installments: [...tabInstallments.values()].sort((a, b) => a.number - b.number),
                    choices: {
                        audio: [audioChoice],
                        server: uniqueChoices(serverChoices),
                        quality: [{ id: "auto", label: "Auto" }],
                    },
                }
            }

            const loader = parseIframeLoader(html, base)
            if (loader) {
                const episodes = await fetchIframeEpisodes(loader, loader.servers[0], pageUrl)
                return {
                    installments: episodes.map((ep) => ({
                        number: ep.number,
                        name: (ep.title || `Episode ${ep.number}`).slice(0, 500),
                        ref: videoRef(providerId, `${slug}|${ep.number}`),
                    })),
                    choices: {
                        audio: [audioChoice],
                        server: uniqueChoices(
                            loader.servers.map((s) => ({
                                id: choiceId(`server-${s}`),
                                label: `Server ${s}`,
                            })),
                        ),
                        quality: [{ id: "auto", label: "Auto" }],
                    },
                }
            }

            return {
                installments: [],
                choices: {
                    audio: [audioChoice],
                    server: [{ id: "default", label: "Default" }],
                    quality: [{ id: "auto", label: "Auto" }],
                },
            }
        },

        async find(context: Context, ref: Ref): Promise<SourcePage> {
            const base = siteBase(context)
            const { slug, epNum } = parseEpisodeNativeId(ref.nativeId)
            const pageUrl = `${base}/${encodeURIComponent(slug)}/`
            const html = await site.text({ url: pageUrl })
            const title = firstText(caye.html.parse(html), ["h1.entry-title", "h1", "title"])
            const audio = audioOfTitle(`${slug} ${title}`)
            const deadline = futureDeadline(context?.deadline)
            const items: Source[] = []

            for (const tab of parseServerTabs(html)) {
                const match = extractTabLinks(html, tab.tabId, base).find((l) => l.epNum === epNum)
                if (!match) continue
                items.push({
                    id: `${audio}:${tab.serverId}:link:${match.linkParam}`,
                    origin: tab.serverId === "mp4upload" ? "http" : "hls",
                    capabilities: ["video"],
                    expiresAt: deadline,
                    tracks: [
                        {
                            id: "main",
                            kind: "video",
                            language: "de",
                            label: `${audio === "dub" ? "Ger Dub" : "Ger Sub"} · ${tab.label}`,
                        },
                    ],
                    ranges: [],
                    choices: {
                        audio,
                        server: tab.serverId,
                        quality: "auto",
                    },
                })
            }

            if (items.length === 0) {
                const loader = parseIframeLoader(html, base)
                if (loader) {
                    const resolvedServers = await pooled(loader.servers, 4, async (srv) => {
                        const embedUrl = await fetchIframeEpisodeUrl(loader, srv, epNum, pageUrl)
                        return { srv, embedUrl }
                    })
                    for (const { srv, embedUrl } of resolvedServers) {
                        if (!embedUrl) continue
                        const serverId = choiceId(`server-${srv}`)
                        items.push({
                            id: `${audio}:${serverId}:ajax:${srv}`,
                            origin: embedUrl.toLowerCase().includes("mp4upload") ? "http" : "hls",
                            capabilities: ["video"],
                            expiresAt: deadline,
                            tracks: [
                                {
                                    id: "main",
                                    kind: "video",
                                    language: "de",
                                    label: `${audio === "dub" ? "Ger Dub" : "Ger Sub"} · Server ${srv}`,
                                },
                            ],
                            ranges: [],
                            choices: {
                                audio,
                                server: serverId,
                                quality: "auto",
                            },
                        })
                    }
                }
            }

            return { items, state: "complete" }
        },

        async resolve(context: Context, input: SourceResolveInput): Promise<Source> {
            const base = siteBase(context)
            const { slug, epNum } = parseEpisodeNativeId(input.ref.nativeId)
            const [rawAudio, serverId, mode, token] = input.sourceId.split(":")
            const audio = rawAudio === "dub" ? "dub" : "sub"
            const pageUrl = `${base}/${encodeURIComponent(slug)}/`
            let embedUrl = ""
            let siteReferer = `${base}/`

            if (mode === "link" && token) {
                const epUrl = `${pageUrl}?link=${encodeURIComponent(token)}`
                siteReferer = epUrl
                const epHtml = await site.text({ url: epUrl })
                const doc = caye.html.parse(epHtml)
                doc.find("iframe[src]").each((_i, el) => {
                    if (embedUrl) return
                    const src = (el.attr("src") ?? "").trim()
                    if (src) embedUrl = resolveUrl(src, epUrl)
                })
            } else if (mode === "ajax" && token) {
                const pageHtml = await site.text({ url: pageUrl })
                const loader = parseIframeLoader(pageHtml, base)
                if (!loader) {
                    throw failure("unavailable", `${providerName} player config was not found`)
                }
                embedUrl = await fetchIframeEpisodeUrl(loader, token, epNum, pageUrl)
                siteReferer = pageUrl
            } else {
                throw failure("unavailable", `${providerName} invalid source identifier`)
            }

            if (!embedUrl) {
                throw failure("unavailable", `${providerName} embed URL was not found`)
            }
            const streams = await extractFromEmbed(embedUrl, siteReferer)
            const selected = streams[0]
            if (!selected) {
                throw failure("unavailable", `${providerName} stream could not be extracted`)
            }
            const handle = await site.handle({ url: selected.url, headers: selected.headers })
            return {
                id: input.sourceId,
                origin: streamOriginOf(selected.url, selected.hint),
                capabilities: ["video"],
                expiresAt: handle.expiresAt,
                handle,
                tracks: [
                    {
                        id: "main",
                        kind: "video",
                        language: "de",
                        label: `${audio === "dub" ? "Ger Dub" : "Ger Sub"} · ${serverId}`,
                    },
                ],
                ranges: [],
                choices: {
                    audio,
                    server: serverId,
                    quality: "auto",
                },
            }
        },
    },
})
