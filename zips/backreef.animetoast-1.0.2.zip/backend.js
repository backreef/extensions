(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/provider-source/src/concurrency.ts
  function pooled(values, size, fn) {
    return __async(this, null, function* () {
      const out = new Array(values.length);
      let next = 0;
      const run = () => __async(null, null, function* () {
        while (next < values.length) {
          const i = next++;
          out[i] = yield fn(values[i]);
        }
      });
      yield Promise.all(Array.from({ length: Math.min(size, values.length) }, run));
      return out;
    });
  }

  // ../../../packages/plugin-std/src/titles.ts
  var YEAR_PAREN_RE = /\((\d{4})\)/;
  var YEAR_STANDALONE_RE = /\b(19\d{2}|20\d{2})\b/;
  function extractYear(title) {
    const paren = title.match(YEAR_PAREN_RE);
    if (paren) {
      const year = Number.parseInt(paren[1], 10);
      if (year >= 1900 && year <= 2100) return year;
    }
    const standalone = title.match(YEAR_STANDALONE_RE);
    if (standalone) {
      return Number.parseInt(standalone[1], 10);
    }
    return -1;
  }
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../../../packages/plugin-std/src/url.ts
  function resolveUrl(raw, base) {
    const trimmed = raw.trim();
    if (!trimmed) return "";
    try {
      const url = new URL(trimmed.startsWith("//") ? `https:${trimmed}` : trimmed, base);
      return url.protocol === "http:" || url.protocol === "https:" ? url.toString() : "";
    } catch (e) {
      return "";
    }
  }
  function cleanBaseUrl(raw, fallback) {
    const resolved = resolveUrl(raw != null ? raw : "");
    if (!resolved) return fallback;
    const url = new URL(resolved);
    return url.origin + url.pathname.replace(/\/+$/, "");
  }

  // ../stream-common/src/common.ts
  function streamOriginOf(url, hint) {
    const lowerUrl = url.toLowerCase();
    const lowerHint = (hint != null ? hint : "").toLowerCase();
    if (lowerHint === "hls" || lowerHint === "m3u8" || /\.m3u8(\?|$|#)/.test(lowerUrl)) {
      return "hls";
    }
    return "http";
  }
  function choiceId(label, fallback = "default") {
    const slug = label.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 64);
    return slug || fallback;
  }
  function uniqueChoices(items) {
    const seen = /* @__PURE__ */ new Set();
    const out = [];
    for (const item of items) {
      if (!item.id || seen.has(item.id) || out.length >= 200) continue;
      seen.add(item.id);
      out.push({
        id: item.id.slice(0, 200),
        label: (item.label || item.id).slice(0, 200)
      });
    }
    return out;
  }
  function firstText(doc, selectors) {
    for (const selector of selectors) {
      const text = doc.find(selector).first().text().trim();
      if (text) return text;
    }
    return "";
  }
  function videoRef(providerId2, nativeId) {
    return {
      providerId: providerId2,
      type: "video",
      nativeId
    };
  }
  function sameRef(ref) {
    return ref.scope ? {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId,
      scope: ref.scope
    } : {
      providerId: ref.providerId,
      type: ref.type,
      nativeId: ref.nativeId
    };
  }
  function limitItems(items, limit) {
    if (typeof limit === "number" && Number.isFinite(limit) && limit > 0) {
      return items.slice(0, limit);
    }
    return items;
  }
  function futureDeadline(contextDeadline, minutes = 10) {
    const now = Date.now();
    if (contextDeadline) {
      const parsed = Date.parse(contextDeadline);
      if (Number.isFinite(parsed) && parsed > now + 5e3 && parsed <= now + 24 * 3600 * 1e3) {
        return contextDeadline;
      }
    }
    return new Date(now + minutes * 60 * 1e3).toISOString();
  }
  function parseEpisodeNumber(raw) {
    if (typeof raw === "number") {
      return Number.isFinite(raw) && raw >= 0 ? raw : void 0;
    }
    if (typeof raw !== "string") return void 0;
    const cleaned = raw.trim().replace(",", ".");
    if (!cleaned) return void 0;
    const match = /\d+(?:\.\d+)?/.exec(cleaned);
    if (!match) return void 0;
    const num = Number(match[0]);
    return Number.isFinite(num) && num >= 0 ? num : void 0;
  }
  function extractFirstYear(text) {
    const year = extractYear(text != null ? text : "");
    return year > 0 ? year : void 0;
  }

  // ../../../packages/plugin-std/src/unpack.ts
  var PACKER_RE = /eval\(function\(p,a,c,k,e,[dr]\)\{[\s\S]*?\}\s*\(\s*(['"])((?:\\.|(?!\1)[\s\S])*)\1\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*(['"])((?:\\.|(?!\5)[\s\S])*)\5\.split\((['"])\|\7\)(?:\s*,\s*\d+\s*,\s*\{\s*\})?\s*\)\)/;
  function unescapeJsString(raw) {
    let out = "";
    for (let i = 0; i < raw.length; i++) {
      const ch = raw[i];
      if (ch !== "\\" || i + 1 >= raw.length) {
        out += ch;
        continue;
      }
      const next = raw[i + 1];
      if (next === "x" && i + 3 < raw.length) {
        const hex = raw.slice(i + 2, i + 4);
        if (/^[0-9a-fA-F]{2}$/.test(hex)) {
          out += String.fromCharCode(Number.parseInt(hex, 16));
          i += 3;
          continue;
        }
      }
      if (next === "u" && i + 5 < raw.length) {
        const hex = raw.slice(i + 2, i + 6);
        if (/^[0-9a-fA-F]{4}$/.test(hex)) {
          out += String.fromCharCode(Number.parseInt(hex, 16));
          i += 5;
          continue;
        }
      }
      switch (next) {
        case "n":
          out += "\n";
          break;
        case "r":
          out += "\r";
          break;
        case "t":
          out += "	";
          break;
        case "\\":
          out += "\\";
          break;
        case "'":
          out += "'";
          break;
        case '"':
          out += '"';
          break;
        default:
          out += next;
          break;
      }
      i += 1;
    }
    return out;
  }
  function encodeBase(value, base) {
    const prefix = value < base ? "" : encodeBase(Math.floor(value / base), base);
    const rem = value % base;
    if (rem > 35) {
      return prefix + String.fromCharCode(rem + 29);
    }
    return prefix + rem.toString(36);
  }
  function isPacked(code) {
    return PACKER_RE.test(code);
  }
  function unpack(code) {
    const match = code.match(PACKER_RE);
    if (!match) return code;
    const payload = unescapeJsString(match[2]);
    const base = Number.parseInt(match[3], 10);
    const count = Number.parseInt(match[4], 10);
    const symtab = unescapeJsString(match[6]).split("|");
    if (!Number.isFinite(base) || base < 2 || base > 62 || symtab.length === 0) {
      return code;
    }
    const dict = /* @__PURE__ */ new Map();
    const limit = Math.min(count, symtab.length);
    for (let i = 0; i < limit; i++) {
      const key = encodeBase(i, base);
      const replacement = symtab[i];
      dict.set(key, replacement || key);
    }
    const unpacked = payload.replace(/\b[0-9A-Za-z]+\b/g, (word) => {
      var _a;
      return (_a = dict.get(word)) != null ? _a : word;
    });
    return code.slice(0, match.index) + unpacked + code.slice(match.index + match[0].length);
  }
  function unpackAll(code) {
    let current = code;
    for (let i = 0; i < 32; i++) {
      if (!isPacked(current)) break;
      const next = unpack(current);
      if (next === current) break;
      current = next;
    }
    return current;
  }

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../stream-common/src/extractors.ts
  var VOE_MARKERS = ["@$", "^^", "~@", "%?", "*~", "!!", "#&"];
  function unpackVoe(api, packed) {
    let text = packed.replace(/[a-zA-Z]/g, (c) => {
      const base = c <= "Z" ? 65 : 97;
      return String.fromCharCode((c.charCodeAt(0) - base + 13) % 26 + base);
    });
    for (const marker of VOE_MARKERS) {
      text = text.split(marker).join("");
    }
    const shifted = api.encoding.latin1.decode(api.encoding.base64.decode(text));
    let reversed = "";
    for (let i = shifted.length - 1; i >= 0; i--) {
      reversed += String.fromCharCode(shifted.charCodeAt(i) - 3);
    }
    return api.encoding.utf8.decode(api.encoding.base64.decode(reversed));
  }
  function voeStreamsFromHtml(api, html) {
    const doc = api.html.parse(html);
    const blob = doc.find('script[type="application/json"]').first().text().trim();
    if (!blob) return [];
    try {
      const packed = JSON.parse(blob);
      const first = Array.isArray(packed) ? packed[0] : packed;
      if (typeof first !== "string") return [];
      const info = JSON.parse(unpackVoe(api, first));
      if (info.source) return [{ url: info.source, hint: "hls" }];
      if (info.direct_access_url) return [{ url: info.direct_access_url, hint: "mp4" }];
    } catch (e) {
    }
    return [];
  }
  function extractVoe(api, embedUrl, providerName2) {
    return __async(this, null, function* () {
      const site2 = httpClient(api, providerName2);
      let html = yield site2.text(embedUrl);
      const hasJsonScript = api.html.parse(html).find('script[type="application/json"]').length > 0;
      if (!hasJsonScript) {
        const hop = /window\.location\.href\s*=\s*['"](https?:\/\/[^'"]+)['"]/.exec(html);
        if (hop) {
          html = yield site2.text(hop[1]);
        }
      }
      return voeStreamsFromHtml(api, html);
    });
  }
  function extractMp4Upload(api, embedUrl, referer, providerName2) {
    return __async(this, null, function* () {
      const html = yield httpClient(api, providerName2).text({
        url: embedUrl,
        headers: { Referer: referer }
      });
      const doc = api.html.parse(html);
      let foundUrl = "";
      const matchIn = (body) => {
        var _a;
        const m = (_a = /src:\s*"([^"]+\.mp4[^"]*)"/i.exec(body)) != null ? _a : /"src"\s*:\s*"([^"]+\.mp4[^"]*)"/i.exec(body);
        return m ? m[1].replace(/\\\//g, "/") : "";
      };
      doc.find("script").each((_i, el) => {
        if (foundUrl) return;
        foundUrl = matchIn(unpackAll(el.text()));
      });
      if (!foundUrl) foundUrl = matchIn(html);
      const resolved = foundUrl ? resolveUrl(foundUrl, embedUrl) : "";
      return resolved ? [{ url: resolved, headers: { Referer: "https://www.mp4upload.com/" }, hint: "mp4" }] : [];
    });
  }

  // src/backend.ts
  var providerId = "backreef.animetoast:source";
  var providerName = "AnimeToast";
  var site = httpClient(caye, providerName);
  var defaultBaseUrl = "https://www.animetoast.cc";
  function siteBase(context) {
    var _a;
    return cleanBaseUrl((_a = context == null ? void 0 : context.config) == null ? void 0 : _a.url, defaultBaseUrl);
  }
  function slugFromHref(href, base) {
    const resolved = resolveUrl(href, base);
    if (!resolved) return "";
    try {
      return new URL(resolved).pathname.replace(/^\/+|\/+$/g, "");
    } catch (e) {
      return "";
    }
  }
  function parseIframeLoader(html, base) {
    var _a, _b, _c;
    const doc = caye.html.parse(html);
    const player = doc.find(".simple-iframe-player").first();
    if (player.length === 0) return void 0;
    const title = ((_a = player.attr("data-title")) != null ? _a : "").trim();
    const cfgMatch = /iframe_loader\s*=\s*(\{[^}]+\})/.exec(html);
    if (!title || !cfgMatch) return void 0;
    let ajaxUrl = "";
    let nonce = "";
    try {
      const parsed = JSON.parse(cfgMatch[1]);
      ajaxUrl = resolveUrl((_b = parsed.ajax_url) != null ? _b : "", base);
      nonce = ((_c = parsed.nonce) != null ? _c : "").trim();
    } catch (e) {
      return void 0;
    }
    if (!ajaxUrl || !nonce) return void 0;
    const servers = [];
    player.find(".server-select option").each((_i, el) => {
      var _a2;
      const val = ((_a2 = el.attr("value")) != null ? _a2 : el.text()).trim();
      if (val) servers.push(val);
    });
    return { ajaxUrl, nonce, title, servers: servers.length > 0 ? servers : ["1"] };
  }
  function fetchIframeEpisodes(cfg, server, referer) {
    return __async(this, null, function* () {
      var _a, _b, _c;
      const body = new URLSearchParams({
        action: "get_episode_data",
        title: cfg.title,
        server,
        nonce: cfg.nonce
      }).toString();
      const payload = yield site.json({
        url: cfg.ajaxUrl,
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          Referer: referer
        },
        body
      });
      const out = [];
      for (const ep of (_b = (_a = payload == null ? void 0 : payload.data) == null ? void 0 : _a.episodes) != null ? _b : []) {
        const num = parseEpisodeNumber(ep == null ? void 0 : ep.number);
        if (num === void 0) continue;
        out.push({ number: num, title: ((_c = ep.title) == null ? void 0 : _c.trim()) || void 0 });
      }
      return out.sort((a, b) => a.number - b.number);
    });
  }
  function fetchIframeEpisodeUrl(cfg, server, episode, referer) {
    return __async(this, null, function* () {
      var _a;
      const body = new URLSearchParams({
        action: "get_episode_data",
        title: cfg.title,
        server,
        episode: String(episode),
        nonce: cfg.nonce
      }).toString();
      const payload = yield site.json({
        url: cfg.ajaxUrl,
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
          Referer: referer
        },
        body
      });
      if (!(payload == null ? void 0 : payload.success) || !((_a = payload.data) == null ? void 0 : _a.url)) return "";
      return resolveUrl(payload.data.url, referer);
    });
  }
  function parseServerTabs(html) {
    const doc = caye.html.parse(html);
    const out = [];
    doc.find('a[data-toggle="tab"]').each((_i, el) => {
      var _a;
      const href = ((_a = el.attr("href")) != null ? _a : "").trim();
      const label = el.text().trim();
      const match = /^#multi_link_tab(\d+)$/.exec(href);
      if (!match || !label) return;
      const lower = label.toLowerCase();
      if (!lower.includes("mp4upload") && !lower.includes("voe")) return;
      out.push({
        tabId: match[1],
        serverId: lower.includes("mp4upload") ? "mp4upload" : "voe",
        label
      });
    });
    return out;
  }
  function extractTabLinks(html, tabId, base) {
    const doc = caye.html.parse(html);
    const container = doc.find(`#multi_link_tab${tabId}`).first();
    const links = [];
    const seen = /* @__PURE__ */ new Set();
    container.find('a[href*="?link="]').each((index, el) => {
      var _a, _b;
      const href = ((_a = el.attr("href")) != null ? _a : "").trim();
      const resolved = resolveUrl(href, base);
      if (!resolved) return;
      const linkParam = (_b = new URL(resolved).searchParams.get("link")) != null ? _b : "";
      if (!linkParam) return;
      const text = el.text().trim();
      const epMatch = /Ep\.?\s*(\d+(?:\.\d+)?)/i.exec(text);
      const epNum = epMatch ? parseEpisodeNumber(epMatch[1]) : index + 1;
      if (epNum === void 0 || seen.has(epNum)) return;
      seen.add(epNum);
      links.push({ epNum, linkParam });
    });
    return links.sort((a, b) => a.epNum - b.epNum);
  }
  function parseEpisodeNativeId(nativeId) {
    const sep = nativeId.lastIndexOf("|");
    if (sep <= 0 || sep >= nativeId.length - 1) {
      throw failure("unavailable", `${providerName} invalid episode reference`);
    }
    const epNum = parseEpisodeNumber(nativeId.slice(sep + 1));
    if (epNum === void 0) {
      throw failure("unavailable", `${providerName} invalid episode number`);
    }
    return { slug: nativeId.slice(0, sep), epNum };
  }
  function audioOfTitle(text) {
    return /\bdub\b/i.test(text) ? "dub" : "sub";
  }
  function extractFromEmbed(embedUrl, siteReferer) {
    return __async(this, null, function* () {
      if (/\.m3u8(?:[?#]|$)/i.test(embedUrl)) return [{ url: embedUrl, hint: "hls" }];
      if (/\.mp4(?:[?#]|$)/i.test(embedUrl)) return [{ url: embedUrl, hint: "mp4" }];
      if (embedUrl.toLowerCase().includes("mp4upload")) {
        return extractMp4Upload(caye, embedUrl, siteReferer, providerName);
      }
      const voe = yield extractVoe(caye, embedUrl, providerName);
      if (voe.length > 0) return voe;
      return extractMp4Upload(caye, embedUrl, siteReferer, providerName);
    });
  }
  caye.register(providerId, {
    source: {
      search(context, query) {
        return __async(this, null, function* () {
          var _a;
          const base = siteBase(context);
          const q = ((_a = query == null ? void 0 : query.q) != null ? _a : "").trim();
          if (!q) return { items: [], nextCursor: "", state: "complete" };
          const url = new URL("/", base);
          url.searchParams.set("s", q);
          const html = yield site.text({ url: url.toString() });
          const doc = caye.html.parse(html);
          const items = [];
          const seen = /* @__PURE__ */ new Set();
          doc.find('div[id^="post-"] h3 a').each((_i, el) => {
            var _a2;
            const href = ((_a2 = el.attr("href")) != null ? _a2 : "").trim();
            const rawTitle = el.text().trim();
            const slug = slugFromHref(href, base);
            if (!slug || !rawTitle || slug.length > 200 || seen.has(slug)) return;
            seen.add(slug);
            const year = extractFirstYear(rawTitle);
            items.push(__spreadValues({
              ref: videoRef(providerId, slug),
              name: rawTitle
            }, year !== void 0 ? { year } : {}));
          });
          return {
            items: limitItems(items, query == null ? void 0 : query.limit),
            nextCursor: "",
            state: "complete"
          };
        });
      },
      read(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const slug = ref.nativeId.split("|")[0];
          const html = yield site.text({ url: `${base}/${encodeURIComponent(slug)}/` });
          const doc = caye.html.parse(html);
          const rawTitle = firstText(doc, ["h1.entry-title", "h1", "title"]).replace(/\s*[-|]\s*AnimeToast.*$/i, "").trim();
          if (!rawTitle) {
            throw failure("unavailable", `${providerName} title was not found`);
          }
          const year = extractFirstYear(rawTitle);
          return __spreadValues({
            ref: sameRef(ref),
            name: rawTitle
          }, year !== void 0 ? { year } : {});
        });
      },
      list(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const slug = ref.nativeId.split("|")[0];
          const pageUrl = `${base}/${encodeURIComponent(slug)}/`;
          const html = yield site.text({ url: pageUrl });
          const doc = caye.html.parse(html);
          const title = firstText(doc, ["h1.entry-title", "h1", "title"]);
          const audio = audioOfTitle(`${slug} ${title}`);
          const audioChoice = audio === "dub" ? { id: "dub", label: "Ger Dub" } : { id: "sub", label: "Ger Sub" };
          const tabs = parseServerTabs(html);
          const tabInstallments = /* @__PURE__ */ new Map();
          const serverChoices = [];
          for (const tab of tabs) {
            const links = extractTabLinks(html, tab.tabId, base);
            if (links.length === 0) continue;
            serverChoices.push({ id: tab.serverId, label: tab.label });
            for (const link of links) {
              if (!tabInstallments.has(link.epNum)) {
                tabInstallments.set(link.epNum, {
                  number: link.epNum,
                  name: `Episode ${link.epNum}`,
                  ref: videoRef(providerId, `${slug}|${link.epNum}`)
                });
              }
            }
          }
          if (tabInstallments.size > 0) {
            return {
              installments: [...tabInstallments.values()].sort((a, b) => a.number - b.number),
              choices: {
                audio: [audioChoice],
                server: uniqueChoices(serverChoices),
                quality: [{ id: "auto", label: "Auto" }]
              }
            };
          }
          const loader = parseIframeLoader(html, base);
          if (loader) {
            const episodes = yield fetchIframeEpisodes(loader, loader.servers[0], pageUrl);
            return {
              installments: episodes.map((ep) => ({
                number: ep.number,
                name: (ep.title || `Episode ${ep.number}`).slice(0, 500),
                ref: videoRef(providerId, `${slug}|${ep.number}`)
              })),
              choices: {
                audio: [audioChoice],
                server: uniqueChoices(
                  loader.servers.map((s) => ({
                    id: choiceId(`server-${s}`),
                    label: `Server ${s}`
                  }))
                ),
                quality: [{ id: "auto", label: "Auto" }]
              }
            };
          }
          return {
            installments: [],
            choices: {
              audio: [audioChoice],
              server: [{ id: "default", label: "Default" }],
              quality: [{ id: "auto", label: "Auto" }]
            }
          };
        });
      },
      find(context, ref) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const { slug, epNum } = parseEpisodeNativeId(ref.nativeId);
          const pageUrl = `${base}/${encodeURIComponent(slug)}/`;
          const html = yield site.text({ url: pageUrl });
          const title = firstText(caye.html.parse(html), ["h1.entry-title", "h1", "title"]);
          const audio = audioOfTitle(`${slug} ${title}`);
          const deadline = futureDeadline(context == null ? void 0 : context.deadline);
          const items = [];
          for (const tab of parseServerTabs(html)) {
            const match = extractTabLinks(html, tab.tabId, base).find((l) => l.epNum === epNum);
            if (!match) continue;
            items.push({
              id: `${audio}:${tab.serverId}:link:${match.linkParam}`,
              origin: tab.serverId === "mp4upload" ? "http" : "hls",
              capabilities: ["video"],
              expiresAt: deadline,
              tracks: [
                {
                  id: "main",
                  kind: "video",
                  language: "de",
                  label: `${audio === "dub" ? "Ger Dub" : "Ger Sub"} \xB7 ${tab.label}`
                }
              ],
              ranges: [],
              choices: {
                audio,
                server: tab.serverId,
                quality: "auto"
              }
            });
          }
          if (items.length === 0) {
            const loader = parseIframeLoader(html, base);
            if (loader) {
              const resolvedServers = yield pooled(loader.servers, 4, (srv) => __async(null, null, function* () {
                const embedUrl = yield fetchIframeEpisodeUrl(loader, srv, epNum, pageUrl);
                return { srv, embedUrl };
              }));
              for (const { srv, embedUrl } of resolvedServers) {
                if (!embedUrl) continue;
                const serverId = choiceId(`server-${srv}`);
                items.push({
                  id: `${audio}:${serverId}:ajax:${srv}`,
                  origin: embedUrl.toLowerCase().includes("mp4upload") ? "http" : "hls",
                  capabilities: ["video"],
                  expiresAt: deadline,
                  tracks: [
                    {
                      id: "main",
                      kind: "video",
                      language: "de",
                      label: `${audio === "dub" ? "Ger Dub" : "Ger Sub"} \xB7 Server ${srv}`
                    }
                  ],
                  ranges: [],
                  choices: {
                    audio,
                    server: serverId,
                    quality: "auto"
                  }
                });
              }
            }
          }
          return { items, state: "complete" };
        });
      },
      resolve(context, input) {
        return __async(this, null, function* () {
          const base = siteBase(context);
          const { slug, epNum } = parseEpisodeNativeId(input.ref.nativeId);
          const [rawAudio, serverId, mode, token] = input.sourceId.split(":");
          const audio = rawAudio === "dub" ? "dub" : "sub";
          const pageUrl = `${base}/${encodeURIComponent(slug)}/`;
          let embedUrl = "";
          let siteReferer = `${base}/`;
          if (mode === "link" && token) {
            const epUrl = `${pageUrl}?link=${encodeURIComponent(token)}`;
            siteReferer = epUrl;
            const epHtml = yield site.text({ url: epUrl });
            const doc = caye.html.parse(epHtml);
            doc.find("iframe[src]").each((_i, el) => {
              var _a;
              if (embedUrl) return;
              const src = ((_a = el.attr("src")) != null ? _a : "").trim();
              if (src) embedUrl = resolveUrl(src, epUrl);
            });
          } else if (mode === "ajax" && token) {
            const pageHtml = yield site.text({ url: pageUrl });
            const loader = parseIframeLoader(pageHtml, base);
            if (!loader) {
              throw failure("unavailable", `${providerName} player config was not found`);
            }
            embedUrl = yield fetchIframeEpisodeUrl(loader, token, epNum, pageUrl);
            siteReferer = pageUrl;
          } else {
            throw failure("unavailable", `${providerName} invalid source identifier`);
          }
          if (!embedUrl) {
            throw failure("unavailable", `${providerName} embed URL was not found`);
          }
          const streams = yield extractFromEmbed(embedUrl, siteReferer);
          const selected = streams[0];
          if (!selected) {
            throw failure("unavailable", `${providerName} stream could not be extracted`);
          }
          const handle = yield site.handle({ url: selected.url, headers: selected.headers });
          return {
            id: input.sourceId,
            origin: streamOriginOf(selected.url, selected.hint),
            capabilities: ["video"],
            expiresAt: handle.expiresAt,
            handle,
            tracks: [
              {
                id: "main",
                kind: "video",
                language: "de",
                label: `${audio === "dub" ? "Ger Dub" : "Ger Sub"} \xB7 ${serverId}`
              }
            ],
            ranges: [],
            choices: {
              audio,
              server: serverId,
              quality: "auto"
            }
          };
        });
      }
    }
  });
})();
//# sourceMappingURL=backend.js.map
