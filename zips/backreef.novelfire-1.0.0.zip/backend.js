(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/provider-source/src/text.ts
  function unescapeHTML(str) {
    return str.replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&#x27;/g, "'").replace(/&#x2F;/g, "/").replace(/&nbsp;/g, " ");
  }
  function toBase64(str) {
    const bytes = [];
    const encoded = encodeURIComponent(str);
    for (let i = 0; i < encoded.length; i++) {
      if (encoded[i] === "%") {
        bytes.push(parseInt(encoded.slice(i + 1, i + 3), 16));
        i += 2;
      } else {
        bytes.push(encoded.charCodeAt(i));
      }
    }
    const alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
    let out = "";
    for (let i = 0; i < bytes.length; i += 3) {
      const a = bytes[i];
      const b = i + 1 < bytes.length ? bytes[i + 1] : 0;
      const c = i + 2 < bytes.length ? bytes[i + 2] : 0;
      out += alphabet[a >> 2] + alphabet[(a & 3) << 4 | b >> 4];
      out += i + 1 < bytes.length ? alphabet[(b & 15) << 2 | c >> 6] : "=";
      out += i + 2 < bytes.length ? alphabet[c & 63] : "=";
    }
    return out;
  }

  // src/year.ts
  function yearOf(value) {
    var _a, _b, _c, _d;
    if (typeof value === "number") {
      return Number.isInteger(value) && value >= 1e3 && value <= 9999 ? value : void 0;
    }
    if (typeof value !== "string") return void 0;
    const text = value.trim();
    const direct = (_a = text.match(/^(\d{4})(?:-\d{2}-\d{2})?$/)) == null ? void 0 : _a[1];
    const field = (_b = text.match(
      /(?:first_air_date|release_date|firstAired|airedOn|data-year|datetime|released|premiere|year)["']?\s*(?::|=)\s*["']?(\d{4})(?=$|[^\w.])/i
    )) == null ? void 0 : _b[1];
    const startDate = (_c = text.match(
      /\bstartDate\b.{0,40}?\byear\b["']?\s*:\s*["']?(\d{4})(?=$|[^\w.])/i
    )) == null ? void 0 : _c[1];
    const year = Number((_d = direct != null ? direct : field) != null ? _d : startDate);
    return Number.isInteger(year) && year >= 1e3 && year <= 9999 ? year : void 0;
  }
  function withYear(record, source) {
    const year = yearOf(source);
    return year === void 0 ? record : __spreadProps(__spreadValues({}, record), { year });
  }

  // src/backend.ts
  var novelfireProviderId = "backreef.novelfire:source";
  var novelfireBaseUrl = "https://novelfire.net";
  var defaultUserAgent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
  function escapeHTML(str) {
    return str.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;");
  }
  var novelfireCookie = "";
  function novelfireFetch(_0) {
    return __async(this, arguments, function* (url, options = {}) {
      var _a, _b, _c;
      for (let attempt = 0; attempt < 3; attempt++) {
        let response;
        try {
          response = yield caye.http({
            url,
            method: (_a = options.method) != null ? _a : "GET",
            headers: __spreadValues(__spreadValues({
              "User-Agent": defaultUserAgent
            }, novelfireCookie ? { Cookie: novelfireCookie } : {}), (_b = options.headers) != null ? _b : {}),
            body: options.body
          });
        } catch (e) {
          throw Object.assign(new Error("NovelFire is unavailable"), {
            code: "unavailable"
          });
        }
        const setCookie = response.headers["set-cookie"];
        if (setCookie) {
          novelfireCookie = setCookie.split(";")[0];
        }
        if (response.status === 429) {
          const rawWait = response.headers["retry-after"];
          const wait = rawWait ? parseInt(rawWait, 10) * 1e3 : 1500;
          try {
            yield caye.sleep(wait);
          } catch (e) {
          }
          continue;
        }
        if (response.status < 200 || response.status >= 300) {
          throw Object.assign(new Error(`NovelFire returned HTTP ${response.status}`), {
            code: "unavailable"
          });
        }
        return (_c = response.body) != null ? _c : "";
      }
      throw Object.assign(new Error("NovelFire rate limit reached."), {
        code: "rate-limited"
      });
    });
  }
  function tagAttr(tag, name) {
    const match = tag.match(new RegExp(`\\s${name}\\s*=\\s*(["'])([\\s\\S]*?)\\1`, "i"));
    return match ? match[2] : void 0;
  }
  function novelUrl(id) {
    if (id.startsWith("http")) return id;
    if (id.startsWith("/")) return `${novelfireBaseUrl}${id}`;
    return `${novelfireBaseUrl}/book/${id}`;
  }
  function chapterPage(url) {
    return __async(this, null, function* () {
      var _a;
      let html = yield novelfireFetch(url);
      for (let hop = 0; hop < 2 && !extractContentDiv(html); hop++) {
        const next = (_a = html.match(/window\.location\.href\s*=\s*"([^"]+)"/)) == null ? void 0 : _a[1];
        if (!next) break;
        html = yield novelfireFetch(next.replace(/\\\//g, "/"));
      }
      return html;
    });
  }
  function extractContentDiv(html) {
    const startIdx = html.indexOf('id="content"');
    const altIdx = html.indexOf("id='content'");
    const targetIdx = startIdx !== -1 ? startIdx : altIdx;
    if (targetIdx === -1) return "";
    const tagStart = html.lastIndexOf("<div", targetIdx);
    if (tagStart === -1) return "";
    const tagEnd = html.indexOf(">", tagStart);
    if (tagEnd === -1) return "";
    let depth = 1;
    let pos = tagEnd + 1;
    while (depth > 0 && pos < html.length) {
      const nextOpen = html.indexOf("<div", pos);
      const nextClose = html.indexOf("</div>", pos);
      if (nextClose === -1) break;
      if (nextOpen !== -1 && nextOpen < nextClose) {
        depth++;
        pos = nextOpen + 4;
      } else {
        depth--;
        if (depth === 0) {
          return html.slice(tagEnd + 1, nextClose);
        }
        pos = nextClose + 6;
      }
    }
    return "";
  }
  var novelfireSource = {
    search(_context, query) {
      return __async(this, null, function* () {
        var _a, _b, _c;
        const text = ((_a = query.q) != null ? _a : "").trim();
        if (!text) {
          return { items: [], nextCursor: "", state: "complete" };
        }
        const url = `${novelfireBaseUrl}/search?keyword=${encodeURIComponent(text)}`;
        const html = yield novelfireFetch(url);
        const items = [];
        const itemRegex = /<li\s+[^>]*class=["'][^"']*novel-item[^"']*["'][^>]*>([\s\S]*?)<\/li>/gi;
        for (const match of html.matchAll(itemRegex)) {
          const itemHtml = match[1];
          let href = "";
          let title = "";
          for (const tag of itemHtml.matchAll(/<a\s[^>]*>/gi)) {
            href = (_b = tagAttr(tag[0], "href")) != null ? _b : "";
            title = (_c = tagAttr(tag[0], "title")) != null ? _c : "";
            if (href && title) break;
          }
          title = unescapeHTML(title).trim();
          if (!href || !title) continue;
          const nativeId = href.replace(/^https?:\/\/novelfire\.net/i, "").replace(/^\/book\//i, "").replace(/^\//i, "");
          const imgMatch = itemHtml.match(/<img\s+[^>]*src=["']([^"']+)["']/i);
          let image = imgMatch ? imgMatch[1] : void 0;
          if (image == null ? void 0 : image.startsWith("/")) {
            image = `${novelfireBaseUrl}${image}`;
          }
          items.push(
            withYear(
              {
                ref: {
                  providerId: novelfireProviderId,
                  type: "novel",
                  nativeId
                },
                name: title
              },
              itemHtml
            )
          );
        }
        const limit = query.limit > 0 ? query.limit : items.length;
        return {
          items: items.slice(0, limit),
          nextCursor: "",
          state: "complete"
        };
      });
    },
    read(_context, ref) {
      return __async(this, null, function* () {
        const url = novelUrl(ref.nativeId);
        const html = yield novelfireFetch(url);
        const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i);
        if (!titleMatch) {
          throw Object.assign(new Error("site changed"), {
            code: "site changed",
            reason: "site changed"
          });
        }
        const name = unescapeHTML(titleMatch[1].replace(/<[^>]*>/g, "")).trim();
        return {
          ref: {
            providerId: novelfireProviderId,
            type: ref.type || "novel",
            nativeId: ref.nativeId
          },
          name
        };
      });
    },
    list(_context, ref) {
      return __async(this, null, function* () {
        var _a, _b;
        let chaptersUrl = novelUrl(ref.nativeId);
        if (!chaptersUrl.endsWith("/chapters")) {
          chaptersUrl = chaptersUrl.endsWith("/") ? `${chaptersUrl}chapters` : `${chaptersUrl}/chapters`;
        }
        const allChapters = [];
        let nextUrl = chaptersUrl;
        let pagesFetched = 0;
        while (nextUrl && pagesFetched < 100) {
          pagesFetched++;
          const html = yield novelfireFetch(nextUrl);
          const chListStart = html.indexOf('<ul class="chapter-list">');
          if (chListStart === -1) break;
          const chListEnd = html.indexOf("</ul>", chListStart);
          const chHtml = chListEnd === -1 ? html.slice(chListStart) : html.slice(chListStart, chListEnd);
          for (const tag of chHtml.matchAll(/<a\s[^>]*>/gi)) {
            const url = (_a = tagAttr(tag[0], "href")) != null ? _a : "";
            const rawTitle = (_b = tagAttr(tag[0], "title")) != null ? _b : "";
            if (!url || !rawTitle) continue;
            const title = unescapeHTML(rawTitle).trim();
            let number;
            const chMatch = title.match(/(?:Chapter|Ch\.)\s*(\d+(?:\.\d+)?)/i);
            if (chMatch) {
              number = parseFloat(chMatch[1]);
            } else {
              const firstNum = title.match(/(\d+(?:\.\d+)?)/);
              if (firstNum) number = parseFloat(firstNum[1]);
            }
            const installment = {
              ref: {
                providerId: novelfireProviderId,
                type: "chapter",
                nativeId: url
              },
              name: title,
              number
            };
            if (number === void 0) {
              delete installment.number;
            }
            allChapters.push(installment);
          }
          const nextMatch = html.match(/<a\s+[^>]*href=["']([^"']+)["'][^>]*rel=["']next["']/i) || html.match(/<a\s+[^>]*rel=["']next["'][^>]*href=["']([^"']+)["']/i);
          if (nextMatch) {
            const nextHref = nextMatch[1];
            nextUrl = nextHref.startsWith("http") ? nextHref : `${novelfireBaseUrl}${nextHref.startsWith("/") ? nextHref : `/${nextHref}`}`;
            try {
              yield caye.sleep(100);
            } catch (e) {
            }
          } else {
            nextUrl = void 0;
          }
        }
        const titleNumbers = allChapters.map((chapter) => chapter.number).filter((number) => number !== void 0);
        if (new Set(titleNumbers).size !== titleNumbers.length) {
          allChapters.forEach((chapter, index) => {
            const indexed = chapter.ref.nativeId.match(/\/chapter-(\d+(?:\.\d+)?)\/?$/i);
            chapter.number = indexed ? parseFloat(indexed[1]) : index + 1;
          });
        }
        if (allChapters.length === 0) {
          throw Object.assign(new Error("site changed"), {
            code: "site changed",
            reason: "site changed"
          });
        }
        const choices = {};
        return { installments: allChapters, choices };
      });
    },
    find(context, _ref) {
      return __async(this, null, function* () {
        return {
          items: [
            {
              id: "text",
              capabilities: ["text"],
              origin: "text",
              expiresAt: context.deadline,
              tracks: [],
              ranges: []
            }
          ],
          state: "complete"
        };
      });
    },
    resolve(_context, input) {
      return __async(this, null, function* () {
        const rawUrl = input.ref.nativeId;
        const url = rawUrl.startsWith("http") ? rawUrl : `${novelfireBaseUrl}${rawUrl.startsWith("/") ? rawUrl : `/${rawUrl}`}`;
        const html = yield chapterPage(url);
        const rawContent = extractContentDiv(html);
        if (!rawContent) {
          throw Object.assign(new Error("Could not extract chapter content."), {
            code: "unavailable"
          });
        }
        const cleaned = rawContent.replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "").replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "").replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, "").replace(/<ins\b[^<]*(?:(?!<\/ins>)<[^<]*)*<\/ins>/gi, "").replace(/<div\b[^>]*class=["'][^"']*(?:ads|ad-)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi, "");
        const pRegex = /<p\b[^>]*>([\s\S]*?)<\/p>/gi;
        const paragraphs = [];
        for (const match of cleaned.matchAll(pRegex)) {
          const text = unescapeHTML(match[1].replace(/<[^>]*>/g, "")).trim();
          if (text) {
            paragraphs.push(text);
          }
        }
        if (paragraphs.length === 0) {
          const plain = unescapeHTML(cleaned.replace(/<[^>]*>/g, "")).trim();
          for (const line of plain.split("\n")) {
            const trimmed = line.trim();
            if (trimmed) paragraphs.push(trimmed);
          }
        }
        if (paragraphs.length === 0) {
          throw Object.assign(new Error("No text content found in chapter"), {
            code: "unavailable"
          });
        }
        const formatted = paragraphs.map((p) => `<p>${escapeHTML(p)}</p>`).join("\n");
        const open = yield caye.stage({});
        const staged = yield caye.stage({
          id: open.id,
          data: toBase64(formatted),
          mediaType: "text/html",
          final: true
        });
        if (!staged.handle) {
          throw Object.assign(new Error("Stage handle unavailable"), {
            code: "unavailable"
          });
        }
        return {
          id: input.sourceId,
          capabilities: ["text"],
          origin: "text",
          expiresAt: staged.handle.expiresAt,
          tracks: [],
          ranges: [],
          handle: staged.handle
        };
      });
    }
  };
  caye.register(novelfireProviderId, {
    source: novelfireSource
  });
})();
//# sourceMappingURL=backend.js.map
