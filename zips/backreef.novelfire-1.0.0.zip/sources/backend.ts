import type {
    API,
    Context,
    HTTPOutput,
    Query,
    Ref,
    Source,
    SourceChoicesDef,
    SourceInstallment,
    SourceListResult,
    SourcePage,
    SourceRecord,
    SourceRecords,
    SourceResolveInput,
} from "../../../../packages/plugin-sdk/src/index"
import { toBase64, unescapeHTML } from "../../../../packages/provider-source/src/text"
import { withYear } from "./year"

declare const caye: API

const novelfireProviderId = "backreef.novelfire:source"
const novelfireBaseUrl = "https://novelfire.net"
const defaultUserAgent =
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

function escapeHTML(str: string): string {
    return str
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#39;")
}

let novelfireCookie = ""

async function novelfireFetch(
    url: string,
    options: {
        method?: "GET" | "POST"
        headers?: Record<string, string>
        body?: string
    } = {},
): Promise<string> {
    for (let attempt = 0; attempt < 3; attempt++) {
        let response: HTTPOutput
        try {
            response = await caye.http({
                url,
                method: options.method ?? "GET",
                headers: {
                    "User-Agent": defaultUserAgent,
                    ...(novelfireCookie ? { Cookie: novelfireCookie } : {}),
                    ...(options.headers ?? {}),
                },
                body: options.body,
            })
        } catch {
            throw Object.assign(new Error("NovelFire is unavailable"), {
                code: "unavailable",
            })
        }

        const setCookie = response.headers["set-cookie"]
        if (setCookie) {
            novelfireCookie = setCookie.split(";")[0]
        }

        if (response.status === 429) {
            const rawWait = response.headers["retry-after"]
            const wait = rawWait ? parseInt(rawWait, 10) * 1000 : 1500
            try {
                await caye.sleep(wait)
            } catch {}
            continue
        }

        if (response.status < 200 || response.status >= 300) {
            throw Object.assign(new Error(`NovelFire returned HTTP ${response.status}`), {
                code: "unavailable",
            })
        }

        return response.body ?? ""
    }
    throw Object.assign(new Error("NovelFire rate limit reached."), {
        code: "rate-limited",
    })
}

function tagAttr(tag: string, name: string): string | undefined {
    const match = tag.match(new RegExp(`\\s${name}\\s*=\\s*(["'])([\\s\\S]*?)\\1`, "i"))
    return match ? match[2] : undefined
}

function novelUrl(id: string): string {
    if (id.startsWith("http")) return id
    if (id.startsWith("/")) return `${novelfireBaseUrl}${id}`
    return `${novelfireBaseUrl}/book/${id}`
}

// NovelFire sends chapter reads to a mirror through a page that redirects in a script
async function chapterPage(url: string): Promise<string> {
    let html = await novelfireFetch(url)
    for (let hop = 0; hop < 2 && !extractContentDiv(html); hop++) {
        const next = html.match(/window\.location\.href\s*=\s*"([^"]+)"/)?.[1]
        if (!next) break
        html = await novelfireFetch(next.replace(/\\\//g, "/"))
    }
    return html
}

function extractContentDiv(html: string): string {
    const startIdx = html.indexOf('id="content"')
    const altIdx = html.indexOf("id='content'")
    const targetIdx = startIdx !== -1 ? startIdx : altIdx
    if (targetIdx === -1) return ""

    const tagStart = html.lastIndexOf("<div", targetIdx)
    if (tagStart === -1) return ""
    const tagEnd = html.indexOf(">", tagStart)
    if (tagEnd === -1) return ""

    let depth = 1
    let pos = tagEnd + 1
    while (depth > 0 && pos < html.length) {
        const nextOpen = html.indexOf("<div", pos)
        const nextClose = html.indexOf("</div>", pos)
        if (nextClose === -1) break
        if (nextOpen !== -1 && nextOpen < nextClose) {
            depth++
            pos = nextOpen + 4
        } else {
            depth--
            if (depth === 0) {
                return html.slice(tagEnd + 1, nextClose)
            }
            pos = nextClose + 6
        }
    }
    return ""
}

const novelfireSource = {
    async search(_context: Context, query: Query): Promise<SourceRecords> {
        const text = (query.q ?? "").trim()
        if (!text) {
            return { items: [], nextCursor: "", state: "complete" }
        }

        const url = `${novelfireBaseUrl}/search?keyword=${encodeURIComponent(text)}`
        const html = await novelfireFetch(url)

        const items: SourceRecord[] = []
        const itemRegex = /<li\s+[^>]*class=["'][^"']*novel-item[^"']*["'][^>]*>([\s\S]*?)<\/li>/gi
        for (const match of html.matchAll(itemRegex)) {
            const itemHtml = match[1]
            let href = ""
            let title = ""
            for (const tag of itemHtml.matchAll(/<a\s[^>]*>/gi)) {
                href = tagAttr(tag[0], "href") ?? ""
                title = tagAttr(tag[0], "title") ?? ""
                if (href && title) break
            }

            title = unescapeHTML(title).trim()
            if (!href || !title) continue

            const nativeId = href
                .replace(/^https?:\/\/novelfire\.net/i, "")
                .replace(/^\/book\//i, "")
                .replace(/^\//i, "")

            const imgMatch = itemHtml.match(/<img\s+[^>]*src=["']([^"']+)["']/i)
            let image = imgMatch ? imgMatch[1] : undefined
            if (image?.startsWith("/")) {
                image = `${novelfireBaseUrl}${image}`
            }

            items.push(
                withYear(
                    {
                        ref: {
                            providerId: novelfireProviderId,
                            type: "novel",
                            nativeId,
                        },
                        name: title,
                    },
                    itemHtml,
                ),
            )
        }

        const limit = query.limit > 0 ? query.limit : items.length
        return {
            items: items.slice(0, limit),
            nextCursor: "",
            state: "complete",
        }
    },

    async read(_context: Context, ref: Ref): Promise<SourceRecord> {
        const url = novelUrl(ref.nativeId)
        const html = await novelfireFetch(url)

        const titleMatch = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/i)
        if (!titleMatch) {
            throw Object.assign(new Error("site changed"), {
                code: "site changed",
                reason: "site changed",
            })
        }
        const name = unescapeHTML(titleMatch[1].replace(/<[^>]*>/g, "")).trim()

        return {
            ref: {
                providerId: novelfireProviderId,
                type: ref.type || "novel",
                nativeId: ref.nativeId,
            },
            name,
        }
    },

    async list(_context: Context, ref: Ref): Promise<SourceListResult> {
        let chaptersUrl = novelUrl(ref.nativeId)
        if (!chaptersUrl.endsWith("/chapters")) {
            chaptersUrl = chaptersUrl.endsWith("/")
                ? `${chaptersUrl}chapters`
                : `${chaptersUrl}/chapters`
        }

        const allChapters: SourceInstallment[] = []
        let nextUrl: string | undefined = chaptersUrl
        let pagesFetched = 0

        while (nextUrl && pagesFetched < 100) {
            pagesFetched++
            const html = await novelfireFetch(nextUrl)
            const chListStart = html.indexOf('<ul class="chapter-list">')
            if (chListStart === -1) break
            const chListEnd = html.indexOf("</ul>", chListStart)
            const chHtml =
                chListEnd === -1 ? html.slice(chListStart) : html.slice(chListStart, chListEnd)

            for (const tag of chHtml.matchAll(/<a\s[^>]*>/gi)) {
                const url = tagAttr(tag[0], "href") ?? ""
                const rawTitle = tagAttr(tag[0], "title") ?? ""
                if (!url || !rawTitle) continue
                const title = unescapeHTML(rawTitle).trim()
                let number: number | undefined
                const chMatch = title.match(/(?:Chapter|Ch\.)\s*(\d+(?:\.\d+)?)/i)
                if (chMatch) {
                    number = parseFloat(chMatch[1])
                } else {
                    const firstNum = title.match(/(\d+(?:\.\d+)?)/)
                    if (firstNum) number = parseFloat(firstNum[1])
                }

                const installment: SourceInstallment = {
                    ref: {
                        providerId: novelfireProviderId,
                        type: "chapter",
                        nativeId: url,
                    },
                    name: title,
                    number: number as number,
                }
                if (number === undefined) {
                    delete (installment as { number?: number }).number
                }
                allChapters.push(installment)
            }

            const nextMatch =
                html.match(/<a\s+[^>]*href=["']([^"']+)["'][^>]*rel=["']next["']/i) ||
                html.match(/<a\s+[^>]*rel=["']next["'][^>]*href=["']([^"']+)["']/i)
            if (nextMatch) {
                const nextHref = nextMatch[1]
                nextUrl = nextHref.startsWith("http")
                    ? nextHref
                    : `${novelfireBaseUrl}${nextHref.startsWith("/") ? nextHref : `/${nextHref}`}`
                try {
                    await caye.sleep(100)
                } catch {}
            } else {
                nextUrl = undefined
            }
        }

        const titleNumbers = allChapters
            .map((chapter) => chapter.number)
            .filter((number) => number !== undefined)
        if (new Set(titleNumbers).size !== titleNumbers.length) {
            allChapters.forEach((chapter, index) => {
                const indexed = chapter.ref.nativeId.match(/\/chapter-(\d+(?:\.\d+)?)\/?$/i)
                chapter.number = indexed ? parseFloat(indexed[1]) : index + 1
            })
        }

        if (allChapters.length === 0) {
            throw Object.assign(new Error("site changed"), {
                code: "site changed",
                reason: "site changed",
            })
        }

        const choices: SourceChoicesDef = {}
        return { installments: allChapters, choices }
    },

    async find(context: Context, _ref: Ref): Promise<SourcePage> {
        return {
            items: [
                {
                    id: "text",
                    capabilities: ["text"],
                    origin: "text",
                    expiresAt: context.deadline,
                    tracks: [],
                    ranges: [],
                },
            ],
            state: "complete",
        }
    },

    async resolve(_context: Context, input: SourceResolveInput): Promise<Source> {
        const rawUrl = input.ref.nativeId
        const url = rawUrl.startsWith("http")
            ? rawUrl
            : `${novelfireBaseUrl}${rawUrl.startsWith("/") ? rawUrl : `/${rawUrl}`}`

        const html = await chapterPage(url)
        const rawContent = extractContentDiv(html)
        if (!rawContent) {
            throw Object.assign(new Error("Could not extract chapter content."), {
                code: "unavailable",
            })
        }

        const cleaned = rawContent
            .replace(/<script\b[^<]*(?:(?!<\/script>)<[^<]*)*<\/script>/gi, "")
            .replace(/<style\b[^<]*(?:(?!<\/style>)<[^<]*)*<\/style>/gi, "")
            .replace(/<iframe\b[^<]*(?:(?!<\/iframe>)<[^<]*)*<\/iframe>/gi, "")
            .replace(/<ins\b[^<]*(?:(?!<\/ins>)<[^<]*)*<\/ins>/gi, "")
            .replace(/<div\b[^>]*class=["'][^"']*(?:ads|ad-)[^"']*["'][^>]*>[\s\S]*?<\/div>/gi, "")

        const pRegex = /<p\b[^>]*>([\s\S]*?)<\/p>/gi
        const paragraphs: string[] = []
        for (const match of cleaned.matchAll(pRegex)) {
            const text = unescapeHTML(match[1].replace(/<[^>]*>/g, "")).trim()
            if (text) {
                paragraphs.push(text)
            }
        }

        if (paragraphs.length === 0) {
            const plain = unescapeHTML(cleaned.replace(/<[^>]*>/g, "")).trim()
            for (const line of plain.split("\n")) {
                const trimmed = line.trim()
                if (trimmed) paragraphs.push(trimmed)
            }
        }

        if (paragraphs.length === 0) {
            throw Object.assign(new Error("No text content found in chapter"), {
                code: "unavailable",
            })
        }

        const formatted = paragraphs.map((p) => `<p>${escapeHTML(p)}</p>`).join("\n")

        const open = await caye.stage({})
        const staged = await caye.stage({
            id: open.id,
            data: toBase64(formatted),
            mediaType: "text/html",
            final: true,
        })

        if (!staged.handle) {
            throw Object.assign(new Error("Stage handle unavailable"), {
                code: "unavailable",
            })
        }

        return {
            id: input.sourceId,
            capabilities: ["text"],
            origin: "text",
            expiresAt: staged.handle.expiresAt,
            tracks: [],
            ranges: [],
            handle: staged.handle,
        }
    },
}

caye.register(novelfireProviderId, {
    source: novelfireSource,
})
