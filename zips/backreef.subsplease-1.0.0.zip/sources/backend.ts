import type {
    AcquisitionPage,
    AcquisitionQuery,
    AcquisitionResolveInput,
    API,
    Context,
    DownloadOption,
} from "../../../../packages/plugin-sdk/src/index"
import {
    cacheOptions,
    clampLimit,
    createTorrentOption,
    fetchJson,
    normalizeResolutionLabel,
    parseIsoDate,
    parseMagnet,
    parseResolutionNumber,
    resolveCachedOrFallback,
    resolveMediaContext,
} from "../../torrent-common/src/index.ts"
import { failure } from "../../../../packages/plugin-std/src/http.ts"

declare const caye: API

const PROVIDER_ID = "backreef.subsplease:search"
const API_URL = "https://subsplease.org/api/"

type SubsPleaseDownload = {
    res?: string
    magnet?: string
}

type SubsPleaseRelease = {
    show?: string
    episode?: string
    downloads?: SubsPleaseDownload[]
    release_date?: string
    page?: string
}

function parseEpisodeNumber(raw: string | undefined): number {
    if (!raw) return -1
    const trimmed = raw.trim()
    if (!/^\d+(?:\.\d+)?$/.test(trimmed)) return -1
    const n = Number(trimmed)
    return Number.isFinite(n) && n >= 0 ? n : -1
}

function formatEpisodeLabel(raw: string | undefined, epNum: number): string {
    if (epNum >= 0 && Number.isInteger(epNum)) {
        return String(epNum).padStart(2, "0")
    }
    return raw?.trim() || "01"
}

function optionIdFor(show: string, episode: string, res: string, infoHash: string): string {
    if (infoHash) return `subsplease-${infoHash}`
    const slug = `${show}-${episode}-${res}`
        .toLowerCase()
        .replace(/[^a-z0-9]+/g, "-")
        .replace(/^-+|-+$/g, "")
    return `subsplease-${slug || "item"}`
}

function releaseToOptions(release: SubsPleaseRelease, targets: number[]): DownloadOption[] {
    const rawEpisode = release.episode?.trim() || ""
    if (!rawEpisode || rawEpisode.toLowerCase() === "batch") return []
    const epNum = parseEpisodeNumber(rawEpisode)
    const show = release.show?.trim() || ""
    if (!show || !Array.isArray(release.downloads)) return []

    const publishedAt = parseIsoDate(caye, release.release_date)
    const pageSlug = release.page?.trim().replace(/^\/+|\/+$/g, "")
    const pageUrl = pageSlug ? `https://subsplease.org/shows/${pageSlug}/` : undefined
    const confirmed = targets.length > 0 && epNum >= 0 && targets.includes(epNum)

    const out: DownloadOption[] = []
    for (const dl of release.downloads) {
        const magnet = dl.magnet?.trim() || ""
        if (!magnet.startsWith("magnet:")) continue
        let infoHash = ""
        let size = 0
        try {
            const parsed = parseMagnet(magnet)
            infoHash = parsed.infoHash
            size = parsed.size
        } catch {
            continue
        }
        const resLabel = normalizeResolutionLabel(dl.res) || (dl.res ? `${dl.res}p` : "")
        const epLabel = formatEpisodeLabel(rawEpisode, epNum)
        const name = `[SubsPlease] ${show} - ${epLabel}${resLabel ? ` (${resLabel})` : ""} [${infoHash.slice(0, 8).toUpperCase()}].mkv`
        out.push(
            createTorrentOption(caye, {
                id: optionIdFor(show, epLabel, resLabel, infoHash),
                key: infoHash || `${show}-${epLabel}-${resLabel}`,
                providerId: PROVIDER_ID,
                name,
                magnet,
                pageUrl,
                size: size > 0 ? size : undefined,
                publishedAt,
                resolution: resLabel,
                group: "SubsPlease",
                confirmed,
            }),
        )
    }
    return out
}

async function find(_context: Context, query: AcquisitionQuery): Promise<AcquisitionPage> {
    if (query.batch) {
        return { items: [], state: "complete" }
    }
    const media = await resolveMediaContext(caye, query)
    const searchTitle = query.text?.trim() || media.romajiTitle || media.englishTitle || ""
    if (!searchTitle) {
        throw failure("unsupported", "Enter a title to search.")
    }
    const url = `${API_URL}?f=search&tz=UTC&s=${encodeURIComponent(searchTitle)}`
    const data = await fetchJson<Record<string, SubsPleaseRelease> | unknown[]>(
        caye,
        "SubsPlease",
        url,
        {
            headers: { Accept: "application/json" },
        },
    )

    const targets = [query.number, query.absolute].filter(
        (n): n is number => typeof n === "number" && Number.isFinite(n) && n > 0,
    )
    const wantedRes = parseResolutionNumber(query.resolution)

    const releases = Array.isArray(data)
        ? (data as SubsPleaseRelease[])
        : data && typeof data === "object"
          ? Object.values(data)
          : []

    const seen = new Set<string>()
    const items: DownloadOption[] = []
    const limit = clampLimit(query.limit, 50, 100)

    for (const release of releases) {
        if (!release || typeof release !== "object") continue
        const epNum = parseEpisodeNumber(release.episode)
        if (targets.length > 0 && (epNum < 0 || !targets.includes(epNum))) {
            continue
        }
        for (const opt of releaseToOptions(release, targets)) {
            if (wantedRes > 0 && parseResolutionNumber(opt.resolution) !== wantedRes) {
                continue
            }
            if (seen.has(opt.id)) continue
            seen.add(opt.id)
            items.push(opt)
            if (items.length >= limit) break
        }
        if (items.length >= limit) break
    }

    await cacheOptions(caye, "subsplease", items)
    return { items, state: "complete" }
}

async function resolve(_context: Context, input: AcquisitionResolveInput): Promise<DownloadOption> {
    return await resolveCachedOrFallback(
        caye,
        "subsplease",
        input,
        "Unknown or uncached SubsPlease option.",
        undefined,
        { providerId: PROVIDER_ID, group: "SubsPlease" },
    )
}

caye.register(PROVIDER_ID, { acquisition: { find, resolve } })
