(() => {
  var __defProp = Object.defineProperty;
  var __defProps = Object.defineProperties;
  var __getOwnPropDescs = Object.getOwnPropertyDescriptors;
  var __getOwnPropSymbols = Object.getOwnPropertySymbols;
  var __hasOwnProp = Object.prototype.hasOwnProperty;
  var __propIsEnum = Object.prototype.propertyIsEnumerable;
  var __defNormalProp = (obj, key, value) => key in obj ? __defProp(obj, key, { enumerable: true, configurable: true, writable: true, value }) : obj[key] = value;
  var __spreadValues = (a, b) => {
    for (var prop in b || (b = {}))
      if (__hasOwnProp.call(b, prop))
        __defNormalProp(a, prop, b[prop]);
    if (__getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(b)) {
        if (__propIsEnum.call(b, prop))
          __defNormalProp(a, prop, b[prop]);
      }
    return a;
  };
  var __spreadProps = (a, b) => __defProps(a, __getOwnPropDescs(b));
  var __objRest = (source, exclude) => {
    var target = {};
    for (var prop in source)
      if (__hasOwnProp.call(source, prop) && exclude.indexOf(prop) < 0)
        target[prop] = source[prop];
    if (source != null && __getOwnPropSymbols)
      for (var prop of __getOwnPropSymbols(source)) {
        if (exclude.indexOf(prop) < 0 && __propIsEnum.call(source, prop))
          target[prop] = source[prop];
      }
    return target;
  };
  var __async = (__this, __arguments, generator) => {
    return new Promise((resolve2, reject) => {
      var fulfilled = (value) => {
        try {
          step(generator.next(value));
        } catch (e) {
          reject(e);
        }
      };
      var rejected = (value) => {
        try {
          step(generator.throw(value));
        } catch (e) {
          reject(e);
        }
      };
      var step = (x) => x.done ? resolve2(x.value) : Promise.resolve(x.value).then(fulfilled, rejected);
      step((generator = generator.apply(__this, __arguments)).next());
    });
  };

  // ../../../packages/plugin-std/src/rate-limit.ts
  function parseRetryAfter(value, now = Date.now()) {
    if (value === null || value === void 0) return 0;
    if (typeof value === "number") {
      if (!Number.isFinite(value) || value <= 0) return 0;
      return Math.round(value * 1e3);
    }
    const trimmed = value.trim();
    if (!trimmed) return 0;
    if (/^\d+(?:\.\d+)?$/.test(trimmed)) {
      const seconds = Number.parseFloat(trimmed);
      return Number.isFinite(seconds) && seconds > 0 ? Math.round(seconds * 1e3) : 0;
    }
    const parsedDate = Date.parse(trimmed);
    if (!Number.isFinite(parsedDate)) return 0;
    const diff = parsedDate - now;
    return diff > 0 ? Math.round(diff) : 0;
  }

  // ../../../packages/plugin-std/src/user-agents.ts
  var CHROME_DESKTOP = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/134.0.0.0 Safari/537.36";

  // ../../../packages/plugin-std/src/http.ts
  var challengeBody = /cf-browser-verification|cf-chl-|<title[^>]*>\s*(?:just a moment|attention required|ddos-guard)/i;
  function failure(code, message, retryAfterSeconds) {
    return Object.assign(new Error(message), __spreadValues({
      code
    }, retryAfterSeconds !== void 0 && retryAfterSeconds > 0 ? { retry_after: Math.ceil(retryAfterSeconds) } : {}));
  }
  function isChallenge(response) {
    var _a, _b;
    return ((_a = response.headers) == null ? void 0 : _a["cf-mitigated"]) === "challenge" || challengeBody.test((_b = response.body) != null ? _b : "");
  }
  function checkResponse(name, response, requested) {
    var _a;
    if (response.status === 429) {
      const wait = parseRetryAfter((_a = response.headers) == null ? void 0 : _a["retry-after"]) / 1e3;
      throw failure("rate-limited", `${name} is limiting requests. Try again later.`, wait);
    }
    if (response.status === 401) {
      throw failure("needs-auth", `${name} requires authorization.`);
    }
    if (isChallenge(response)) {
      const page = response.url || requested || "";
      if (page.startsWith("https://")) {
        throw Object.assign(
          failure("challenge", `${name} asks you to confirm you are a person.`),
          {
            url: page
          }
        );
      }
      throw failure("unavailable", `${name} blocked the request.`);
    }
    if (response.status < 200 || response.status >= 300) {
      throw failure("unavailable", `${name} returned HTTP ${response.status}.`);
    }
  }
  function withUserAgent(headers) {
    const out = __spreadValues({}, headers != null ? headers : {});
    if (!Object.keys(out).some((key) => key.toLowerCase() === "user-agent")) {
      out["User-Agent"] = CHROME_DESKTOP;
    }
    return out;
  }
  function httpClient(api, name) {
    const send = (raw, options) => __async(null, null, function* () {
      const input = typeof raw === "string" ? { url: raw } : raw;
      let response;
      try {
        response = yield api.http(__spreadProps(__spreadValues({}, input), { headers: withUserAgent(input.headers) }));
      } catch (e) {
        throw failure("unavailable", `${name} is unavailable.`);
      }
      if ((options == null ? void 0 : options.missing) && response.status === 404) {
        throw failure("missing", options.missing);
      }
      if (input.redirect === "manual" && response.status >= 300 && response.status < 400) {
        return response;
      }
      checkResponse(name, response, input.url);
      return response;
    });
    const withMode = (raw, mode) => __spreadProps(__spreadValues({}, typeof raw === "string" ? { url: raw } : raw), {
      mode
    });
    return {
      send,
      text(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          return (_a2 = response.body) != null ? _a2 : "";
        });
      },
      json(input, options) {
        return __async(this, null, function* () {
          var _a2;
          const response = yield send(withMode(input, "text"), options);
          try {
            return JSON.parse((_a2 = response.body) != null ? _a2 : "");
          } catch (e) {
            throw failure("unavailable", `${name} returned invalid JSON.`);
          }
        });
      },
      base64(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "base64"), options);
          if (!response.bodyBase64) {
            throw failure("unavailable", `${name} returned an empty file.`);
          }
          return response.bodyBase64;
        });
      },
      handle(input, options) {
        return __async(this, null, function* () {
          const response = yield send(withMode(input, "handle"), options);
          if (!response.handle) {
            throw failure("unavailable", `${name} returned no file.`);
          }
          return response.handle;
        });
      }
    };
  }

  // ../../../packages/plugin-std/src/magnet.ts
  var BASE32_ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567";
  function decodeBase32(input) {
    const cleaned = input.trim().toUpperCase().replace(/=+$/, "");
    if (!cleaned || !/^[A-Z2-7]+$/.test(cleaned)) {
      throw new TypeError("Invalid base32 string");
    }
    const bytes = [];
    let buffer = 0;
    let bitsLeft = 0;
    for (let i = 0; i < cleaned.length; i++) {
      const val = BASE32_ALPHABET.indexOf(cleaned[i]);
      buffer = buffer << 5 | val;
      bitsLeft += 5;
      if (bitsLeft >= 8) {
        bitsLeft -= 8;
        bytes.push(buffer >>> bitsLeft & 255);
      }
    }
    return new Uint8Array(bytes);
  }
  function bytesToHex(bytes) {
    let out = "";
    for (let i = 0; i < bytes.length; i++) {
      out += bytes[i].toString(16).padStart(2, "0");
    }
    return out;
  }
  function normalizeInfoHash(raw) {
    const trimmed = raw.trim();
    if (/^[0-9a-fA-F]{40}$/.test(trimmed)) {
      return trimmed.toLowerCase();
    }
    if (/^[A-Za-z2-7]{32}=*$/.test(trimmed)) {
      const decoded = decodeBase32(trimmed);
      if (decoded.length === 20) {
        return bytesToHex(decoded);
      }
    }
    throw new TypeError(`Invalid infoHash: ${raw}`);
  }
  function parseMagnet(uri) {
    var _a;
    const trimmed = uri.trim();
    if (!/^magnet:\?/i.test(trimmed)) {
      throw new TypeError("Invalid magnet URI");
    }
    const query = trimmed.slice(trimmed.indexOf("?") + 1);
    const params = new URLSearchParams(query);
    let infoHash = "";
    for (const xt of params.getAll("xt")) {
      const match = xt.match(/^urn:btih:([0-9a-fA-F]{40}|[A-Za-z2-7]{32}=*)$/i);
      if (match) {
        infoHash = normalizeInfoHash(match[1]);
        break;
      }
    }
    if (!infoHash) {
      throw new TypeError("Magnet URI missing valid btih infoHash");
    }
    const name = (_a = params.get("dn")) != null ? _a : "";
    const seen = /* @__PURE__ */ new Set();
    const trackers = [];
    for (const tr of params.getAll("tr")) {
      const t = tr.trim();
      if (t && !seen.has(t)) {
        seen.add(t);
        trackers.push(t);
      }
    }
    const xlRaw = params.get("xl");
    let size = 0;
    if (xlRaw && /^\d+$/.test(xlRaw.trim())) {
      size = Number.parseInt(xlRaw.trim(), 10);
    }
    return { infoHash, name, trackers, size };
  }
  function buildMagnet(options) {
    const infoHash = normalizeInfoHash(options.infoHash);
    const parts = [`magnet:?xt=urn:btih:${infoHash}`];
    if (options.name) {
      parts.push(`dn=${encodeURIComponent(options.name)}`);
    }
    if (options.trackers) {
      const seen = /* @__PURE__ */ new Set();
      for (const tr of options.trackers) {
        const trimmed = tr.trim();
        if (trimmed && !seen.has(trimmed)) {
          seen.add(trimmed);
          parts.push(`tr=${encodeURIComponent(trimmed)}`);
        }
      }
    }
    return parts.join("&");
  }

  // ../../../packages/plugin-std/src/titles.ts
  var CHAPTER_NUMBER = String.raw`0*(\d+(?:[.,]\d+|-\d(?!\d))?)`;
  var CHAPTER_PATTERNS = [
    new RegExp(
      String.raw`(?:^|\b)(?:chapter|chap|ch|cap[ií]tulo|capitulo|cap)\.?[-\s._]*${CHAPTER_NUMBER}`,
      "i"
    ),
    new RegExp(String.raw`\bc${CHAPTER_NUMBER}\b`, "i"),
    new RegExp(String.raw`第\s*${CHAPTER_NUMBER}\s*[話章话]`),
    new RegExp(String.raw`(?:^|\s)#${CHAPTER_NUMBER}\b`),
    new RegExp(String.raw`^\s*${CHAPTER_NUMBER}\s*$`)
  ];

  // ../torrent-common/src/option.ts
  var DEFAULT_TRACKERS = [
    "http://nyaa.tracker.wf:7777/announce",
    "udp://open.stealth.si:80/announce",
    "udp://tracker.opentrackr.org:1337/announce",
    "udp://exodus.desync.com:6969/announce",
    "udp://tracker.torrent.eu.org:451/announce"
  ];
  var MAX_RETRIEVAL_URI_LENGTH = 2e3;
  function numberValue(value) {
    return { kind: "number", number: value };
  }
  function makeFact(producerId, id, field, value, at = (/* @__PURE__ */ new Date()).toISOString()) {
    return {
      id,
      producerId,
      field,
      value: numberValue(value),
      locale: "",
      region: "",
      status: "complete",
      at
    };
  }
  function buildCountsFacts(producerId, key, counts) {
    const at = (/* @__PURE__ */ new Date()).toISOString();
    const facts = [];
    if (counts.size !== void 0 && Number.isFinite(counts.size) && counts.size > 0) {
      facts.push(makeFact(producerId, `size-${key}`, "size", counts.size, at));
    }
    if (counts.seeders !== void 0 && Number.isFinite(counts.seeders) && counts.seeders >= 0) {
      facts.push(makeFact(producerId, `seeders-${key}`, "seeders", counts.seeders, at));
    }
    if (counts.leechers !== void 0 && Number.isFinite(counts.leechers) && counts.leechers >= 0) {
      facts.push(makeFact(producerId, `leechers-${key}`, "leechers", counts.leechers, at));
    }
    if (counts.downloads !== void 0 && Number.isFinite(counts.downloads) && counts.downloads > 0) {
      facts.push(makeFact(producerId, `downloads-${key}`, "downloads", counts.downloads, at));
    }
    return facts;
  }
  function parseIsoDate(caye2, raw, layouts) {
    var _a;
    const trimmed = raw == null ? void 0 : raw.trim();
    if (!trimmed) return void 0;
    if (typeof ((_a = caye2.time) == null ? void 0 : _a.parse) === "function") {
      try {
        const ms = caye2.time.parse(trimmed, layouts ? { layouts } : void 0);
        if (Number.isFinite(ms)) {
          return new Date(ms).toISOString();
        }
      } catch (e) {
      }
    }
    const parsed = Date.parse(trimmed);
    if (Number.isFinite(parsed)) {
      return new Date(parsed).toISOString();
    }
    return void 0;
  }
  function pickUri(magnet, torrentUrl) {
    if (magnet && Array.from(magnet).length <= MAX_RETRIEVAL_URI_LENGTH) {
      return magnet;
    }
    return torrentUrl || magnet || "";
  }
  function createTorrentOption(caye2, input) {
    var _a, _b, _c, _d;
    const uri = pickUri(input.magnet, input.torrentUrl);
    const facts = buildCountsFacts(input.providerId, input.key, {
      size: input.size,
      seeders: input.seeders,
      leechers: input.leechers,
      downloads: input.downloads
    });
    let resolution = ((_a = input.resolution) == null ? void 0 : _a.trim()) || "";
    let group = ((_b = input.group) == null ? void 0 : _b.trim()) || "";
    if ((!resolution || !group) && typeof ((_c = caye2.release) == null ? void 0 : _c.parse) === "function") {
      try {
        const parsed = caye2.release.parse(input.name);
        if (!resolution && parsed.resolution) resolution = parsed.resolution;
        if (!group && parsed.group) group = parsed.group;
      } catch (e) {
      }
    }
    const option = {
      id: input.id,
      name: input.name,
      kind: "torrent",
      uri,
      files: [],
      facts,
      availability: "available",
      eligible: true,
      reasons: [],
      confirmed: Boolean(input.confirmed)
    };
    if (input.seeders !== void 0 && Number.isFinite(input.seeders) && input.seeders >= 0) {
      option.seeders = Math.trunc(input.seeders);
    }
    if (input.size !== void 0 && Number.isFinite(input.size) && input.size > 0) {
      option.size = Math.round(input.size);
    }
    if (input.publishedAt) option.publishedAt = input.publishedAt;
    if (input.pageUrl && /^https?:\/\//i.test(input.pageUrl)) {
      option.pageUrl = input.pageUrl;
    }
    if ((_d = input.magnet) == null ? void 0 : _d.startsWith("magnet:")) {
      option.magnet = input.magnet;
    }
    if (resolution) option.resolution = resolution;
    if (group) option.group = group;
    if (input.best) option.best = true;
    return option;
  }
  var missingMessage = (service) => `${service} no longer lists this torrent.`;
  function fetchText(caye2, service, url, options) {
    return __async(this, null, function* () {
      var _b, _c;
      const _a = options != null ? options : {}, { missingOn404 } = _a, input = __objRest(_a, ["missingOn404"]);
      const response = yield httpClient(caye2, service).send(
        __spreadProps(__spreadValues({}, input), { url }),
        missingOn404 ? { missing: missingMessage(service) } : void 0
      );
      return {
        status: response.status,
        headers: (_b = response.headers) != null ? _b : {},
        body: (_c = response.body) != null ? _c : "",
        url: response.url
      };
    });
  }
  function fetchJson(caye2, service, url, options) {
    return __async(this, null, function* () {
      const res = yield fetchText(caye2, service, url, options);
      if (!res.body) {
        throw failure("unavailable", `${service} returned an empty response.`);
      }
      try {
        return JSON.parse(res.body);
      } catch (e) {
        throw failure("unavailable", `${service} returned malformed JSON.`);
      }
    });
  }

  // ../../../packages/plugin-std/src/cache.ts
  function getCachedJson(api, key) {
    return __async(this, null, function* () {
      try {
        const value = yield api.cache.get({ key });
        if ((value == null ? void 0 : value.kind) === "text") return JSON.parse(value.text);
      } catch (e) {
      }
      return void 0;
    });
  }
  function setCachedJson(api, key, value, ttlSeconds) {
    return __async(this, null, function* () {
      try {
        yield api.cache.set({
          key,
          value: { kind: "text", text: JSON.stringify(value) },
          ttlSeconds
        });
      } catch (e) {
      }
    });
  }

  // ../torrent-common/src/smart.ts
  var OPTION_CACHE_TTL_SECONDS = 7 * 24 * 60 * 60;
  function parseResolutionNumber(raw) {
    if (!raw) return 0;
    const lower = raw.trim().toLowerCase();
    if (lower === "4k" || lower === "uhd") return 2160;
    if (lower === "8k") return 4320;
    const match = /(\d{3,4})/.exec(lower);
    return match ? Number.parseInt(match[1], 10) : 0;
  }
  function normalizeResolutionLabel(raw) {
    const n = parseResolutionNumber(raw);
    if (n >= 360 && n <= 4320) return `${n}p`;
    return "";
  }
  function clampLimit(limit, fallback = 50, max = 100) {
    return Math.min(Math.max(limit || fallback, 1), max);
  }
  function cacheOptions(_0, _1, _2) {
    return __async(this, arguments, function* (caye2, prefix, options, ttlSeconds = OPTION_CACHE_TTL_SECONDS) {
      for (const option of options) {
        yield setCachedJson(caye2, `${prefix}:option:${option.id}`, option, ttlSeconds);
      }
    });
  }
  function validateHttpUrl(raw) {
    const trimmed = (raw == null ? void 0 : raw.trim()) || "";
    if (!trimmed) return void 0;
    try {
      const parsed = new URL(trimmed);
      if (parsed.protocol === "http:" || parsed.protocol === "https:") {
        return parsed.toString();
      }
    } catch (e) {
    }
    return void 0;
  }
  function resolveFromRetrievalInput(caye2, providerId, prefix, input, notFoundMessage, defaultGroup) {
    var _a, _b, _c, _d;
    const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
    const rawMagnet = ((_b = input.magnet) == null ? void 0 : _b.trim()) || "";
    const rawInfoHash = ((_c = input.infoHash) == null ? void 0 : _c.trim()) || "";
    const rawTorrentUrl = ((_d = input.torrentUrl) == null ? void 0 : _d.trim()) || "";
    const hasRetrieval = Boolean(rawMagnet || rawInfoHash || rawTorrentUrl);
    if (!hasRetrieval) return void 0;
    if (optionId && !optionId.startsWith(`${prefix}-`)) {
      throw failure("missing", notFoundMessage);
    }
    const validTorrentUrl = rawTorrentUrl ? validateHttpUrl(rawTorrentUrl) : void 0;
    if (rawTorrentUrl && !validTorrentUrl) {
      throw failure("missing", "Invalid torrent retrieval URL.");
    }
    if (rawMagnet) {
      let parsed;
      try {
        parsed = parseMagnet(rawMagnet);
      } catch (e) {
        throw failure("missing", "Invalid magnet retrieval URI.");
      }
      const id = optionId || `${prefix}-${parsed.infoHash}`;
      return createTorrentOption(caye2, {
        id,
        key: parsed.infoHash,
        providerId,
        name: parsed.name || `${prefix} ${parsed.infoHash}`,
        magnet: rawMagnet,
        torrentUrl: validTorrentUrl,
        size: parsed.size > 0 ? parsed.size : void 0,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (rawInfoHash) {
      let infoHash = "";
      try {
        infoHash = normalizeInfoHash(rawInfoHash);
      } catch (e) {
        throw failure("missing", "Invalid torrent info hash.");
      }
      const id = optionId || `${prefix}-${infoHash}`;
      const magnet = buildMagnet({ infoHash, trackers: DEFAULT_TRACKERS });
      return createTorrentOption(caye2, {
        id,
        key: infoHash,
        providerId,
        name: `${prefix} ${infoHash}`,
        magnet,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    if (validTorrentUrl) {
      const id = optionId || `${prefix}-torrent`;
      const key = id.startsWith(`${prefix}-`) ? id.slice(prefix.length + 1) : id;
      return createTorrentOption(caye2, {
        id,
        key,
        providerId,
        name: `${prefix} ${key}`,
        torrentUrl: validTorrentUrl,
        group: defaultGroup,
        confirmed: false
      });
    }
    return void 0;
  }
  function resolveCachedOrFallback(caye2, prefix, input, notFoundMessage, fetchFallback, options) {
    return __async(this, null, function* () {
      var _a;
      const optionId = ((_a = input.optionId) == null ? void 0 : _a.trim()) || "";
      if (!optionId && !input.magnet && !input.torrentUrl && !input.infoHash) {
        throw failure("missing", notFoundMessage);
      }
      if (optionId && !optionId.startsWith(`${prefix}-`)) {
        throw failure("missing", notFoundMessage);
      }
      if (optionId) {
        const cached = yield getCachedJson(caye2, `${prefix}:option:${optionId}`);
        if (cached && cached.id === optionId) {
          return cached;
        }
      }
      if (fetchFallback && optionId) {
        try {
          return yield fetchFallback(optionId);
        } catch (err) {
          const code = err == null ? void 0 : err.code;
          if (code !== "missing" && code !== "unavailable" && code !== "rate-limited") throw err;
          const fallback2 = resolveFromRetrievalInput(
            caye2,
            (options == null ? void 0 : options.providerId) || `backreef.${prefix}:search`,
            prefix,
            input,
            notFoundMessage,
            options == null ? void 0 : options.group
          );
          if (fallback2) return fallback2;
          throw err;
        }
      }
      const fallback = resolveFromRetrievalInput(
        caye2,
        (options == null ? void 0 : options.providerId) || `backreef.${prefix}:search`,
        prefix,
        input,
        notFoundMessage,
        options == null ? void 0 : options.group
      );
      if (fallback) return fallback;
      throw failure("missing", notFoundMessage);
    });
  }

  // ../torrent-common/src/media.ts
  function asRecord(value) {
    if (!value || typeof value !== "object" || Array.isArray(value)) return void 0;
    return value;
  }
  function positiveIntString(value) {
    if (typeof value === "number") {
      return Number.isInteger(value) && value > 0 ? String(value) : void 0;
    }
    if (typeof value === "string") {
      const trimmed = value.trim();
      return /^[1-9][0-9]*$/.test(trimmed) ? trimmed : void 0;
    }
    return void 0;
  }
  function addUniqueTitle(target, raw) {
    if (typeof raw !== "string") return;
    const trimmed = raw.trim();
    if (trimmed && !target.includes(trimmed)) {
      target.push(trimmed);
    }
  }
  function extractEntriesIds(entriesValue, preferredNative) {
    if (!Array.isArray(entriesValue)) return {};
    let anilistId;
    let anidbId;
    let malId;
    let bgmId;
    const inspect = (requireMatch) => {
      var _a, _b, _c, _d, _e, _f, _g, _h, _i;
      for (const rawEntry of entriesValue) {
        const entry = asRecord(rawEntry);
        if (!entry) continue;
        const ref = asRecord(entry.ref);
        if (requireMatch && preferredNative) {
          if ((ref == null ? void 0 : ref.providerId) !== preferredNative.entry.providerId || (ref == null ? void 0 : ref.nativeId) !== preferredNative.entry.nativeId) {
            continue;
          }
        }
        const ids = asRecord(entry.ids);
        if (ids) {
          anilistId != null ? anilistId : anilistId = positiveIntString((_b = (_a = ids.anilistid) != null ? _a : ids.anilistId) != null ? _b : ids.anilist);
          anidbId != null ? anidbId : anidbId = positiveIntString((_d = (_c = ids.anidbid) != null ? _c : ids.anidbId) != null ? _d : ids.anidb);
          malId != null ? malId : malId = positiveIntString((_f = (_e = ids.malid) != null ? _e : ids.malId) != null ? _f : ids.mal);
          bgmId != null ? bgmId : bgmId = positiveIntString((_i = (_h = (_g = ids.bgmid) != null ? _g : ids.bgmId) != null ? _h : ids.bgm) != null ? _i : ids.bangumi);
        }
        if ((ref == null ? void 0 : ref.providerId) === "caye.anilist:catalog" || (ref == null ? void 0 : ref.providerId) === "anilist" || typeof (ref == null ? void 0 : ref.providerId) === "string" && ref.providerId.includes("anilist")) {
          anilistId != null ? anilistId : anilistId = positiveIntString(ref.nativeId);
        }
      }
    };
    if (preferredNative) inspect(true);
    inspect(false);
    return { anilistId, anidbId, malId, bgmId };
  }
  function extractFieldMap(fieldsValue) {
    const out = {};
    if (!Array.isArray(fieldsValue)) return out;
    for (const rawField of fieldsValue) {
      const entry = asRecord(rawField);
      if (!entry || typeof entry.field !== "string") continue;
      const val = asRecord(entry.value);
      if (val) out[entry.field] = val;
    }
    return out;
  }
  function parseDateParts(raw) {
    if (typeof raw !== "string") return void 0;
    const m = /^(\d{4})(?:-(\d{2})(?:-(\d{2}))?)?/.exec(raw.trim());
    if (!m) return void 0;
    const year = Number.parseInt(m[1], 10);
    if (year < 1900 || year > 2100) return void 0;
    return {
      year,
      month: m[2] ? Number.parseInt(m[2], 10) : void 0,
      day: m[3] ? Number.parseInt(m[3], 10) : void 0
    };
  }
  function safeGetItem(caye2, itemId) {
    return __async(this, null, function* () {
      if (!itemId || typeof caye2.request !== "function") return void 0;
      try {
        const raw = yield caye2.request("getItem", { path: { itemId } });
        return asRecord(raw);
      } catch (e) {
        return void 0;
      }
    });
  }
  function pickPreferredNative(query) {
    var _a;
    const refs = (_a = query.native) != null ? _a : [];
    if (refs.length === 0) return void 0;
    const exact = refs.find((r) => r.itemId === query.itemId);
    if (exact) return exact;
    return refs[0];
  }
  function resolveMediaContext(caye2, query) {
    return __async(this, null, function* () {
      var _a, _b;
      const titles = [];
      let romajiTitle = "";
      let englishTitle = "";
      let originalTitle = "";
      const synonyms = [];
      let anilistId;
      let anidbId;
      let malId;
      let bgmId;
      let isMovie = false;
      let isAnime = false;
      let adult = false;
      let year;
      let startDate;
      let episodeCount;
      let releaseStatus;
      const preferredNative = pickPreferredNative(query);
      const item = yield safeGetItem(caye2, query.itemId || (preferredNative == null ? void 0 : preferredNative.itemId));
      const parentId = typeof (item == null ? void 0 : item.parentId) === "string" ? item.parentId : void 0;
      const parentItem = parentId ? yield safeGetItem(caye2, parentId) : void 0;
      const consumeTitlesObj = (rawTitles) => {
        const t = asRecord(rawTitles);
        if (!t) return;
        if (!romajiTitle && typeof t.romaji === "string") romajiTitle = t.romaji.trim();
        if (!englishTitle && typeof t.english === "string") englishTitle = t.english.trim();
        if (!originalTitle && typeof t.original === "string") originalTitle = t.original.trim();
        addUniqueTitle(titles, t.romaji);
        addUniqueTitle(titles, t.english);
        addUniqueTitle(titles, t.original);
      };
      const inspectRecord = (record) => {
        var _a2, _b2, _c, _d, _e, _f, _g, _h, _i, _j, _k;
        if (!record) return;
        if (record.adult === true) adult = true;
        const kindId = typeof record.kindId === "string" ? record.kindId : "";
        const kindLeaf = (kindId.includes(":") ? kindId.split(":")[1] : kindId).toLowerCase();
        if (kindLeaf === "movie") isMovie = true;
        if (kindLeaf === "anime" || kindId.toLowerCase().includes(":anime")) isAnime = true;
        const ids = extractEntriesIds(record.entries, preferredNative);
        anilistId != null ? anilistId : anilistId = ids.anilistId;
        anidbId != null ? anidbId : anidbId = ids.anidbId;
        malId != null ? malId : malId = ids.malId;
        bgmId != null ? bgmId : bgmId = ids.bgmId;
        if (anilistId || anidbId) isAnime = true;
        const parentSummary = asRecord(record.parent);
        if (parentSummary) {
          consumeTitlesObj(parentSummary.titles);
          addUniqueTitle(titles, parentSummary.name);
        }
        consumeTitlesObj(record.titles);
        addUniqueTitle(titles, record.name);
        const totalChildren = typeof record.totalChildren === "number" ? record.totalChildren : typeof record.childCount === "number" ? record.childCount : void 0;
        if (totalChildren !== void 0 && totalChildren > 0 && episodeCount === void 0) {
          episodeCount = totalChildren;
        }
        const fields = extractFieldMap(record.fields);
        if (((_a2 = fields["caye:adult"]) == null ? void 0 : _a2.boolean) === true) adult = true;
        const formatVal = typeof ((_b2 = fields["caye:format"]) == null ? void 0 : _b2.text) === "string" ? fields["caye:format"].text.trim() : "";
        if (/^movie$/i.test(formatVal)) isMovie = true;
        if (/^(?:tv|tv_short|ova|ona|special|anime)$/i.test(formatVal) && isAnime) isMovie = false;
        const romajiField = typeof ((_c = fields["caye:romaji"]) == null ? void 0 : _c.text) === "string" ? fields["caye:romaji"].text.trim() : "";
        const englishField = typeof ((_d = fields["caye:english"]) == null ? void 0 : _d.text) === "string" ? fields["caye:english"].text.trim() : "";
        const originalField = typeof ((_e = fields["caye:original"]) == null ? void 0 : _e.text) === "string" ? fields["caye:original"].text.trim() : "";
        if (!romajiTitle && romajiField) romajiTitle = romajiField;
        if (!englishTitle && englishField) englishTitle = englishField;
        if (!originalTitle && originalField) originalTitle = originalField;
        addUniqueTitle(titles, romajiField);
        addUniqueTitle(titles, englishField);
        addUniqueTitle(titles, originalField);
        if (!releaseStatus) {
          const statusVal = (_h = (_f = fields["caye:status"]) == null ? void 0 : _f.text) != null ? _h : (_g = fields["caye:releaseStatus"]) == null ? void 0 : _g.text;
          if (typeof statusVal === "string" && statusVal.trim()) releaseStatus = statusVal.trim();
        }
        if (!startDate) {
          const releaseAt = (_i = fields["caye:releaseAt"]) == null ? void 0 : _i.text;
          startDate = parseDateParts(releaseAt);
        }
        if (year === void 0) {
          const yNum = (_j = fields["caye:year"]) == null ? void 0 : _j.number;
          if (typeof yNum === "number" && yNum >= 1900 && yNum <= 2100) {
            year = Math.trunc(yNum);
          } else if (startDate) {
            year = startDate.year;
          }
        }
        for (const key of ["caye:titles", "caye:synonyms", "caye:alternativeTitles"]) {
          const list = (_k = fields[key]) == null ? void 0 : _k.list;
          if (Array.isArray(list)) {
            for (const v of list) {
              const obj = asRecord(v);
              if (typeof (obj == null ? void 0 : obj.text) === "string" && obj.text.trim()) {
                addUniqueTitle(synonyms, obj.text);
                addUniqueTitle(titles, obj.text);
              }
            }
          }
        }
      };
      inspectRecord(parentItem);
      inspectRecord(item);
      const text = ((_a = query.text) == null ? void 0 : _a.trim()) || "";
      if (text) {
        addUniqueTitle(titles, text);
      }
      if (!anilistId) {
        for (const ref of (_b = query.native) != null ? _b : []) {
          if (ref.entry.providerId === "caye.anilist:catalog" || ref.entry.providerId === "anilist" || ref.entry.providerId.includes("anilist")) {
            anilistId = positiveIntString(ref.entry.nativeId);
            if (anilistId) break;
          }
        }
      }
      const season = typeof query.season === "number" && query.season > 0 ? query.season : typeof (item == null ? void 0 : item.season) === "number" && item.season > 0 ? item.season : void 0;
      const number = typeof query.number === "number" && query.number > 0 ? query.number : typeof (item == null ? void 0 : item.number) === "number" && item.number > 0 ? item.number : void 0;
      const absolute = typeof query.absolute === "number" && query.absolute > 0 ? query.absolute : void 0;
      const absoluteSeasonOffset = absolute !== void 0 && number !== void 0 && absolute > number ? absolute - number : 0;
      return {
        text,
        titles,
        romajiTitle: romajiTitle || titles[0] || "",
        englishTitle: englishTitle || "",
        originalTitle,
        synonyms,
        anilistId,
        anidbId,
        malId,
        bgmId,
        season,
        number,
        absolute,
        isMovie,
        isAnime,
        adult,
        year,
        startDate: startDate != null ? startDate : year ? { year } : void 0,
        episodeCount,
        releaseStatus,
        absoluteSeasonOffset
      };
    });
  }

  // src/backend.ts
  var PROVIDER_ID = "backreef.subsplease:search";
  var API_URL = "https://subsplease.org/api/";
  function parseEpisodeNumber(raw) {
    if (!raw) return -1;
    const trimmed = raw.trim();
    if (!/^\d+(?:\.\d+)?$/.test(trimmed)) return -1;
    const n = Number(trimmed);
    return Number.isFinite(n) && n >= 0 ? n : -1;
  }
  function formatEpisodeLabel(raw, epNum) {
    if (epNum >= 0 && Number.isInteger(epNum)) {
      return String(epNum).padStart(2, "0");
    }
    return (raw == null ? void 0 : raw.trim()) || "01";
  }
  function optionIdFor(show, episode, res, infoHash) {
    if (infoHash) return `subsplease-${infoHash}`;
    const slug = `${show}-${episode}-${res}`.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    return `subsplease-${slug || "item"}`;
  }
  function releaseToOptions(release, targets) {
    var _a, _b, _c, _d;
    const rawEpisode = ((_a = release.episode) == null ? void 0 : _a.trim()) || "";
    if (!rawEpisode || rawEpisode.toLowerCase() === "batch") return [];
    const epNum = parseEpisodeNumber(rawEpisode);
    const show = ((_b = release.show) == null ? void 0 : _b.trim()) || "";
    if (!show || !Array.isArray(release.downloads)) return [];
    const publishedAt = parseIsoDate(caye, release.release_date);
    const pageSlug = (_c = release.page) == null ? void 0 : _c.trim().replace(/^\/+|\/+$/g, "");
    const pageUrl = pageSlug ? `https://subsplease.org/shows/${pageSlug}/` : void 0;
    const confirmed = targets.length > 0 && epNum >= 0 && targets.includes(epNum);
    const out = [];
    for (const dl of release.downloads) {
      const magnet = ((_d = dl.magnet) == null ? void 0 : _d.trim()) || "";
      if (!magnet.startsWith("magnet:")) continue;
      let infoHash = "";
      let size = 0;
      try {
        const parsed = parseMagnet(magnet);
        infoHash = parsed.infoHash;
        size = parsed.size;
      } catch (e) {
        continue;
      }
      const resLabel = normalizeResolutionLabel(dl.res) || (dl.res ? `${dl.res}p` : "");
      const epLabel = formatEpisodeLabel(rawEpisode, epNum);
      const name = `[SubsPlease] ${show} - ${epLabel}${resLabel ? ` (${resLabel})` : ""} [${infoHash.slice(0, 8).toUpperCase()}].mkv`;
      out.push(
        createTorrentOption(caye, {
          id: optionIdFor(show, epLabel, resLabel, infoHash),
          key: infoHash || `${show}-${epLabel}-${resLabel}`,
          providerId: PROVIDER_ID,
          name,
          magnet,
          pageUrl,
          size: size > 0 ? size : void 0,
          publishedAt,
          resolution: resLabel,
          group: "SubsPlease",
          confirmed
        })
      );
    }
    return out;
  }
  function find(_context, query) {
    return __async(this, null, function* () {
      var _a;
      if (query.batch) {
        return { items: [], state: "complete" };
      }
      const media = yield resolveMediaContext(caye, query);
      const searchTitle = ((_a = query.text) == null ? void 0 : _a.trim()) || media.romajiTitle || media.englishTitle || "";
      if (!searchTitle) {
        throw failure("unsupported", "Enter a title to search.");
      }
      const url = `${API_URL}?f=search&tz=UTC&s=${encodeURIComponent(searchTitle)}`;
      const data = yield fetchJson(
        caye,
        "SubsPlease",
        url,
        {
          headers: { Accept: "application/json" }
        }
      );
      const targets = [query.number, query.absolute].filter(
        (n) => typeof n === "number" && Number.isFinite(n) && n > 0
      );
      const wantedRes = parseResolutionNumber(query.resolution);
      const releases = Array.isArray(data) ? data : data && typeof data === "object" ? Object.values(data) : [];
      const seen = /* @__PURE__ */ new Set();
      const items = [];
      const limit = clampLimit(query.limit, 50, 100);
      for (const release of releases) {
        if (!release || typeof release !== "object") continue;
        const epNum = parseEpisodeNumber(release.episode);
        if (targets.length > 0 && (epNum < 0 || !targets.includes(epNum))) {
          continue;
        }
        for (const opt of releaseToOptions(release, targets)) {
          if (wantedRes > 0 && parseResolutionNumber(opt.resolution) !== wantedRes) {
            continue;
          }
          if (seen.has(opt.id)) continue;
          seen.add(opt.id);
          items.push(opt);
          if (items.length >= limit) break;
        }
        if (items.length >= limit) break;
      }
      yield cacheOptions(caye, "subsplease", items);
      return { items, state: "complete" };
    });
  }
  function resolve(_context, input) {
    return __async(this, null, function* () {
      return yield resolveCachedOrFallback(
        caye,
        "subsplease",
        input,
        "Unknown or uncached SubsPlease option.",
        void 0,
        { providerId: PROVIDER_ID, group: "SubsPlease" }
      );
    });
  }
  caye.register(PROVIDER_ID, { acquisition: { find, resolve } });
})();
//# sourceMappingURL=backend.js.map
